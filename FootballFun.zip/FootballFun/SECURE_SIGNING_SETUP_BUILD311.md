# Secure release signing — build 311

No keystore or signing password is stored in this source package.

Protected CI/GitHub secrets required for a signed release:
- FOOTBALL_FUN_KEYSTORE_PATH
- FOOTBALL_FUN_KEYSTORE_PASSWORD
- FOOTBALL_FUN_KEY_ALIAS
- FOOTBALL_FUN_KEY_PASSWORD

The keystore should be reconstructed/mounted temporarily in CI and never committed
to the repository or stored inside FootballFun.zip.

Debug builds do not need the production/upload key.
Release APK/AAB tasks intentionally fail if secure signing is not configured.
