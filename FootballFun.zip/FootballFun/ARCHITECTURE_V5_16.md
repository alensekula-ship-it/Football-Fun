# Football Fun architecture foundation — v5.16

This release starts the migration from a single large Activity to a modular codebase without changing the approved user interface.

## Current module boundaries

- `core/AppConfig.java` — feature flags and refresh timing
- `model/Match.java` — shared match model
- `model/DetailEvent.java` — normalized match timeline item
- `model/TeamRow.java` — World Cup group-table model
- `domain/MatchStatus.java` — one source of truth for live, finished and upcoming states
- `data/LiveDataClient.java` — HTTP and fallback data-source boundary
- `data/UserPreferences.java` — durable user choices
- `data/CompetitionCatalog.java` — canonical competition metadata and API codes
- `data/WorldCupData.java` — World Cup schedule and prediction data store
- `MainActivity.java` — current UI composition and screen navigation

## Migration rule

No screen is visually redesigned during architecture releases. Existing behavior must remain stable while infrastructure is moved behind clear boundaries. Future screens will be extracted one at a time after their data contracts are stable.

## Next safe extraction

The Match Center should move into its own screen controller after v5.16 is confirmed on-device. It will use the shared `Match`, `MatchStatus`, `CompetitionCatalog` and `LiveDataClient` classes introduced here.
