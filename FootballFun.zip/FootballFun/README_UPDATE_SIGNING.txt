Football Fun stable update signing

applicationId: com.asappfactory.footballfun
versionCode: 3
versionName: 1.2
stable key: app/footballfun-update.jks

Do not delete, rename, or replace footballfun-update.jks.
Do not change applicationId.
Every future build must use a higher versionCode.

If the currently installed APK was signed with a different key, Android requires one final uninstall before installing this build. After installing this build, later APKs from this project can update over it without uninstalling.

This embedded key is for direct APK updates during development/testing. Use a separate secure upload key and Play App Signing for Google Play production releases.
