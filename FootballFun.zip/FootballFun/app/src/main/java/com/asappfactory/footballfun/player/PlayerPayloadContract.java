package com.asappfactory.footballfun.player;

/**
 * Vendor-neutral field contract for player and squad payloads.
 *
 * Keeping these names stable means a future paid API only needs one adapter;
 * Club Center, Player Center, Favorites and Search do not need redesigning.
 */
public final class PlayerPayloadContract {
    public static final int SCHEMA_VERSION = 1;

    public static final String PLAYERS = "players";
    public static final String SQUAD = "squad";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String CLUB = "club";
    public static final String POSITION = "position";
    public static final String SHIRT_NUMBER = "shirtNumber";
    public static final String NATIONALITY = "nationality";
    public static final String DATE_OF_BIRTH = "dateOfBirth";
    public static final String PHOTO_URL = "photoUrl";
    public static final String HEIGHT = "height";
    public static final String WEIGHT = "weight";
    public static final String APPEARANCES = "appearances";
    public static final String MINUTES = "minutes";
    public static final String GOALS = "goals";
    public static final String ASSISTS = "assists";
    public static final String YELLOW_CARDS = "yellowCards";
    public static final String RED_CARDS = "redCards";
    public static final String RATING = "rating";
    public static final String RECENT_FORM = "recentForm";
    public static final String CLUB_HISTORY = "clubHistory";

    private PlayerPayloadContract() {}
}
