package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Official Ligue 1 2026/27 fixture and club-identity fallback. */
public final class Ligue12627Data {
    private static final String COMPETITION_NAME = "Ligue 1";
    private static final String COMPETITION_CODE = "FL1";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-22";
    private static final String LAST_DATE = "2027-05-29";

    private static final String DATA =
            "2026-08-22|1|Angers|Lille|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-08-22|1|Le Havre|Monaco|Stade Océane|SCHEDULED\n" +
            "2026-08-22|1|Le Mans|Brest|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-08-22|1|Lens|Auxerre|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-08-22|1|Marseille|Strasbourg|Orange Vélodrome|SCHEDULED\n" +
            "2026-08-22|1|Nice|Lorient|Allianz Riviera|SCHEDULED\n" +
            "2026-08-22|1|Paris Saint-Germain|Rennes|Parc des Princes|SCHEDULED\n" +
            "2026-08-22|1|Toulouse|Lyon|Stadium de Toulouse|SCHEDULED\n" +
            "2026-08-22|1|Troyes|Paris FC|Stade de l'Aube|SCHEDULED\n" +
            "2026-08-29|2|Auxerre|Angers|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-08-29|2|Brest|Toulouse|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-08-30 20:45|2|Lille|Paris Saint-Germain|Decathlon Arena - Stade Pierre-Mauroy|TIMED\n" +
            "2026-08-29|2|Lorient|Troyes|Stade du Moustoir|SCHEDULED\n" +
            "2026-08-29|2|Lyon|Le Havre|Groupama Stadium|SCHEDULED\n" +
            "2026-08-29|2|Monaco|Marseille|Stade Louis II|SCHEDULED\n" +
            "2026-08-29|2|Paris FC|Nice|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-08-29|2|Rennes|Le Mans|Roazhon Park|SCHEDULED\n" +
            "2026-08-29|2|Strasbourg|Lens|Stade de la Meinau|SCHEDULED\n" +
            "2026-09-05|3|Angers|Rennes|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-09-05|3|Le Havre|Brest|Stade Océane|SCHEDULED\n" +
            "2026-09-05|3|Lens|Lorient|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-09-05|3|Lyon|Auxerre|Groupama Stadium|SCHEDULED\n" +
            "2026-09-05|3|Marseille|Paris FC|Orange Vélodrome|SCHEDULED\n" +
            "2026-09-05|3|Nice|Le Mans|Allianz Riviera|SCHEDULED\n" +
            "2026-09-05|3|Paris Saint-Germain|Monaco|Parc des Princes|SCHEDULED\n" +
            "2026-09-05|3|Toulouse|Lille|Stadium de Toulouse|SCHEDULED\n" +
            "2026-09-05|3|Troyes|Strasbourg|Stade de l'Aube|SCHEDULED\n" +
            "2026-09-12|4|Auxerre|Nice|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-09-12|4|Brest|Paris Saint-Germain|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-09-12|4|Le Havre|Angers|Stade Océane|SCHEDULED\n" +
            "2026-09-12|4|Le Mans|Lens|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-09-12|4|Lille|Troyes|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-09-12|4|Lorient|Toulouse|Stade du Moustoir|SCHEDULED\n" +
            "2026-09-12|4|Paris FC|Lyon|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-09-12|4|Rennes|Marseille|Roazhon Park|SCHEDULED\n" +
            "2026-09-12|4|Strasbourg|Monaco|Stade de la Meinau|SCHEDULED\n" +
            "2026-09-19|5|Angers|Troyes|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-09-19|5|Auxerre|Brest|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-09-19|5|Le Mans|Lorient|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-09-19|5|Lyon|Rennes|Groupama Stadium|SCHEDULED\n" +
            "2026-09-20 20:45|5|Marseille|Paris Saint-Germain|Orange Vélodrome|TIMED\n" +
            "2026-09-19|5|Monaco|Lens|Stade Louis II|SCHEDULED\n" +
            "2026-09-19|5|Nice|Lille|Allianz Riviera|SCHEDULED\n" +
            "2026-09-19|5|Paris FC|Strasbourg|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-09-19|5|Toulouse|Le Havre|Stadium de Toulouse|SCHEDULED\n" +
            "2026-10-10|6|Brest|Angers|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-10-10|6|Lens|Lyon|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-10-10|6|Lille|Le Havre|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-10-10|6|Lorient|Paris FC|Stade du Moustoir|SCHEDULED\n" +
            "2026-10-10|6|Monaco|Toulouse|Stade Louis II|SCHEDULED\n" +
            "2026-10-10|6|Nice|Strasbourg|Allianz Riviera|SCHEDULED\n" +
            "2026-10-10|6|Paris Saint-Germain|Le Mans|Parc des Princes|SCHEDULED\n" +
            "2026-10-10|6|Rennes|Auxerre|Roazhon Park|SCHEDULED\n" +
            "2026-10-10|6|Troyes|Marseille|Stade de l'Aube|SCHEDULED\n" +
            "2026-10-17|7|Angers|Marseille|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-10-17|7|Le Havre|Auxerre|Stade Océane|SCHEDULED\n" +
            "2026-10-17|7|Le Mans|Toulouse|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-10-17|7|Lille|Brest|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-10-17|7|Lorient|Monaco|Stade du Moustoir|SCHEDULED\n" +
            "2026-10-17|7|Lyon|Nice|Groupama Stadium|SCHEDULED\n" +
            "2026-10-17|7|Paris FC|Rennes|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-10-17|7|Strasbourg|Paris Saint-Germain|Stade de la Meinau|SCHEDULED\n" +
            "2026-10-17|7|Troyes|Lens|Stade de l'Aube|SCHEDULED\n" +
            "2026-10-24|8|Angers|Lorient|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-10-24|8|Auxerre|Le Mans|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-10-24|8|Brest|Nice|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-10-24|8|Lens|Paris FC|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-10-24|8|Marseille|Le Havre|Orange Vélodrome|SCHEDULED\n" +
            "2026-10-24|8|Monaco|Lille|Stade Louis II|SCHEDULED\n" +
            "2026-10-25 20:45|8|Paris Saint-Germain|Lyon|Parc des Princes|TIMED\n" +
            "2026-10-24|8|Rennes|Strasbourg|Roazhon Park|SCHEDULED\n" +
            "2026-10-24|8|Toulouse|Troyes|Stadium de Toulouse|SCHEDULED\n" +
            "2026-10-31|9|Le Havre|Paris Saint-Germain|Stade Océane|SCHEDULED\n" +
            "2026-10-31|9|Lille|Lens|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-10-31|9|Lorient|Brest|Stade du Moustoir|SCHEDULED\n" +
            "2026-10-31|9|Lyon|Angers|Groupama Stadium|SCHEDULED\n" +
            "2026-10-31|9|Marseille|Toulouse|Orange Vélodrome|SCHEDULED\n" +
            "2026-10-31|9|Nice|Rennes|Allianz Riviera|SCHEDULED\n" +
            "2026-10-31|9|Paris FC|Monaco|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-10-31|9|Strasbourg|Auxerre|Stade de la Meinau|SCHEDULED\n" +
            "2026-10-31|9|Troyes|Le Mans|Stade de l'Aube|SCHEDULED\n" +
            "2026-11-07|10|Angers|Nice|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-11-07|10|Auxerre|Paris FC|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-11-07|10|Brest|Lyon|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-11-07|10|Le Havre|Lorient|Stade Océane|SCHEDULED\n" +
            "2026-11-07|10|Le Mans|Monaco|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-11-07 20:45|10|Lens|Marseille|Stade Bollaert-Delelis|TIMED\n" +
            "2026-11-07|10|Paris Saint-Germain|Troyes|Parc des Princes|SCHEDULED\n" +
            "2026-11-07|10|Rennes|Lille|Roazhon Park|SCHEDULED\n" +
            "2026-11-07|10|Toulouse|Strasbourg|Stadium de Toulouse|SCHEDULED\n" +
            "2026-11-21|11|Lens|Toulouse|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-11-21|11|Lille|Lyon|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-11-21|11|Lorient|Rennes|Stade du Moustoir|SCHEDULED\n" +
            "2026-11-21|11|Marseille|Le Mans|Orange Vélodrome|SCHEDULED\n" +
            "2026-11-21|11|Monaco|Auxerre|Stade Louis II|SCHEDULED\n" +
            "2026-11-21|11|Nice|Paris Saint-Germain|Allianz Riviera|SCHEDULED\n" +
            "2026-11-21|11|Paris FC|Angers|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-11-21|11|Strasbourg|Brest|Stade de la Meinau|SCHEDULED\n" +
            "2026-11-21|11|Troyes|Le Havre|Stade de l'Aube|SCHEDULED\n" +
            "2026-11-28|12|Angers|Lens|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-11-28|12|Auxerre|Marseille|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-11-28|12|Brest|Paris FC|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-11-28|12|Le Havre|Strasbourg|Stade Océane|SCHEDULED\n" +
            "2026-11-28|12|Le Mans|Lille|Stade Marie-Marvingt|SCHEDULED\n" +
            "2026-11-28|12|Lyon|Monaco|Groupama Stadium|SCHEDULED\n" +
            "2026-11-28|12|Nice|Troyes|Allianz Riviera|SCHEDULED\n" +
            "2026-11-28|12|Paris Saint-Germain|Lorient|Parc des Princes|SCHEDULED\n" +
            "2026-11-28|12|Toulouse|Rennes|Stadium de Toulouse|SCHEDULED\n" +
            "2026-12-05|13|Lens|Le Havre|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2026-12-05|13|Lille|Auxerre|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2026-12-05|13|Marseille|Nice|Orange Vélodrome|SCHEDULED\n" +
            "2026-12-05|13|Monaco|Angers|Stade Louis II|SCHEDULED\n" +
            "2026-12-05|13|Paris FC|Le Mans|Stade Jean-Bouin|SCHEDULED\n" +
            "2026-12-05|13|Rennes|Brest|Roazhon Park|SCHEDULED\n" +
            "2026-12-05|13|Strasbourg|Lorient|Stade de la Meinau|SCHEDULED\n" +
            "2026-12-05|13|Toulouse|Paris Saint-Germain|Stadium de Toulouse|SCHEDULED\n" +
            "2026-12-05|13|Troyes|Lyon|Stade de l'Aube|SCHEDULED\n" +
            "2026-12-12|14|Angers|Strasbourg|Stade Raymond Kopa|SCHEDULED\n" +
            "2026-12-12|14|Auxerre|Toulouse|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2026-12-12|14|Brest|Troyes|Stade Francis-Le Blé|SCHEDULED\n" +
            "2026-12-12|14|Le Havre|Le Mans|Stade Océane|SCHEDULED\n" +
            "2026-12-12|14|Lorient|Lille|Stade du Moustoir|SCHEDULED\n" +
            "2026-12-13 20:45|14|Lyon|Marseille|Groupama Stadium|TIMED\n" +
            "2026-12-12|14|Nice|Lens|Allianz Riviera|SCHEDULED\n" +
            "2026-12-12|14|Paris Saint-Germain|Paris FC|Parc des Princes|SCHEDULED\n" +
            "2026-12-12|14|Rennes|Monaco|Roazhon Park|SCHEDULED\n" +
            "2027-01-02|15|Brest|Marseille|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-01-02|15|Le Mans|Lyon|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-01-03 20:45|15|Lens|Paris Saint-Germain|Stade Bollaert-Delelis|TIMED\n" +
            "2027-01-02|15|Lille|Strasbourg|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-01-02|15|Lorient|Auxerre|Stade du Moustoir|SCHEDULED\n" +
            "2027-01-02|15|Monaco|Nice|Stade Louis II|SCHEDULED\n" +
            "2027-01-02|15|Paris FC|Le Havre|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-01-02|15|Toulouse|Angers|Stadium de Toulouse|SCHEDULED\n" +
            "2027-01-02|15|Troyes|Rennes|Stade de l'Aube|SCHEDULED\n" +
            "2027-01-16|16|Angers|Paris Saint-Germain|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-01-16|16|Auxerre|Troyes|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-01-16|16|Lyon|Lorient|Groupama Stadium|SCHEDULED\n" +
            "2027-01-16|16|Marseille|Lille|Orange Vélodrome|SCHEDULED\n" +
            "2027-01-16|16|Monaco|Brest|Stade Louis II|SCHEDULED\n" +
            "2027-01-16|16|Nice|Le Havre|Allianz Riviera|SCHEDULED\n" +
            "2027-01-16|16|Paris FC|Toulouse|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-01-16|16|Rennes|Lens|Roazhon Park|SCHEDULED\n" +
            "2027-01-16|16|Strasbourg|Le Mans|Stade de la Meinau|SCHEDULED\n" +
            "2027-01-23|17|Le Havre|Rennes|Stade Océane|SCHEDULED\n" +
            "2027-01-23|17|Le Mans|Angers|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-01-23|17|Lens|Brest|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-01-23|17|Lille|Paris FC|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-01-23|17|Lorient|Marseille|Stade du Moustoir|SCHEDULED\n" +
            "2027-01-23|17|Paris Saint-Germain|Auxerre|Parc des Princes|SCHEDULED\n" +
            "2027-01-23|17|Strasbourg|Lyon|Stade de la Meinau|SCHEDULED\n" +
            "2027-01-23|17|Toulouse|Nice|Stadium de Toulouse|SCHEDULED\n" +
            "2027-01-23|17|Troyes|Monaco|Stade de l'Aube|SCHEDULED\n" +
            "2027-01-30|18|Angers|Le Havre|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-01-30|18|Brest|Strasbourg|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-01-30|18|Le Mans|Nice|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-01-30|18|Lyon|Lille|Groupama Stadium|SCHEDULED\n" +
            "2027-01-30|18|Marseille|Troyes|Orange Vélodrome|SCHEDULED\n" +
            "2027-01-30|18|Monaco|Paris Saint-Germain|Stade Louis II|SCHEDULED\n" +
            "2027-01-30|18|Paris FC|Auxerre|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-01-30|18|Rennes|Lorient|Roazhon Park|SCHEDULED\n" +
            "2027-01-30|18|Toulouse|Lens|Stadium de Toulouse|SCHEDULED\n" +
            "2027-02-06|19|Auxerre|Monaco|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-02-06|19|Le Havre|Toulouse|Stade Océane|SCHEDULED\n" +
            "2027-02-06|19|Lens|Angers|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-02-06|19|Lorient|Le Mans|Stade du Moustoir|SCHEDULED\n" +
            "2027-02-06|19|Nice|Brest|Allianz Riviera|SCHEDULED\n" +
            "2027-02-07 20:45|19|Paris Saint-Germain|Marseille|Parc des Princes|TIMED\n" +
            "2027-02-06|19|Rennes|Lyon|Roazhon Park|SCHEDULED\n" +
            "2027-02-06|19|Strasbourg|Paris FC|Stade de la Meinau|SCHEDULED\n" +
            "2027-02-06|19|Troyes|Lille|Stade de l'Aube|SCHEDULED\n" +
            "2027-02-13|20|Auxerre|Strasbourg|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-02-13|20|Brest|Rennes|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-02-13|20|Le Mans|Paris Saint-Germain|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-02-13|20|Lille|Nice|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-02-13|20|Lorient|Le Havre|Stade du Moustoir|SCHEDULED\n" +
            "2027-02-13|20|Lyon|Lens|Groupama Stadium|SCHEDULED\n" +
            "2027-02-13|20|Marseille|Angers|Orange Vélodrome|SCHEDULED\n" +
            "2027-02-13|20|Paris FC|Troyes|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-02-13|20|Toulouse|Monaco|Stadium de Toulouse|SCHEDULED\n" +
            "2027-02-20|21|Angers|Paris FC|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-02-20|21|Le Havre|Lyon|Stade Océane|SCHEDULED\n" +
            "2027-02-20|21|Lens|Troyes|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-02-20|21|Lille|Lorient|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-02-20|21|Monaco|Le Mans|Stade Louis II|SCHEDULED\n" +
            "2027-02-20|21|Nice|Auxerre|Allianz Riviera|SCHEDULED\n" +
            "2027-02-20|21|Paris Saint-Germain|Brest|Parc des Princes|SCHEDULED\n" +
            "2027-02-20|21|Rennes|Toulouse|Roazhon Park|SCHEDULED\n" +
            "2027-02-20|21|Strasbourg|Marseille|Stade de la Meinau|SCHEDULED\n" +
            "2027-02-27|22|Auxerre|Lille|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-02-27|22|Brest|Monaco|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-02-27|22|Le Mans|Paris FC|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-02-27|22|Lorient|Angers|Stade du Moustoir|SCHEDULED\n" +
            "2027-02-27|22|Lyon|Toulouse|Groupama Stadium|SCHEDULED\n" +
            "2027-02-27|22|Marseille|Rennes|Orange Vélodrome|SCHEDULED\n" +
            "2027-02-28 20:45|22|Paris Saint-Germain|Lens|Parc des Princes|TIMED\n" +
            "2027-02-27|22|Strasbourg|Le Havre|Stade de la Meinau|SCHEDULED\n" +
            "2027-02-27|22|Troyes|Nice|Stade de l'Aube|SCHEDULED\n" +
            "2027-03-06|23|Angers|Auxerre|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-03-06|23|Le Havre|Nice|Stade Océane|SCHEDULED\n" +
            "2027-03-06|23|Lens|Strasbourg|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-03-06|23|Lille|Marseille|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-03-06|23|Monaco|Lyon|Stade Louis II|SCHEDULED\n" +
            "2027-03-06|23|Paris FC|Brest|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-03-06|23|Rennes|Paris Saint-Germain|Roazhon Park|SCHEDULED\n" +
            "2027-03-06|23|Toulouse|Le Mans|Stadium de Toulouse|SCHEDULED\n" +
            "2027-03-06|23|Troyes|Lorient|Stade de l'Aube|SCHEDULED\n" +
            "2027-03-13|24|Auxerre|Paris Saint-Germain|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-03-13|24|Brest|Lille|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-03-13|24|Le Havre|Lens|Stade Océane|SCHEDULED\n" +
            "2027-03-13|24|Le Mans|Rennes|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-03-13|24|Lyon|Troyes|Groupama Stadium|SCHEDULED\n" +
            "2027-03-13|24|Marseille|Monaco|Orange Vélodrome|SCHEDULED\n" +
            "2027-03-13|24|Nice|Toulouse|Allianz Riviera|SCHEDULED\n" +
            "2027-03-13|24|Paris FC|Lorient|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-03-13|24|Strasbourg|Angers|Stade de la Meinau|SCHEDULED\n" +
            "2027-03-20|25|Angers|Le Mans|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-03-20|25|Lens|Lille|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-03-20|25|Lorient|Nice|Stade du Moustoir|SCHEDULED\n" +
            "2027-03-21 20:45|25|Marseille|Lyon|Orange Vélodrome|TIMED\n" +
            "2027-03-20|25|Monaco|Le Havre|Stade Louis II|SCHEDULED\n" +
            "2027-03-20|25|Paris Saint-Germain|Strasbourg|Parc des Princes|SCHEDULED\n" +
            "2027-03-20|25|Rennes|Paris FC|Roazhon Park|SCHEDULED\n" +
            "2027-03-20|25|Toulouse|Brest|Stadium de Toulouse|SCHEDULED\n" +
            "2027-03-20|25|Troyes|Auxerre|Stade de l'Aube|SCHEDULED\n" +
            "2027-04-03|26|Angers|Monaco|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-04-03|26|Auxerre|Lens|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-04-03|26|Brest|Lorient|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-04-03|26|Le Havre|Troyes|Stade Océane|SCHEDULED\n" +
            "2027-04-03|26|Le Mans|Marseille|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-04-03|26|Lille|Rennes|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-04-03|26|Nice|Lyon|Allianz Riviera|SCHEDULED\n" +
            "2027-04-03|26|Paris FC|Paris Saint-Germain|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-04-03|26|Strasbourg|Toulouse|Stade de la Meinau|SCHEDULED\n" +
            "2027-04-10|27|Le Mans|Auxerre|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-04-10|27|Lille|Toulouse|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-04-10|27|Lorient|Lens|Stade du Moustoir|SCHEDULED\n" +
            "2027-04-10|27|Lyon|Strasbourg|Groupama Stadium|SCHEDULED\n" +
            "2027-04-10|27|Marseille|Brest|Orange Vélodrome|SCHEDULED\n" +
            "2027-04-10|27|Monaco|Rennes|Stade Louis II|SCHEDULED\n" +
            "2027-04-10|27|Nice|Paris FC|Allianz Riviera|SCHEDULED\n" +
            "2027-04-10|27|Paris Saint-Germain|Le Havre|Parc des Princes|SCHEDULED\n" +
            "2027-04-10|27|Troyes|Angers|Stade de l'Aube|SCHEDULED\n" +
            "2027-04-17|28|Angers|Lyon|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-04-17|28|Auxerre|Lorient|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-04-17|28|Brest|Le Mans|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-04-17|28|Le Havre|Marseille|Stade Océane|SCHEDULED\n" +
            "2027-04-17|28|Lens|Nice|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-04-17|28|Monaco|Strasbourg|Stade Louis II|SCHEDULED\n" +
            "2027-04-17|28|Paris Saint-Germain|Lille|Parc des Princes|SCHEDULED\n" +
            "2027-04-17|28|Rennes|Troyes|Roazhon Park|SCHEDULED\n" +
            "2027-04-17|28|Toulouse|Paris FC|Stadium de Toulouse|SCHEDULED\n" +
            "2027-04-24|29|Le Mans|Le Havre|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-04-24|29|Lille|Monaco|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-04-24|29|Lorient|Paris Saint-Germain|Stade du Moustoir|SCHEDULED\n" +
            "2027-04-24|29|Lyon|Brest|Groupama Stadium|SCHEDULED\n" +
            "2027-04-24|29|Marseille|Auxerre|Orange Vélodrome|SCHEDULED\n" +
            "2027-04-24|29|Nice|Angers|Allianz Riviera|SCHEDULED\n" +
            "2027-04-24|29|Paris FC|Lens|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-04-24|29|Strasbourg|Rennes|Stade de la Meinau|SCHEDULED\n" +
            "2027-04-24|29|Troyes|Toulouse|Stade de l'Aube|SCHEDULED\n" +
            "2027-05-01|30|Auxerre|Lyon|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-05-01|30|Le Havre|Paris FC|Stade Océane|SCHEDULED\n" +
            "2027-05-01|30|Lens|Le Mans|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-05-01|30|Monaco|Lorient|Stade Louis II|SCHEDULED\n" +
            "2027-05-01|30|Paris Saint-Germain|Angers|Parc des Princes|SCHEDULED\n" +
            "2027-05-01|30|Rennes|Nice|Roazhon Park|SCHEDULED\n" +
            "2027-05-01|30|Strasbourg|Lille|Stade de la Meinau|SCHEDULED\n" +
            "2027-05-01|30|Toulouse|Marseille|Stadium de Toulouse|SCHEDULED\n" +
            "2027-05-01|30|Troyes|Brest|Stade de l'Aube|SCHEDULED\n" +
            "2027-05-08|31|Angers|Toulouse|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-05-08|31|Brest|Auxerre|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-05-08|31|Le Mans|Troyes|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-05-08|31|Lens|Monaco|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-05-08|31|Lorient|Strasbourg|Stade du Moustoir|SCHEDULED\n" +
            "2027-05-09 20:45|31|Lyon|Paris Saint-Germain|Groupama Stadium|TIMED\n" +
            "2027-05-08|31|Nice|Marseille|Allianz Riviera|SCHEDULED\n" +
            "2027-05-08|31|Paris FC|Lille|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-05-08|31|Rennes|Le Havre|Roazhon Park|SCHEDULED\n" +
            "2027-05-16|32|Auxerre|Rennes|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-05-16|32|Brest|Le Havre|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-05-16|32|Lille|Angers|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-05-16|32|Lyon|Le Mans|Groupama Stadium|SCHEDULED\n" +
            "2027-05-16|32|Marseille|Lens|Orange Vélodrome|SCHEDULED\n" +
            "2027-05-16|32|Monaco|Paris FC|Stade Louis II|SCHEDULED\n" +
            "2027-05-16|32|Paris Saint-Germain|Nice|Parc des Princes|SCHEDULED\n" +
            "2027-05-16|32|Strasbourg|Troyes|Stade de la Meinau|SCHEDULED\n" +
            "2027-05-16|32|Toulouse|Lorient|Stadium de Toulouse|SCHEDULED\n" +
            "2027-05-22|33|Angers|Brest|Stade Raymond Kopa|SCHEDULED\n" +
            "2027-05-22|33|Le Havre|Lille|Stade Océane|SCHEDULED\n" +
            "2027-05-22|33|Le Mans|Strasbourg|Stade Marie-Marvingt|SCHEDULED\n" +
            "2027-05-22|33|Lens|Rennes|Stade Bollaert-Delelis|SCHEDULED\n" +
            "2027-05-22|33|Lorient|Lyon|Stade du Moustoir|SCHEDULED\n" +
            "2027-05-22|33|Nice|Monaco|Allianz Riviera|SCHEDULED\n" +
            "2027-05-22|33|Paris FC|Marseille|Stade Jean-Bouin|SCHEDULED\n" +
            "2027-05-22|33|Toulouse|Auxerre|Stadium de Toulouse|SCHEDULED\n" +
            "2027-05-22|33|Troyes|Paris Saint-Germain|Stade de l'Aube|SCHEDULED\n" +
            "2027-05-29|34|Auxerre|Le Havre|Stade de l'Abbé-Deschamps|SCHEDULED\n" +
            "2027-05-29|34|Brest|Lens|Stade Francis-Le Blé|SCHEDULED\n" +
            "2027-05-29|34|Lille|Le Mans|Decathlon Arena - Stade Pierre-Mauroy|SCHEDULED\n" +
            "2027-05-29|34|Lyon|Paris FC|Groupama Stadium|SCHEDULED\n" +
            "2027-05-29|34|Marseille|Lorient|Orange Vélodrome|SCHEDULED\n" +
            "2027-05-29|34|Monaco|Troyes|Stade Louis II|SCHEDULED\n" +
            "2027-05-29|34|Paris Saint-Germain|Toulouse|Parc des Princes|SCHEDULED\n" +
            "2027-05-29|34|Rennes|Angers|Roazhon Park|SCHEDULED\n" +
            "2027-05-29|34|Strasbourg|Nice|Stade de la Meinau|SCHEDULED\n";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        TLA.put("Angers", "ANG");
        TLA.put("Auxerre", "AJA");
        TLA.put("Brest", "BRE");
        TLA.put("Le Havre", "HAC");
        TLA.put("Le Mans", "LEM");
        TLA.put("Lens", "RCL");
        TLA.put("Lille", "LIL");
        TLA.put("Lorient", "FCL");
        TLA.put("Lyon", "OL");
        TLA.put("Marseille", "OM");
        TLA.put("Monaco", "ASM");
        TLA.put("Nice", "NIC");
        TLA.put("Paris FC", "PFC");
        TLA.put("Paris Saint-Germain", "PSG");
        TLA.put("Rennes", "REN");
        TLA.put("Strasbourg", "RCS");
        TLA.put("Toulouse", "TFC");
        TLA.put("Troyes", "EST");

        CRESTS.put("Angers", "https://a.espncdn.com/i/teamlogos/soccer/500/7868.png");
        CRESTS.put("Auxerre", "https://a.espncdn.com/i/teamlogos/soccer/500/172.png");
        CRESTS.put("Brest", "https://a.espncdn.com/i/teamlogos/soccer/500/6997.png");
        CRESTS.put("Le Havre", "https://a.espncdn.com/i/teamlogos/soccer/500/3236.png");
        CRESTS.put("Le Mans", "https://a.espncdn.com/i/teamlogos/soccer/500/2697.png");
        CRESTS.put("Lens", "https://a.espncdn.com/i/teamlogos/soccer/500/175.png");
        CRESTS.put("Lille", "https://a.espncdn.com/i/teamlogos/soccer/500/166.png");
        CRESTS.put("Lorient", "https://a.espncdn.com/i/teamlogos/soccer/500/273.png");
        CRESTS.put("Lyon", "https://a.espncdn.com/i/teamlogos/soccer/500/167.png");
        CRESTS.put("Marseille", "https://a.espncdn.com/i/teamlogos/soccer/500/176.png");
        CRESTS.put("Monaco", "https://a.espncdn.com/i/teamlogos/soccer/500/174.png");
        CRESTS.put("Nice", "https://a.espncdn.com/i/teamlogos/soccer/500/2502.png");
        CRESTS.put("Paris FC", "https://a.espncdn.com/i/teamlogos/soccer/500/6851.png");
        CRESTS.put("Paris Saint-Germain", "https://a.espncdn.com/i/teamlogos/soccer/500/160.png");
        CRESTS.put("Rennes", "https://a.espncdn.com/i/teamlogos/soccer/500/169.png");
        CRESTS.put("Strasbourg", "https://a.espncdn.com/i/teamlogos/soccer/500/180.png");
        CRESTS.put("Toulouse", "https://a.espncdn.com/i/teamlogos/soccer/500/179.png");
        CRESTS.put("Troyes", "https://a.espncdn.com/i/teamlogos/soccer/500/170.png");

        VENUES.put("Angers", "Stade Raymond Kopa");
        VENUES.put("Auxerre", "Stade de l'Abbé-Deschamps");
        VENUES.put("Brest", "Stade Francis-Le Blé");
        VENUES.put("Le Havre", "Stade Océane");
        VENUES.put("Le Mans", "Stade Marie-Marvingt");
        VENUES.put("Lens", "Stade Bollaert-Delelis");
        VENUES.put("Lille", "Decathlon Arena - Stade Pierre-Mauroy");
        VENUES.put("Lorient", "Stade du Moustoir");
        VENUES.put("Lyon", "Groupama Stadium");
        VENUES.put("Marseille", "Orange Vélodrome");
        VENUES.put("Monaco", "Stade Louis II");
        VENUES.put("Nice", "Allianz Riviera");
        VENUES.put("Paris FC", "Stade Jean-Bouin");
        VENUES.put("Paris Saint-Germain", "Parc des Princes");
        VENUES.put("Rennes", "Roazhon Park");
        VENUES.put("Strasbourg", "Stade de la Meinau");
        VENUES.put("Toulouse", "Stadium de Toulouse");
        VENUES.put("Troyes", "Stade de l'Aube");

        FOUNDED.put("Angers", 1919);
        FOUNDED.put("Auxerre", 1905);
        FOUNDED.put("Brest", 1950);
        FOUNDED.put("Le Havre", 1894);
        FOUNDED.put("Le Mans", 1985);
        FOUNDED.put("Lens", 1906);
        FOUNDED.put("Lille", 1944);
        FOUNDED.put("Lorient", 1926);
        FOUNDED.put("Lyon", 1950);
        FOUNDED.put("Marseille", 1899);
        FOUNDED.put("Monaco", 1924);
        FOUNDED.put("Nice", 1904);
        FOUNDED.put("Paris FC", 1969);
        FOUNDED.put("Paris Saint-Germain", 1970);
        FOUNDED.put("Rennes", 1901);
        FOUNDED.put("Strasbourg", 1906);
        FOUNDED.put("Toulouse", 1970);
        FOUNDED.put("Troyes", 1986);

        WEBSITES.put("Angers", "https://angers-sco.fr");
        WEBSITES.put("Auxerre", "https://www.aja.fr");
        WEBSITES.put("Brest", "https://www.sb29.bzh");
        WEBSITES.put("Le Havre", "https://www.hac-foot.com");
        WEBSITES.put("Le Mans", "https://www.lemansfc.fr");
        WEBSITES.put("Lens", "https://www.rclens.fr");
        WEBSITES.put("Lille", "https://www.losc.fr");
        WEBSITES.put("Lorient", "https://www.fclorient.bzh");
        WEBSITES.put("Lyon", "https://www.ol.fr");
        WEBSITES.put("Marseille", "https://www.om.fr");
        WEBSITES.put("Monaco", "https://www.asmonaco.com");
        WEBSITES.put("Nice", "https://www.ogcnice.com");
        WEBSITES.put("Paris FC", "https://parisfc.fr");
        WEBSITES.put("Paris Saint-Germain", "https://www.psg.fr");
        WEBSITES.put("Rennes", "https://www.staderennais.com");
        WEBSITES.put("Strasbourg", "https://www.rcstrasbourgalsace.fr");
        WEBSITES.put("Toulouse", "https://www.toulousefc.com");
        WEBSITES.put("Troyes", "https://www.estac.fr");

        COLORS.put("Angers", "Black / White");
        COLORS.put("Auxerre", "Blue / White");
        COLORS.put("Brest", "Red / White");
        COLORS.put("Le Havre", "Sky Blue / Navy");
        COLORS.put("Le Mans", "Red / Yellow");
        COLORS.put("Lens", "Red / Yellow");
        COLORS.put("Lille", "Red / Navy / White");
        COLORS.put("Lorient", "Orange / Black");
        COLORS.put("Lyon", "White / Red / Blue");
        COLORS.put("Marseille", "White / Sky Blue");
        COLORS.put("Monaco", "Red / White");
        COLORS.put("Nice", "Red / Black");
        COLORS.put("Paris FC", "Navy / White");
        COLORS.put("Paris Saint-Germain", "Blue / Red / White");
        COLORS.put("Rennes", "Red / Black");
        COLORS.put("Strasbourg", "Blue / White");
        COLORS.put("Toulouse", "Purple / White");
        COLORS.put("Troyes", "Blue / White");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutLigue1(root.optJSONArray("matches")));
            root.put("live", copyWithoutLigue1(root.optJSONArray("live")));
            root.put("finished", copyWithoutLigue1(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutLigue1(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // A future malformed manual update must never block other leagues.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonLigue1(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "FL1-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "SCHEDULED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "LFP official Ligue 1 fixture calendar");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Ligue 1 source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"tla", "crest", "emblem", "logo", "venue", "address", "website", "clubColors", "founded"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            Object raw = richer.opt(key);
            String value = String.valueOf(raw).trim();
            if (value.length() > 0 && !"null".equalsIgnoreCase(value)) out.put(key, raw);
        }
        Object richerArea = richer.opt("area");
        if (richerArea instanceof JSONObject) out.put("area", richerArea);
        else if (richerArea != null && String.valueOf(richerArea).trim().length() > 0) {
            JSONObject area = new JSONObject(); area.put("name", String.valueOf(richerArea).trim()); out.put("area", area);
        }
        String name = out.optString("name", out.optString("shortName", ""));
        String canonical = canonicalName(name);
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(canonical)) out.put("crest", CRESTS.get(canonical));
        return out;
    }

    private static JSONArray copyWithoutLigue1(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isLigue1(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonLigue1(JSONObject row) {
        if (!isLigue1(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isLigue1(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        String rawCode = ""; String rawName = "";
        if (raw instanceof JSONObject) { JSONObject c = (JSONObject) raw; rawCode = c.optString("code", ""); rawName = c.optString("name", ""); }
        else if (raw != null) rawName = String.valueOf(raw);
        String rowCode = row.optString("competitionCode", "");
        String rawCodeNormalized = normalize(rawCode); String rowCodeNormalized = normalize(rowCode);
        if (rawCodeNormalized.equals("fl1") || rowCodeNormalized.equals("fl1")) return true;
        if (rawCodeNormalized.length() > 0 || rowCodeNormalized.length() > 0) return false;
        String rowName = row.optString("competitionName", "");
        String rawNormalized = normalize(rawName); String rowNormalized = normalize(rowName);
        return rawNormalized.equals("ligue1") || rawNormalized.equals("franceligue1") ||
                rowNormalized.equals("ligue1") || rowNormalized.equals("franceligue1");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true); String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0; String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30; else if (isLive(status)) score += 25; else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2; if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") || value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject(); competition.put("code", COMPETITION_CODE); competition.put("name", COMPETITION_NAME); return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject(); team.put("name", name); team.put("shortName", name); team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        JSONObject area = new JSONObject(); area.put("name", "France"); team.put("area", area);
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        if (VENUES.containsKey(name)) team.put("venue", VENUES.get(name));
        if (FOUNDED.containsKey(name)) team.put("founded", FOUNDED.get(name));
        if (WEBSITES.containsKey(name)) team.put("website", WEBSITES.get(name));
        if (COLORS.containsKey(name)) team.put("clubColors", COLORS.get(name));
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = new JSONArray();
        if (source != null) {
            for (int i = 0; i < source.length(); i++) {
                JSONObject team = source.optJSONObject(i); if (team == null) continue;
                String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
                if (isCurrentOrStaleLigue1Club(name)) continue;
                teams.put(new JSONObject(team.toString()));
            }
        }
        for (String name : TLA.keySet()) teams.put(teamObject(name));
        root.put("teams", teams);
    }

    private static boolean isCurrentOrStaleLigue1Club(String value) {
        String key = clubKey(value);
        if (TLA.containsKey(canonicalName(value))) return true;
        return key.equals("saintetienne") || key.equals("nantes") || key.equals("metz");
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings"); if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE); if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", ""); String end = season == null ? "" : season.optString("endDate", "");
        if (!(start.startsWith("2026") && end.startsWith("2027"))) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources"); if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject ligue1 = sources.optJSONObject(COMPETITION_CODE); if (ligue1 == null) ligue1 = new JSONObject();
        ligue1.put("status", "connected");
        ligue1.put("provider", "LFP official 2026/27 calendar + connected live source");
        ligue1.put("season", SEASON); ligue1.put("matchCount", matchCount); ligue1.put("teamCount", TLA.size()); ligue1.put("roundCount", 34);
        sources.put(COMPETITION_CODE, ligue1);
    }

    private static String canonicalName(String value) {
        String key = clubKey(value);
        for (String name : TLA.keySet()) if (clubKey(name).equals(key)) return name;
        return value == null ? "" : value.trim();
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("angerssco")) return "angers";
        if (key.equals("scoangers")) return "angers";
        if (key.equals("ajauxerre")) return "auxerre";
        if (key.equals("stadebrestois29")) return "brest";
        if (key.equals("stadebrestois")) return "brest";
        if (key.equals("havreac")) return "lehavre";
        if (key.equals("lehac")) return "lehavre";
        if (key.equals("lemansfc")) return "lemans";
        if (key.equals("rclens")) return "lens";
        if (key.equals("losc")) return "lille";
        if (key.equals("losclille")) return "lille";
        if (key.equals("fclorient")) return "lorient";
        if (key.equals("olympiquelyonnais")) return "lyon";
        if (key.equals("ol")) return "lyon";
        if (key.equals("olympiquedemarseille")) return "marseille";
        if (key.equals("om")) return "marseille";
        if (key.equals("asmonaco")) return "monaco";
        if (key.equals("asmonacofc")) return "monaco";
        if (key.equals("ogcnice")) return "nice";
        if (key.equals("parisfootballclub")) return "parisfc";
        if (key.equals("psg")) return "parissaintgermain";
        if (key.equals("parissaintgermainfc")) return "parissaintgermain";
        if (key.equals("staderennais")) return "rennes";
        if (key.equals("staderennaisfc")) return "rennes";
        if (key.equals("rcstrasbourg")) return "strasbourg";
        if (key.equals("rcstrasbourgaslace")) return "strasbourg";
        if (key.equals("toulousefc")) return "toulouse";
        if (key.equals("estactroyes")) return "troyes";
        if (key.equals("esperancesportivetroyesaubechampagne")) return "troyes";
        if (key.equals("saintetienne")) return "saintetienne";
        if (key.equals("assaintetienne")) return "saintetienne";
        if (key.equals("asstetienne")) return "saintetienne";
        if (key.equals("asse")) return "saintetienne";
        if (key.equals("nantes")) return "nantes";
        if (key.equals("fcnantes")) return "nantes";
        if (key.equals("metz")) return "metz";
        if (key.equals("fcmetz")) return "metz";
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private Ligue12627Data() {}
}
