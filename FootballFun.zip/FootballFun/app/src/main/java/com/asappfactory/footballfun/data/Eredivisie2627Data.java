package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Official Eredivisie 2026/27 fixture and club-identity fallback. */
public final class Eredivisie2627Data {
    private static final String COMPETITION_NAME = "Eredivisie";
    private static final String COMPETITION_CODE = "DED";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-07";
    private static final String LAST_DATE = "2027-05-23";

    private static final String DATA =
            "2026-08-07 20:00|1|SC Cambuur|Excelsior Rotterdam|Kooi Stadion|TIMED\n" +
            "2026-08-08 16:30|1|N.E.C.|Telstar|Goffertstadion|TIMED\n" +
            "2026-08-08 18:45|1|Go Ahead Eagles|Willem II|De Adelaarshorst|TIMED\n" +
            "2026-08-08 20:00|1|PSV|Fortuna Sittard|Philips Stadion|TIMED\n" +
            "2026-08-08 21:00|1|AZ|ADO Den Haag|AFAS Stadion|TIMED\n" +
            "2026-08-09 12:15|1|Sparta Rotterdam|Feyenoord|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-08-09 14:30|1|FC Groningen|FC Utrecht|Euroborg|TIMED\n" +
            "2026-08-09 14:30|1|PEC Zwolle|Ajax|MAC³PARK Stadion|TIMED\n" +
            "2026-08-09 16:45|1|SC Heerenveen|FC Twente|Abe Lenstra Stadion|TIMED\n" +
            "2026-08-14 20:00|2|Telstar|Sparta Rotterdam|711 Stadion|TIMED\n" +
            "2026-08-15 16:30|2|Willem II|N.E.C.|Koning Willem II Stadion|TIMED\n" +
            "2026-08-15 18:45|2|FC Utrecht|AZ|Stadion Galgenwaard|TIMED\n" +
            "2026-08-15 20:00|2|Excelsior Rotterdam|PSV|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-08-15 21:00|2|Fortuna Sittard|SC Cambuur|Fortuna Sittard Stadion|TIMED\n" +
            "2026-08-16 12:15|2|ADO Den Haag|FC Groningen|Bingoal Stadion|TIMED\n" +
            "2026-08-16 14:30|2|Feyenoord|Go Ahead Eagles|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2026-08-16 14:30|2|FC Twente|PEC Zwolle|De Grolsch Veste|TIMED\n" +
            "2026-08-16 16:45|2|Ajax|SC Heerenveen|Johan Cruijff ArenA|TIMED\n" +
            "2026-08-22 16:30|3|Fortuna Sittard|AZ|Fortuna Sittard Stadion|TIMED\n" +
            "2026-08-22 18:45|3|Sparta Rotterdam|FC Utrecht|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-08-22 20:00|3|N.E.C.|Excelsior Rotterdam|Goffertstadion|TIMED\n" +
            "2026-08-22 21:00|3|SC Heerenveen|PEC Zwolle|Abe Lenstra Stadion|TIMED\n" +
            "2026-08-23 12:15|3|Go Ahead Eagles|ADO Den Haag|De Adelaarshorst|TIMED\n" +
            "2026-08-23 14:30|3|PSV|FC Groningen|Philips Stadion|TIMED\n" +
            "2026-08-23 16:45|3|SC Cambuur|Feyenoord|Kooi Stadion|TIMED\n" +
            "2026-08-28 20:00|4|FC Groningen|Fortuna Sittard|Euroborg|TIMED\n" +
            "2026-08-29 16:30|4|Excelsior Rotterdam|Sparta Rotterdam|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-08-29 18:45|4|AZ|Go Ahead Eagles|AFAS Stadion|TIMED\n" +
            "2026-08-29 21:00|4|PEC Zwolle|N.E.C.|MAC³PARK Stadion|TIMED\n" +
            "2026-08-30 12:15|4|FC Utrecht|PSV|Stadion Galgenwaard|TIMED\n" +
            "2026-08-30 14:30|4|Willem II|SC Heerenveen|Koning Willem II Stadion|TIMED\n" +
            "2026-08-30 14:30|4|Feyenoord|ADO Den Haag|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2026-08-30 16:45|4|Telstar|Ajax|711 Stadion|TIMED\n" +
            "2026-08-30 20:00|4|SC Cambuur|FC Twente|Kooi Stadion|TIMED\n" +
            "2026-09-04 20:00|5|Sparta Rotterdam|PEC Zwolle|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-09-05 16:30|5|N.E.C.|Feyenoord|Goffertstadion|TIMED\n" +
            "2026-09-05 18:45|5|FC Utrecht|Go Ahead Eagles|Stadion Galgenwaard|TIMED\n" +
            "2026-09-05 20:00|5|Ajax|PSV|Johan Cruijff ArenA|TIMED\n" +
            "2026-09-05 21:00|5|Willem II|Excelsior Rotterdam|Koning Willem II Stadion|TIMED\n" +
            "2026-09-06 12:15|5|FC Groningen|FC Twente|Euroborg|TIMED\n" +
            "2026-09-06 14:30|5|SC Heerenveen|AZ|Abe Lenstra Stadion|TIMED\n" +
            "2026-09-06 14:30|5|Telstar|SC Cambuur|711 Stadion|TIMED\n" +
            "2026-09-06 16:45|5|ADO Den Haag|Fortuna Sittard|Bingoal Stadion|TIMED\n" +
            "2026-09-09 18:45|3|FC Twente|Telstar|De Grolsch Veste|TIMED\n" +
            "2026-09-11 20:00|6|AZ|Willem II|AFAS Stadion|TIMED\n" +
            "2026-09-12 16:30|6|FC Twente|ADO Den Haag|De Grolsch Veste|TIMED\n" +
            "2026-09-12 18:45|6|Go Ahead Eagles|FC Groningen|De Adelaarshorst|TIMED\n" +
            "2026-09-12 20:00|6|Fortuna Sittard|Ajax|Fortuna Sittard Stadion|TIMED\n" +
            "2026-09-12 21:00|6|SC Heerenveen|Telstar|Abe Lenstra Stadion|TIMED\n" +
            "2026-09-13 12:15|6|Excelsior Rotterdam|FC Utrecht|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-09-13 14:30|6|PSV|Sparta Rotterdam|Philips Stadion|TIMED\n" +
            "2026-09-13 14:30|6|SC Cambuur|N.E.C.|Kooi Stadion|TIMED\n" +
            "2026-09-13 16:45|6|PEC Zwolle|Feyenoord|MAC³PARK Stadion|TIMED\n" +
            "2026-09-15 20:00|3|Ajax|Willem II|Johan Cruijff ArenA|TIMED\n" +
            "2026-09-18 20:00|7|FC Groningen|PEC Zwolle|Euroborg|TIMED\n" +
            "2026-09-19 16:30|7|ADO Den Haag|SC Cambuur|Bingoal Stadion|TIMED\n" +
            "2026-09-19 18:45|7|Sparta Rotterdam|SC Heerenveen|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-09-19 20:00|7|Ajax|Excelsior Rotterdam|Johan Cruijff ArenA|TIMED\n" +
            "2026-09-19 21:00|7|Willem II|Fortuna Sittard|Koning Willem II Stadion|TIMED\n" +
            "2026-09-20 12:15|7|Feyenoord|FC Utrecht|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2026-09-20 14:30|7|AZ|Telstar|AFAS Stadion|TIMED\n" +
            "2026-09-20 14:30|7|N.E.C.|Go Ahead Eagles|Goffertstadion|TIMED\n" +
            "2026-09-20 16:45|7|FC Twente|PSV|De Grolsch Veste|TIMED\n" +
            "2026-10-10 16:30|8|PSV|SC Heerenveen|Philips Stadion|TIMED\n" +
            "2026-10-10 18:45|8|Feyenoord|AZ|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2026-10-10 18:45|8|Go Ahead Eagles|Sparta Rotterdam|De Adelaarshorst|TIMED\n" +
            "2026-10-10 21:00|8|Ajax|N.E.C.|Johan Cruijff ArenA|TIMED\n" +
            "2026-10-10 21:00|8|Fortuna Sittard|FC Twente|Fortuna Sittard Stadion|TIMED\n" +
            "2026-10-11 12:15|8|FC Utrecht|Willem II|Stadion Galgenwaard|TIMED\n" +
            "2026-10-11 14:30|8|PEC Zwolle|SC Cambuur|MAC³PARK Stadion|TIMED\n" +
            "2026-10-11 14:30|8|Telstar|ADO Den Haag|711 Stadion|TIMED\n" +
            "2026-10-11 16:45|8|Excelsior Rotterdam|FC Groningen|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-10-16 20:00|9|SC Heerenveen|Excelsior Rotterdam|Abe Lenstra Stadion|TIMED\n" +
            "2026-10-17 16:30|9|ADO Den Haag|PSV|Bingoal Stadion|TIMED\n" +
            "2026-10-17 18:45|9|N.E.C.|Fortuna Sittard|Goffertstadion|TIMED\n" +
            "2026-10-17 20:00|9|Telstar|Feyenoord|711 Stadion|TIMED\n" +
            "2026-10-17 21:00|9|Sparta Rotterdam|Willem II|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-10-18 12:15|9|PEC Zwolle|Go Ahead Eagles|MAC³PARK Stadion|TIMED\n" +
            "2026-10-18 14:30|9|FC Twente|FC Utrecht|De Grolsch Veste|TIMED\n" +
            "2026-10-18 14:30|9|SC Cambuur|AZ|Kooi Stadion|TIMED\n" +
            "2026-10-18 16:45|9|FC Groningen|Ajax|Euroborg|TIMED\n" +
            "2026-10-23 20:00|10|Go Ahead Eagles|Telstar|De Adelaarshorst|TIMED\n" +
            "2026-10-24 16:30|10|FC Utrecht|PEC Zwolle|Stadion Galgenwaard|TIMED\n" +
            "2026-10-24 18:45|10|Willem II|SC Cambuur|Koning Willem II Stadion|TIMED\n" +
            "2026-10-24 21:00|10|ADO Den Haag|SC Heerenveen|Bingoal Stadion|TIMED\n" +
            "2026-10-25 12:15|10|Fortuna Sittard|Excelsior Rotterdam|Fortuna Sittard Stadion|TIMED\n" +
            "2026-10-25 14:30|10|N.E.C.|FC Groningen|Goffertstadion|TIMED\n" +
            "2026-10-25 14:30|10|PSV|Feyenoord|Philips Stadion|TIMED\n" +
            "2026-10-25 16:45|10|Sparta Rotterdam|Ajax|Sparta Stadion Het Kasteel|TIMED\n" +
            "2026-10-25 20:00|10|AZ|FC Twente|AFAS Stadion|TIMED\n" +
            "2026-10-31 16:30|11|Feyenoord|Fortuna Sittard|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2026-10-31 18:45|11|PSV|Willem II|Philips Stadion|TIMED\n" +
            "2026-10-31 18:45|11|SC Heerenveen|N.E.C.|Abe Lenstra Stadion|TIMED\n" +
            "2026-10-31 21:00|11|Ajax|AZ|Johan Cruijff ArenA|TIMED\n" +
            "2026-10-31 21:00|11|SC Cambuur|Go Ahead Eagles|Kooi Stadion|TIMED\n" +
            "2026-11-01 12:15|11|PEC Zwolle|ADO Den Haag|MAC³PARK Stadion|TIMED\n" +
            "2026-11-01 14:30|11|Excelsior Rotterdam|FC Twente|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-11-01 14:30|11|Telstar|FC Utrecht|711 Stadion|TIMED\n" +
            "2026-11-01 16:45|11|FC Groningen|Sparta Rotterdam|Euroborg|TIMED\n" +
            "2026-11-06 20:00|12|Willem II|PEC Zwolle|Koning Willem II Stadion|TIMED\n" +
            "2026-11-07 16:30|12|Fortuna Sittard|Telstar|Fortuna Sittard Stadion|TIMED\n" +
            "2026-11-07 18:45|12|ADO Den Haag|Sparta Rotterdam|Bingoal Stadion|TIMED\n" +
            "2026-11-07 20:00|12|SC Cambuur|PSV|Kooi Stadion|TIMED\n" +
            "2026-11-07 21:00|12|Excelsior Rotterdam|Go Ahead Eagles|Van Donge & De Roo Stadion|TIMED\n" +
            "2026-11-08 12:15|12|SC Heerenveen|Feyenoord|Abe Lenstra Stadion|TIMED\n" +
            "2026-11-08 14:30|12|FC Twente|Ajax|De Grolsch Veste|TIMED\n" +
            "2026-11-08 14:30|12|FC Utrecht|N.E.C.|Stadion Galgenwaard|TIMED\n" +
            "2026-11-08 16:45|12|AZ|FC Groningen|AFAS Stadion|TIMED\n" +
            "2026-11-22|13|Ajax|ADO Den Haag|Johan Cruijff ArenA|SCHEDULED\n" +
            "2026-11-22|13|FC Groningen|SC Heerenveen|Euroborg|SCHEDULED\n" +
            "2026-11-22|13|FC Twente|Willem II|De Grolsch Veste|SCHEDULED\n" +
            "2026-11-22|13|FC Utrecht|SC Cambuur|Stadion Galgenwaard|SCHEDULED\n" +
            "2026-11-22|13|Feyenoord|Excelsior Rotterdam|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2026-11-22|13|Go Ahead Eagles|Fortuna Sittard|De Adelaarshorst|SCHEDULED\n" +
            "2026-11-22|13|N.E.C.|PSV|Goffertstadion|SCHEDULED\n" +
            "2026-11-22|13|Sparta Rotterdam|AZ|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2026-11-22|13|Telstar|PEC Zwolle|711 Stadion|SCHEDULED\n" +
            "2026-11-29|14|ADO Den Haag|FC Utrecht|Bingoal Stadion|SCHEDULED\n" +
            "2026-11-29|14|Excelsior Rotterdam|Telstar|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2026-11-29|14|FC Groningen|Willem II|Euroborg|SCHEDULED\n" +
            "2026-11-29|14|Feyenoord|Ajax|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2026-11-29|14|Fortuna Sittard|SC Heerenveen|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2026-11-29|14|N.E.C.|FC Twente|Goffertstadion|SCHEDULED\n" +
            "2026-11-29|14|PEC Zwolle|AZ|MAC³PARK Stadion|SCHEDULED\n" +
            "2026-11-29|14|PSV|Go Ahead Eagles|Philips Stadion|SCHEDULED\n" +
            "2026-11-29|14|SC Cambuur|Sparta Rotterdam|Kooi Stadion|SCHEDULED\n" +
            "2026-12-06|15|ADO Den Haag|Excelsior Rotterdam|Bingoal Stadion|SCHEDULED\n" +
            "2026-12-06|15|Ajax|FC Utrecht|Johan Cruijff ArenA|SCHEDULED\n" +
            "2026-12-06|15|AZ|PSV|AFAS Stadion|SCHEDULED\n" +
            "2026-12-06|15|Fortuna Sittard|PEC Zwolle|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2026-12-06|15|Go Ahead Eagles|FC Twente|De Adelaarshorst|SCHEDULED\n" +
            "2026-12-06|15|SC Heerenveen|SC Cambuur|Abe Lenstra Stadion|SCHEDULED\n" +
            "2026-12-06|15|Sparta Rotterdam|N.E.C.|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2026-12-06|15|Telstar|FC Groningen|711 Stadion|SCHEDULED\n" +
            "2026-12-06|15|Willem II|Feyenoord|Koning Willem II Stadion|SCHEDULED\n" +
            "2026-12-13|16|Ajax|SC Cambuur|Johan Cruijff ArenA|SCHEDULED\n" +
            "2026-12-13|16|AZ|N.E.C.|AFAS Stadion|SCHEDULED\n" +
            "2026-12-13|16|FC Groningen|Feyenoord|Euroborg|SCHEDULED\n" +
            "2026-12-13|16|FC Twente|Sparta Rotterdam|De Grolsch Veste|SCHEDULED\n" +
            "2026-12-13|16|FC Utrecht|Fortuna Sittard|Stadion Galgenwaard|SCHEDULED\n" +
            "2026-12-13|16|PEC Zwolle|Excelsior Rotterdam|MAC³PARK Stadion|SCHEDULED\n" +
            "2026-12-13|16|PSV|Telstar|Philips Stadion|SCHEDULED\n" +
            "2026-12-13|16|SC Heerenveen|Go Ahead Eagles|Abe Lenstra Stadion|SCHEDULED\n" +
            "2026-12-13|16|Willem II|ADO Den Haag|Koning Willem II Stadion|SCHEDULED\n" +
            "2026-12-20|17|Excelsior Rotterdam|AZ|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2026-12-20|17|FC Utrecht|SC Heerenveen|Stadion Galgenwaard|SCHEDULED\n" +
            "2026-12-20|17|Feyenoord|FC Twente|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2026-12-20|17|Fortuna Sittard|Sparta Rotterdam|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2026-12-20|17|Go Ahead Eagles|Ajax|De Adelaarshorst|SCHEDULED\n" +
            "2026-12-20|17|N.E.C.|ADO Den Haag|Goffertstadion|SCHEDULED\n" +
            "2026-12-20|17|PSV|PEC Zwolle|Philips Stadion|SCHEDULED\n" +
            "2026-12-20|17|SC Cambuur|FC Groningen|Kooi Stadion|SCHEDULED\n" +
            "2026-12-20|17|Telstar|Willem II|711 Stadion|SCHEDULED\n" +
            "2027-01-08 20:00|18|FC Twente|Fortuna Sittard|De Grolsch Veste|TIMED\n" +
            "2027-01-09 16:30|18|Sparta Rotterdam|Excelsior Rotterdam|Sparta Stadion Het Kasteel|TIMED\n" +
            "2027-01-09 18:45|18|PEC Zwolle|FC Utrecht|MAC³PARK Stadion|TIMED\n" +
            "2027-01-09 20:00|18|Willem II|Ajax|Koning Willem II Stadion|TIMED\n" +
            "2027-01-09 21:00|18|AZ|SC Heerenveen|AFAS Stadion|TIMED\n" +
            "2027-01-10 12:15|18|N.E.C.|SC Cambuur|Goffertstadion|TIMED\n" +
            "2027-01-10 14:30|18|ADO Den Haag|Telstar|Bingoal Stadion|TIMED\n" +
            "2027-01-10 14:30|18|Feyenoord|PSV|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2027-01-10 16:45|18|FC Groningen|Go Ahead Eagles|Euroborg|TIMED\n" +
            "2027-01-17|19|ADO Den Haag|PEC Zwolle|Bingoal Stadion|SCHEDULED\n" +
            "2027-01-17|19|Ajax|FC Groningen|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-01-17|19|Excelsior Rotterdam|Feyenoord|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-01-17|19|FC Utrecht|FC Twente|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-01-17|19|Fortuna Sittard|PSV|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-01-17|19|Go Ahead Eagles|AZ|De Adelaarshorst|SCHEDULED\n" +
            "2027-01-17|19|SC Cambuur|Willem II|Kooi Stadion|SCHEDULED\n" +
            "2027-01-17|19|SC Heerenveen|Sparta Rotterdam|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-01-17|19|Telstar|N.E.C.|711 Stadion|SCHEDULED\n" +
            "2027-01-24|20|Ajax|Telstar|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-01-24|20|AZ|FC Utrecht|AFAS Stadion|SCHEDULED\n" +
            "2027-01-24|20|Excelsior Rotterdam|Fortuna Sittard|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-01-24|20|FC Twente|SC Heerenveen|De Grolsch Veste|SCHEDULED\n" +
            "2027-01-24|20|Feyenoord|PEC Zwolle|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-01-24|20|Go Ahead Eagles|SC Cambuur|De Adelaarshorst|SCHEDULED\n" +
            "2027-01-24|20|N.E.C.|Willem II|Goffertstadion|SCHEDULED\n" +
            "2027-01-24|20|PSV|ADO Den Haag|Philips Stadion|SCHEDULED\n" +
            "2027-01-24|20|Sparta Rotterdam|FC Groningen|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-01-31|21|ADO Den Haag|Go Ahead Eagles|Bingoal Stadion|SCHEDULED\n" +
            "2027-01-31|21|AZ|Feyenoord|AFAS Stadion|SCHEDULED\n" +
            "2027-01-31|21|FC Groningen|N.E.C.|Euroborg|SCHEDULED\n" +
            "2027-01-31|21|FC Twente|SC Cambuur|De Grolsch Veste|SCHEDULED\n" +
            "2027-01-31|21|FC Utrecht|Excelsior Rotterdam|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-01-31|21|PEC Zwolle|Fortuna Sittard|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-01-31|21|SC Heerenveen|Ajax|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-01-31|21|Sparta Rotterdam|Telstar|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-01-31|21|Willem II|PSV|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-02-14|22|Excelsior Rotterdam|Ajax|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-02-14|22|FC Groningen|AZ|Euroborg|SCHEDULED\n" +
            "2027-02-14|22|Feyenoord|N.E.C.|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-02-14|22|Fortuna Sittard|ADO Den Haag|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-02-14|22|Go Ahead Eagles|PEC Zwolle|De Adelaarshorst|SCHEDULED\n" +
            "2027-02-14|22|PSV|FC Twente|Philips Stadion|SCHEDULED\n" +
            "2027-02-14|22|SC Cambuur|FC Utrecht|Kooi Stadion|SCHEDULED\n" +
            "2027-02-14|22|Telstar|SC Heerenveen|711 Stadion|SCHEDULED\n" +
            "2027-02-14|22|Willem II|Sparta Rotterdam|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-02-21|23|Ajax|Go Ahead Eagles|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-02-21|23|AZ|Fortuna Sittard|AFAS Stadion|SCHEDULED\n" +
            "2027-02-21|23|FC Twente|Excelsior Rotterdam|De Grolsch Veste|SCHEDULED\n" +
            "2027-02-21|23|FC Utrecht|ADO Den Haag|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-02-21|23|Feyenoord|Telstar|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-02-21|23|N.E.C.|Sparta Rotterdam|Goffertstadion|SCHEDULED\n" +
            "2027-02-21|23|PEC Zwolle|FC Groningen|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-02-21|23|PSV|SC Cambuur|Philips Stadion|SCHEDULED\n" +
            "2027-02-21|23|SC Heerenveen|Willem II|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-02-28|24|ADO Den Haag|FC Twente|Bingoal Stadion|SCHEDULED\n" +
            "2027-02-28|24|Ajax|Feyenoord|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-02-28|24|Excelsior Rotterdam|SC Heerenveen|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-02-28|24|Fortuna Sittard|FC Utrecht|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-02-28|24|N.E.C.|AZ|Goffertstadion|SCHEDULED\n" +
            "2027-02-28|24|SC Cambuur|PEC Zwolle|Kooi Stadion|SCHEDULED\n" +
            "2027-02-28|24|Sparta Rotterdam|PSV|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-02-28|24|Telstar|Go Ahead Eagles|711 Stadion|SCHEDULED\n" +
            "2027-02-28|24|Willem II|FC Groningen|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-03-07|25|ADO Den Haag|Ajax|Bingoal Stadion|SCHEDULED\n" +
            "2027-03-07|25|FC Groningen|Telstar|Euroborg|SCHEDULED\n" +
            "2027-03-07|25|FC Twente|AZ|De Grolsch Veste|SCHEDULED\n" +
            "2027-03-07|25|Feyenoord|SC Heerenveen|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-03-07|25|Fortuna Sittard|N.E.C.|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-03-07|25|Go Ahead Eagles|Excelsior Rotterdam|De Adelaarshorst|SCHEDULED\n" +
            "2027-03-07|25|PEC Zwolle|Willem II|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-03-07|25|PSV|FC Utrecht|Philips Stadion|SCHEDULED\n" +
            "2027-03-07|25|Sparta Rotterdam|SC Cambuur|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-03-14|26|Ajax|PEC Zwolle|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-03-14|26|AZ|Sparta Rotterdam|AFAS Stadion|SCHEDULED\n" +
            "2027-03-14|26|Excelsior Rotterdam|N.E.C.|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-03-14|26|FC Utrecht|FC Groningen|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-03-14|26|Go Ahead Eagles|Feyenoord|De Adelaarshorst|SCHEDULED\n" +
            "2027-03-14|26|SC Cambuur|ADO Den Haag|Kooi Stadion|SCHEDULED\n" +
            "2027-03-14|26|SC Heerenveen|Fortuna Sittard|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-03-14|26|Telstar|PSV|711 Stadion|SCHEDULED\n" +
            "2027-03-14|26|Willem II|FC Twente|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-03-21|27|ADO Den Haag|Willem II|Bingoal Stadion|SCHEDULED\n" +
            "2027-03-21|27|AZ|Excelsior Rotterdam|AFAS Stadion|SCHEDULED\n" +
            "2027-03-21|27|FC Groningen|PSV|Euroborg|SCHEDULED\n" +
            "2027-03-21|27|FC Twente|Go Ahead Eagles|De Grolsch Veste|SCHEDULED\n" +
            "2027-03-21|27|FC Utrecht|Sparta Rotterdam|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-03-21|27|Feyenoord|SC Cambuur|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-03-21|27|N.E.C.|Ajax|Goffertstadion|SCHEDULED\n" +
            "2027-03-21|27|PEC Zwolle|SC Heerenveen|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-03-21|27|Telstar|Fortuna Sittard|711 Stadion|SCHEDULED\n" +
            "2027-04-04|28|Ajax|FC Twente|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-04-04|28|Excelsior Rotterdam|PEC Zwolle|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-04-04|28|Fortuna Sittard|Feyenoord|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-04-04|28|Go Ahead Eagles|N.E.C.|De Adelaarshorst|SCHEDULED\n" +
            "2027-04-04|28|PSV|AZ|Philips Stadion|SCHEDULED\n" +
            "2027-04-04|28|SC Cambuur|Telstar|Kooi Stadion|SCHEDULED\n" +
            "2027-04-04|28|SC Heerenveen|FC Groningen|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-04-04|28|Sparta Rotterdam|ADO Den Haag|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-04-04|28|Willem II|FC Utrecht|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-04-11|29|ADO Den Haag|Feyenoord|Bingoal Stadion|SCHEDULED\n" +
            "2027-04-11|29|FC Groningen|Excelsior Rotterdam|Euroborg|SCHEDULED\n" +
            "2027-04-11|29|FC Utrecht|Ajax|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-04-11|29|N.E.C.|SC Heerenveen|Goffertstadion|SCHEDULED\n" +
            "2027-04-11|29|PEC Zwolle|PSV|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-04-11|29|SC Cambuur|Fortuna Sittard|Kooi Stadion|SCHEDULED\n" +
            "2027-04-11|29|Sparta Rotterdam|Go Ahead Eagles|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-04-11|29|Telstar|FC Twente|711 Stadion|SCHEDULED\n" +
            "2027-04-11|29|Willem II|AZ|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-04-25|30|AZ|SC Cambuur|AFAS Stadion|SCHEDULED\n" +
            "2027-04-25|30|Excelsior Rotterdam|Willem II|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-04-25|30|FC Twente|N.E.C.|De Grolsch Veste|SCHEDULED\n" +
            "2027-04-25|30|Feyenoord|Sparta Rotterdam|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-04-25|30|Fortuna Sittard|FC Groningen|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-04-25|30|Go Ahead Eagles|FC Utrecht|De Adelaarshorst|SCHEDULED\n" +
            "2027-04-25|30|PEC Zwolle|Telstar|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-04-25|30|PSV|Ajax|Philips Stadion|SCHEDULED\n" +
            "2027-04-25|30|SC Heerenveen|ADO Den Haag|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-05-02|31|Ajax|Fortuna Sittard|Johan Cruijff ArenA|SCHEDULED\n" +
            "2027-05-02|31|Excelsior Rotterdam|SC Cambuur|Van Donge & De Roo Stadion|SCHEDULED\n" +
            "2027-05-02|31|FC Groningen|ADO Den Haag|Euroborg|SCHEDULED\n" +
            "2027-05-02|31|Feyenoord|Willem II|Stadion Feijenoord - De Kuip|SCHEDULED\n" +
            "2027-05-02|31|Go Ahead Eagles|PSV|De Adelaarshorst|SCHEDULED\n" +
            "2027-05-02|31|N.E.C.|PEC Zwolle|Goffertstadion|SCHEDULED\n" +
            "2027-05-02|31|SC Heerenveen|FC Utrecht|Abe Lenstra Stadion|SCHEDULED\n" +
            "2027-05-02|31|Sparta Rotterdam|FC Twente|Sparta Stadion Het Kasteel|SCHEDULED\n" +
            "2027-05-02|31|Telstar|AZ|711 Stadion|SCHEDULED\n" +
            "2027-05-09|32|ADO Den Haag|N.E.C.|Bingoal Stadion|SCHEDULED\n" +
            "2027-05-09|32|AZ|Ajax|AFAS Stadion|SCHEDULED\n" +
            "2027-05-09|32|FC Twente|FC Groningen|De Grolsch Veste|SCHEDULED\n" +
            "2027-05-09|32|FC Utrecht|Feyenoord|Stadion Galgenwaard|SCHEDULED\n" +
            "2027-05-09|32|Fortuna Sittard|Go Ahead Eagles|Fortuna Sittard Stadion|SCHEDULED\n" +
            "2027-05-09|32|PEC Zwolle|Sparta Rotterdam|MAC³PARK Stadion|SCHEDULED\n" +
            "2027-05-09|32|PSV|Excelsior Rotterdam|Philips Stadion|SCHEDULED\n" +
            "2027-05-09|32|SC Cambuur|SC Heerenveen|Kooi Stadion|SCHEDULED\n" +
            "2027-05-09|32|Willem II|Telstar|Koning Willem II Stadion|SCHEDULED\n" +
            "2027-05-16 14:30|33|Ajax|Sparta Rotterdam|Johan Cruijff ArenA|TIMED\n" +
            "2027-05-16 14:30|33|AZ|PEC Zwolle|AFAS Stadion|TIMED\n" +
            "2027-05-16 14:30|33|Excelsior Rotterdam|ADO Den Haag|Van Donge & De Roo Stadion|TIMED\n" +
            "2027-05-16 14:30|33|FC Groningen|SC Cambuur|Euroborg|TIMED\n" +
            "2027-05-16 14:30|33|FC Twente|Feyenoord|De Grolsch Veste|TIMED\n" +
            "2027-05-16 14:30|33|FC Utrecht|Telstar|Stadion Galgenwaard|TIMED\n" +
            "2027-05-16 14:30|33|Fortuna Sittard|Willem II|Fortuna Sittard Stadion|TIMED\n" +
            "2027-05-16 14:30|33|Go Ahead Eagles|SC Heerenveen|De Adelaarshorst|TIMED\n" +
            "2027-05-16 14:30|33|PSV|N.E.C.|Philips Stadion|TIMED\n" +
            "2027-05-23 14:30|34|ADO Den Haag|AZ|Bingoal Stadion|TIMED\n" +
            "2027-05-23 14:30|34|Feyenoord|FC Groningen|Stadion Feijenoord - De Kuip|TIMED\n" +
            "2027-05-23 14:30|34|N.E.C.|FC Utrecht|Goffertstadion|TIMED\n" +
            "2027-05-23 14:30|34|PEC Zwolle|FC Twente|MAC³PARK Stadion|TIMED\n" +
            "2027-05-23 14:30|34|SC Cambuur|Ajax|Kooi Stadion|TIMED\n" +
            "2027-05-23 14:30|34|SC Heerenveen|PSV|Abe Lenstra Stadion|TIMED\n" +
            "2027-05-23 14:30|34|Sparta Rotterdam|Fortuna Sittard|Sparta Stadion Het Kasteel|TIMED\n" +
            "2027-05-23 14:30|34|Telstar|Excelsior Rotterdam|711 Stadion|TIMED\n" +
            "2027-05-23 14:30|34|Willem II|Go Ahead Eagles|Koning Willem II Stadion|TIMED\n";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        TLA.put("ADO Den Haag", "ADO");
        TLA.put("Ajax", "AJA");
        TLA.put("AZ", "AZ");
        TLA.put("Excelsior Rotterdam", "EXC");
        TLA.put("FC Groningen", "GRO");
        TLA.put("FC Twente", "TWE");
        TLA.put("FC Utrecht", "UTR");
        TLA.put("Feyenoord", "FEY");
        TLA.put("Fortuna Sittard", "FOR");
        TLA.put("Go Ahead Eagles", "GAE");
        TLA.put("N.E.C.", "NEC");
        TLA.put("PEC Zwolle", "PEC");
        TLA.put("PSV", "PSV");
        TLA.put("SC Cambuur", "CAM");
        TLA.put("SC Heerenveen", "HEE");
        TLA.put("Sparta Rotterdam", "SPA");
        TLA.put("Telstar", "TEL");
        TLA.put("Willem II", "WIL");

        CRESTS.put("ADO Den Haag", "https://eredivisie.b-cdn.net/production/clubs/ado-den-haag/ADODenHaag_Logo.png");
        CRESTS.put("Ajax", "https://eredivisie.b-cdn.net/production/clubs/ajax/Ajax_Logo.png");
        CRESTS.put("AZ", "https://eredivisie.b-cdn.net/production/clubs/az/AZ_Logo.png");
        CRESTS.put("Excelsior Rotterdam", "https://eredivisie.b-cdn.net/production/clubs/excelsior-rotterdam/ExcelsiorRotterdam_Logo.png");
        CRESTS.put("FC Groningen", "https://eredivisie.b-cdn.net/production/clubs/fc-groningen/FCGroningen_Logo.png");
        CRESTS.put("FC Twente", "https://eredivisie.b-cdn.net/production/clubs/fc-twente/FCTwente_Logo.png");
        CRESTS.put("FC Utrecht", "https://eredivisie.b-cdn.net/production/clubs/fc-utrecht/FCUtrecht_Logo.png");
        CRESTS.put("Feyenoord", "https://eredivisie.b-cdn.net/production/clubs/feyenoord/Feyenoord_Logo.png");
        CRESTS.put("Fortuna Sittard", "https://eredivisie.b-cdn.net/production/clubs/fortuna-sittard/FortunaSittard_Logo.png");
        CRESTS.put("Go Ahead Eagles", "https://eredivisie.b-cdn.net/production/clubs/go-ahead-eagles/GoAheadEagles_Logo.png");
        CRESTS.put("N.E.C.", "https://eredivisie.b-cdn.net/production/clubs/nec-nijmegen/NEC_Nijmegen_Logo.png");
        CRESTS.put("PEC Zwolle", "https://eredivisie.b-cdn.net/production/clubs/pec-zwolle/PECZwolle_Logo.png");
        CRESTS.put("PSV", "https://eredivisie.b-cdn.net/production/clubs/psv/PSV_Logo.png");
        CRESTS.put("SC Cambuur", "https://eredivisie.b-cdn.net/production/clubs/sc-cambuur/SCCambuur_Logo.png");
        CRESTS.put("SC Heerenveen", "https://eredivisie.b-cdn.net/production/clubs/sc-heerenveen/scHeerenveen_Logo.png");
        CRESTS.put("Sparta Rotterdam", "https://eredivisie.b-cdn.net/production/clubs/sparta-rotterdam/SpartaRotterdam_Logo.png");
        CRESTS.put("Telstar", "https://eredivisie.b-cdn.net/production/clubs/telstar/Telstar_Logo.png");
        CRESTS.put("Willem II", "https://eredivisie.b-cdn.net/production/clubs/willem-ii/WillemII_Logo.png");

        VENUES.put("ADO Den Haag", "Bingoal Stadion");
        VENUES.put("Ajax", "Johan Cruijff ArenA");
        VENUES.put("AZ", "AFAS Stadion");
        VENUES.put("Excelsior Rotterdam", "Van Donge & De Roo Stadion");
        VENUES.put("FC Groningen", "Euroborg");
        VENUES.put("FC Twente", "De Grolsch Veste");
        VENUES.put("FC Utrecht", "Stadion Galgenwaard");
        VENUES.put("Feyenoord", "Stadion Feijenoord - De Kuip");
        VENUES.put("Fortuna Sittard", "Fortuna Sittard Stadion");
        VENUES.put("Go Ahead Eagles", "De Adelaarshorst");
        VENUES.put("N.E.C.", "Goffertstadion");
        VENUES.put("PEC Zwolle", "MAC³PARK Stadion");
        VENUES.put("PSV", "Philips Stadion");
        VENUES.put("SC Cambuur", "Kooi Stadion");
        VENUES.put("SC Heerenveen", "Abe Lenstra Stadion");
        VENUES.put("Sparta Rotterdam", "Sparta Stadion Het Kasteel");
        VENUES.put("Telstar", "711 Stadion");
        VENUES.put("Willem II", "Koning Willem II Stadion");

        FOUNDED.put("ADO Den Haag", 1905);
        FOUNDED.put("Ajax", 1900);
        FOUNDED.put("AZ", 1967);
        FOUNDED.put("Excelsior Rotterdam", 1902);
        FOUNDED.put("FC Groningen", 1971);
        FOUNDED.put("FC Twente", 1965);
        FOUNDED.put("FC Utrecht", 1970);
        FOUNDED.put("Feyenoord", 1908);
        FOUNDED.put("Fortuna Sittard", 1968);
        FOUNDED.put("Go Ahead Eagles", 1902);
        FOUNDED.put("N.E.C.", 1900);
        FOUNDED.put("PEC Zwolle", 1910);
        FOUNDED.put("PSV", 1913);
        FOUNDED.put("SC Cambuur", 1964);
        FOUNDED.put("SC Heerenveen", 1920);
        FOUNDED.put("Sparta Rotterdam", 1888);
        FOUNDED.put("Telstar", 1963);
        FOUNDED.put("Willem II", 1896);

        WEBSITES.put("ADO Den Haag", "https://adodenhaag.nl");
        WEBSITES.put("Ajax", "https://www.ajax.nl");
        WEBSITES.put("AZ", "https://www.az.nl");
        WEBSITES.put("Excelsior Rotterdam", "https://excelsiorrotterdam.nl");
        WEBSITES.put("FC Groningen", "https://www.fcgroningen.nl");
        WEBSITES.put("FC Twente", "https://www.fctwente.nl");
        WEBSITES.put("FC Utrecht", "https://www.fcutrecht.nl");
        WEBSITES.put("Feyenoord", "https://www.feyenoord.nl");
        WEBSITES.put("Fortuna Sittard", "https://www.fortunasittard.nl");
        WEBSITES.put("Go Ahead Eagles", "https://www.ga-eagles.nl");
        WEBSITES.put("N.E.C.", "https://www.nec-nijmegen.nl");
        WEBSITES.put("PEC Zwolle", "https://peczwolle.nl");
        WEBSITES.put("PSV", "https://www.psv.nl");
        WEBSITES.put("SC Cambuur", "https://cambuur.nl");
        WEBSITES.put("SC Heerenveen", "https://www.sc-heerenveen.nl");
        WEBSITES.put("Sparta Rotterdam", "https://www.sparta-rotterdam.nl");
        WEBSITES.put("Telstar", "https://sctelstar.nl");
        WEBSITES.put("Willem II", "https://www.willem-ii.nl");

        COLORS.put("ADO Den Haag", "Yellow / Green");
        COLORS.put("Ajax", "Red / White");
        COLORS.put("AZ", "Red / White");
        COLORS.put("Excelsior Rotterdam", "Red / Black");
        COLORS.put("FC Groningen", "Green / White");
        COLORS.put("FC Twente", "Red");
        COLORS.put("FC Utrecht", "Red / White");
        COLORS.put("Feyenoord", "Red / White / Black");
        COLORS.put("Fortuna Sittard", "Yellow / Green");
        COLORS.put("Go Ahead Eagles", "Red / Yellow");
        COLORS.put("N.E.C.", "Red / Green / Black");
        COLORS.put("PEC Zwolle", "Blue / White");
        COLORS.put("PSV", "Red / White");
        COLORS.put("SC Cambuur", "Yellow / Blue");
        COLORS.put("SC Heerenveen", "Blue / White");
        COLORS.put("Sparta Rotterdam", "Red / White");
        COLORS.put("Telstar", "White / Red / Blue");
        COLORS.put("Willem II", "Red / White / Blue");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutEredivisie(root.optJSONArray("matches")));
            root.put("live", copyWithoutEredivisie(root.optJSONArray("live")));
            root.put("finished", copyWithoutEredivisie(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutEredivisie(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // A future malformed manual update must never block other leagues.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonEredivisie(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "DED-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "SCHEDULED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "Official Eredivisie / KNVB 2026/27 programme");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Eredivisie source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"tla", "crest", "emblem", "logo", "venue", "address", "website", "clubColors", "founded"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            Object raw = richer.opt(key);
            String value = String.valueOf(raw).trim();
            if (value.length() > 0 && !"null".equalsIgnoreCase(value)) out.put(key, raw);
        }
        Object richerArea = richer.opt("area");
        if (richerArea instanceof JSONObject) out.put("area", richerArea);
        else if (richerArea != null && String.valueOf(richerArea).trim().length() > 0) {
            JSONObject area = new JSONObject(); area.put("name", String.valueOf(richerArea).trim()); out.put("area", area);
        }
        String name = out.optString("name", out.optString("shortName", ""));
        String canonical = canonicalName(name);
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(canonical)) out.put("crest", CRESTS.get(canonical));
        return out;
    }

    private static JSONArray copyWithoutEredivisie(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isEredivisie(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonEredivisie(JSONObject row) {
        if (!isEredivisie(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isEredivisie(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        String rawCode = ""; String rawName = "";
        if (raw instanceof JSONObject) { JSONObject c = (JSONObject) raw; rawCode = c.optString("code", ""); rawName = c.optString("name", ""); }
        else if (raw != null) rawName = String.valueOf(raw);
        String rowCode = row.optString("competitionCode", "");
        String rawCodeNormalized = normalize(rawCode); String rowCodeNormalized = normalize(rowCode);
        if (rawCodeNormalized.equals("ded") || rowCodeNormalized.equals("ded")) return true;
        if (rawCodeNormalized.length() > 0 || rowCodeNormalized.length() > 0) return false;
        String rowName = row.optString("competitionName", "");
        String rawNormalized = normalize(rawName); String rowNormalized = normalize(rowName);
        return rawNormalized.equals("eredivisie") || rowNormalized.equals("eredivisie");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true); String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0; String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30; else if (isLive(status)) score += 25; else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2; if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") || value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject(); competition.put("code", COMPETITION_CODE); competition.put("name", COMPETITION_NAME); return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject(); team.put("name", name); team.put("shortName", name); team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        JSONObject area = new JSONObject(); area.put("name", "Netherlands"); team.put("area", area);
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        if (VENUES.containsKey(name)) team.put("venue", VENUES.get(name));
        if (FOUNDED.containsKey(name)) team.put("founded", FOUNDED.get(name));
        if (WEBSITES.containsKey(name)) team.put("website", WEBSITES.get(name));
        if (COLORS.containsKey(name)) team.put("clubColors", COLORS.get(name));
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = new JSONArray();
        if (source != null) {
            for (int i = 0; i < source.length(); i++) {
                JSONObject team = source.optJSONObject(i); if (team == null) continue;
                String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
                if (isCurrentOrStaleEredivisieClub(name)) continue;
                teams.put(new JSONObject(team.toString()));
            }
        }
        for (String name : TLA.keySet()) teams.put(teamObject(name));
        root.put("teams", teams);
    }

    private static boolean isCurrentOrStaleEredivisieClub(String value) {
        String key = clubKey(value);
        if (TLA.containsKey(canonicalName(value))) return true;
        return key.equals("heraclesalmelo") || key.equals("nacbreda") || key.equals("volendam") ||
                key.equals("almerecity") || key.equals("rkcwaalwijk");
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings"); if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE); if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", ""); String end = season == null ? "" : season.optString("endDate", "");
        if (!(start.startsWith("2026") && end.startsWith("2027"))) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources"); if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject eredivisie = sources.optJSONObject(COMPETITION_CODE); if (eredivisie == null) eredivisie = new JSONObject();
        eredivisie.put("status", "connected");
        eredivisie.put("provider", "Official Eredivisie / KNVB 2026/27 programme + connected live source");
        eredivisie.put("season", SEASON); eredivisie.put("matchCount", matchCount); eredivisie.put("teamCount", TLA.size()); eredivisie.put("roundCount", 34);
        sources.put(COMPETITION_CODE, eredivisie);
    }

    private static String canonicalName(String value) {
        String key = clubKey(value);
        for (String name : TLA.keySet()) if (clubKey(name).equals(key)) return name;
        return value == null ? "" : value.trim();
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("afcajax") || key.equals("ajaxamsterdam")) return "ajax";
        if (key.equals("azalkmaar") || key.equals("az67")) return "az";
        if (key.equals("excelsior") || key.equals("sbvexcelsior")) return "excelsiorrotterdam";
        if (key.equals("groningen")) return "fcgroningen";
        if (key.equals("twente") || key.equals("twenteenschede")) return "fctwente";
        if (key.equals("utrecht")) return "fcutrecht";
        if (key.equals("fortuna")) return "fortunasittard";
        if (key.equals("goaheadeaglesdeventer")) return "goaheadeagles";
        if (key.equals("nec") || key.equals("necnijmegen")) return "nec";
        if (key.equals("zwolle")) return "peczwolle";
        if (key.equals("psveindhoven")) return "psv";
        if (key.equals("cambuur") || key.equals("cambuurleeuwarden")) return "sccambuur";
        if (key.equals("heerenveen") || key.equals("scheerenveenfriesland")) return "scheerenveen";
        if (key.equals("sparta")) return "spartarotterdam";
        if (key.equals("sctelstar") || key.equals("telstarijmuiden")) return "telstar";
        if (key.equals("willem2")) return "willemii";
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private Eredivisie2627Data() {}
}
