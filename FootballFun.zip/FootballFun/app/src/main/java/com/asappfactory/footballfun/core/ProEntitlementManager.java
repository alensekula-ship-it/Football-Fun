package com.asappfactory.footballfun.core;

import com.asappfactory.footballfun.data.UserPreferences;

/**
 * Single source of truth for Football Fun Free/Pro policy.
 *
 * Point 11 Release Candidate entitlement policy.
 * Debug/QA builds remain fully unlocked for development; public builds use Google Play entitlement.
 */
public final class ProEntitlementManager {
    public static final int FREE_FAVORITE_CLUBS = 3;
    public static final int FREE_FAVORITE_NATIONAL_TEAMS = 1;
    public static final int FREE_FOLLOWED_COMPETITIONS = 2;
    public static final int FREE_FOLLOWED_MATCHES = 3;

    // Google Play Console structure:
    // subscription product: football_fun_pro
    // base plans: monthly / yearly
    // optional monthly trial offer: free-trial-7d
    public static final String PRO_PRODUCT_ID = "football_fun_pro";
    public static final String MONTHLY_BASE_PLAN_ID = "monthly";
    public static final String YEARLY_BASE_PLAN_ID = "yearly";
    public static final String MONTHLY_TRIAL_OFFER_ID = "free-trial-7d";

    // Informational fallback labels only. Google Play will be authoritative for
    // localized price/renewal text after BillingClient is connected.
    public static final String MONTHLY_PRICE_FALLBACK = "1,99 €";
    public static final String YEARLY_PRICE_FALLBACK = "14,99 €";

    private final UserPreferences preferences;
    private volatile boolean googlePlayEntitled;

    public ProEntitlementManager(UserPreferences preferences){
        this.preferences = preferences;
    }

    /** Single entitlement contract for the Release Candidate.
     * Debug builds remain QA-unlocked. Public builds rely on Google Play entitlement only.
     */
    public boolean isPro(){
        return AppConfig.QA_UNLOCK_ALL_PRO || googlePlayEntitled;
    }


    public void setGooglePlayEntitled(boolean entitled){
        this.googlePlayEntitled = entitled;
    }

    public boolean isGooglePlayEntitled(){ return googlePlayEntitled; }

    /** True only while internal QA unlock is active. */
    public boolean isQaUnlocked(){
        return AppConfig.QA_UNLOCK_ALL_PRO;
    }

    public int freeFavoriteClubLimit(){ return FREE_FAVORITE_CLUBS; }
    public int freeFavoriteNationalTeamLimit(){ return FREE_FAVORITE_NATIONAL_TEAMS; }
    public int freeCompetitionLimit(){ return FREE_FOLLOWED_COMPETITIONS; }
    public int freeFollowedMatchLimit(){ return FREE_FOLLOWED_MATCHES; }

    public String proProductId(){ return PRO_PRODUCT_ID; }
    public String monthlyBasePlanId(){ return MONTHLY_BASE_PLAN_ID; }
    public String yearlyBasePlanId(){ return YEARLY_BASE_PLAN_ID; }

    private ProEntitlementManager(){
        this.preferences = null;
    }
}
