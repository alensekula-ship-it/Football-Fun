package com.asappfactory.footballfun.timeline;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public final class TimelineProviderManager {
    private final List<TimelineProvider> providers = new ArrayList<>();

    public TimelineProviderManager add(TimelineProvider provider) {
        if (provider != null) providers.add(provider);
        return this;
    }

    public String format(JSONObject match, TimelineEnvironment env) {
        if (match == null || env == null) return "";
        for (TimelineProvider provider : providers) {
            if (provider.supports(match)) {
                String result = provider.format(match, env);
                if (result != null && !result.trim().isEmpty()) return result.trim();
            }
        }
        return "";
    }

    public static TimelineProviderManager createDefault() {
        return new TimelineProviderManager().add(new FootballDataTimelineProvider());
    }
}
