package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Complete verified La Liga 2026/27 fixture fallback.
 *
 * The bundled list keeps all 20 clubs, 38 rounds and 380 fixtures available
 * before the connected provider exposes the new season. Matching connected
 * rows are merged over the fallback so live status, scores and later fixture
 * changes still win without creating duplicates.
 */
public final class LaLiga2627Data {
    private static final String COMPETITION_NAME = "La Liga";
    private static final String COMPETITION_CODE = "PD";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-16";
    private static final String LAST_DATE = "2027-05-30";

    private static final String DATA =
            "2026-08-16|1|Deportivo Alavés|Getafe CF|Mendizorrotza|SCHEDULED\n" +
            "2026-08-16|1|Atlético de Madrid|Málaga CF|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-08-16|1|Celta de Vigo|CA Osasuna|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-08-16|1|Deportivo La Coruña|Elche CF|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-08-16|1|RCD Espanyol|Levante UD|RCDE Stadium|SCHEDULED\n" +
            "2026-08-16|1|FC Barcelona|Athletic Club|Spotify Camp Nou|SCHEDULED\n" +
            "2026-08-16|1|Racing Santander|Villarreal CF|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-08-16|1|Real Madrid|Real Sociedad|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-08-16|1|Sevilla FC|Rayo Vallecano|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-08-16|1|Valencia CF|Real Betis|Estadio de Mestalla|SCHEDULED\n" +
            "2026-08-23|2|Athletic Club|Sevilla FC|San Mamés|SCHEDULED\n" +
            "2026-08-23|2|Atlético de Madrid|Villarreal CF|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-08-23|2|Real Betis|Real Sociedad|Estadio La Cartuja|SCHEDULED\n" +
            "2026-08-23|2|Elche CF|FC Barcelona|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-08-23|2|RCD Espanyol|Real Madrid|RCDE Stadium|SCHEDULED\n" +
            "2026-08-23|2|Getafe CF|Racing Santander|Coliseum|SCHEDULED\n" +
            "2026-08-23|2|Málaga CF|Deportivo La Coruña|La Rosaleda|SCHEDULED\n" +
            "2026-08-23|2|CA Osasuna|Levante UD|El Sadar|SCHEDULED\n" +
            "2026-08-23|2|Rayo Vallecano|Deportivo Alavés|Estadio de Vallecas|SCHEDULED\n" +
            "2026-08-23|2|Valencia CF|Celta de Vigo|Estadio de Mestalla|SCHEDULED\n" +
            "2026-08-30|3|Deportivo Alavés|Villarreal CF|Mendizorrotza|SCHEDULED\n" +
            "2026-08-30|3|Celta de Vigo|Athletic Club|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-08-30|3|Deportivo La Coruña|Valencia CF|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-08-30|3|FC Barcelona|Rayo Vallecano|Spotify Camp Nou|SCHEDULED\n" +
            "2026-08-30|3|Levante UD|Real Betis|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-08-30|3|CA Osasuna|Getafe CF|El Sadar|SCHEDULED\n" +
            "2026-08-30|3|Racing Santander|Elche CF|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-08-30|3|Real Madrid|Málaga CF|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-08-30|3|Real Sociedad|RCD Espanyol|Reale Arena|SCHEDULED\n" +
            "2026-08-30|3|Sevilla FC|Atlético de Madrid|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-09-06|4|Deportivo Alavés|CA Osasuna|Mendizorrotza|SCHEDULED\n" +
            "2026-09-06|4|Athletic Club|Atlético de Madrid|San Mamés|SCHEDULED\n" +
            "2026-09-06|4|Real Betis|Real Madrid|Estadio La Cartuja|SCHEDULED\n" +
            "2026-09-06|4|Elche CF|Real Sociedad|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-09-06|4|RCD Espanyol|Sevilla FC|RCDE Stadium|SCHEDULED\n" +
            "2026-09-06|4|Getafe CF|Celta de Vigo|Coliseum|SCHEDULED\n" +
            "2026-09-06|4|Málaga CF|Levante UD|La Rosaleda|SCHEDULED\n" +
            "2026-09-06|4|Rayo Vallecano|Racing Santander|Estadio de Vallecas|SCHEDULED\n" +
            "2026-09-06|4|Valencia CF|FC Barcelona|Estadio de Mestalla|SCHEDULED\n" +
            "2026-09-06|4|Villarreal CF|Deportivo La Coruña|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-09-13|5|Athletic Club|Elche CF|San Mamés|SCHEDULED\n" +
            "2026-09-13|5|Celta de Vigo|Málaga CF|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-09-13|5|Getafe CF|Deportivo La Coruña|Coliseum|SCHEDULED\n" +
            "2026-09-13|5|Levante UD|FC Barcelona|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-09-13|5|CA Osasuna|RCD Espanyol|El Sadar|SCHEDULED\n" +
            "2026-09-13|5|Racing Santander|Deportivo Alavés|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-09-13|5|Real Madrid|Rayo Vallecano|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-09-13|5|Real Sociedad|Atlético de Madrid|Reale Arena|SCHEDULED\n" +
            "2026-09-13|5|Sevilla FC|Valencia CF|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-09-13|5|Villarreal CF|Real Betis|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-09-16|6|Deportivo Alavés|Valencia CF|Mendizorrotza|SCHEDULED\n" +
            "2026-09-16|6|Atlético de Madrid|CA Osasuna|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-09-16|6|Real Betis|Getafe CF|Estadio La Cartuja|SCHEDULED\n" +
            "2026-09-16|6|Deportivo La Coruña|Sevilla FC|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-09-16|6|Elche CF|Real Madrid|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-09-16|6|FC Barcelona|Racing Santander|Spotify Camp Nou|SCHEDULED\n" +
            "2026-09-16|6|Levante UD|Athletic Club|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-09-16|6|Málaga CF|Villarreal CF|La Rosaleda|SCHEDULED\n" +
            "2026-09-16|6|Rayo Vallecano|RCD Espanyol|Estadio de Vallecas|SCHEDULED\n" +
            "2026-09-16|6|Real Sociedad|Celta de Vigo|Reale Arena|SCHEDULED\n" +
            "2026-09-20|7|Athletic Club|Deportivo Alavés|San Mamés|SCHEDULED\n" +
            "2026-09-20|7|Atlético de Madrid|Real Madrid|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-09-20|7|Celta de Vigo|Racing Santander|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-09-20|7|Deportivo La Coruña|Real Betis|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-09-20|7|RCD Espanyol|Elche CF|RCDE Stadium|SCHEDULED\n" +
            "2026-09-20|7|Getafe CF|Málaga CF|Coliseum|SCHEDULED\n" +
            "2026-09-20|7|CA Osasuna|Rayo Vallecano|El Sadar|SCHEDULED\n" +
            "2026-09-20|7|Sevilla FC|FC Barcelona|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-09-20|7|Valencia CF|Real Sociedad|Estadio de Mestalla|SCHEDULED\n" +
            "2026-09-20|7|Villarreal CF|Levante UD|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-10-11|8|Deportivo Alavés|Atlético de Madrid|Mendizorrotza|SCHEDULED\n" +
            "2026-10-11|8|Real Betis|CA Osasuna|Estadio La Cartuja|SCHEDULED\n" +
            "2026-10-11|8|Elche CF|Celta de Vigo|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-10-11|8|FC Barcelona|Getafe CF|Spotify Camp Nou|SCHEDULED\n" +
            "2026-10-11|8|Levante UD|Sevilla FC|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-10-11|8|Málaga CF|RCD Espanyol|La Rosaleda|SCHEDULED\n" +
            "2026-10-11|8|Racing Santander|Valencia CF|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-10-11|8|Rayo Vallecano|Athletic Club|Estadio de Vallecas|SCHEDULED\n" +
            "2026-10-11|8|Real Madrid|Villarreal CF|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-10-11|8|Real Sociedad|Deportivo La Coruña|Reale Arena|SCHEDULED\n" +
            "2026-10-18|9|Real Betis|FC Barcelona|Estadio La Cartuja|SCHEDULED\n" +
            "2026-10-18|9|Celta de Vigo|Deportivo Alavés|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-10-18|9|Deportivo La Coruña|Levante UD|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-10-18|9|RCD Espanyol|Atlético de Madrid|RCDE Stadium|SCHEDULED\n" +
            "2026-10-18|9|Getafe CF|Rayo Vallecano|Coliseum|SCHEDULED\n" +
            "2026-10-18|9|Málaga CF|Real Sociedad|La Rosaleda|SCHEDULED\n" +
            "2026-10-18|9|CA Osasuna|Racing Santander|El Sadar|SCHEDULED\n" +
            "2026-10-18|9|Real Madrid|Sevilla FC|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-10-18|9|Valencia CF|Athletic Club|Estadio de Mestalla|SCHEDULED\n" +
            "2026-10-18|9|Villarreal CF|Elche CF|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-10-25|10|Deportivo Alavés|Málaga CF|Mendizorrotza|SCHEDULED\n" +
            "2026-10-25|10|Athletic Club|Getafe CF|San Mamés|SCHEDULED\n" +
            "2026-10-25|10|Atlético de Madrid|Deportivo La Coruña|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-10-25|10|Celta de Vigo|Real Betis|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-10-25|10|FC Barcelona|Real Madrid|Spotify Camp Nou|SCHEDULED\n" +
            "2026-10-25|10|Racing Santander|RCD Espanyol|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-10-25|10|Rayo Vallecano|Elche CF|Estadio de Vallecas|SCHEDULED\n" +
            "2026-10-25|10|Real Sociedad|Levante UD|Reale Arena|SCHEDULED\n" +
            "2026-10-25|10|Sevilla FC|CA Osasuna|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-10-25|10|Valencia CF|Villarreal CF|Estadio de Mestalla|SCHEDULED\n" +
            "2026-11-01|11|Athletic Club|Real Sociedad|San Mamés|SCHEDULED\n" +
            "2026-11-01|11|Real Betis|Málaga CF|Estadio La Cartuja|SCHEDULED\n" +
            "2026-11-01|11|Deportivo La Coruña|CA Osasuna|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-11-01|11|Elche CF|Valencia CF|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-11-01|11|FC Barcelona|Deportivo Alavés|Spotify Camp Nou|SCHEDULED\n" +
            "2026-11-01|11|Getafe CF|Sevilla FC|Coliseum|SCHEDULED\n" +
            "2026-11-01|11|Levante UD|Atlético de Madrid|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-11-01|11|Racing Santander|Real Madrid|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-11-01|11|Rayo Vallecano|Celta de Vigo|Estadio de Vallecas|SCHEDULED\n" +
            "2026-11-01|11|Villarreal CF|RCD Espanyol|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-11-08|12|Atlético de Madrid|FC Barcelona|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-11-08|12|Celta de Vigo|Levante UD|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-11-08|12|Elche CF|Real Betis|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-11-08|12|RCD Espanyol|Deportivo La Coruña|RCDE Stadium|SCHEDULED\n" +
            "2026-11-08|12|Málaga CF|Racing Santander|La Rosaleda|SCHEDULED\n" +
            "2026-11-08|12|CA Osasuna|Athletic Club|El Sadar|SCHEDULED\n" +
            "2026-11-08|12|Real Sociedad|Rayo Vallecano|Reale Arena|SCHEDULED\n" +
            "2026-11-08|12|Sevilla FC|Deportivo Alavés|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-11-08|12|Valencia CF|Real Madrid|Estadio de Mestalla|SCHEDULED\n" +
            "2026-11-08|12|Villarreal CF|Getafe CF|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-11-22|13|Deportivo Alavés|Deportivo La Coruña|Mendizorrotza|SCHEDULED\n" +
            "2026-11-22|13|Athletic Club|RCD Espanyol|San Mamés|SCHEDULED\n" +
            "2026-11-22|13|FC Barcelona|Villarreal CF|Spotify Camp Nou|SCHEDULED\n" +
            "2026-11-22|13|Getafe CF|Atlético de Madrid|Coliseum|SCHEDULED\n" +
            "2026-11-22|13|Levante UD|Elche CF|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-11-22|13|CA Osasuna|Málaga CF|El Sadar|SCHEDULED\n" +
            "2026-11-22|13|Racing Santander|Real Sociedad|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-11-22|13|Rayo Vallecano|Valencia CF|Estadio de Vallecas|SCHEDULED\n" +
            "2026-11-22|13|Real Madrid|Celta de Vigo|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-11-22|13|Sevilla FC|Real Betis|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-11-29|14|Real Betis|Rayo Vallecano|Estadio La Cartuja|SCHEDULED\n" +
            "2026-11-29|14|Celta de Vigo|Villarreal CF|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-11-29|14|Deportivo La Coruña|FC Barcelona|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-11-29|14|Elche CF|Atlético de Madrid|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-11-29|14|RCD Espanyol|Getafe CF|RCDE Stadium|SCHEDULED\n" +
            "2026-11-29|14|Levante UD|Racing Santander|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-11-29|14|Málaga CF|Athletic Club|La Rosaleda|SCHEDULED\n" +
            "2026-11-29|14|Real Madrid|Deportivo Alavés|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-11-29|14|Real Sociedad|Sevilla FC|Reale Arena|SCHEDULED\n" +
            "2026-11-29|14|Valencia CF|CA Osasuna|Estadio de Mestalla|SCHEDULED\n" +
            "2026-12-06|15|Deportivo Alavés|RCD Espanyol|Mendizorrotza|SCHEDULED\n" +
            "2026-12-06|15|Athletic Club|Real Madrid|San Mamés|SCHEDULED\n" +
            "2026-12-06|15|Atlético de Madrid|Real Betis|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-12-06|15|FC Barcelona|Celta de Vigo|Spotify Camp Nou|SCHEDULED\n" +
            "2026-12-06|15|Getafe CF|Valencia CF|Coliseum|SCHEDULED\n" +
            "2026-12-06|15|CA Osasuna|Elche CF|El Sadar|SCHEDULED\n" +
            "2026-12-06|15|Racing Santander|Deportivo La Coruña|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2026-12-06|15|Rayo Vallecano|Levante UD|Estadio de Vallecas|SCHEDULED\n" +
            "2026-12-06|15|Sevilla FC|Málaga CF|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-12-06|15|Villarreal CF|Real Sociedad|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-12-13|16|Atlético de Madrid|Valencia CF|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2026-12-13|16|Real Betis|Racing Santander|Estadio La Cartuja|SCHEDULED\n" +
            "2026-12-13|16|Deportivo La Coruña|Athletic Club|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-12-13|16|Elche CF|Sevilla FC|Estadio Martínez Valero|SCHEDULED\n" +
            "2026-12-13|16|RCD Espanyol|Celta de Vigo|RCDE Stadium|SCHEDULED\n" +
            "2026-12-13|16|Levante UD|Deportivo Alavés|Estadi Ciutat de València|SCHEDULED\n" +
            "2026-12-13|16|Málaga CF|FC Barcelona|La Rosaleda|SCHEDULED\n" +
            "2026-12-13|16|Real Madrid|CA Osasuna|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2026-12-13|16|Real Sociedad|Getafe CF|Reale Arena|SCHEDULED\n" +
            "2026-12-13|16|Villarreal CF|Rayo Vallecano|Estadio de la Cerámica|SCHEDULED\n" +
            "2026-12-20|17|Deportivo Alavés|Elche CF|Mendizorrotza|SCHEDULED\n" +
            "2026-12-20|17|Athletic Club|Real Betis|San Mamés|SCHEDULED\n" +
            "2026-12-20|17|Celta de Vigo|Atlético de Madrid|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2026-12-20|17|Deportivo La Coruña|Real Madrid|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2026-12-20|17|FC Barcelona|Real Sociedad|Spotify Camp Nou|SCHEDULED\n" +
            "2026-12-20|17|Getafe CF|Levante UD|Coliseum|SCHEDULED\n" +
            "2026-12-20|17|CA Osasuna|Villarreal CF|El Sadar|SCHEDULED\n" +
            "2026-12-20|17|Rayo Vallecano|Málaga CF|Estadio de Vallecas|SCHEDULED\n" +
            "2026-12-20|17|Sevilla FC|Racing Santander|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2026-12-20|17|Valencia CF|RCD Espanyol|Estadio de Mestalla|SCHEDULED\n" +
            "2027-01-03|18|Real Betis|Deportivo Alavés|Estadio La Cartuja|SCHEDULED\n" +
            "2027-01-03|18|Celta de Vigo|Deportivo La Coruña|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-01-03|18|RCD Espanyol|FC Barcelona|RCDE Stadium|SCHEDULED\n" +
            "2027-01-03|18|Levante UD|Valencia CF|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-01-03|18|Málaga CF|Elche CF|La Rosaleda|SCHEDULED\n" +
            "2027-01-03|18|Racing Santander|Athletic Club|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-01-03|18|Rayo Vallecano|Atlético de Madrid|Estadio de Vallecas|SCHEDULED\n" +
            "2027-01-03|18|Real Madrid|Getafe CF|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-01-03|18|Real Sociedad|CA Osasuna|Reale Arena|SCHEDULED\n" +
            "2027-01-03|18|Villarreal CF|Sevilla FC|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-01-10|19|Deportivo Alavés|Real Sociedad|Mendizorrotza|SCHEDULED\n" +
            "2027-01-10|19|Athletic Club|Villarreal CF|San Mamés|SCHEDULED\n" +
            "2027-01-10|19|Atlético de Madrid|Racing Santander|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-01-10|19|Deportivo La Coruña|Rayo Vallecano|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-01-10|19|Elche CF|Getafe CF|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-01-10|19|RCD Espanyol|Real Betis|RCDE Stadium|SCHEDULED\n" +
            "2027-01-10|19|CA Osasuna|FC Barcelona|El Sadar|SCHEDULED\n" +
            "2027-01-10|19|Real Madrid|Levante UD|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-01-10|19|Sevilla FC|Celta de Vigo|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-01-10|19|Valencia CF|Málaga CF|Estadio de Mestalla|SCHEDULED\n" +
            "2027-01-17|20|Atlético de Madrid|Real Sociedad|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-01-17|20|Real Betis|Deportivo La Coruña|Estadio La Cartuja|SCHEDULED\n" +
            "2027-01-17|20|Celta de Vigo|Valencia CF|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-01-17|20|FC Barcelona|Elche CF|Spotify Camp Nou|SCHEDULED\n" +
            "2027-01-17|20|Getafe CF|Athletic Club|Coliseum|SCHEDULED\n" +
            "2027-01-17|20|Levante UD|RCD Espanyol|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-01-17|20|Málaga CF|Real Madrid|La Rosaleda|SCHEDULED\n" +
            "2027-01-17|20|Racing Santander|CA Osasuna|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-01-17|20|Rayo Vallecano|Sevilla FC|Estadio de Vallecas|SCHEDULED\n" +
            "2027-01-17|20|Villarreal CF|Deportivo Alavés|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-01-24|21|Deportivo Alavés|FC Barcelona|Mendizorrotza|SCHEDULED\n" +
            "2027-01-24|21|Athletic Club|Levante UD|San Mamés|SCHEDULED\n" +
            "2027-01-24|21|Deportivo La Coruña|Atlético de Madrid|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-01-24|21|Elche CF|Rayo Vallecano|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-01-24|21|RCD Espanyol|Villarreal CF|RCDE Stadium|SCHEDULED\n" +
            "2027-01-24|21|Getafe CF|CA Osasuna|Coliseum|SCHEDULED\n" +
            "2027-01-24|21|Racing Santander|Celta de Vigo|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-01-24|21|Real Madrid|Real Betis|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-01-24|21|Real Sociedad|Málaga CF|Reale Arena|SCHEDULED\n" +
            "2027-01-24|21|Valencia CF|Sevilla FC|Estadio de Mestalla|SCHEDULED\n" +
            "2027-01-31|22|Atlético de Madrid|RCD Espanyol|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-01-31|22|Real Betis|Elche CF|Estadio La Cartuja|SCHEDULED\n" +
            "2027-01-31|22|Celta de Vigo|Getafe CF|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-01-31|22|FC Barcelona|Valencia CF|Spotify Camp Nou|SCHEDULED\n" +
            "2027-01-31|22|Levante UD|Real Sociedad|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-01-31|22|Málaga CF|Deportivo Alavés|La Rosaleda|SCHEDULED\n" +
            "2027-01-31|22|CA Osasuna|Deportivo La Coruña|El Sadar|SCHEDULED\n" +
            "2027-01-31|22|Rayo Vallecano|Real Madrid|Estadio de Vallecas|SCHEDULED\n" +
            "2027-01-31|22|Sevilla FC|Athletic Club|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-01-31|22|Villarreal CF|Racing Santander|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-02-07|23|Deportivo Alavés|Celta de Vigo|Mendizorrotza|SCHEDULED\n" +
            "2027-02-07|23|Athletic Club|CA Osasuna|San Mamés|SCHEDULED\n" +
            "2027-02-07|23|Real Betis|Sevilla FC|Estadio La Cartuja|SCHEDULED\n" +
            "2027-02-07|23|Deportivo La Coruña|Málaga CF|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-02-07|23|Elche CF|Levante UD|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-02-07|23|RCD Espanyol|Rayo Vallecano|RCDE Stadium|SCHEDULED\n" +
            "2027-02-07|23|FC Barcelona|Atlético de Madrid|Spotify Camp Nou|SCHEDULED\n" +
            "2027-02-07|23|Getafe CF|Villarreal CF|Coliseum|SCHEDULED\n" +
            "2027-02-07|23|Real Sociedad|Real Madrid|Reale Arena|SCHEDULED\n" +
            "2027-02-07|23|Valencia CF|Racing Santander|Estadio de Mestalla|SCHEDULED\n" +
            "2027-02-14|24|Celta de Vigo|Rayo Vallecano|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-02-14|24|Elche CF|Deportivo La Coruña|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-02-14|24|Levante UD|Málaga CF|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-02-14|24|CA Osasuna|Atlético de Madrid|El Sadar|SCHEDULED\n" +
            "2027-02-14|24|Racing Santander|Getafe CF|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-02-14|24|Real Madrid|Athletic Club|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-02-14|24|Real Sociedad|Real Betis|Reale Arena|SCHEDULED\n" +
            "2027-02-14|24|Sevilla FC|RCD Espanyol|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-02-14|24|Valencia CF|Deportivo Alavés|Estadio de Mestalla|SCHEDULED\n" +
            "2027-02-14|24|Villarreal CF|FC Barcelona|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-02-21|25|Deportivo Alavés|Racing Santander|Mendizorrotza|SCHEDULED\n" +
            "2027-02-21|25|Athletic Club|Celta de Vigo|San Mamés|SCHEDULED\n" +
            "2027-02-21|25|Atlético de Madrid|Elche CF|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-02-21|25|Deportivo La Coruña|Real Sociedad|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-02-21|25|RCD Espanyol|CA Osasuna|RCDE Stadium|SCHEDULED\n" +
            "2027-02-21|25|FC Barcelona|Levante UD|Spotify Camp Nou|SCHEDULED\n" +
            "2027-02-21|25|Málaga CF|Real Betis|La Rosaleda|SCHEDULED\n" +
            "2027-02-21|25|Rayo Vallecano|Getafe CF|Estadio de Vallecas|SCHEDULED\n" +
            "2027-02-21|25|Sevilla FC|Real Madrid|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-02-21|25|Villarreal CF|Valencia CF|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-02-28|26|Athletic Club|FC Barcelona|San Mamés|SCHEDULED\n" +
            "2027-02-28|26|Real Betis|Villarreal CF|Estadio La Cartuja|SCHEDULED\n" +
            "2027-02-28|26|Celta de Vigo|RCD Espanyol|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-02-28|26|Getafe CF|Deportivo Alavés|Coliseum|SCHEDULED\n" +
            "2027-02-28|26|Levante UD|Deportivo La Coruña|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-02-28|26|Málaga CF|Atlético de Madrid|La Rosaleda|SCHEDULED\n" +
            "2027-02-28|26|CA Osasuna|Sevilla FC|El Sadar|SCHEDULED\n" +
            "2027-02-28|26|Racing Santander|Rayo Vallecano|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-02-28|26|Real Madrid|Valencia CF|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-02-28|26|Real Sociedad|Elche CF|Reale Arena|SCHEDULED\n" +
            "2027-03-07|27|Deportivo Alavés|Athletic Club|Mendizorrotza|SCHEDULED\n" +
            "2027-03-07|27|Atlético de Madrid|Celta de Vigo|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-03-07|27|Deportivo La Coruña|Getafe CF|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-03-07|27|Elche CF|Málaga CF|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-03-07|27|RCD Espanyol|Racing Santander|RCDE Stadium|SCHEDULED\n" +
            "2027-03-07|27|FC Barcelona|Real Betis|Spotify Camp Nou|SCHEDULED\n" +
            "2027-03-07|27|Rayo Vallecano|CA Osasuna|Estadio de Vallecas|SCHEDULED\n" +
            "2027-03-07|27|Sevilla FC|Real Sociedad|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-03-07|27|Valencia CF|Levante UD|Estadio de Mestalla|SCHEDULED\n" +
            "2027-03-07|27|Villarreal CF|Real Madrid|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-03-14|28|Deportivo Alavés|Sevilla FC|Mendizorrotza|SCHEDULED\n" +
            "2027-03-14|28|Athletic Club|Valencia CF|San Mamés|SCHEDULED\n" +
            "2027-03-14|28|Real Betis|Levante UD|Estadio La Cartuja|SCHEDULED\n" +
            "2027-03-14|28|Elche CF|Villarreal CF|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-03-14|28|FC Barcelona|Deportivo La Coruña|Spotify Camp Nou|SCHEDULED\n" +
            "2027-03-14|28|Getafe CF|Real Sociedad|Coliseum|SCHEDULED\n" +
            "2027-03-14|28|Málaga CF|Rayo Vallecano|La Rosaleda|SCHEDULED\n" +
            "2027-03-14|28|CA Osasuna|Celta de Vigo|El Sadar|SCHEDULED\n" +
            "2027-03-14|28|Racing Santander|Atlético de Madrid|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-03-14|28|Real Madrid|RCD Espanyol|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-03-21|29|Atlético de Madrid|Getafe CF|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-03-21|29|Celta de Vigo|Real Madrid|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-03-21|29|RCD Espanyol|Athletic Club|RCDE Stadium|SCHEDULED\n" +
            "2027-03-21|29|Levante UD|CA Osasuna|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-03-21|29|Racing Santander|Real Betis|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-03-21|29|Rayo Vallecano|FC Barcelona|Estadio de Vallecas|SCHEDULED\n" +
            "2027-03-21|29|Real Sociedad|Deportivo Alavés|Reale Arena|SCHEDULED\n" +
            "2027-03-21|29|Sevilla FC|Elche CF|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-03-21|29|Valencia CF|Deportivo La Coruña|Estadio de Mestalla|SCHEDULED\n" +
            "2027-03-21|29|Villarreal CF|Málaga CF|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-04-04|30|Athletic Club|Racing Santander|San Mamés|SCHEDULED\n" +
            "2027-04-04|30|Real Betis|Celta de Vigo|Estadio La Cartuja|SCHEDULED\n" +
            "2027-04-04|30|Deportivo La Coruña|Villarreal CF|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-04-04|30|Elche CF|Deportivo Alavés|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-04-04|30|FC Barcelona|Sevilla FC|Spotify Camp Nou|SCHEDULED\n" +
            "2027-04-04|30|Getafe CF|RCD Espanyol|Coliseum|SCHEDULED\n" +
            "2027-04-04|30|Levante UD|Rayo Vallecano|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-04-04|30|Málaga CF|CA Osasuna|La Rosaleda|SCHEDULED\n" +
            "2027-04-04|30|Real Madrid|Atlético de Madrid|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-04-04|30|Real Sociedad|Valencia CF|Reale Arena|SCHEDULED\n" +
            "2027-04-11|31|Deportivo Alavés|Real Betis|Mendizorrotza|SCHEDULED\n" +
            "2027-04-11|31|Atlético de Madrid|Levante UD|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-04-11|31|Celta de Vigo|Elche CF|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-04-11|31|RCD Espanyol|Málaga CF|RCDE Stadium|SCHEDULED\n" +
            "2027-04-11|31|CA Osasuna|Real Madrid|El Sadar|SCHEDULED\n" +
            "2027-04-11|31|Racing Santander|FC Barcelona|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-04-11|31|Rayo Vallecano|Real Sociedad|Estadio de Vallecas|SCHEDULED\n" +
            "2027-04-11|31|Sevilla FC|Deportivo La Coruña|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-04-11|31|Valencia CF|Getafe CF|Estadio de Mestalla|SCHEDULED\n" +
            "2027-04-11|31|Villarreal CF|Athletic Club|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-04-18|32|Deportivo Alavés|Rayo Vallecano|Mendizorrotza|SCHEDULED\n" +
            "2027-04-18|32|Atlético de Madrid|Sevilla FC|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-04-18|32|Real Betis|Athletic Club|Estadio La Cartuja|SCHEDULED\n" +
            "2027-04-18|32|Deportivo La Coruña|Celta de Vigo|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-04-18|32|Elche CF|CA Osasuna|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-04-18|32|FC Barcelona|RCD Espanyol|Spotify Camp Nou|SCHEDULED\n" +
            "2027-04-18|32|Getafe CF|Real Madrid|Coliseum|SCHEDULED\n" +
            "2027-04-18|32|Levante UD|Villarreal CF|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-04-18|32|Málaga CF|Valencia CF|La Rosaleda|SCHEDULED\n" +
            "2027-04-18|32|Real Sociedad|Racing Santander|Reale Arena|SCHEDULED\n" +
            "2027-04-21|33|Athletic Club|Deportivo La Coruña|San Mamés|SCHEDULED\n" +
            "2027-04-21|33|Celta de Vigo|FC Barcelona|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-04-21|33|RCD Espanyol|Real Sociedad|RCDE Stadium|SCHEDULED\n" +
            "2027-04-21|33|Getafe CF|Real Betis|Coliseum|SCHEDULED\n" +
            "2027-04-21|33|CA Osasuna|Deportivo Alavés|El Sadar|SCHEDULED\n" +
            "2027-04-21|33|Racing Santander|Málaga CF|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-04-21|33|Real Madrid|Elche CF|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-04-21|33|Sevilla FC|Levante UD|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-04-21|33|Valencia CF|Rayo Vallecano|Estadio de Mestalla|SCHEDULED\n" +
            "2027-04-21|33|Villarreal CF|Atlético de Madrid|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-05-02|34|Atlético de Madrid|Deportivo Alavés|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-05-02|34|Real Betis|Valencia CF|Estadio La Cartuja|SCHEDULED\n" +
            "2027-05-02|34|Celta de Vigo|Sevilla FC|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-05-02|34|Deportivo La Coruña|Racing Santander|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-05-02|34|Elche CF|RCD Espanyol|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-05-02|34|FC Barcelona|CA Osasuna|Spotify Camp Nou|SCHEDULED\n" +
            "2027-05-02|34|Levante UD|Real Madrid|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-05-02|34|Málaga CF|Getafe CF|La Rosaleda|SCHEDULED\n" +
            "2027-05-02|34|Rayo Vallecano|Villarreal CF|Estadio de Vallecas|SCHEDULED\n" +
            "2027-05-02|34|Real Sociedad|Athletic Club|Reale Arena|SCHEDULED\n" +
            "2027-05-09|35|Deportivo Alavés|Levante UD|Mendizorrotza|SCHEDULED\n" +
            "2027-05-09|35|Athletic Club|Málaga CF|San Mamés|SCHEDULED\n" +
            "2027-05-09|35|Real Betis|RCD Espanyol|Estadio La Cartuja|SCHEDULED\n" +
            "2027-05-09|35|Getafe CF|Elche CF|Coliseum|SCHEDULED\n" +
            "2027-05-09|35|CA Osasuna|Real Sociedad|El Sadar|SCHEDULED\n" +
            "2027-05-09|35|Racing Santander|Sevilla FC|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-05-09|35|Rayo Vallecano|Deportivo La Coruña|Estadio de Vallecas|SCHEDULED\n" +
            "2027-05-09|35|Real Madrid|FC Barcelona|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-05-09|35|Valencia CF|Atlético de Madrid|Estadio de Mestalla|SCHEDULED\n" +
            "2027-05-09|35|Villarreal CF|Celta de Vigo|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-05-16|36|Atlético de Madrid|Rayo Vallecano|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-05-16|36|Deportivo La Coruña|Deportivo Alavés|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-05-16|36|Elche CF|Athletic Club|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-05-16|36|RCD Espanyol|Valencia CF|RCDE Stadium|SCHEDULED\n" +
            "2027-05-16|36|Levante UD|Getafe CF|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-05-16|36|Málaga CF|Celta de Vigo|La Rosaleda|SCHEDULED\n" +
            "2027-05-16|36|CA Osasuna|Real Betis|El Sadar|SCHEDULED\n" +
            "2027-05-16|36|Real Madrid|Racing Santander|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-05-16|36|Real Sociedad|FC Barcelona|Reale Arena|SCHEDULED\n" +
            "2027-05-16|36|Sevilla FC|Villarreal CF|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-05-23|37|Deportivo Alavés|Real Madrid|Mendizorrotza|SCHEDULED\n" +
            "2027-05-23|37|Atlético de Madrid|Athletic Club|Riyadh Air Metropolitano|SCHEDULED\n" +
            "2027-05-23|37|Celta de Vigo|Real Sociedad|Estadio Abanca Balaídos|SCHEDULED\n" +
            "2027-05-23|37|Deportivo La Coruña|RCD Espanyol|Estadio Abanca-Riazor|SCHEDULED\n" +
            "2027-05-23|37|FC Barcelona|Málaga CF|Spotify Camp Nou|SCHEDULED\n" +
            "2027-05-23|37|Racing Santander|Levante UD|Campos de Sport de El Sardinero|SCHEDULED\n" +
            "2027-05-23|37|Rayo Vallecano|Real Betis|Estadio de Vallecas|SCHEDULED\n" +
            "2027-05-23|37|Sevilla FC|Getafe CF|Estadio Ramón Sánchez-Pizjuán|SCHEDULED\n" +
            "2027-05-23|37|Valencia CF|Elche CF|Estadio de Mestalla|SCHEDULED\n" +
            "2027-05-23|37|Villarreal CF|CA Osasuna|Estadio de la Cerámica|SCHEDULED\n" +
            "2027-05-30|38|Athletic Club|Rayo Vallecano|San Mamés|SCHEDULED\n" +
            "2027-05-30|38|Real Betis|Atlético de Madrid|Estadio La Cartuja|SCHEDULED\n" +
            "2027-05-30|38|Elche CF|Racing Santander|Estadio Martínez Valero|SCHEDULED\n" +
            "2027-05-30|38|RCD Espanyol|Deportivo Alavés|RCDE Stadium|SCHEDULED\n" +
            "2027-05-30|38|Getafe CF|FC Barcelona|Coliseum|SCHEDULED\n" +
            "2027-05-30|38|Levante UD|Celta de Vigo|Estadi Ciutat de València|SCHEDULED\n" +
            "2027-05-30|38|Málaga CF|Sevilla FC|La Rosaleda|SCHEDULED\n" +
            "2027-05-30|38|CA Osasuna|Valencia CF|El Sadar|SCHEDULED\n" +
            "2027-05-30|38|Real Madrid|Deportivo La Coruña|Estadio Santiago Bernabéu|SCHEDULED\n" +
            "2027-05-30|38|Real Sociedad|Villarreal CF|Reale Arena|SCHEDULED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    static {
        TLA.put("Athletic Club", "ATH");
        TLA.put("Atlético de Madrid", "ATM");
        TLA.put("CA Osasuna", "OSA");
        TLA.put("Celta de Vigo", "CEL");
        TLA.put("Deportivo Alavés", "ALA");
        TLA.put("Deportivo La Coruña", "DEP");
        TLA.put("Elche CF", "ELC");
        TLA.put("FC Barcelona", "BAR");
        TLA.put("Getafe CF", "GET");
        TLA.put("Levante UD", "LEV");
        TLA.put("Málaga CF", "MAL");
        TLA.put("Racing Santander", "RAC");
        TLA.put("Rayo Vallecano", "RAY");
        TLA.put("RCD Espanyol", "ESP");
        TLA.put("Real Betis", "BET");
        TLA.put("Real Madrid", "RMA");
        TLA.put("Real Sociedad", "RSO");
        TLA.put("Sevilla FC", "SEV");
        TLA.put("Valencia CF", "VAL");
        TLA.put("Villarreal CF", "VIL");
        CRESTS.put("Athletic Club", "https://crests.football-data.org/77.png");
        CRESTS.put("Atlético de Madrid", "https://crests.football-data.org/78.png");
        CRESTS.put("CA Osasuna", "https://crests.football-data.org/79.png");
        CRESTS.put("RCD Espanyol", "https://crests.football-data.org/80.png");
        CRESTS.put("FC Barcelona", "https://crests.football-data.org/81.png");
        CRESTS.put("Getafe CF", "https://crests.football-data.org/82.png");
        CRESTS.put("Málaga CF", "https://crests.football-data.org/84.png");
        CRESTS.put("Real Madrid", "https://crests.football-data.org/86.png");
        CRESTS.put("Rayo Vallecano", "https://crests.football-data.org/87.png");
        CRESTS.put("Levante UD", "https://crests.football-data.org/88.png");
        CRESTS.put("Racing Santander", "https://crests.football-data.org/89.png");
        CRESTS.put("Real Betis", "https://crests.football-data.org/90.png");
        CRESTS.put("Real Sociedad", "https://crests.football-data.org/92.png");
        CRESTS.put("Villarreal CF", "https://crests.football-data.org/94.png");
        CRESTS.put("Valencia CF", "https://crests.football-data.org/95.png");
        CRESTS.put("Deportivo Alavés", "https://crests.football-data.org/263.png");
        CRESTS.put("Elche CF", "https://crests.football-data.org/285.png");
        CRESTS.put("Celta de Vigo", "https://crests.football-data.org/558.png");
        CRESTS.put("Sevilla FC", "https://crests.football-data.org/559.png");
        CRESTS.put("Deportivo La Coruña", "https://crests.football-data.org/560.png");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutLaLiga(root.optJSONArray("matches")));
            root.put("live", copyWithoutLaLiga(root.optJSONArray("live")));
            root.put("finished", copyWithoutLaLiga(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutLaLiga(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");

            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // Keep every other competition usable if this bundled fallback is
            // malformed by a future manual edit.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonLaLiga(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "PD-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "TIMED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "RFEF official La Liga fixture calendar");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected La Liga source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"name", "shortName", "tla", "crest", "emblem", "logo", "area", "venue"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            String value = String.valueOf(richer.opt(key)).trim();
            if (value.length() > 0) out.put(key, richer.opt(key));
        }
        String name = out.optString("name", out.optString("shortName", ""));
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(name)) out.put("crest", CRESTS.get(name));
        return out;
    }

    private static JSONArray copyWithoutLaLiga(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isLaLiga(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonLaLiga(JSONObject row) {
        if (!isLaLiga(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isLaLiga(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        StringBuilder value = new StringBuilder();
        if (raw instanceof JSONObject) {
            JSONObject competition = (JSONObject) raw;
            value.append(competition.optString("code", "")).append(' ')
                    .append(competition.optString("name", ""));
        } else if (raw != null) value.append(String.valueOf(raw));
        value.append(' ').append(row.optString("competitionCode", ""))
                .append(' ').append(row.optString("competitionName", ""));
        String normalized = normalize(value.toString());
        return normalized.equals("pd") || normalized.contains("primeradivision") || normalized.contains("laliga");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true);
        String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0;
        String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30;
        else if (isLive(status)) score += 25;
        else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2;
        if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") ||
                value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject();
        competition.put("code", COMPETITION_CODE);
        competition.put("name", COMPETITION_NAME);
        return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject();
        team.put("name", name);
        team.put("shortName", name);
        team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        team.put("area", "Spain");
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        return team;
    }


    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = source == null ? new JSONArray() : new JSONArray(source.toString());
        Map<String, Integer> positions = new HashMap<String, Integer>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (name.length() > 0) positions.put(clubKey(name), i);
        }
        for (String name : TLA.keySet()) {
            JSONObject fallback = teamObject(name);
            Integer position = positions.get(clubKey(name));
            if (position == null) teams.put(fallback);
            else {
                JSONObject richer = teams.optJSONObject(position);
                teams.put(position, mergeTeam(fallback, richer == null ? new JSONObject() : richer));
            }
        }
        root.put("teams", teams);
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE);
        if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        boolean current = start.startsWith("2026") && end.startsWith("2027");
        if (!current) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources");
        if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject laLiga = sources.optJSONObject(COMPETITION_CODE);
        if (laLiga == null) laLiga = new JSONObject();
        laLiga.put("status", "connected");
        laLiga.put("provider", "RFEF official calendar + connected live source");
        laLiga.put("season", SEASON);
        laLiga.put("matchCount", matchCount);
        laLiga.put("teamCount", TLA.size());
        laLiga.put("roundCount", 38);
        sources.put(COMPETITION_CODE, laLiga);
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("clubatleticodemadrid") || key.equals("atleticomadrid")) return "atleticodemadrid";
        if (key.equals("clubatleticoosasuna") || key.equals("osasuna")) return "caosasuna";
        if (key.equals("rcceltadevigo") || key.equals("celtavigo")) return "celtadevigo";
        if (key.equals("rcdeportivo") || key.equals("deportivocoruna") || key.equals("deportivolacoruna")) return "deportivolacoruna";
        if (key.equals("rcdespanyoldebarcelona") || key.equals("espanyol")) return "rcdespanyol";
        if (key.equals("realracingclubdesantander") || key.equals("racingsantander")) return "racingsantander";
        if (key.equals("realmadridcf")) return "realmadrid";
        if (key.equals("realsociedaddefutbol")) return "realsociedad";
        if (key.equals("rayovallecanodemadrid")) return "rayovallecano";
        if (key.equals("realbetisbalompie")) return "realbetis";
        if (key.endsWith("associationfootballclub")) key = key.substring(0, key.length() - "associationfootballclub".length());
        else if (key.endsWith("footballclub")) key = key.substring(0, key.length() - "footballclub".length());
        else if (key.endsWith("afc")) key = key.substring(0, key.length() - 3);
        else if (key.endsWith("fc")) key = key.substring(0, key.length() - 2);
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private LaLiga2627Data() {}
}
