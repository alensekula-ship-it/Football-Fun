package com.asappfactory.footballfun.player;

/**
 * Separate future contract for paid match events, cards and lineups.
 * It is intentionally independent from PlayerDataProvider because those data
 * sets can come from different plans/providers.
 */
public interface MatchDisciplineProvider {
    String providerId();
    boolean isConfigured();

    /** Normalized verified cards/events payload for one provider match id. */
    String fetchCardsAndEvents(String providerMatchId) throws Exception;

    /** Normalized verified starting XI / bench payload for one provider match id. */
    String fetchLineups(String providerMatchId) throws Exception;
}
