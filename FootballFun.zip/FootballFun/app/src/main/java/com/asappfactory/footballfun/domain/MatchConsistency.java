package com.asappfactory.footballfun.domain;

import com.asappfactory.footballfun.model.Match;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Central validation and normalization pass for every Match object used by the UI.
 * Home, Matches, Competition Center, Favorites and Match Center all read the same
 * normalized fields after this pass.
 */
public final class MatchConsistency {

    public static void normalizeAll(List<Match> matches) {
        if (matches == null) return;
        for (Match match : matches) normalize(match);
    }

    public static boolean hasVerifiedScore(Match match) {
        return match != null && match.homeGoals >= 0 && match.awayGoals >= 0;
    }

    /**
     * The single app-wide definition of a played/final match. A status marker by
     * itself is never enough; both final scores must be present as well.
     */
    public static boolean isVerifiedFinished(Match match) {
        return match != null && MatchStatus.isFinished(match.status) && hasVerifiedScore(match);
    }

    public static void normalize(Match match) {
        if (match == null) return;

        match.group = clean(match.group);
        match.home = clean(match.home);
        match.away = clean(match.away);
        match.date = clean(match.date);
        match.venue = clean(match.venue);
        match.competition = clean(match.competition);
        match.roundName = clean(match.roundName);
        match.status = canonicalStatus(match.status);
        match.minute = canonicalMinute(match.minute);

        if (match.matchday < 0) match.matchday = 0;
        if (match.homeGoals < -1) match.homeGoals = -1;
        if (match.awayGoals < -1) match.awayGoals = -1;

        // A partial score is never shown. Both values must come from the same
        // verified update or both remain unavailable.
        if ((match.homeGoals < 0) != (match.awayGoals < 0)) {
            match.homeGoals = -1;
            match.awayGoals = -1;
        }

        boolean hasScore = hasVerifiedScore(match);

        // Legacy cached/manual results with a complete score but no status are
        // promoted once, here, so every screen receives the same final state.
        if (match.status.isEmpty()) {
            match.status = hasScore ? "FINISHED" : "SCHEDULED";
        }

        // Core invariant: a match can be FINISHED only when a complete score is
        // available. A finished/played marker without a verified score becomes
        // NO_RESULT everywhere instead of appearing as "played" with a dash.
        if (MatchStatus.isFinished(match.status) && !hasScore) {
            match.status = "NO_RESULT";
        } else if (MatchStatus.isResultUnavailable(match.status) && hasScore) {
            // If a later verified refresh supplies both goals, resolve the old
            // NO_RESULT state centrally rather than leaving screens inconsistent.
            match.status = "FINISHED";
        }

        // A stale scheduled fixture is neither a future match nor a verified
        // result. Expire it centrally so every screen agrees on NO_RESULT, even
        // during startup before the online/cache layer has finished loading.
        if (MatchStatus.isUpcoming(match.status) && isExpiredUpcoming(match.date)) {
            match.status = "NO_RESULT";
        }

        boolean live = MatchStatus.isLive(match.status);
        boolean finished = MatchStatus.isFinished(match.status);

        // Scheduled/postponed/cancelled/no-result matches must not inherit an old
        // score. Only LIVE and verified FINISHED states are allowed to carry it.
        if (!live && !finished) {
            match.homeGoals = -1;
            match.awayGoals = -1;
        }

        if (!live) match.minute = "";

        String stage = !match.roundName.isEmpty() ? match.roundName : match.venue;
        if (isKnockoutStage(stage)) match.group = "";
    }

    public static String canonicalStatus(String raw) {
        String value = clean(raw).toUpperCase(Locale.US)
                .replace('-', '_').replace(' ', '_');
        while (value.contains("__")) value = value.replace("__", "_");

        if (value.isEmpty()) return "";
        if (value.equals("TIMED") || value.equals("NOT_STARTED") || value.equals("UPCOMING") ||
                value.equals("TBD") || value.equals("TBA") || value.equals("NS")) return "SCHEDULED";
        if (value.equals("IN_PROGRESS") || value.equals("IN_PLAY") || value.equals("INPLAY") ||
                value.equals("1H") || value.equals("2H")) return "LIVE";
        if (value.equals("HALFTIME") || value.equals("HALF_TIME") || value.equals("HT") || value.equals("PAUSED")) return "HALF_TIME";
        if (value.equals("FULL_TIME") || value.equals("FT") || value.equals("FINAL") || value.equals("AWARDED") ||
                value.equals("AFTER_EXTRA_TIME") || value.equals("AFTER_PENALTIES")) return "FINISHED";
        if (value.equals("PLAYED") || value.equals("PLAYED_NO_SCORE") || value.equals("FINISHED_NO_SCORE") ||
                value.equals("NO_RESULT") || value.equals("RESULT_PENDING") || value.equals("UNCONFIRMED_RESULT") ||
                value.equals("RESULT_UNCONFIRMED")) return "NO_RESULT";
        if (value.startsWith("POSTPON")) return "POSTPONED";
        if (value.startsWith("CANCEL")) return "CANCELLED";
        if (value.startsWith("SUSPEND")) return "SUSPENDED";
        if (value.equals("PENALTIES")) return "PENALTY_SHOOTOUT";
        return value;
    }

    private static String canonicalMinute(String raw) {
        String value = clean(raw).replace("′", "").replace("'", "");
        if (value.isEmpty()) return "";
        int plus = value.indexOf('+');
        String base = plus >= 0 ? value.substring(0, plus) : value;
        try {
            int minute = Integer.parseInt(base.replaceAll("[^0-9]", ""));
            if (minute < 0) return "";
            if (minute > 130) minute = 130;
            if (plus >= 0) {
                String extra = value.substring(plus + 1).replaceAll("[^0-9]", "");
                return extra.isEmpty() ? String.valueOf(minute) : minute + "+" + extra;
            }
            return String.valueOf(minute);
        } catch (Exception ignored) {
            return "";
        }
    }

    private static boolean isExpiredUpcoming(String rawDate) {
        String raw = clean(rawDate);
        if (raw.isEmpty()) return false;
        long kickoff = parseKickoff(raw);
        if (kickoff <= 0L) return false;
        if (raw.matches("\\d{4}-\\d{2}-\\d{2}")) kickoff += 24L * 60L * 60L * 1000L - 1L;
        return System.currentTimeMillis() > kickoff + 6L * 60L * 60L * 1000L;
    }

    private static long parseKickoff(String raw) {
        String[] formats = {
                "yyyy-MM-dd HH:mm 'UTC'", "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd"
        };
        for (String format : formats) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(format, Locale.US);
                parser.setLenient(false);
                parser.setTimeZone(TimeZone.getTimeZone("UTC"));
                java.text.ParsePosition position = new java.text.ParsePosition(0);
                Date parsed = parser.parse(raw, position);
                if (parsed != null && position.getIndex() == raw.length()) return parsed.getTime();
            } catch (Exception ignored) {}
        }
        if (raw.length() >= 10) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                parser.setLenient(false);
                parser.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed = parser.parse(raw.substring(0, 10));
                return parsed == null ? 0L : parsed.getTime();
            } catch (Exception ignored) {}
        }
        return 0L;
    }

    private static boolean isKnockoutStage(String raw) {
        String value = clean(raw).toUpperCase(Locale.US).replace('-', '_').replace(' ', '_');
        return value.contains("ROUND_OF_") || value.contains("LAST_") ||
                value.contains("QUARTER") || value.contains("SEMI") ||
                value.equals("FINAL") || value.endsWith("_FINAL") ||
                value.contains("THIRD_PLACE") || value.contains("PLAYOFF");
    }

    private static String clean(String value) {
        if (value == null) return "";
        String clean = value.trim();
        return "null".equalsIgnoreCase(clean) ? "" : clean;
    }

    private MatchConsistency() {}
}
