package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Brasileirão Série A 2026 verified schedule/identity fallback.
 *
 * Pairings and round structure are bundled so the competition remains complete
 * between API refreshes. Current connected rows always override the fallback
 * for status, score, kickoff, venue and match events.
 */
public final class Brasileirao2026Data {
    private static final String COMPETITION_NAME = "Brasileirão Série A";
    private static final String COMPETITION_CODE = "BSA";
    private static final String SEASON = "2026";
    private static final String FIRST_DATE = "2026-01-28";
    private static final String LAST_DATE = "2026-12-02";

    private static final String[] FIRST_HALF_DATES = new String[]{
            "2026-01-28","2026-02-04","2026-02-11","2026-02-25","2026-03-11","2026-03-15","2026-03-18","2026-03-22","2026-04-01","2026-04-05","2026-04-12","2026-04-19","2026-04-25","2026-05-03","2026-05-10","2026-05-17","2026-05-24","2026-05-31","2026-07-22"
    };
    private static final String[] SECOND_HALF_DATES = new String[]{
            "2026-07-26","2026-07-29","2026-08-09","2026-08-16","2026-08-23","2026-08-30","2026-09-06","2026-09-13","2026-09-20","2026-10-07","2026-10-11","2026-10-18","2026-10-25","2026-10-28","2026-11-04","2026-11-18","2026-11-22","2026-11-29","2026-12-02"
    };

    // Official first-half pairings. Rounds 20-38 are the reverse fixtures.
    private static final String[][][] FIRST_HALF = new String[][][]{
            {{"Fluminense","Grêmio"}, {"Botafogo","Cruzeiro"}, {"São Paulo","Flamengo"}, {"Corinthians","Bahia"}, {"Mirassol","Vasco da Gama"}, {"Atlético Mineiro","Palmeiras"}, {"Internacional","Athletico Paranaense"}, {"Coritiba","Red Bull Bragantino"}, {"Vitória","Remo"}, {"Chapecoense","Santos"}},
            {{"Flamengo","Internacional"}, {"Vasco da Gama","Chapecoense"}, {"Santos","São Paulo"}, {"Palmeiras","Vitória"}, {"Red Bull Bragantino","Atlético Mineiro"}, {"Cruzeiro","Coritiba"}, {"Grêmio","Botafogo"}, {"Athletico Paranaense","Corinthians"}, {"Bahia","Fluminense"}, {"Remo","Mirassol"}},
            {{"Fluminense","Botafogo"}, {"Vasco da Gama","Bahia"}, {"São Paulo","Grêmio"}, {"Corinthians","Red Bull Bragantino"}, {"Mirassol","Cruzeiro"}, {"Atlético Mineiro","Remo"}, {"Internacional","Palmeiras"}, {"Athletico Paranaense","Santos"}, {"Vitória","Flamengo"}, {"Chapecoense","Coritiba"}},
            {{"Flamengo","Mirassol"}, {"Botafogo","Vitória"}, {"Santos","Vasco da Gama"}, {"Palmeiras","Fluminense"}, {"Red Bull Bragantino","Athletico Paranaense"}, {"Cruzeiro","Corinthians"}, {"Grêmio","Atlético Mineiro"}, {"Coritiba","São Paulo"}, {"Bahia","Chapecoense"}, {"Remo","Internacional"}},
            {{"Flamengo","Cruzeiro"}, {"Vasco da Gama","Palmeiras"}, {"São Paulo","Chapecoense"}, {"Corinthians","Coritiba"}, {"Mirassol","Santos"}, {"Atlético Mineiro","Internacional"}, {"Grêmio","Red Bull Bragantino"}, {"Athletico Paranaense","Botafogo"}, {"Bahia","Vitória"}, {"Remo","Fluminense"}},
            {{"Fluminense","Athletico Paranaense"}, {"Botafogo","Flamengo"}, {"Santos","Corinthians"}, {"Palmeiras","Mirassol"}, {"Red Bull Bragantino","São Paulo"}, {"Cruzeiro","Vasco da Gama"}, {"Internacional","Bahia"}, {"Coritiba","Remo"}, {"Vitória","Atlético Mineiro"}, {"Chapecoense","Grêmio"}},
            {{"Flamengo","Remo"}, {"Vasco da Gama","Fluminense"}, {"Santos","Internacional"}, {"Palmeiras","Botafogo"}, {"Mirassol","Coritiba"}, {"Atlético Mineiro","São Paulo"}, {"Grêmio","Vitória"}, {"Athletico Paranaense","Cruzeiro"}, {"Bahia","Red Bull Bragantino"}, {"Chapecoense","Corinthians"}},
            {{"Fluminense","Atlético Mineiro"}, {"Vasco da Gama","Grêmio"}, {"São Paulo","Palmeiras"}, {"Corinthians","Flamengo"}, {"Red Bull Bragantino","Botafogo"}, {"Cruzeiro","Santos"}, {"Internacional","Chapecoense"}, {"Athletico Paranaense","Coritiba"}, {"Vitória","Mirassol"}, {"Remo","Bahia"}},
            {{"Fluminense","Corinthians"}, {"Botafogo","Mirassol"}, {"Santos","Remo"}, {"Palmeiras","Grêmio"}, {"Red Bull Bragantino","Flamengo"}, {"Cruzeiro","Vitória"}, {"Internacional","São Paulo"}, {"Coritiba","Vasco da Gama"}, {"Bahia","Athletico Paranaense"}, {"Chapecoense","Atlético Mineiro"}},
            {{"Flamengo","Santos"}, {"Vasco da Gama","Botafogo"}, {"São Paulo","Cruzeiro"}, {"Corinthians","Internacional"}, {"Mirassol","Red Bull Bragantino"}, {"Atlético Mineiro","Athletico Paranaense"}, {"Grêmio","Remo"}, {"Coritiba","Fluminense"}, {"Bahia","Palmeiras"}, {"Chapecoense","Vitória"}},
            {{"Fluminense","Flamengo"}, {"Botafogo","Coritiba"}, {"Santos","Atlético Mineiro"}, {"Corinthians","Palmeiras"}, {"Mirassol","Bahia"}, {"Cruzeiro","Red Bull Bragantino"}, {"Internacional","Grêmio"}, {"Athletico Paranaense","Chapecoense"}, {"Vitória","São Paulo"}, {"Remo","Vasco da Gama"}},
            {{"Flamengo","Bahia"}, {"Vasco da Gama","São Paulo"}, {"Santos","Fluminense"}, {"Palmeiras","Athletico Paranaense"}, {"Red Bull Bragantino","Remo"}, {"Cruzeiro","Grêmio"}, {"Internacional","Mirassol"}, {"Coritiba","Atlético Mineiro"}, {"Vitória","Corinthians"}, {"Chapecoense","Botafogo"}},
            {{"Fluminense","Chapecoense"}, {"Botafogo","Internacional"}, {"São Paulo","Mirassol"}, {"Corinthians","Vasco da Gama"}, {"Red Bull Bragantino","Palmeiras"}, {"Atlético Mineiro","Flamengo"}, {"Grêmio","Coritiba"}, {"Athletico Paranaense","Vitória"}, {"Bahia","Santos"}, {"Remo","Cruzeiro"}},
            {{"Flamengo","Vasco da Gama"}, {"Botafogo","Remo"}, {"São Paulo","Bahia"}, {"Palmeiras","Santos"}, {"Mirassol","Corinthians"}, {"Cruzeiro","Atlético Mineiro"}, {"Internacional","Fluminense"}, {"Athletico Paranaense","Grêmio"}, {"Vitória","Coritiba"}, {"Chapecoense","Red Bull Bragantino"}},
            {{"Fluminense","Vitória"}, {"Vasco da Gama","Athletico Paranaense"}, {"Santos","Red Bull Bragantino"}, {"Corinthians","São Paulo"}, {"Mirassol","Chapecoense"}, {"Atlético Mineiro","Botafogo"}, {"Grêmio","Flamengo"}, {"Coritiba","Internacional"}, {"Bahia","Cruzeiro"}, {"Remo","Palmeiras"}},
            {{"Fluminense","São Paulo"}, {"Botafogo","Corinthians"}, {"Santos","Coritiba"}, {"Palmeiras","Cruzeiro"}, {"Red Bull Bragantino","Vitória"}, {"Atlético Mineiro","Mirassol"}, {"Internacional","Vasco da Gama"}, {"Athletico Paranaense","Flamengo"}, {"Bahia","Grêmio"}, {"Chapecoense","Remo"}},
            {{"Flamengo","Palmeiras"}, {"Vasco da Gama","Red Bull Bragantino"}, {"São Paulo","Botafogo"}, {"Corinthians","Atlético Mineiro"}, {"Mirassol","Fluminense"}, {"Cruzeiro","Chapecoense"}, {"Grêmio","Santos"}, {"Coritiba","Bahia"}, {"Vitória","Internacional"}, {"Remo","Athletico Paranaense"}},
            {{"Flamengo","Coritiba"}, {"Vasco da Gama","Atlético Mineiro"}, {"Santos","Vitória"}, {"Palmeiras","Chapecoense"}, {"Red Bull Bragantino","Internacional"}, {"Cruzeiro","Fluminense"}, {"Grêmio","Corinthians"}, {"Athletico Paranaense","Mirassol"}, {"Bahia","Botafogo"}, {"Remo","São Paulo"}},
            {{"Fluminense","Red Bull Bragantino"}, {"Botafogo","Santos"}, {"São Paulo","Athletico Paranaense"}, {"Corinthians","Remo"}, {"Mirassol","Grêmio"}, {"Atlético Mineiro","Bahia"}, {"Internacional","Cruzeiro"}, {"Coritiba","Palmeiras"}, {"Vitória","Vasco da Gama"}, {"Chapecoense","Flamengo"}}
    };

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        addClub("Athletico Paranaense","CAP","https://www.athletico.com.br","Ligga Arena",1924,"Red / Black");
        addClub("Atlético Mineiro","CAM","https://atletico.com.br","Arena MRV",1908,"Black / White");
        addClub("Bahia","BAH","https://www.esporteclubebahia.com.br","Arena Fonte Nova",1931,"Blue / Red / White");
        addClub("Botafogo","BOT","https://www.botafogo.com.br","Estádio Nilton Santos",1904,"Black / White");
        addClub("Chapecoense","CHA","https://chapecoense.com","Arena Condá",1973,"Green / White");
        addClub("Corinthians","COR","https://www.corinthians.com.br","Neo Química Arena",1910,"Black / White");
        addClub("Coritiba","CFC","https://www.coritiba.com.br","Estádio Couto Pereira",1909,"Green / White");
        addClub("Cruzeiro","CRU","https://www.cruzeiro.com.br","Mineirão",1921,"Blue / White");
        addClub("Flamengo","FLA","https://www.flamengo.com.br","Maracanã",1895,"Red / Black");
        addClub("Fluminense","FLU","https://www.fluminense.com.br","Maracanã",1902,"Green / Red / White");
        addClub("Grêmio","GRE","https://gremio.net","Arena do Grêmio",1903,"Blue / Black / White");
        addClub("Internacional","INT","https://internacional.com.br","Estádio Beira-Rio",1909,"Red / White");
        addClub("Mirassol","MIR","https://www.mirassolfc.com.br","Estádio José Maria de Campos Maia",1925,"Yellow / Green");
        addClub("Palmeiras","PAL","https://www.palmeiras.com.br","Nubank Park",1914,"Green / White");
        addClub("Red Bull Bragantino","RBB","https://www.redbullbragantino.com.br","Estádio Cícero de Souza Marques",1928,"Red / White");
        addClub("Remo","REM","https://www.clubedoremo.com.br","Estádio Mangueirão",1905,"Blue / White");
        addClub("Santos","SAN","https://www.santosfc.com.br","Vila Belmiro",1912,"Black / White");
        addClub("São Paulo","SAO","https://www.saopaulofc.net","MorumBIS",1930,"Red / Black / White");
        addClub("Vasco da Gama","VAS","https://vasco.com.br","São Januário",1898,"Black / White");
        addClub("Vitória","VIT","https://ecvitoria.com.br","Barradão",1899,"Red / Black");

        CRESTS.put("Athletico Paranaense","https://www.footylogos.com/downloads/logo/athletico-paranaense-logo-footylogos.png");
        CRESTS.put("Atlético Mineiro","https://www.footylogos.com/downloads/logo/atletico-mineiro-logo-footylogos.png");
        CRESTS.put("Bahia","https://www.footylogos.com/downloads/logo/bahia-logo-footylogos.png");
        CRESTS.put("Botafogo","https://www.footylogos.com/downloads/logo/botafogo-logo-footylogos.png");
        CRESTS.put("Chapecoense","https://www.footylogos.com/downloads/logo/chapecoense-logo-footylogos.png");
        CRESTS.put("Corinthians","https://www.footylogos.com/downloads/logo/corinthians-logo-footylogos.png");
        CRESTS.put("Coritiba","https://www.footylogos.com/downloads/logo/coritiba-logo-footylogos.png");
        CRESTS.put("Cruzeiro","https://www.footylogos.com/downloads/logo/cruzeiro-logo-footylogos.png");
        CRESTS.put("Flamengo","https://www.footylogos.com/downloads/logo/flamengo-logo-footylogos.png");
        CRESTS.put("Fluminense","https://www.footylogos.com/downloads/logo/fluminense-logo-footylogos.png");
        CRESTS.put("Grêmio","https://www.footylogos.com/downloads/logo/gremio-logo-footylogos.png");
        CRESTS.put("Internacional","https://www.footylogos.com/downloads/logo/sc-internacional-logo-footylogos.png");
        CRESTS.put("Mirassol","https://www.footylogos.com/downloads/logo/mirassol-fc-logo-footylogos.png");
        CRESTS.put("Palmeiras","https://www.footylogos.com/downloads/logo/palmeiras-logo-footylogos.png");
        CRESTS.put("Red Bull Bragantino","https://www.footylogos.com/downloads/logo/rb-bragantino-logo-footylogos.png");
        CRESTS.put("Remo","https://www.footylogos.com/downloads/logo/club-de-remo-logo-footylogos.png");
        CRESTS.put("Santos","https://www.footylogos.com/downloads/logo/santos-fc-logo-footylogos.png");
        CRESTS.put("São Paulo","https://www.footylogos.com/downloads/logo/sao-paulo-logo-footylogos.png");
        CRESTS.put("Vasco da Gama","https://www.footylogos.com/downloads/logo/vasco-da-gama-logo-footylogos.png");
        CRESTS.put("Vitória","https://www.footylogos.com/downloads/logo/vitoria-logo-footylogos.png");
    }

    private static void addClub(String name,String tla,String website,String venue,int founded,String colors) {
        TLA.put(name,tla); WEBSITES.put(name,website); VENUES.put(name,venue); FOUNDED.put(name,founded); COLORS.put(name,colors);
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutBrazil(root.optJSONArray("matches")));
            root.put("live", copyWithoutBrazil(root.optJSONArray("live")));
            root.put("finished", copyWithoutBrazil(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutBrazil(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");
            for (int i=0;i<fixtures.length();i++) {
                JSONObject fixture=fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status=fixture.optString("status","SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status) && scoreValue(fixture,true)>=0 && scoreValue(fixture,false)>=0)
                    finished.put(new JSONObject(fixture.toString()));
                else if (isTrueUpcoming(status))
                    upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            mergeStandings(root);
            addSourceMetadata(root,fixtures.length());
        } catch (Exception ignored) {
            // A malformed local fallback must never block the rest of the app.
        }
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result=new JSONArray();
        int index=0;
        for(int round=1;round<=38;round++) {
            int sourceRound=round<=19?round:round-19;
            String roundDate=round<=19?FIRST_HALF_DATES[sourceRound-1]:SECOND_HALF_DATES[sourceRound-1];
            String[][] pairings=FIRST_HALF[sourceRound-1];
            for(String[] pairing:pairings) {
                String home=round<=19?pairing[0]:pairing[1];
                String away=round<=19?pairing[1]:pairing[0];
                String date=roundDate;
                String status=round<=20?"NO_RESULT":"SCHEDULED";
                Integer homeScore=null,awayScore=null;

                // Six completed round-21 matches are bundled as verified results.
                if(round==21) {
                    String k=clubKey(home)+"|"+clubKey(away);
                    if(k.equals("internacional|flamengo")) {date="2026-07-29T22:30:00Z";status="FINISHED";homeScore=1;awayScore=1;}
                    else if(k.equals("vitoria|palmeiras")) {date="2026-07-30T00:30:00Z";status="FINISHED";homeScore=0;awayScore=4;}
                    else if(k.equals("coritiba|cruzeiro")) {date="2026-07-31T00:30:00Z";status="FINISHED";homeScore=0;awayScore=1;}
                    else if(k.equals("corinthians|athleticoparanaense")) {date="2026-07-30T22:30:00Z";status="FINISHED";homeScore=0;awayScore=0;}
                    else if(k.equals("fluminense|bahia")) {date="2026-07-30T00:30:00Z";status="FINISHED";homeScore=0;awayScore=0;}
                    else if(k.equals("mirassol|remo")) {date="2026-07-29T22:30:00Z";status="FINISHED";homeScore=2;awayScore=1;}
                    else status="POSTPONED_TBC";
                }

                // Exact published round-22 kickoffs as available on 8 Aug 2026.
                if(round==22) {
                    String k=clubKey(home)+"|"+clubKey(away);
                    if(k.equals("gremio|saopaulo")) date="2026-08-08T19:00:00Z";
                    else if(k.equals("remo|atleticomineiro")) date="2026-08-08T21:30:00Z";
                    else if(k.equals("coritiba|chapecoense")) date="2026-08-08T23:30:00Z";
                    else if(k.equals("botafogo|fluminense")) date="2026-08-09T00:00:00Z";
                    else if(k.equals("cruzeiro|mirassol")) date="2026-08-09T14:00:00Z";
                    else if(k.equals("palmeiras|internacional")) date="2026-08-09T19:00:00Z";
                    else if(k.equals("bahia|vascodagama")) date="2026-08-09T19:00:00Z";
                    else if(k.equals("santos|athleticoparanaense")) date="2026-08-09T21:30:00Z";
                    else if(k.equals("redbullbragantino|corinthians")) date="2026-08-09T21:30:00Z";
                    else if(k.equals("flamengo|vitoria")) date="2026-08-09T22:30:00Z";
                    status="TIMED";
                }

                JSONObject fixture=new JSONObject();
                fixture.put("id","BSA-2026-"+round+"-"+(++index));
                fixture.put("competition",competitionObject());
                fixture.put("competitionName",COMPETITION_NAME);
                fixture.put("competitionCode",COMPETITION_CODE);
                fixture.put("home",home); fixture.put("away",away);
                fixture.put("homeTeam",teamObject(home)); fixture.put("awayTeam",teamObject(away));
                fixture.put("utcDate",date); fixture.put("date",date);
                fixture.put("status",status);
                fixture.put("matchday",round); fixture.put("roundNumber",round);
                fixture.put("roundName","Kolo "+round); fixture.put("stage","Kolo "+round); fixture.put("group","");
                fixture.put("venue",VENUES.containsKey(home)?VENUES.get(home):"");
                fixture.put("dataProvider","Verified Brasileirão Série A 2026 programme");
                fixture.put("season",SEASON);
                if(status.equals("NO_RESULT")) fixture.put("historicalPairingOnly",true);
                if(status.equals("POSTPONED_TBC")) fixture.put("dateTbc",true);
                if(homeScore!=null&&awayScore!=null) {fixture.put("homeScore",homeScore);fixture.put("awayScore",awayScore);}

                JSONObject richer=online.get(matchKey(fixture));
                if(richer!=null) mergeOnlineRow(fixture,richer);
                result.put(fixture);
            }
        }
        return result;
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String,JSONObject> result=new HashMap<String,JSONObject>();
        String[] feeds={"matches","upcoming","live","finished"};
        for(String feed:feeds) {
            JSONArray source=root.optJSONArray(feed); if(source==null)continue;
            for(int i=0;i<source.length();i++) {
                JSONObject row=source.optJSONObject(i);
                if(!isCurrentSeasonBrazil(row))continue;
                String key=matchKey(row); if(key.length()==0)continue;
                JSONObject existing=result.get(key);
                if(existing==null||rowRichness(row)>=rowRichness(existing))
                    try{result.put(key,new JSONObject(row.toString()));}catch(Exception ignored){}
            }
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target,JSONObject source) {
        try {
            String[] keys={"status","minute","matchMinute","elapsed","venue","attendance","score","scores","result",
                    "homeGoals","awayGoals","homeScore","awayScore","events","goals","bookings","substitutions","referees"};
            for(String key:keys) if(source.has(key)&&!source.isNull(key))target.put(key,source.opt(key));
            JSONObject home=source.optJSONObject("homeTeam"),away=source.optJSONObject("awayTeam");
            if(home!=null)target.put("homeTeam",mergeTeam(target.optJSONObject("homeTeam"),home));
            if(away!=null)target.put("awayTeam",mergeTeam(target.optJSONObject("awayTeam"),away));
            String sourceDate=source.optString("utcDate",source.optString("date","")).trim();
            if(sourceDate.length()>=10){target.put("utcDate",sourceDate);target.put("date",sourceDate);}
            target.put("dataProvider",source.optString("dataProvider","Connected Brasileirão source"));
            target.remove("historicalPairingOnly");
            if(!source.optBoolean("dateTbc",false))target.remove("dateTbc");
        } catch(Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback,JSONObject richer) throws Exception {
        JSONObject out=fallback==null?new JSONObject():new JSONObject(fallback.toString());
        String[] keys={"tla","crest","emblem","logo","venue","address","website","clubColors","founded"};
        for(String key:keys) if(richer.has(key)&&!richer.isNull(key)) {
            Object raw=richer.opt(key);String value=String.valueOf(raw).trim();
            if(value.length()>0&&!"null".equalsIgnoreCase(value))out.put(key,raw);
        }
        Object richerArea=richer.opt("area");
        if(richerArea instanceof JSONObject)out.put("area",richerArea);
        else if(richerArea!=null&&String.valueOf(richerArea).trim().length()>0) {
            JSONObject area=new JSONObject();area.put("name",String.valueOf(richerArea).trim());out.put("area",area);
        }
        String canonical=canonicalName(out.optString("name",out.optString("shortName","")));
        if(out.optString("crest","").trim().length()==0&&CRESTS.containsKey(canonical))out.put("crest",CRESTS.get(canonical));
        return out;
    }

    private static JSONArray copyWithoutBrazil(JSONArray source) {
        JSONArray result=new JSONArray(); if(source==null)return result;
        for(int i=0;i<source.length();i++) {
            JSONObject row=source.optJSONObject(i);if(row==null||isBrazil(row))continue;
            try{result.put(new JSONObject(row.toString()));}catch(Exception ignored){}
        }
        return result;
    }

    private static boolean isCurrentSeasonBrazil(JSONObject row) {
        if(!isBrazil(row))return false;
        String date=row.optString("utcDate",row.optString("date",""));
        if(date.length()<10)return false;
        String day=date.substring(0,10);
        return day.compareTo(FIRST_DATE)>=0&&day.compareTo(LAST_DATE)<=0;
    }

    private static boolean isBrazil(JSONObject row) {
        if(row==null)return false;
        Object raw=row.opt("competition");String rawCode="",rawName="";
        if(raw instanceof JSONObject){JSONObject c=(JSONObject)raw;rawCode=c.optString("code","");rawName=c.optString("name","");}
        else if(raw!=null)rawName=String.valueOf(raw);
        String rowCode=row.optString("competitionCode","");
        String a=normalize(rawCode),b=normalize(rowCode);
        if(a.equals("bsa")||b.equals("bsa"))return true;
        if(a.length()>0||b.length()>0)return false;
        String n1=normalize(rawName),n2=normalize(row.optString("competitionName",""));
        return n1.contains("brasileirao")||n1.equals("serieabrazil")||n2.contains("brasileirao")||n2.equals("serieabrazil");
    }

    private static String matchKey(JSONObject row) {
        if(row==null)return "";
        String home=teamName(row,true),away=teamName(row,false);
        if(home.length()==0||away.length()==0)return "";
        return clubKey(home)+"|"+clubKey(away);
    }

    private static String teamName(JSONObject row,boolean home) {
        String value=row.optString(home?"home":"away","").trim();if(value.length()>0)return value;
        JSONObject team=row.optJSONObject(home?"homeTeam":"awayTeam");if(team==null)return "";
        return team.optString("name",team.optString("shortName",team.optString("tla",""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if(row==null)return 0;
        int score=0;String status=row.optString("status","").toUpperCase(Locale.US);
        if(isFinished(status))score+=30;else if(isLive(status))score+=25;else if(status.contains("TIMED"))score+=8;
        if(row.has("score")||row.has("homeGoals")||row.has("homeScore"))score+=12;
        if(row.has("events")||row.has("goals"))score+=8;
        if(row.optString("venue","").trim().length()>0)score+=4;
        if(row.optJSONObject("homeTeam")!=null)score+=2;if(row.optJSONObject("awayTeam")!=null)score+=2;
        return score;
    }

    private static boolean isLive(String status) {
        String v=status==null?"":status.toUpperCase(Locale.US);
        return v.contains("LIVE")||v.contains("IN_PLAY")||v.contains("IN PROGRESS")||v.equals("PAUSED")||v.equals("HALF_TIME")||v.equals("HT");
    }
    private static boolean isFinished(String status) {
        String v=status==null?"":status.toUpperCase(Locale.US);
        return v.contains("FINISHED")||v.equals("FT")||v.contains("FINAL")||v.equals("AWARDED");
    }
    private static boolean isTrueUpcoming(String status) {
        String v=status==null?"":status.toUpperCase(Locale.US);
        return v.contains("SCHEDULED")||v.contains("TIMED")||v.contains("UPCOMING")||v.contains("NOT_STARTED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject c=new JSONObject();c.put("code",COMPETITION_CODE);c.put("name",COMPETITION_NAME);return c;
    }

    private static JSONObject teamObject(String name) throws Exception {
        String canonical=canonicalName(name);
        JSONObject team=new JSONObject();team.put("name",canonical);team.put("shortName",canonical);
        team.put("tla",TLA.containsKey(canonical)?TLA.get(canonical):"");
        JSONObject area=new JSONObject();area.put("name","Brazil");team.put("area",area);
        if(CRESTS.containsKey(canonical))team.put("crest",CRESTS.get(canonical));
        if(VENUES.containsKey(canonical))team.put("venue",VENUES.get(canonical));
        if(FOUNDED.containsKey(canonical))team.put("founded",FOUNDED.get(canonical));
        if(WEBSITES.containsKey(canonical))team.put("website",WEBSITES.get(canonical));
        if(COLORS.containsKey(canonical))team.put("clubColors",COLORS.get(canonical));
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source=root.optJSONArray("teams");JSONArray teams=new JSONArray();
        if(source!=null)for(int i=0;i<source.length();i++) {
            JSONObject team=source.optJSONObject(i);if(team==null)continue;
            String name=team.optString("shortName",team.optString("name",""));
            if(isBrazilClub(name))continue;
            teams.put(new JSONObject(team.toString()));
        }
        for(String name:TLA.keySet()) {
            JSONObject canonical=teamObject(name);
            if(source!=null)for(int i=0;i<source.length();i++) {
                JSONObject existing=source.optJSONObject(i);if(existing==null)continue;
                String existingName=existing.optString("shortName",existing.optString("name",""));
                if(clubKey(existingName).equals(clubKey(name))){canonical=mergeTeam(canonical,existing);break;}
            }
            teams.put(canonical);
        }
        root.put("teams",teams);
    }

    private static boolean isBrazilClub(String value) {
        String key=clubKey(value);
        for(String name:TLA.keySet())if(clubKey(name).equals(key))return true;
        // stale provider identities from the prior Brazilian top-flight season
        return key.equals("fortaleza")||key.equals("ceara")||key.equals("sportrecife")||key.equals("juventude");
    }

    private static void mergeStandings(JSONObject root) throws Exception {
        JSONObject all=root.optJSONObject("standings");if(all==null){all=new JSONObject();root.put("standings",all);}
        JSONObject existing=all.optJSONObject(COMPETITION_CODE);
        if(hasCurrentVerifiedTable(existing)){canonicalizeStandingTeams(existing);return;}
        all.put(COMPETITION_CODE,fallbackStandings());
    }

    private static boolean hasCurrentVerifiedTable(JSONObject entry) {
        if(entry==null)return false;
        JSONObject season=entry.optJSONObject("season");String start=season==null?"":season.optString("startDate","");
        if(!start.startsWith("2026"))return false;
        JSONArray blocks=entry.optJSONArray("standings");if(blocks==null)return false;
        for(int i=0;i<blocks.length();i++) {
            JSONObject block=blocks.optJSONObject(i);JSONArray table=block==null?null:block.optJSONArray("table");
            if(table!=null&&table.length()>=20)return true;
        }
        return false;
    }

    private static void canonicalizeStandingTeams(JSONObject entry) {
        try {
            JSONArray blocks=entry.optJSONArray("standings");if(blocks==null)return;
            for(int i=0;i<blocks.length();i++) {
                JSONObject block=blocks.optJSONObject(i);JSONArray table=block==null?null:block.optJSONArray("table");if(table==null)continue;
                for(int j=0;j<table.length();j++) {
                    JSONObject row=table.optJSONObject(j);JSONObject team=row==null?null:row.optJSONObject("team");if(team==null)continue;
                    String name=team.optString("shortName",team.optString("name",""));String canonical=canonicalName(name);
                    if(TLA.containsKey(canonical))row.put("team",mergeTeam(teamObject(canonical),team));
                }
            }
        } catch(Exception ignored) {}
    }

    private static JSONObject fallbackStandings() throws Exception {
        String[][] data={
                {"Palmeiras","21","14","5","2","38","16","47"},
                {"Flamengo","20","11","6","3","37","18","39"},
                {"Athletico Paranaense","21","11","4","6","28","19","37"},
                {"Fluminense","21","9","7","5","30","25","34"},
                {"Bahia","21","8","8","5","29","25","32"},
                {"Red Bull Bragantino","20","9","4","7","26","20","31"},
                {"Cruzeiro","21","8","6","7","27","30","30"},
                {"Botafogo","20","8","5","7","34","32","29"},
                {"Corinthians","21","7","8","6","22","20","29"},
                {"Atlético Mineiro","20","8","4","8","25","25","28"},
                {"Coritiba","21","7","6","8","25","28","27"},
                {"São Paulo","20","7","5","8","25","23","26"},
                {"Vitória","21","7","5","9","22","31","26"},
                {"Mirassol","20","6","5","9","23","27","23"},
                {"Santos","20","5","7","8","29","33","22"},
                {"Internacional","21","5","7","9","23","27","22"},
                {"Grêmio","20","5","7","8","22","26","22"},
                {"Vasco da Gama","20","5","6","9","23","31","21"},
                {"Remo","21","5","6","10","24","34","21"},
                {"Chapecoense","20","1","7","12","19","41","10"}
        };
        JSONArray table=new JSONArray();
        for(int i=0;i<data.length;i++) {
            String[] d=data[i];int played=Integer.parseInt(d[1]),won=Integer.parseInt(d[2]),draw=Integer.parseInt(d[3]),lost=Integer.parseInt(d[4]);
            int gf=Integer.parseInt(d[5]),ga=Integer.parseInt(d[6]),pts=Integer.parseInt(d[7]);
            JSONObject row=new JSONObject();row.put("position",i+1);row.put("team",teamObject(d[0]));
            row.put("playedGames",played);row.put("won",won);row.put("draw",draw);row.put("lost",lost);
            row.put("points",pts);row.put("goalsFor",gf);row.put("goalsAgainst",ga);row.put("goalDifference",gf-ga);
            table.put(row);
        }
        JSONObject block=new JSONObject();block.put("stage","REGULAR_SEASON");block.put("type","TOTAL");block.put("group","");block.put("table",table);
        JSONArray blocks=new JSONArray();blocks.put(block);
        JSONObject season=new JSONObject();season.put("startDate",FIRST_DATE);season.put("endDate",LAST_DATE);season.put("currentMatchday",22);
        JSONObject entry=new JSONObject();entry.put("competition",competitionObject());entry.put("competitionName",COMPETITION_NAME);
        entry.put("competitionCode",COMPETITION_CODE);entry.put("season",season);entry.put("standings",blocks);
        entry.put("dataProvider","Verified Brasileirão Série A 2026 standings snapshot");
        return entry;
    }

    private static int scoreValue(JSONObject row,boolean home) {
        String[] direct=home?new String[]{"homeGoals","homeScore","scoreHome","goalsHome"}:new String[]{"awayGoals","awayScore","scoreAway","goalsAway"};
        for(String key:direct)if(row.has(key))try{return row.getInt(key);}catch(Exception ignored){}
        JSONObject score=row.optJSONObject("score");
        if(score!=null) {
            JSONObject full=score.optJSONObject("fullTime");String key=home?"home":"away";
            if(full!=null&&full.has(key))try{return full.getInt(key);}catch(Exception ignored){}
            if(score.has(key))try{return score.getInt(key);}catch(Exception ignored){}
        }
        return -1;
    }

    private static void addSourceMetadata(JSONObject root,int matchCount) throws Exception {
        JSONObject sources=root.optJSONObject("sources");if(sources==null){sources=new JSONObject();root.put("sources",sources);}
        JSONObject brazil=sources.optJSONObject(COMPETITION_CODE);if(brazil==null)brazil=new JSONObject();
        brazil.put("status","connected");
        brazil.put("provider","Verified Brasileirão Série A 2026 programme + connected live source");
        brazil.put("season",SEASON);brazil.put("matchCount",matchCount);brazil.put("teamCount",TLA.size());brazil.put("roundCount",38);
        sources.put(COMPETITION_CODE,brazil);
    }

    private static String canonicalName(String value) {
        String key=clubKey(value);
        for(String name:TLA.keySet())if(clubKey(name).equals(key))return name;
        return value==null?"":value.trim();
    }

    private static String clubKey(String value) {
        String key=normalize(value);
        if(key.equals("cap")||key.equals("clubathleticoparanaense")||key.equals("athleticopr")||key.equals("athleticoparanaense"))return "athleticoparanaense";
        if(key.equals("cam")||key.equals("camineiro")||key.equals("clubeatleticomineiro")||key.equals("atleticomg"))return "atleticomineiro";
        if(key.equals("ecbahia")||key.equals("esporteclubebahia"))return "bahia";
        if(key.equals("botafogofr")||key.equals("botafogodefuteboleregatas"))return "botafogo";
        if(key.equals("chapecoenseaf")||key.equals("associacaochapecoensedefutebol"))return "chapecoense";
        if(key.equals("sportclubcorinthianspaulista")||key.equals("corinthianspaulista"))return "corinthians";
        if(key.equals("coritibafbc")||key.equals("coritibafc"))return "coritiba";
        if(key.equals("cruzeiroec")||key.equals("cruzeiroesporteclube"))return "cruzeiro";
        if(key.equals("crflamengo")||key.equals("clubederegatasdoflamengo"))return "flamengo";
        if(key.equals("fluminensefc")||key.equals("fluminensefootballclub"))return "fluminense";
        if(key.equals("gremiofbpa")||key.equals("gremiofootballportoalegrense"))return "gremio";
        if(key.equals("scinternacional")||key.equals("sportclubinternacional"))return "internacional";
        if(key.equals("mirassolfc"))return "mirassol";
        if(key.equals("sepalmeiras")||key.equals("sociedadeesportivapalmeiras"))return "palmeiras";
        if(key.equals("rbbragantino")||key.equals("redbullbragantinosp"))return "redbullbragantino";
        if(key.equals("clubedoremo")||key.equals("remopa"))return "remo";
        if(key.equals("santosfc")||key.equals("santosfutebolclube"))return "santos";
        if(key.equals("saopaulofc")||key.equals("saopaulofutebolclube"))return "saopaulo";
        if(key.equals("crvascodagama")||key.equals("clubederegatasvascodagama"))return "vascodagama";
        if(key.equals("ecvitoria")||key.equals("esporteclubedavitoria"))return "vitoria";
        return key;
    }

    private static String normalize(String value) {
        if(value==null)return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US),Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]+","");
    }

    private Brasileirao2026Data() {}
}
