package com.asappfactory.footballfun.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives a scheduled AlarmManager event and displays the match reminder. */
public final class MatchReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        MatchReminderScheduler.postScheduledNotification(context.getApplicationContext(), intent);
    }
}
