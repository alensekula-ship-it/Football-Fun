package com.asappfactory.footballfun.timeline;

import com.asappfactory.footballfun.model.DetailEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public final class FootballDataTimelineProvider implements TimelineProvider {
    @Override public String id() { return "football-data.org"; }
    @Override public boolean supports(JSONObject match) { return match != null; }

    @Override public String format(JSONObject match, TimelineEnvironment env) {
        ArrayList<DetailEvent> all = new ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        appendGoals(all, seen, match.optJSONArray("goals"), env);
        appendBookings(all, seen, match.optJSONArray("bookings"), env);
        appendSubstitutions(all, seen, match.optJSONArray("substitutions"), env);
        appendGeneric(all, seen, match.optJSONArray("varEvents"), env);
        appendGeneric(all, seen, match.optJSONArray("var"), env);
        appendGeneric(all, seen, match.optJSONArray("penaltyEvents"), env);
        appendGeneric(all, seen, match.optJSONArray("events"), env);
        appendPeriodEvents(all, seen, match, env);
        Collections.sort(all, (a,b) -> a.minute == b.minute ? a.text.compareTo(b.text) : a.minute - b.minute);
        StringBuilder out = new StringBuilder();
        for (DetailEvent event : all) {
            if (out.length() > 0) out.append('\n');
            out.append(event.text);
        }
        return out.toString();
    }

    private void appendGoals(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, JSONArray goals, TimelineEnvironment env) {
        if (goals == null) return;
        for (int i=0;i<goals.length();i++) {
            JSONObject g=goals.optJSONObject(i); if(g==null) continue;
            int minute=g.optInt("minute",0), injury=g.optInt("injuryTime",0);
            String text="⚽ "+minuteLabel(minute,injury)+" "+name(g.optJSONObject("scorer"));
            String assist=name(g.optJSONObject("assist"));
            if(!assist.isEmpty()) text+=" ("+env.text("assist","asistencija","Vorlage","asistencia","passe")+": "+assist+")";
            String team=name(g.optJSONObject("team"));
            if(!team.isEmpty()) text+=" • "+env.displayTeamName(team);
            add(all,seen,minute,text);
        }
    }

    private void appendBookings(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, JSONArray bookings, TimelineEnvironment env) {
        if(bookings==null)return;
        for(int i=0;i<bookings.length();i++){
            JSONObject b=bookings.optJSONObject(i);if(b==null)continue;
            int minute=b.optInt("minute",0);String card=b.optString("card",b.optString("type","")).toUpperCase(Locale.US);
            String text=(card.contains("RED")?"🟥":"🟨")+" "+minuteLabel(minute,b.optInt("injuryTime",0))+" "+name(b.optJSONObject("player"));
            String team=name(b.optJSONObject("team"));if(!team.isEmpty())text+=" • "+env.displayTeamName(team);add(all,seen,minute,text);
        }
    }

    private void appendSubstitutions(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, JSONArray substitutions, TimelineEnvironment env) {
        if(substitutions==null)return;
        for(int i=0;i<substitutions.length();i++){
            JSONObject s=substitutions.optJSONObject(i);if(s==null)continue;int minute=s.optInt("minute",0);
            String text="🔄 "+minuteLabel(minute,s.optInt("injuryTime",0))+" "+name(s.optJSONObject("playerIn"))+" ↔ "+name(s.optJSONObject("playerOut"));
            String team=name(s.optJSONObject("team"));if(!team.isEmpty())text+=" • "+env.displayTeamName(team);add(all,seen,minute,text);
        }
    }

    private void appendGeneric(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, JSONArray events, TimelineEnvironment env) {
        if(events==null)return;
        for(int i=0;i<events.length();i++){
            JSONObject e=events.optJSONObject(i);if(e==null)continue;
            int minute=e.optInt("minute",e.optInt("time",0)),injury=e.optInt("injuryTime",e.optInt("addedTime",0));
            String type=e.optString("type",e.optString("eventType",e.optString("detail",""))).toUpperCase(Locale.US);
            String detail=e.optString("detail",e.optString("reason",e.optString("description","")));
            String player=name(e.optJSONObject("player"));if(player.isEmpty())player=e.optString("playerName",e.optString("name",""));
            String team=name(e.optJSONObject("team"));if(team.isEmpty())team=e.optString("teamName","");
            String icon="●",caption=detail;
            if(type.contains("CANCELLED_GOAL")||type.contains("DISALLOWED_GOAL")||type.contains("GOAL_CANCEL")||type.contains("GOAL_DISALLOW")){icon="⚽";caption=env.text("Goal disallowed","Poništen gol","Tor aberkannt","Gol anulado","But refusé")+(detail.isEmpty()?"":" — "+detail);} 
            else if(type.contains("VAR")){icon="📺";caption=env.text("VAR check","VAR provjera","VAR-Prüfung","Revisión VAR","Vérification VAR")+(detail.isEmpty()?"":" — "+detail);} 
            else if(type.contains("PENALTY")||type.contains("PEN")){icon="🎯";caption=type.contains("MISS")?env.text("Penalty missed","Promašen jedanaesterac","Elfmeter verschossen","Penalti fallado","Penalty manqué"):env.text("Penalty","Jedanaesterac","Elfmeter","Penalti","Penalty");if(!detail.isEmpty())caption+=" — "+detail;} 
            else if(type.contains("GOAL")){icon="⚽";caption=detail.isEmpty()?env.text("Goal","Gol","Tor","Gol","But"):detail;} 
            else if(type.contains("RED")){icon="🟥";} else if(type.contains("YELLOW")||type.contains("CARD")){icon="🟨";} else if(type.contains("SUB")){icon="🔄";} 
            else if(type.contains("EXTRA_TIME")||type.equals("ET")){icon="⏱️";caption=env.text("Extra time","Produžeci","Verlängerung","Prórroga","Prolongation");}
            if(caption==null||caption.trim().isEmpty())caption=type.isEmpty()?env.text("Match event","Događaj utakmice","Spielereignis","Evento del partido","Événement du match"):type;
            String text=icon+" "+minuteLabel(minute,injury)+" "+caption;
            if(!player.isEmpty()&&!caption.toLowerCase(Locale.US).contains(player.toLowerCase(Locale.US)))text+=" • "+player;
            if(!team.isEmpty())text+=" • "+env.displayTeamName(team);add(all,seen,minute,text);
        }
    }

    private void appendPeriodEvents(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, JSONObject match, TimelineEnvironment env) {
        String status=match.optString("status",match.optString("state","")).toUpperCase(Locale.US);
        int minute=env.parseMinute(match.optString("minute",match.optString("elapsed",match.optString("clock",""))));
        JSONObject score=match.optJSONObject("score"),half=score==null?null:score.optJSONObject("halfTime");
        boolean hasHalf=half!=null&&!half.isNull("home")&&!half.isNull("away");
        if(hasHalf||status.contains("HALF")||status.equals("HT")||minute>=46){String detail=hasHalf?" • "+half.optInt("home")+" : "+half.optInt("away"):"";add(all,seen,45,"⏸️ 45′ "+env.text("Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps")+detail);} 
        if(minute>=46&&(status.contains("LIVE")||status.contains("IN_PLAY")||status.contains("SECOND")||status.contains("2H")||status.contains("PAUSED")))add(all,seen,46,"▶️ 46′ "+env.text("Second half started","Početak drugog poluvremena","Zweite Halbzeit begonnen","Comenzó la segunda parte","Début de la seconde période"));
        if(env.isFinished(status))add(all,seen,90,"🏁 90′ "+env.text("Full-time","Kraj utakmice","Spielende","Final del partido","Fin du match"));
    }

    private void add(ArrayList<DetailEvent> all, LinkedHashSet<String> seen, int minute, String text){String normalized=text==null?"":text.replaceAll("\\s+"," ").trim();if(normalized.isEmpty())return;String key=minute+"|"+normalized.toLowerCase(Locale.US);if(seen.add(key))all.add(new DetailEvent(minute,normalized));}
    private String minuteLabel(int minute,int injury){if(injury>0)return minute+"+"+injury+"′";return minute>0?minute+"′":"";}
    private String name(JSONObject o){return o==null?"":o.optString("name",o.optString("shortName",""));}
}
