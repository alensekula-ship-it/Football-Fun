package com.asappfactory.footballfun.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

/** Single boundary for durable user choices. Online cache remains in its own repository path. */
public final class UserPreferences {
    private final SharedPreferences preferences;

    public UserPreferences(Context context) {
        preferences = context.getSharedPreferences("footballfun", Context.MODE_PRIVATE);
    }

    public SharedPreferences raw() {
        return preferences;
    }

    public boolean darkMode() { return preferences.getBoolean("darkMode", true); }
    public String language() { return preferences.getString("lang", "EN"); }
    public String nationalTeam() { return preferences.getString("team", "Croatia"); }
    public String favoriteClub() { return preferences.getString("favoriteClub", "Dinamo Zagreb"); }
    public String profileName() { return preferences.getString("profileName", "Football Fan"); }
    public String profileCountry() { return preferences.getString("profileCountry", "Croatia"); }
    public boolean favoriteNotifications() { return preferences.getBoolean("favoriteNotifications", true); }

    public LinkedHashSet<String> favoriteClubs(String primaryClub) {
        Set<String> stored = preferences.getStringSet(
                "favoriteClubs",
                new LinkedHashSet<String>(Arrays.asList(primaryClub))
        );
        LinkedHashSet<String> result = new LinkedHashSet<String>(stored);
        if (result.isEmpty()) result.add(primaryClub);
        return result;
    }

    public LinkedHashSet<String> followedCompetitions() {
        Set<String> stored = preferences.getStringSet(
                "followedCompetitions",
                new LinkedHashSet<String>(Arrays.asList("UEFA Champions League", "HNL", "World Cup 2026"))
        );
        return new LinkedHashSet<String>(stored);
    }

    public void saveFavoriteClubs(Set<String> clubs, String primaryClub) {
        preferences.edit()
                .putStringSet("favoriteClubs", new LinkedHashSet<String>(clubs))
                .putString("favoriteClub", primaryClub)
                .apply();
    }

    public void saveFollowedCompetitions(Set<String> competitions) {
        preferences.edit().putStringSet("followedCompetitions", new LinkedHashSet<String>(competitions)).apply();
    }

    public void saveFavoriteNotifications(boolean enabled) {
        preferences.edit().putBoolean("favoriteNotifications", enabled).apply();
    }

    public void saveNationalTeam(String team) { preferences.edit().putString("team", team).apply(); }
    public void saveLanguage(String language) { preferences.edit().putString("lang", language).apply(); }
    public void saveDarkMode(boolean enabled) { preferences.edit().putBoolean("darkMode", enabled).apply(); }
    public void saveProfile(String name, String country) {
        preferences.edit().putString("profileName", name).putString("profileCountry", country).apply();
    }
}
