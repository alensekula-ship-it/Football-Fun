package com.asappfactory.footballfun.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.LinkedHashSet;
import java.util.Set;

/** Single boundary for durable user choices. Online cache remains in its own repository path. */
public final class UserPreferences {
    private final SharedPreferences preferences;

    public UserPreferences(Context context) {
        preferences = context.getSharedPreferences("footballfun", Context.MODE_PRIVATE);
    }

    public SharedPreferences raw() {
        return preferences;
    }

    public boolean darkMode() { return preferences.getBoolean("darkMode", true); }
    public String language() { return preferences.getString("lang", "EN"); }
    public String nationalTeam() { return preferences.getString("team", ""); }
    public String favoriteClub() { return preferences.getString("favoriteClub", ""); }
    public String profileName() { return preferences.getString("profileName", "Football Fan"); }
    public String profileCountry() { return preferences.getString("profileCountry", "Croatia"); }
    public boolean favoriteNotifications() { return preferences.getBoolean("favoriteNotifications", true); }
    public int matchReminderMinutes() { return preferences.getInt("matchReminderMinutes", 60); }
    public boolean competitionReminders() { return preferences.getBoolean("competitionReminders", false); }
    public boolean proUnlocked() { return preferences.getBoolean("proUnlocked", false); }

    public LinkedHashSet<String> favoriteClubs(String primaryClub) {
        Set<String> stored = preferences.getStringSet("favoriteClubs", new LinkedHashSet<String>());
        LinkedHashSet<String> result = new LinkedHashSet<String>(stored);
        if (primaryClub != null && !primaryClub.trim().isEmpty()) result.add(primaryClub.trim());
        return result;
    }

    public LinkedHashSet<String> favoriteNationalTeams(String primaryTeam) {
        Set<String> stored=preferences.getStringSet("favoriteNationalTeams",new LinkedHashSet<String>());
        LinkedHashSet<String> result = new LinkedHashSet<String>(stored);
        if (primaryTeam != null && !primaryTeam.trim().isEmpty()) result.add(primaryTeam.trim());
        return result;
    }

    public void saveFavoriteNationalTeams(Set<String> teams) {
        preferences.edit().putStringSet("favoriteNationalTeams",new LinkedHashSet<String>(teams)).apply();
    }

    public LinkedHashSet<String> followedCompetitions() {
        Set<String> stored = preferences.getStringSet("followedCompetitions", new LinkedHashSet<String>());
        return new LinkedHashSet<String>(stored);
    }

    public void saveFavoriteClubs(Set<String> clubs, String primaryClub) {
        preferences.edit()
                .putStringSet("favoriteClubs", new LinkedHashSet<String>(clubs))
                .putString("favoriteClub", primaryClub)
                .apply();
    }

    public void savePrimaryClub(String primaryClub) {
        preferences.edit().putString("favoriteClub", primaryClub).apply();
    }

    public void saveFollowedCompetitions(Set<String> competitions) {
        preferences.edit().putStringSet("followedCompetitions", new LinkedHashSet<String>(competitions)).apply();
    }

    public void saveFavoriteNotifications(boolean enabled) {
        preferences.edit().putBoolean("favoriteNotifications", enabled).apply();
    }

    public void saveMatchReminderMinutes(int minutes) {
        preferences.edit().putInt("matchReminderMinutes", minutes).apply();
    }

    public void saveCompetitionReminders(boolean enabled) {
        preferences.edit().putBoolean("competitionReminders", enabled).apply();
    }

    /** Set only after a verified Google Play Billing purchase in the release integration. */
    public void saveProUnlocked(boolean unlocked) {
        preferences.edit().putBoolean("proUnlocked", unlocked).apply();
    }

    public void saveNationalTeam(String team) { preferences.edit().putString("team", team).apply(); }
    public void saveLanguage(String language) { preferences.edit().putString("lang", language).apply(); }
    public void saveDarkMode(boolean enabled) { preferences.edit().putBoolean("darkMode", enabled).apply(); }
    public void saveProfile(String name, String country) {
        preferences.edit().putString("profileName", name).putString("profileCountry", country).apply();
    }
}
