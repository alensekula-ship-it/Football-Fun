package com.asappfactory.footballfun.match;

/**
 * Normalized schema contract used between future providers and Football Fun.
 * It deliberately separates stable match identity from dynamic paid modules.
 */
public final class MatchDetailPayloadContract {
    public static final int SCHEMA_VERSION = 1;

    public static final String MATCH_ID = "matchId";
    public static final String STATISTICS = "statistics";
    public static final String EVENTS = "events";
    public static final String LINEUPS = "lineups";
    public static final String CARDS = "cards";
    public static final String SUBSTITUTIONS = "substitutions";
    public static final String GOALS = "goals";
    public static final String ASSISTS = "assists";
    public static final String VAR = "var";
    public static final String VERIFIED = "verified";
    public static final String SOURCE = "source";
    public static final String UPDATED_AT = "updatedAt";

    private MatchDetailPayloadContract() {}
}
