package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Official Liga Portugal Betclic 2026/27 fixture and club-identity fallback. */
public final class PrimeiraLiga2627Data {
    private static final String COMPETITION_NAME = "Primeira Liga";
    private static final String COMPETITION_CODE = "PPL";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-07";
    private static final String LAST_DATE = "2027-05-16";

    private static final String DATA =
            "2026-08-07T19:15:00Z|1|Estoril Praia|FC Famalicão|Estádio António Coimbra da Mota|FINISHED|1|1\n" +
            "2026-08-08T14:30:00Z|1|Marítimo|Casa Pia AC|Estádio do Marítimo|TIMED\n" +
            "2026-08-08T17:00:00Z|1|Vitória SC|FC Arouca|Estádio D. Afonso Henriques|TIMED\n" +
            "2026-08-08T19:30:00Z|1|Estrela Amadora|Sporting CP|Estádio José Gomes|TIMED\n" +
            "2026-08-09T17:00:00Z|1|FC Porto|FC Alverca|Estádio do Dragão|TIMED\n" +
            "2026-08-09T19:30:00Z|1|Gil Vicente FC|Rio Ave FC|Estádio Cidade de Barcelos|TIMED\n" +
            "2026-08-09T19:30:00Z|1|SL Benfica|Académico|Estádio do Sport Lisboa e Benfica|TIMED\n" +
            "2026-08-09T19:30:00Z|1|Moreirense FC|SC Braga|Parque Desportivo Comendador Joaquim de Almeida Freitas|TIMED\n" +
            "2026-08-10T19:15:00Z|1|Santa Clara|CD Nacional|Estádio de São Miguel|TIMED\n" +
            "2026-08-14T19:15:00Z|2|Sporting CP|Vitória SC|Estádio José Alvalade|TIMED\n" +
            "2026-08-15T14:30:00Z|2|FC Alverca|Estrela Amadora|Estádio do FC Alverca|TIMED\n" +
            "2026-08-15T17:00:00Z|2|Académico|Santa Clara|Estádio Municipal do Fontelo|TIMED\n" +
            "2026-08-15T19:30:00Z|2|Rio Ave FC|FC Porto|Estádio do Rio Ave Futebol Clube|TIMED\n" +
            "2026-08-16T14:30:00Z|2|CD Nacional|Estoril Praia|Estádio da Madeira|TIMED\n" +
            "2026-08-16T14:30:00Z|2|FC Famalicão|Marítimo|Estádio Municipal de Famalicão|TIMED\n" +
            "2026-08-16T19:30:00Z|2|Casa Pia AC|SL Benfica|Estádio Municipal de Rio Maior|TIMED\n" +
            "2026-08-16T19:30:00Z|2|SC Braga|Gil Vicente FC|Estádio Municipal de Braga|TIMED\n" +
            "2026-08-17T19:15:00Z|2|FC Arouca|Moreirense FC|Estádio Municipal de Arouca|TIMED\n" +
            "2026-08-23|3|FC Porto|FC Arouca|Estádio do Dragão|SCHEDULED\n" +
            "2026-08-23|3|Vitória SC|CD Nacional|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-08-23|3|Sporting CP|FC Alverca|Estádio José Alvalade|SCHEDULED\n" +
            "2026-08-23|3|Santa Clara|FC Famalicão|Estádio de São Miguel|SCHEDULED\n" +
            "2026-08-23|3|Gil Vicente FC|Casa Pia AC|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-08-23|3|Moreirense FC|SL Benfica|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-08-23|3|Marítimo|Académico|Estádio do Marítimo|SCHEDULED\n" +
            "2026-08-23|3|Estrela Amadora|SC Braga|Estádio José Gomes|SCHEDULED\n" +
            "2026-08-23|3|Estoril Praia|Rio Ave FC|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-08-30|4|SL Benfica|Estoril Praia|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-08-30|4|Rio Ave FC|Sporting CP|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-08-30|4|CD Nacional|Estrela Amadora|Estádio da Madeira|SCHEDULED\n" +
            "2026-08-30|4|FC Famalicão|Gil Vicente FC|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-08-30|4|Casa Pia AC|Moreirense FC|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-08-30|4|SC Braga|Vitória SC|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-08-30|4|FC Arouca|Marítimo|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-08-30|4|FC Alverca|Santa Clara|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-08-30|4|Académico|FC Porto|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-09-06|5|FC Porto|Moreirense FC|Estádio do Dragão|SCHEDULED\n" +
            "2026-09-06|5|Vitória SC|Casa Pia AC|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-09-06|5|Sporting CP|CD Nacional|Estádio José Alvalade|SCHEDULED\n" +
            "2026-09-06|5|Santa Clara|Rio Ave FC|Estádio de São Miguel|SCHEDULED\n" +
            "2026-09-06|5|Estrela Amadora|FC Famalicão|Estádio José Gomes|SCHEDULED\n" +
            "2026-09-06|5|Marítimo|SL Benfica|Estádio do Marítimo|SCHEDULED\n" +
            "2026-09-06|5|Estoril Praia|FC Arouca|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-09-06|5|Gil Vicente FC|Académico|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-09-06|5|FC Alverca|SC Braga|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-09-13|6|SL Benfica|Gil Vicente FC|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-09-13|6|Rio Ave FC|Estrela Amadora|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-09-13|6|CD Nacional|FC Alverca|Estádio da Madeira|SCHEDULED\n" +
            "2026-09-13|6|Moreirense FC|Marítimo|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-09-13|6|FC Famalicão|Sporting CP|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-09-13|6|Casa Pia AC|FC Porto|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-09-13|6|SC Braga|Estoril Praia|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-09-13|6|FC Arouca|Santa Clara|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-09-13|6|Académico|Vitória SC|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-09-20|7|Vitória SC|Moreirense FC|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-09-20|7|Sporting CP|FC Arouca|Estádio José Alvalade|SCHEDULED\n" +
            "2026-09-20|7|Santa Clara|SC Braga|Estádio de São Miguel|SCHEDULED\n" +
            "2026-09-20|7|FC Porto|SL Benfica|Estádio do Dragão|SCHEDULED\n" +
            "2026-09-20|7|CD Nacional|FC Famalicão|Estádio da Madeira|SCHEDULED\n" +
            "2026-09-20|7|Gil Vicente FC|Marítimo|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-09-20|7|Estoril Praia|Casa Pia AC|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-09-20|7|Estrela Amadora|Académico|Estádio José Gomes|SCHEDULED\n" +
            "2026-09-20|7|FC Alverca|Rio Ave FC|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-10-11|8|Académico|Estoril Praia|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-10-11|8|FC Arouca|Estrela Amadora|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-10-11|8|SC Braga|Sporting CP|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-10-11|8|Casa Pia AC|Santa Clara|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-10-11|8|FC Famalicão|FC Alverca|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-10-11|8|Marítimo|FC Porto|Estádio do Marítimo|SCHEDULED\n" +
            "2026-10-11|8|Moreirense FC|Gil Vicente FC|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-10-11|8|Rio Ave FC|CD Nacional|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-10-11|8|SL Benfica|Vitória SC|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-10-25|9|Rio Ave FC|FC Famalicão|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-10-25|9|Vitória SC|Marítimo|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-10-25|9|Sporting CP|Académico|Estádio José Alvalade|SCHEDULED\n" +
            "2026-10-25|9|Santa Clara|SL Benfica|Estádio de São Miguel|SCHEDULED\n" +
            "2026-10-25|9|Gil Vicente FC|FC Porto|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-10-25|9|CD Nacional|SC Braga|Estádio da Madeira|SCHEDULED\n" +
            "2026-10-25|9|Estrela Amadora|Casa Pia AC|Estádio José Gomes|SCHEDULED\n" +
            "2026-10-25|9|FC Alverca|FC Arouca|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-10-25|9|Estoril Praia|Moreirense FC|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-11-01|10|Moreirense FC|Estrela Amadora|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-11-01|10|SL Benfica|FC Alverca|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-11-01|10|FC Porto|Estoril Praia|Estádio do Dragão|SCHEDULED\n" +
            "2026-11-01|10|Académico|Rio Ave FC|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-11-01|10|Marítimo|Santa Clara|Estádio do Marítimo|SCHEDULED\n" +
            "2026-11-01|10|Gil Vicente FC|Vitória SC|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-11-01|10|Casa Pia AC|Sporting CP|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-11-01|10|FC Arouca|CD Nacional|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-11-01|10|SC Braga|FC Famalicão|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-11-08|11|Estoril Praia|Marítimo|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-11-08|11|Santa Clara|Gil Vicente FC|Estádio de São Miguel|SCHEDULED\n" +
            "2026-11-08|11|CD Nacional|Académico|Estádio da Madeira|SCHEDULED\n" +
            "2026-11-08|11|FC Famalicão|FC Arouca|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-11-08|11|Vitória SC|FC Porto|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-11-08|11|Estrela Amadora|SL Benfica|Estádio José Gomes|SCHEDULED\n" +
            "2026-11-08|11|Sporting CP|Moreirense FC|Estádio José Alvalade|SCHEDULED\n" +
            "2026-11-08|11|FC Alverca|Casa Pia AC|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-11-08|11|Rio Ave FC|SC Braga|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-11-29|12|Académico|FC Alverca|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-11-29|12|Casa Pia AC|SC Braga|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-11-29|12|Gil Vicente FC|Estoril Praia|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-11-29|12|Marítimo|CD Nacional|Estádio do Marítimo|SCHEDULED\n" +
            "2026-11-29|12|Moreirense FC|Santa Clara|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-11-29|12|FC Porto|Sporting CP|Estádio do Dragão|SCHEDULED\n" +
            "2026-11-29|12|SL Benfica|FC Famalicão|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-11-29|12|Vitória SC|Estrela Amadora|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-11-29|12|FC Arouca|Rio Ave FC|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-12-06|13|Estrela Amadora|Gil Vicente FC|Estádio José Gomes|SCHEDULED\n" +
            "2026-12-06|13|Estoril Praia|Vitória SC|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-12-06|13|SC Braga|FC Arouca|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-12-06|13|FC Famalicão|Académico|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-12-06|13|Santa Clara|FC Porto|Estádio de São Miguel|SCHEDULED\n" +
            "2026-12-06|13|Rio Ave FC|Casa Pia AC|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-12-06|13|Sporting CP|Marítimo|Estádio José Alvalade|SCHEDULED\n" +
            "2026-12-06|13|CD Nacional|SL Benfica|Estádio da Madeira|SCHEDULED\n" +
            "2026-12-06|13|FC Alverca|Moreirense FC|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-12-13|14|Moreirense FC|FC Famalicão|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-12-13|14|Vitória SC|FC Alverca|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-12-13|14|SL Benfica|SC Braga|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-12-13|14|FC Porto|Estrela Amadora|Estádio do Dragão|SCHEDULED\n" +
            "2026-12-13|14|Gil Vicente FC|Sporting CP|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-12-13|14|Marítimo|Rio Ave FC|Estádio do Marítimo|SCHEDULED\n" +
            "2026-12-13|14|Estoril Praia|Santa Clara|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-12-13|14|Casa Pia AC|CD Nacional|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2026-12-13|14|Académico|FC Arouca|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2026-12-20|15|CD Nacional|Moreirense FC|Estádio da Madeira|SCHEDULED\n" +
            "2026-12-20|15|Santa Clara|Vitória SC|Estádio de São Miguel|SCHEDULED\n" +
            "2026-12-20|15|Rio Ave FC|SL Benfica|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2026-12-20|15|Sporting CP|Estoril Praia|Estádio José Alvalade|SCHEDULED\n" +
            "2026-12-20|15|FC Famalicão|FC Porto|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2026-12-20|15|FC Arouca|Casa Pia AC|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2026-12-20|15|Estrela Amadora|Marítimo|Estádio José Gomes|SCHEDULED\n" +
            "2026-12-20|15|FC Alverca|Gil Vicente FC|Estádio do FC Alverca|SCHEDULED\n" +
            "2026-12-20|15|SC Braga|Académico|Estádio Municipal de Braga|SCHEDULED\n" +
            "2026-12-27|16|FC Porto|CD Nacional|Estádio do Dragão|SCHEDULED\n" +
            "2026-12-27|16|SL Benfica|Sporting CP|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2026-12-27|16|Santa Clara|Estrela Amadora|Estádio de São Miguel|SCHEDULED\n" +
            "2026-12-27|16|Vitória SC|Rio Ave FC|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2026-12-27|16|Moreirense FC|Académico|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2026-12-27|16|Marítimo|SC Braga|Estádio do Marítimo|SCHEDULED\n" +
            "2026-12-27|16|Gil Vicente FC|FC Arouca|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2026-12-27|16|Estoril Praia|FC Alverca|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2026-12-27|16|Casa Pia AC|FC Famalicão|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-01-10|17|Sporting CP|Santa Clara|Estádio José Alvalade|SCHEDULED\n" +
            "2027-01-10|17|Rio Ave FC|Moreirense FC|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-01-10|17|CD Nacional|Gil Vicente FC|Estádio da Madeira|SCHEDULED\n" +
            "2027-01-10|17|FC Famalicão|Vitória SC|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-01-10|17|SC Braga|FC Porto|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-01-10|17|FC Arouca|SL Benfica|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-01-10|17|Estrela Amadora|Estoril Praia|Estádio José Gomes|SCHEDULED\n" +
            "2027-01-10|17|FC Alverca|Marítimo|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-01-10|17|Académico|Casa Pia AC|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-01-17|18|FC Alverca|FC Porto|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-01-17|18|FC Arouca|Vitória SC|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-01-17|18|Académico|SL Benfica|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-01-17|18|CD Nacional|Santa Clara|Estádio da Madeira|SCHEDULED\n" +
            "2027-01-17|18|Sporting CP|Estrela Amadora|Estádio José Alvalade|SCHEDULED\n" +
            "2027-01-17|18|SC Braga|Moreirense FC|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-01-17|18|Rio Ave FC|Gil Vicente FC|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-01-17|18|FC Famalicão|Estoril Praia|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-01-17|18|Casa Pia AC|Marítimo|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-01-24|19|Marítimo|FC Famalicão|Estádio do Marítimo|SCHEDULED\n" +
            "2027-01-24|19|Vitória SC|Sporting CP|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-01-24|19|FC Porto|Rio Ave FC|Estádio do Dragão|SCHEDULED\n" +
            "2027-01-24|19|Estoril Praia|CD Nacional|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-01-24|19|Estrela Amadora|FC Alverca|Estádio José Gomes|SCHEDULED\n" +
            "2027-01-24|19|SL Benfica|Casa Pia AC|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-01-24|19|Gil Vicente FC|SC Braga|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-01-24|19|Moreirense FC|FC Arouca|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-01-24|19|Santa Clara|Académico|Estádio de São Miguel|SCHEDULED\n" +
            "2027-01-31|20|FC Arouca|FC Porto|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-01-31|20|CD Nacional|Vitória SC|Estádio da Madeira|SCHEDULED\n" +
            "2027-01-31|20|FC Alverca|Sporting CP|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-01-31|20|FC Famalicão|Santa Clara|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-01-31|20|SL Benfica|Moreirense FC|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-01-31|20|Casa Pia AC|Gil Vicente FC|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-01-31|20|Rio Ave FC|Estoril Praia|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-01-31|20|Académico|Marítimo|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-01-31|20|SC Braga|Estrela Amadora|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-02-07|21|Moreirense FC|Casa Pia AC|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-02-07|21|FC Porto|Académico|Estádio do Dragão|SCHEDULED\n" +
            "2027-02-07|21|Santa Clara|FC Alverca|Estádio de São Miguel|SCHEDULED\n" +
            "2027-02-07|21|Marítimo|FC Arouca|Estádio do Marítimo|SCHEDULED\n" +
            "2027-02-07|21|Vitória SC|SC Braga|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-02-07|21|Gil Vicente FC|FC Famalicão|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-02-07|21|Estrela Amadora|CD Nacional|Estádio José Gomes|SCHEDULED\n" +
            "2027-02-07|21|Sporting CP|Rio Ave FC|Estádio José Alvalade|SCHEDULED\n" +
            "2027-02-07|21|Estoril Praia|SL Benfica|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-02-14|22|CD Nacional|Sporting CP|Estádio da Madeira|SCHEDULED\n" +
            "2027-02-14|22|Moreirense FC|FC Porto|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-02-14|22|Casa Pia AC|Vitória SC|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-02-14|22|Rio Ave FC|Santa Clara|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-02-14|22|SL Benfica|Marítimo|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-02-14|22|SC Braga|FC Alverca|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-02-14|22|FC Arouca|Estoril Praia|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-02-14|22|FC Famalicão|Estrela Amadora|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-02-14|22|Académico|Gil Vicente FC|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-02-21|23|Sporting CP|FC Famalicão|Estádio José Alvalade|SCHEDULED\n" +
            "2027-02-21|23|Vitória SC|Académico|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-02-21|23|Santa Clara|FC Arouca|Estádio de São Miguel|SCHEDULED\n" +
            "2027-02-21|23|Estoril Praia|SC Braga|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-02-21|23|FC Porto|Casa Pia AC|Estádio do Dragão|SCHEDULED\n" +
            "2027-02-21|23|Marítimo|Moreirense FC|Estádio do Marítimo|SCHEDULED\n" +
            "2027-02-21|23|FC Alverca|CD Nacional|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-02-21|23|Estrela Amadora|Rio Ave FC|Estádio José Gomes|SCHEDULED\n" +
            "2027-02-21|23|Gil Vicente FC|SL Benfica|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-02-28|24|FC Famalicão|CD Nacional|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-02-28|24|FC Arouca|Sporting CP|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-02-28|24|Moreirense FC|Vitória SC|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-02-28|24|SC Braga|Santa Clara|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-02-28|24|Casa Pia AC|Estoril Praia|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-02-28|24|SL Benfica|FC Porto|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-02-28|24|Marítimo|Gil Vicente FC|Estádio do Marítimo|SCHEDULED\n" +
            "2027-02-28|24|Académico|Estrela Amadora|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-02-28|24|Rio Ave FC|FC Alverca|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-03-07|25|Estoril Praia|Académico|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-03-07|25|Estrela Amadora|FC Arouca|Estádio José Gomes|SCHEDULED\n" +
            "2027-03-07|25|Sporting CP|SC Braga|Estádio José Alvalade|SCHEDULED\n" +
            "2027-03-07|25|Santa Clara|Casa Pia AC|Estádio de São Miguel|SCHEDULED\n" +
            "2027-03-07|25|FC Alverca|FC Famalicão|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-03-07|25|FC Porto|Marítimo|Estádio do Dragão|SCHEDULED\n" +
            "2027-03-07|25|Gil Vicente FC|Moreirense FC|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-03-07|25|CD Nacional|Rio Ave FC|Estádio da Madeira|SCHEDULED\n" +
            "2027-03-07|25|Vitória SC|SL Benfica|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-03-14|26|SL Benfica|Santa Clara|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-03-14|26|Casa Pia AC|Estrela Amadora|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-03-14|26|Académico|Sporting CP|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-03-14|26|Marítimo|Vitória SC|Estádio do Marítimo|SCHEDULED\n" +
            "2027-03-14|26|FC Famalicão|Rio Ave FC|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-03-14|26|FC Arouca|FC Alverca|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-03-14|26|SC Braga|CD Nacional|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-03-14|26|Moreirense FC|Estoril Praia|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-03-14|26|FC Porto|Gil Vicente FC|Estádio do Dragão|SCHEDULED\n" +
            "2027-03-21|27|CD Nacional|FC Arouca|Estádio da Madeira|SCHEDULED\n" +
            "2027-03-21|27|Rio Ave FC|Académico|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-03-21|27|FC Famalicão|SC Braga|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-03-21|27|Sporting CP|Casa Pia AC|Estádio José Alvalade|SCHEDULED\n" +
            "2027-03-21|27|Vitória SC|Gil Vicente FC|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-03-21|27|Santa Clara|Marítimo|Estádio de São Miguel|SCHEDULED\n" +
            "2027-03-21|27|Estrela Amadora|Moreirense FC|Estádio José Gomes|SCHEDULED\n" +
            "2027-03-21|27|Estoril Praia|FC Porto|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-03-21|27|FC Alverca|SL Benfica|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-04-04|28|FC Porto|Vitória SC|Estádio do Dragão|SCHEDULED\n" +
            "2027-04-04|28|Moreirense FC|Sporting CP|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-04-04|28|Gil Vicente FC|Santa Clara|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-04-04|28|SC Braga|Rio Ave FC|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-04-04|28|Académico|CD Nacional|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-04-04|28|Casa Pia AC|FC Alverca|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-04-04|28|FC Arouca|FC Famalicão|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-04-04|28|SL Benfica|Estrela Amadora|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-04-04|28|Marítimo|Estoril Praia|Estádio do Marítimo|SCHEDULED\n" +
            "2027-04-11|29|FC Alverca|Académico|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-04-11|29|Rio Ave FC|FC Arouca|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-04-11|29|SC Braga|Casa Pia AC|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-04-11|29|CD Nacional|Marítimo|Estádio da Madeira|SCHEDULED\n" +
            "2027-04-11|29|Santa Clara|Moreirense FC|Estádio de São Miguel|SCHEDULED\n" +
            "2027-04-11|29|Sporting CP|FC Porto|Estádio José Alvalade|SCHEDULED\n" +
            "2027-04-11|29|FC Famalicão|SL Benfica|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-04-11|29|Estrela Amadora|Vitória SC|Estádio José Gomes|SCHEDULED\n" +
            "2027-04-11|29|Estoril Praia|Gil Vicente FC|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-04-18|30|SL Benfica|CD Nacional|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-04-18|30|Marítimo|Sporting CP|Estádio do Marítimo|SCHEDULED\n" +
            "2027-04-18|30|FC Porto|Santa Clara|Estádio do Dragão|SCHEDULED\n" +
            "2027-04-18|30|Casa Pia AC|Rio Ave FC|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-04-18|30|Académico|FC Famalicão|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-04-18|30|Moreirense FC|FC Alverca|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-04-18|30|Vitória SC|Estoril Praia|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-04-18|30|Gil Vicente FC|Estrela Amadora|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-04-18|30|FC Arouca|SC Braga|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-04-25|31|FC Arouca|Académico|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-04-25|31|CD Nacional|Casa Pia AC|Estádio da Madeira|SCHEDULED\n" +
            "2027-04-25|31|Santa Clara|Estoril Praia|Estádio de São Miguel|SCHEDULED\n" +
            "2027-04-25|31|Rio Ave FC|Marítimo|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-04-25|31|FC Famalicão|Moreirense FC|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-04-25|31|Estrela Amadora|FC Porto|Estádio José Gomes|SCHEDULED\n" +
            "2027-04-25|31|SC Braga|SL Benfica|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-04-25|31|FC Alverca|Vitória SC|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-04-25|31|Sporting CP|Gil Vicente FC|Estádio José Alvalade|SCHEDULED\n" +
            "2027-05-02|32|Moreirense FC|CD Nacional|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED\n" +
            "2027-05-02|32|Estoril Praia|Sporting CP|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-05-02|32|Vitória SC|Santa Clara|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-05-02|32|SL Benfica|Rio Ave FC|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-05-02|32|FC Porto|FC Famalicão|Estádio do Dragão|SCHEDULED\n" +
            "2027-05-02|32|Casa Pia AC|FC Arouca|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-05-02|32|Marítimo|Estrela Amadora|Estádio do Marítimo|SCHEDULED\n" +
            "2027-05-02|32|Gil Vicente FC|FC Alverca|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-05-02|32|Académico|SC Braga|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-05-09|33|CD Nacional|FC Porto|Estádio da Madeira|SCHEDULED\n" +
            "2027-05-09|33|Rio Ave FC|Vitória SC|Estádio do Rio Ave Futebol Clube|SCHEDULED\n" +
            "2027-05-09|33|Sporting CP|SL Benfica|Estádio José Alvalade|SCHEDULED\n" +
            "2027-05-09|33|Estrela Amadora|Santa Clara|Estádio José Gomes|SCHEDULED\n" +
            "2027-05-09|33|Académico|Moreirense FC|Estádio Municipal do Fontelo|SCHEDULED\n" +
            "2027-05-09|33|SC Braga|Marítimo|Estádio Municipal de Braga|SCHEDULED\n" +
            "2027-05-09|33|FC Arouca|Gil Vicente FC|Estádio Municipal de Arouca|SCHEDULED\n" +
            "2027-05-09|33|FC Alverca|Estoril Praia|Estádio do FC Alverca|SCHEDULED\n" +
            "2027-05-09|33|FC Famalicão|Casa Pia AC|Estádio Municipal de Famalicão|SCHEDULED\n" +
            "2027-05-16|34|Casa Pia AC|Académico|Estádio Municipal de Rio Maior|SCHEDULED\n" +
            "2027-05-16|34|Marítimo|FC Alverca|Estádio do Marítimo|SCHEDULED\n" +
            "2027-05-16|34|Estoril Praia|Estrela Amadora|Estádio António Coimbra da Mota|SCHEDULED\n" +
            "2027-05-16|34|SL Benfica|FC Arouca|Estádio do Sport Lisboa e Benfica|SCHEDULED\n" +
            "2027-05-16|34|FC Porto|SC Braga|Estádio do Dragão|SCHEDULED\n" +
            "2027-05-16|34|Vitória SC|FC Famalicão|Estádio D. Afonso Henriques|SCHEDULED\n" +
            "2027-05-16|34|Santa Clara|Sporting CP|Estádio de São Miguel|SCHEDULED\n" +
            "2027-05-16|34|Gil Vicente FC|CD Nacional|Estádio Cidade de Barcelos|SCHEDULED\n" +
            "2027-05-16|34|Moreirense FC|Rio Ave FC|Parque Desportivo Comendador Joaquim de Almeida Freitas|SCHEDULED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        TLA.put("Estoril Praia", "EST");
        TLA.put("FC Famalicão", "FAM");
        TLA.put("Marítimo", "CSM");
        TLA.put("Casa Pia AC", "CPA");
        TLA.put("Vitória SC", "VSC");
        TLA.put("FC Arouca", "ARO");
        TLA.put("Estrela Amadora", "EAM");
        TLA.put("Sporting CP", "SCP");
        TLA.put("FC Porto", "FCP");
        TLA.put("FC Alverca", "ALV");
        TLA.put("Gil Vicente FC", "GIL");
        TLA.put("Rio Ave FC", "RAV");
        TLA.put("SL Benfica", "SLB");
        TLA.put("Académico", "ACV");
        TLA.put("Moreirense FC", "MOR");
        TLA.put("SC Braga", "SCB");
        TLA.put("Santa Clara", "SCL");
        TLA.put("CD Nacional", "CDN");

        CRESTS.put("Estoril Praia", "https://www.ligaportugal.pt/backoffice/assets/small_Emb_Estoril_Praia_044249cca4.png");
        CRESTS.put("FC Famalicão", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_FC_Famalicao_AF_200x200_300_af9671a0a4.png");
        CRESTS.put("Marítimo", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_Maritimo_M_AF_200x200_300_1b7f65a856.png");
        CRESTS.put("Casa Pia AC", "https://www.ligaportugal.pt/backoffice/assets/small_Emb_Casa_Pia_AC_AF_200x200_300_aa0e9e9667.png");
        CRESTS.put("Vitória SC", "https://www.ligaportugal.pt/backoffice/assets/medium_Simbolo_Original_Preto_branco_2f7cd164d2.png");
        CRESTS.put("FC Arouca", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_FC_Arouca_AF_200x200_300_ab36fb5518.png");
        CRESTS.put("Estrela Amadora", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_CF_Est_Amadora_AF_200x200_300_576b195166.png");
        CRESTS.put("Sporting CP", "https://www.ligaportugal.pt/backoffice/assets/medium_Sporting_Site_Letras_1330565ca0.png");
        CRESTS.put("FC Porto", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_FC_Porto_AF_200x200_300_0ff1ab3115.png");
        CRESTS.put("FC Alverca", "https://www.ligaportugal.pt/backoffice/assets/medium_FC_Alverca_280d268be1.png");
        CRESTS.put("Gil Vicente FC", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_Gil_Vicente_AF_200x200_300_d617d176cd.png");
        CRESTS.put("Rio Ave FC", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_Rio_Ave_FC_AF_200x200_300_e2e84f5563.png");
        CRESTS.put("SL Benfica", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_SL_Benfica_AF_200x200_300_0707325542.png");
        CRESTS.put("Académico", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_Ac_Viseu_AF_200x200_300_849bd92d0b.png");
        CRESTS.put("Moreirense FC", "https://www.ligaportugal.pt/backoffice/assets/small_MFC_logo_94240ed691.png");
        CRESTS.put("SC Braga", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_SC_Braga_AF_200x200_300_53d73be09a.png");
        CRESTS.put("Santa Clara", "https://www.ligaportugal.pt/backoffice/assets/small_CD_Santa_Clara_Emblema_1x1_v2_d629cef527.png");
        CRESTS.put("CD Nacional", "https://www.ligaportugal.pt/backoffice/assets/medium_Emb_CD_Nacional_AF_200x200_300_a3a56992f4.png");

        VENUES.put("Estoril Praia", "Estádio António Coimbra da Mota");
        VENUES.put("FC Famalicão", "Estádio Municipal de Famalicão");
        VENUES.put("Marítimo", "Estádio do Marítimo");
        VENUES.put("Casa Pia AC", "Estádio Municipal de Rio Maior");
        VENUES.put("Vitória SC", "Estádio D. Afonso Henriques");
        VENUES.put("FC Arouca", "Estádio Municipal de Arouca");
        VENUES.put("Estrela Amadora", "Estádio José Gomes");
        VENUES.put("Sporting CP", "Estádio José Alvalade");
        VENUES.put("FC Porto", "Estádio do Dragão");
        VENUES.put("FC Alverca", "Estádio do FC Alverca");
        VENUES.put("Gil Vicente FC", "Estádio Cidade de Barcelos");
        VENUES.put("Rio Ave FC", "Estádio do Rio Ave Futebol Clube");
        VENUES.put("SL Benfica", "Estádio do Sport Lisboa e Benfica");
        VENUES.put("Académico", "Estádio Municipal do Fontelo");
        VENUES.put("Moreirense FC", "Parque Desportivo Comendador Joaquim de Almeida Freitas");
        VENUES.put("SC Braga", "Estádio Municipal de Braga");
        VENUES.put("Santa Clara", "Estádio de São Miguel");
        VENUES.put("CD Nacional", "Estádio da Madeira");

        FOUNDED.put("Estoril Praia", 1939);
        FOUNDED.put("FC Famalicão", 1931);
        FOUNDED.put("Marítimo", 1910);
        FOUNDED.put("Casa Pia AC", 1920);
        FOUNDED.put("Vitória SC", 1922);
        FOUNDED.put("FC Arouca", 1951);
        FOUNDED.put("Estrela Amadora", 1932);
        FOUNDED.put("Sporting CP", 1906);
        FOUNDED.put("FC Porto", 1893);
        FOUNDED.put("FC Alverca", 1939);
        FOUNDED.put("Gil Vicente FC", 1924);
        FOUNDED.put("Rio Ave FC", 1939);
        FOUNDED.put("SL Benfica", 1904);
        FOUNDED.put("Académico", 1914);
        FOUNDED.put("Moreirense FC", 1938);
        FOUNDED.put("SC Braga", 1921);
        FOUNDED.put("Santa Clara", 1927);
        FOUNDED.put("CD Nacional", 1910);

        WEBSITES.put("Estoril Praia", "https://estorilpraia.pt");
        WEBSITES.put("FC Famalicão", "https://www.fcfamalicao.pt");
        WEBSITES.put("Marítimo", "https://www.csmaritimo.org.pt");
        WEBSITES.put("Casa Pia AC", "https://casapiaac.pt");
        WEBSITES.put("Vitória SC", "https://vitoriasc.pt");
        WEBSITES.put("FC Arouca", "https://www.fcarouca.eu");
        WEBSITES.put("Estrela Amadora", "https://estrelaamadorasad.pt");
        WEBSITES.put("Sporting CP", "https://www.sporting.pt");
        WEBSITES.put("FC Porto", "https://www.fcporto.pt");
        WEBSITES.put("FC Alverca", "https://www.ligaportugal.pt/team/135/fc-alverca/ligaportugalbetclic/20262027");
        WEBSITES.put("Gil Vicente FC", "https://gilvicentefc.pt");
        WEBSITES.put("Rio Ave FC", "https://rioavefc.pt");
        WEBSITES.put("SL Benfica", "https://www.slbenfica.pt");
        WEBSITES.put("Académico", "https://academicodeviseu.pt");
        WEBSITES.put("Moreirense FC", "https://www.moreirensefc.pt");
        WEBSITES.put("SC Braga", "https://scbraga.pt");
        WEBSITES.put("Santa Clara", "https://cdsantaclara.com");
        WEBSITES.put("CD Nacional", "https://www.cdnacional.pt");

        COLORS.put("Estoril Praia", "Yellow / Blue");
        COLORS.put("FC Famalicão", "Blue / White");
        COLORS.put("Marítimo", "Red / Green");
        COLORS.put("Casa Pia AC", "Black / White");
        COLORS.put("Vitória SC", "Black / White");
        COLORS.put("FC Arouca", "Yellow / Blue");
        COLORS.put("Estrela Amadora", "Red / Green / White");
        COLORS.put("Sporting CP", "Green / White");
        COLORS.put("FC Porto", "Blue / White");
        COLORS.put("FC Alverca", "Red / Blue");
        COLORS.put("Gil Vicente FC", "Red / Blue");
        COLORS.put("Rio Ave FC", "Green / White");
        COLORS.put("SL Benfica", "Red / White");
        COLORS.put("Académico", "Black / White");
        COLORS.put("Moreirense FC", "Green / White");
        COLORS.put("SC Braga", "Red / White");
        COLORS.put("Santa Clara", "Red / White");
        COLORS.put("CD Nacional", "Black / White");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutPrimeira(root.optJSONArray("matches")));
            root.put("live", copyWithoutPrimeira(root.optJSONArray("live")));
            root.put("finished", copyWithoutPrimeira(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutPrimeira(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");
            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            mergeStandings(root, fixtures);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // A future malformed manual update must never block other leagues.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonPrimeira(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6 && parts.length != 8) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "PPL-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "SCHEDULED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "Official Liga Portugal 2026/27 programme");
            fixture.put("season", SEASON);
            if (parts.length == 8) {
                try {
                    fixture.put("homeScore", Integer.parseInt(parts[6].trim()));
                    fixture.put("awayScore", Integer.parseInt(parts[7].trim()));
                } catch (Exception ignored) {}
            }

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Primeira Liga source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"tla", "crest", "emblem", "logo", "venue", "address", "website", "clubColors", "founded"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            Object raw = richer.opt(key);
            String value = String.valueOf(raw).trim();
            if (value.length() > 0 && !"null".equalsIgnoreCase(value)) out.put(key, raw);
        }
        Object richerArea = richer.opt("area");
        if (richerArea instanceof JSONObject) out.put("area", richerArea);
        else if (richerArea != null && String.valueOf(richerArea).trim().length() > 0) {
            JSONObject area = new JSONObject(); area.put("name", String.valueOf(richerArea).trim()); out.put("area", area);
        }
        String name = out.optString("name", out.optString("shortName", ""));
        String canonical = canonicalName(name);
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(canonical)) out.put("crest", CRESTS.get(canonical));
        return out;
    }

    private static JSONArray copyWithoutPrimeira(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isPrimeira(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonPrimeira(JSONObject row) {
        if (!isPrimeira(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isPrimeira(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        String rawCode = ""; String rawName = "";
        if (raw instanceof JSONObject) { JSONObject c = (JSONObject) raw; rawCode = c.optString("code", ""); rawName = c.optString("name", ""); }
        else if (raw != null) rawName = String.valueOf(raw);
        String rowCode = row.optString("competitionCode", "");
        String rawCodeNormalized = normalize(rawCode); String rowCodeNormalized = normalize(rowCode);
        if (rawCodeNormalized.equals("ppl") || rowCodeNormalized.equals("ppl")) return true;
        if (rawCodeNormalized.length() > 0 || rowCodeNormalized.length() > 0) return false;
        String rowName = row.optString("competitionName", "");
        String rawNormalized = normalize(rawName); String rowNormalized = normalize(rowName);
        return rawNormalized.equals("primeiraliga") || rawNormalized.equals("ligaportugalbetclic") || rowNormalized.equals("primeiraliga") || rowNormalized.equals("ligaportugalbetclic");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true); String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0; String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30; else if (isLive(status)) score += 25; else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2; if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") || value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject(); competition.put("code", COMPETITION_CODE); competition.put("name", COMPETITION_NAME); return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject(); team.put("name", name); team.put("shortName", name); team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        JSONObject area = new JSONObject(); area.put("name", "Portugal"); team.put("area", area);
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        if (VENUES.containsKey(name)) team.put("venue", VENUES.get(name));
        if (FOUNDED.containsKey(name)) team.put("founded", FOUNDED.get(name));
        if (WEBSITES.containsKey(name)) team.put("website", WEBSITES.get(name));
        if (COLORS.containsKey(name)) team.put("clubColors", COLORS.get(name));
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = new JSONArray();
        if (source != null) {
            for (int i = 0; i < source.length(); i++) {
                JSONObject team = source.optJSONObject(i); if (team == null) continue;
                String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
                if (isCurrentOrStalePrimeiraClub(name)) continue;
                teams.put(new JSONObject(team.toString()));
            }
        }
        for (String name : TLA.keySet()) teams.put(teamObject(name));
        root.put("teams", teams);
    }

    private static boolean isCurrentOrStalePrimeiraClub(String value) {
        String key = clubKey(value);
        if (TLA.containsKey(canonicalName(value))) return true;
        return key.equals("afs") || key.equals("avsfutebolsad") || key.equals("cdtondela") ||
                key.equals("tondela") || key.equals("boavista") || key.equals("boavistafc");
    }

    private static void mergeStandings(JSONObject root, JSONArray fixtures) throws Exception {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) { all = new JSONObject(); root.put("standings", all); }

        JSONObject existing = all.optJSONObject(COMPETITION_CODE);
        if (hasCurrentVerifiedTable(existing)) {
            canonicalizeStandingTeams(existing);
            return;
        }
        all.put(COMPETITION_CODE, derivedStandings(fixtures));
    }

    private static boolean hasCurrentVerifiedTable(JSONObject entry) {
        if (entry == null) return false;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        if (!(start.startsWith("2026") && end.startsWith("2027"))) return false;
        JSONArray standings = entry.optJSONArray("standings");
        if (standings == null) return false;
        for (int i = 0; i < standings.length(); i++) {
            JSONObject standing = standings.optJSONObject(i);
            JSONArray table = standing == null ? null : standing.optJSONArray("table");
            if (table != null && table.length() >= 18) return true;
        }
        return false;
    }

    private static void canonicalizeStandingTeams(JSONObject entry) {
        try {
            JSONArray standings = entry.optJSONArray("standings");
            if (standings == null) return;
            for (int i = 0; i < standings.length(); i++) {
                JSONObject standing = standings.optJSONObject(i);
                JSONArray table = standing == null ? null : standing.optJSONArray("table");
                if (table == null) continue;
                for (int j = 0; j < table.length(); j++) {
                    JSONObject row = table.optJSONObject(j);
                    JSONObject team = row == null ? null : row.optJSONObject("team");
                    if (team == null) continue;
                    String name = team.optString("shortName", team.optString("name", ""));
                    String canonical = canonicalName(name);
                    if (TLA.containsKey(canonical)) row.put("team", mergeTeam(teamObject(canonical), team));
                }
            }
        } catch (Exception ignored) {}
    }

    private static JSONObject derivedStandings(JSONArray fixtures) throws Exception {
        class Row {
            String name; int played, won, draw, lost, gf, ga, points;
            Row(String n) { name = n; }
            int gd() { return gf - ga; }
        }
        LinkedHashMap<String, Row> rows = new LinkedHashMap<String, Row>();
        for (String name : TLA.keySet()) rows.put(name, new Row(name));

        int currentMatchday = 0;
        for (int i = 0; i < fixtures.length(); i++) {
            JSONObject fixture = fixtures.optJSONObject(i);
            if (fixture == null || !isFinished(fixture.optString("status", ""))) continue;
            int hg = scoreValue(fixture, true);
            int ag = scoreValue(fixture, false);
            if (hg < 0 || ag < 0) continue;
            String homeName = canonicalName(teamName(fixture, true));
            String awayName = canonicalName(teamName(fixture, false));
            Row home = rows.get(homeName); Row away = rows.get(awayName);
            if (home == null || away == null) continue;
            home.played++; away.played++; home.gf += hg; home.ga += ag; away.gf += ag; away.ga += hg;
            if (hg > ag) { home.won++; home.points += 3; away.lost++; }
            else if (ag > hg) { away.won++; away.points += 3; home.lost++; }
            else { home.draw++; away.draw++; home.points++; away.points++; }
            currentMatchday = Math.max(currentMatchday, fixture.optInt("matchday", 0));
        }

        java.util.ArrayList<Row> ordered = new java.util.ArrayList<Row>(rows.values());
        java.util.Collections.sort(ordered, (a,b) -> {
            if (a.points != b.points) return b.points - a.points;
            if (a.gd() != b.gd()) return b.gd() - a.gd();
            if (a.gf != b.gf) return b.gf - a.gf;
            return a.name.compareToIgnoreCase(b.name);
        });

        JSONArray table = new JSONArray();
        for (int i = 0; i < ordered.size(); i++) {
            Row r = ordered.get(i);
            JSONObject row = new JSONObject();
            row.put("position", i + 1);
            row.put("team", teamObject(r.name));
            row.put("playedGames", r.played);
            row.put("won", r.won);
            row.put("draw", r.draw);
            row.put("lost", r.lost);
            row.put("points", r.points);
            row.put("goalsFor", r.gf);
            row.put("goalsAgainst", r.ga);
            row.put("goalDifference", r.gd());
            table.put(row);
        }

        JSONObject block = new JSONObject();
        block.put("stage", "REGULAR_SEASON");
        block.put("type", "TOTAL");
        block.put("group", "");
        block.put("table", table);
        JSONArray blocks = new JSONArray(); blocks.put(block);

        JSONObject season = new JSONObject();
        season.put("startDate", FIRST_DATE);
        season.put("endDate", LAST_DATE);
        season.put("currentMatchday", currentMatchday > 0 ? currentMatchday : 1);

        JSONObject entry = new JSONObject();
        entry.put("competition", competitionObject());
        entry.put("competitionName", COMPETITION_NAME);
        entry.put("competitionCode", COMPETITION_CODE);
        entry.put("season", season);
        entry.put("standings", blocks);
        entry.put("dataProvider", "Official Liga Portugal 2026/27 programme + verified results");
        return entry;
    }

    private static int scoreValue(JSONObject row, boolean home) {
        String[] direct = home ? new String[]{"homeGoals","homeScore","scoreHome","goalsHome"} :
                new String[]{"awayGoals","awayScore","scoreAway","goalsAway"};
        for (String key : direct) if (row.has(key)) {
            try { return row.getInt(key); } catch (Exception ignored) {}
        }
        JSONObject score = row.optJSONObject("score");
        if (score != null) {
            JSONObject full = score.optJSONObject("fullTime");
            if (full != null) {
                String key = home ? "home" : "away";
                if (full.has(key)) try { return full.getInt(key); } catch (Exception ignored) {}
            }
            String key = home ? "home" : "away";
            if (score.has(key)) try { return score.getInt(key); } catch (Exception ignored) {}
        }
        return -1;
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources"); if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject primeira = sources.optJSONObject(COMPETITION_CODE); if (primeira == null) primeira = new JSONObject();
        primeira.put("status", "connected");
        primeira.put("provider", "Official Liga Portugal 2026/27 programme + connected live source");
        primeira.put("season", SEASON); primeira.put("matchCount", matchCount); primeira.put("teamCount", TLA.size()); primeira.put("roundCount", 34);
        sources.put(COMPETITION_CODE, primeira);
    }

    private static String canonicalName(String value) {
        String key = clubKey(value);
        for (String name : TLA.keySet()) if (clubKey(name).equals(key)) return name;
        return value == null ? "" : value.trim();
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("estoril") || key.equals("gdestorilpraia")) return "estorilpraia";
        if (key.equals("famalicao") || key.equals("fcfamalicaosad")) return "fcfamalicao";
        if (key.equals("maritimo") || key.equals("csmaritimo") || key.equals("maritimom")) return "maritimo";
        if (key.equals("casapia")) return "casapiaac";
        if (key.equals("vitoriaguimaraes") || key.equals("vitoriadeguimaraes") || key.equals("guimaraes")) return "vitoriasc";
        if (key.equals("arouca")) return "fcarouca";
        if (key.equals("estrela") || key.equals("cfestrelaamadora") || key.equals("estrelaamadorasad")) return "estrelaamadora";
        if (key.equals("sporting") || key.equals("sportinglisbon") || key.equals("sportingclubedeportugal")) return "sportingcp";
        if (key.equals("porto") || key.equals("futebolclubeporto")) return "fcporto";
        if (key.equals("alverca")) return "fcalverca";
        if (key.equals("gilvicente")) return "gilvicentefc";
        if (key.equals("rioave")) return "rioavefc";
        if (key.equals("benfica") || key.equals("sportlisboaebenfica")) return "slbenfica";
        if (key.equals("academicodeviseu") || key.equals("academicodeviseufc") || key.equals("acviseu")) return "academico";
        if (key.equals("moreirense")) return "moreirensefc";
        if (key.equals("braga") || key.equals("sportingbraga")) return "scbraga";
        if (key.equals("cdsantaclara") || key.equals("santaclaraacores")) return "santaclara";
        if (key.equals("nacional") || key.equals("nacionalmadeira")) return "cdnacional";
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private PrimeiraLiga2627Data() {}
}
