package com.asappfactory.footballfun.model;

/** Immutable club identity used by the favorites picker and club center. */
public final class ClubProfile {
    public final String name;
    public final String competition;
    public final String country;

    public ClubProfile(String name, String competition, String country) {
        this.name = name == null ? "" : name.trim();
        this.competition = competition == null ? "" : competition.trim();
        this.country = country == null ? "" : country.trim();
    }
}
