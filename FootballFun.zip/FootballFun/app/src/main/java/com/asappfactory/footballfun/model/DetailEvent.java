package com.asappfactory.footballfun.model;

/** A normalized timeline event used by the match-details screen. */
public final class DetailEvent {
    public final int minute;
    public final String text;

    public DetailEvent(int minute, String text) {
        this.minute = minute;
        this.text = text;
    }
}
