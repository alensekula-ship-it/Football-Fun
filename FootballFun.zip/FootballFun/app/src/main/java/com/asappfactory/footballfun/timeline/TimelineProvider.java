package com.asappfactory.footballfun.timeline;

import org.json.JSONObject;

public interface TimelineProvider {
    String id();
    boolean supports(JSONObject match);
    String format(JSONObject match, TimelineEnvironment env);
}
