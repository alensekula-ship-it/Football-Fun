package com.asappfactory.footballfun.billing;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.asappfactory.footballfun.core.ProEntitlementManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Google Play Billing client for Football Fun Pro.
 * Point 11 RC keeps Play Billing 8.3.0, a supported production line, to avoid a late release migration.
 *
 * Product IDs must exist in Play Console before live prices/offers are returned.
 * QA entitlement remains separate from Play entitlement.
 *
 * Production hardening note: Google recommends verifying purchase tokens on a
 * secure backend before granting durable entitlement. Client-side handling here
 * establishes the Play flow and test path; backend verification is required
 * before public monetization is considered complete.
 */
public final class GooglePlayBillingManager implements PurchasesUpdatedListener {

    public interface Listener {
        void onBillingStateChanged();
        void onBillingMessage(String message);
    }

    private final Context appContext;
    private final Listener listener;
    private final BillingClient billingClient;

    private ProductDetails proDetails;
    private ProductDetails.SubscriptionOfferDetails monthlyOffer;
    private ProductDetails.SubscriptionOfferDetails yearlyOffer;
    private boolean ready;
    private boolean entitlementKnown;
    private boolean playProEntitled;
    private final SharedPreferences preferences;
    private static final String PREF_PLAY_PRO_CACHE = "play_pro_entitled_cache";

    public GooglePlayBillingManager(Context context, Listener listener) {
        this.appContext = context.getApplicationContext();
        this.listener = listener;
        this.preferences = appContext.getSharedPreferences("footballfun", Context.MODE_PRIVATE);
        // Never grant Pro from a locally editable cache after process start.
        // Google Play must confirm the entitlement in the current process.
        this.playProEntitled = false;
        this.entitlementKnown = false;
        billingClient = BillingClient.newBuilder(appContext)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public void start() {
        if (billingClient.isReady()) {
            ready = true;
            refresh();
            return;
        }
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                ready = result.getResponseCode() == BillingClient.BillingResponseCode.OK;
                if (ready) refresh();
                else message("Google Play Billing unavailable (" + result.getResponseCode() + ").");
                changed();
            }
            @Override public void onBillingServiceDisconnected() {
                ready = false;
                changed();
            }
        });
    }

    public void close() {
        try { billingClient.endConnection(); } catch (Exception ignored) {}
    }

    public boolean isReady() { return ready && billingClient.isReady(); }
    public boolean hasPlayProEntitlement() { return playProEntitled; }
    public boolean isEntitlementKnown() { return entitlementKnown; }

    public String monthlyPrice() {
        return formattedRecurringPrice(monthlyOffer, ProEntitlementManager.MONTHLY_PRICE_FALLBACK);
    }

    public String yearlyPrice() {
        return formattedRecurringPrice(yearlyOffer, ProEntitlementManager.YEARLY_PRICE_FALLBACK);
    }

    public boolean monthlyAvailable() { return proDetails != null && monthlyOffer != null; }
    public boolean yearlyAvailable() { return proDetails != null && yearlyOffer != null; }

    /** True when the selected monthly Play offer contains an eligible zero-price phase. */
    public boolean monthlyTrialAvailable() {
        if (monthlyOffer == null || monthlyOffer.getPricingPhases() == null) return false;
        for (ProductDetails.PricingPhase phase : monthlyOffer.getPricingPhases().getPricingPhaseList()) {
            if (phase != null && phase.getPriceAmountMicros() == 0L) return true;
        }
        return false;
    }

    public void refresh() {
        if (!isReady()) { start(); return; }
        queryProducts();
        queryPurchases();
    }

    public void restorePurchases() {
        if (!isReady()) {
            message("Google Play Billing is not connected yet.");
            start();
            return;
        }
        queryPurchases();
        message("Checking Google Play purchases…");
    }

    public void launchMonthly(Activity activity) { launch(activity, proDetails, monthlyOffer); }
    public void launchYearly(Activity activity) { launch(activity, proDetails, yearlyOffer); }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> products = Collections.singletonList(
                QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(ProEntitlementManager.PRO_PRODUCT_ID)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
        );
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(products).build();
        billingClient.queryProductDetailsAsync(params, (result, detailsResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                message("Unable to load Google Play subscription details.");
                return;
            }
            proDetails = null;
            monthlyOffer = null;
            yearlyOffer = null;
            for (ProductDetails d : detailsResult.getProductDetailsList()) {
                if (ProEntitlementManager.PRO_PRODUCT_ID.equals(d.getProductId())) {
                    proDetails = d;
                    break;
                }
            }
            if (proDetails != null && proDetails.getSubscriptionOfferDetails() != null) {
                monthlyOffer = chooseOffer(proDetails.getSubscriptionOfferDetails(),
                        ProEntitlementManager.MONTHLY_BASE_PLAN_ID,
                        ProEntitlementManager.MONTHLY_TRIAL_OFFER_ID);
                yearlyOffer = chooseOffer(proDetails.getSubscriptionOfferDetails(),
                        ProEntitlementManager.YEARLY_BASE_PLAN_ID, null);
            }
            changed();
        });
    }

    private void queryPurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                entitlementKnown = false;
                message("Unable to verify Google Play subscriptions right now.");
                changed();
                return;
            }
            processPurchases(purchases);
        });
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            processPurchases(purchases);
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            message("Purchase cancelled.");
        } else {
            message("Google Play purchase could not be completed.");
        }
    }

    private void processPurchases(List<Purchase> purchases) {
        boolean entitled = false;
        if (purchases != null) {
            for (Purchase purchase : purchases) {
                if (!containsProProduct(purchase)) continue;
                if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    entitled = true;
                    if (!purchase.isAcknowledged()) acknowledge(purchase);
                }
            }
        }
        playProEntitled = entitled;
        entitlementKnown = true;
        preferences.edit().putBoolean(PREF_PLAY_PRO_CACHE, entitled).apply();
        changed();
    }

    private boolean containsProProduct(Purchase purchase) {
        if (purchase == null || purchase.getProducts() == null) return false;
        return purchase.getProducts().contains(ProEntitlementManager.PRO_PRODUCT_ID);
    }

    private void acknowledge(Purchase purchase) {
        AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken()).build();
        billingClient.acknowledgePurchase(params, result -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK)
                message("Google Play purchase acknowledgement is pending.");
        });
    }

    private void launch(Activity activity, ProductDetails details,
                        ProductDetails.SubscriptionOfferDetails offer) {
        if (!isReady() || activity == null || details == null || offer == null) {
            message("This subscription is not available from Google Play yet.");
            return;
        }
        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offer.getOfferToken())
                        .build();
        BillingFlowParams params = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();
        BillingResult result = billingClient.launchBillingFlow(activity, params);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK)
            message("Google Play purchase screen could not be opened.");
    }

    private ProductDetails.SubscriptionOfferDetails chooseOffer(
            List<ProductDetails.SubscriptionOfferDetails> offers,
            String basePlanId, String preferredOfferId) {
        if (offers == null || basePlanId == null) return null;
        ProductDetails.SubscriptionOfferDetails baseFallback = null;
        ProductDetails.SubscriptionOfferDetails anyFallback = null;
        for (ProductDetails.SubscriptionOfferDetails offer : offers) {
            if (offer == null || !basePlanId.equals(offer.getBasePlanId())) continue;
            if (anyFallback == null) anyFallback = offer;
            String offerId = offer.getOfferId();
            if (preferredOfferId != null && preferredOfferId.equals(offerId)) return offer;
            if (offerId == null && baseFallback == null) baseFallback = offer;
        }
        return baseFallback != null ? baseFallback : anyFallback;
    }

    private String formattedRecurringPrice(
            ProductDetails.SubscriptionOfferDetails offer, String fallback) {
        if (offer == null || offer.getPricingPhases() == null
                || offer.getPricingPhases().getPricingPhaseList().isEmpty()) return fallback;
        List<ProductDetails.PricingPhase> phases = offer.getPricingPhases().getPricingPhaseList();
        return phases.get(phases.size() - 1).getFormattedPrice();
    }

    private void changed() {
        if (listener != null) listener.onBillingStateChanged();
    }

    private void message(String value) {
        if (listener != null) listener.onBillingMessage(value);
    }
}
