package com.asappfactory.footballfun.presentation;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Localizes national-team names while leaving club names untouched. */
public final class TeamLocalizer {
    private static final Map<String, String> COUNTRY_CODES;

    static {
        HashMap<String, String> codes = new HashMap<String, String>();
        codes.put("Mexico", "MX");
        codes.put("South Africa", "ZA");
        codes.put("Korea Republic", "KR");
        codes.put("Czechia", "CZ");
        codes.put("Canada", "CA");
        codes.put("Bosnia and Herzegovina", "BA");
        codes.put("Qatar", "QA");
        codes.put("Switzerland", "CH");
        codes.put("Brazil", "BR");
        codes.put("Morocco", "MA");
        codes.put("Haiti", "HT");
        codes.put("USA", "US");
        codes.put("Paraguay", "PY");
        codes.put("Australia", "AU");
        codes.put("Turkey", "TR");
        codes.put("Germany", "DE");
        codes.put("Curacao", "CW");
        codes.put("Curaçao", "CW");
        codes.put("Ivory Coast", "CI");
        codes.put("Ecuador", "EC");
        codes.put("Netherlands", "NL");
        codes.put("Japan", "JP");
        codes.put("Sweden", "SE");
        codes.put("Tunisia", "TN");
        codes.put("Belgium", "BE");
        codes.put("Egypt", "EG");
        codes.put("Iran", "IR");
        codes.put("New Zealand", "NZ");
        codes.put("Spain", "ES");
        codes.put("Cape Verde", "CV");
        codes.put("Saudi Arabia", "SA");
        codes.put("Uruguay", "UY");
        codes.put("France", "FR");
        codes.put("Senegal", "SN");
        codes.put("Iraq", "IQ");
        codes.put("Norway", "NO");
        codes.put("Argentina", "AR");
        codes.put("Algeria", "DZ");
        codes.put("Austria", "AT");
        codes.put("Jordan", "JO");
        codes.put("Portugal", "PT");
        codes.put("DR Congo", "CD");
        codes.put("Uzbekistan", "UZ");
        codes.put("Colombia", "CO");
        codes.put("Croatia", "HR");
        codes.put("Ghana", "GH");
        codes.put("Panama", "PA");
        COUNTRY_CODES = Collections.unmodifiableMap(codes);
    }

    public static Locale localeFor(String language) {
        if ("HR".equals(language)) return new Locale("hr", "HR");
        if ("DE".equals(language)) return Locale.GERMANY;
        if ("ES".equals(language)) return new Locale("es", "ES");
        if ("FR".equals(language)) return Locale.FRANCE;
        return Locale.ENGLISH;
    }

    public static String displayName(String team, String language) {
        if (team == null) return "";
        if ("England".equals(team)) return choose(language, "England", "Engleska", "England", "Inglaterra", "Angleterre");
        if ("Scotland".equals(team)) return choose(language, "Scotland", "Škotska", "Schottland", "Escocia", "Écosse");
        String code = COUNTRY_CODES.get(team);
        if (code == null) return team;
        String localized = new Locale("", code).getDisplayCountry(localeFor(language));
        return localized == null || localized.trim().isEmpty() ? team : localized;
    }

    private static String choose(String language, String en, String hr, String de, String es, String fr) {
        if ("HR".equals(language)) return hr;
        if ("DE".equals(language)) return de;
        if ("ES".equals(language)) return es;
        if ("FR".equals(language)) return fr;
        return en;
    }

    private TeamLocalizer() {}
}
