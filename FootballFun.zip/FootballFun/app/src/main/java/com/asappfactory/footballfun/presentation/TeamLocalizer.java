package com.asappfactory.footballfun.presentation;

import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Formats national-team and verified club names for user-facing screens. */
public final class TeamLocalizer {
    private static final Map<String, String> COUNTRY_CODES;
    private static final Map<String, String> CLUB_DISPLAY_NAMES;

    static {
        HashMap<String, String> codes = new HashMap<String, String>();
        codes.put("Mexico", "MX");
        codes.put("South Africa", "ZA");
        codes.put("Korea Republic", "KR");
        codes.put("Czechia", "CZ");
        codes.put("Canada", "CA");
        codes.put("Bosnia and Herzegovina", "BA");
        codes.put("Qatar", "QA");
        codes.put("Switzerland", "CH");
        codes.put("Brazil", "BR");
        codes.put("Morocco", "MA");
        codes.put("Haiti", "HT");
        codes.put("USA", "US");
        codes.put("Paraguay", "PY");
        codes.put("Australia", "AU");
        codes.put("Turkey", "TR");
        codes.put("Germany", "DE");
        codes.put("Curacao", "CW");
        codes.put("Curaçao", "CW");
        codes.put("Ivory Coast", "CI");
        codes.put("Ecuador", "EC");
        codes.put("Netherlands", "NL");
        codes.put("Japan", "JP");
        codes.put("Sweden", "SE");
        codes.put("Tunisia", "TN");
        codes.put("Belgium", "BE");
        codes.put("Egypt", "EG");
        codes.put("Iran", "IR");
        codes.put("New Zealand", "NZ");
        codes.put("Spain", "ES");
        codes.put("Cape Verde", "CV");
        codes.put("Saudi Arabia", "SA");
        codes.put("Uruguay", "UY");
        codes.put("France", "FR");
        codes.put("Senegal", "SN");
        codes.put("Iraq", "IQ");
        codes.put("Norway", "NO");
        codes.put("Argentina", "AR");
        codes.put("Algeria", "DZ");
        codes.put("Austria", "AT");
        codes.put("Jordan", "JO");
        codes.put("Portugal", "PT");
        codes.put("DR Congo", "CD");
        codes.put("Uzbekistan", "UZ");
        codes.put("Colombia", "CO");
        codes.put("Croatia", "HR");
        codes.put("Ghana", "GH");
        codes.put("Panama", "PA");
        COUNTRY_CODES = Collections.unmodifiableMap(codes);

        HashMap<String, String> clubNames = new HashMap<String, String>();
        // User-facing aliases only. Raw provider names remain unchanged internally,
        // so match IDs, favorites and data synchronization stay stable.
        clubNames.put(clubKey("Botafogo FR"), "Botafogo");
        clubNames.put(clubKey("CA Mineiro"), "Atlético Mineiro");
        clubNames.put(clubKey("Chapecoense AF"), "Chapecoense");
        clubNames.put(clubKey("Coritiba FBC"), "Coritiba");
        clubNames.put(clubKey("CR Vasco da Gama"), "Vasco da Gama");
        clubNames.put(clubKey("CR Flamengo"), "Flamengo");
        clubNames.put(clubKey("Fluminense FC"), "Fluminense");
        clubNames.put(clubKey("SE Palmeiras"), "Palmeiras");
        clubNames.put(clubKey("São Paulo FC"), "São Paulo");
        clubNames.put(clubKey("SC Internacional"), "Internacional");
        clubNames.put(clubKey("Grêmio FBPA"), "Grêmio");
        clubNames.put(clubKey("EC Bahia"), "Bahia");
        clubNames.put(clubKey("EC Vitória"), "Vitória");
        clubNames.put(clubKey("Cruzeiro EC"), "Cruzeiro");
        clubNames.put(clubKey("Fortaleza EC"), "Fortaleza");
        clubNames.put(clubKey("Santos FC"), "Santos");
        clubNames.put(clubKey("Club Athletico Paranaense"), "Athletico Paranaense");
        clubNames.put(clubKey("Athletico-PR"), "Athletico Paranaense");
        clubNames.put(clubKey("Clube Atlético Mineiro"), "Atlético Mineiro");
        clubNames.put(clubKey("Sport Club Corinthians Paulista"), "Corinthians");
        clubNames.put(clubKey("Mirassol FC"), "Mirassol");
        clubNames.put(clubKey("Red Bull Bragantino"), "Red Bull Bragantino");
        clubNames.put(clubKey("RB Bragantino"), "Red Bull Bragantino");
        clubNames.put(clubKey("Clube do Remo"), "Remo");
        clubNames.put(clubKey("Sport Club Internacional"), "Internacional");
        clubNames.put(clubKey("Santos Futebol Clube"), "Santos");
        clubNames.put(clubKey("São Paulo Futebol Clube"), "São Paulo");
        clubNames.put(clubKey("Clube de Regatas do Vasco da Gama"), "Vasco da Gama");
        clubNames.put(clubKey("Clube de Regatas do Flamengo"), "Flamengo");
        clubNames.put(clubKey("Esporte Clube Bahia"), "Bahia");
        clubNames.put(clubKey("Esporte Clube Vitória"), "Vitória");
        clubNames.put(clubKey("Atalanta BC"), "Atalanta");
        clubNames.put(clubKey("Bologna FC 1909"), "Bologna");
        clubNames.put(clubKey("Cagliari Calcio"), "Cagliari");
        clubNames.put(clubKey("Como 1907"), "Como");
        clubNames.put(clubKey("ACF Fiorentina"), "Fiorentina");
        clubNames.put(clubKey("Frosinone Calcio"), "Frosinone");
        clubNames.put(clubKey("Genoa CFC"), "Genoa");
        clubNames.put(clubKey("FC Internazionale Milano"), "Inter");
        clubNames.put(clubKey("Inter Milan"), "Inter");
        clubNames.put(clubKey("Juventus FC"), "Juventus");
        clubNames.put(clubKey("SS Lazio"), "Lazio");
        clubNames.put(clubKey("US Lecce"), "Lecce");
        clubNames.put(clubKey("AC Milan"), "Milan");
        clubNames.put(clubKey("AC Monza"), "Monza");
        clubNames.put(clubKey("SSC Napoli"), "Napoli");
        clubNames.put(clubKey("Parma Calcio 1913"), "Parma");
        clubNames.put(clubKey("AS Roma"), "Roma");
        clubNames.put(clubKey("US Sassuolo Calcio"), "Sassuolo");
        clubNames.put(clubKey("Torino FC"), "Torino");
        clubNames.put(clubKey("Udinese Calcio"), "Udinese");
        clubNames.put(clubKey("Venezia FC"), "Venezia");
        clubNames.put(clubKey("Heart of Midlothia"), "Heart of Midlothian");
        clubNames.put(clubKey("Heart of Midlothian"), "Heart of Midlothian");
        clubNames.put(clubKey("Heart of Midlothian FC"), "Heart of Midlothian");
        clubNames.put(clubKey("Telstar 1963"), "Telstar");
        clubNames.put(clubKey("SC Telstar"), "Telstar");
        clubNames.put(clubKey("Sporting Clube de Portugal"), "Sporting CP");
        clubNames.put(clubKey("Sporting Lisbon"), "Sporting CP");
        clubNames.put(clubKey("Blackburn Rovers FC"), "Blackburn Rovers");
        clubNames.put(clubKey("Bolton Wanderers FC"), "Bolton Wanderers");
        clubNames.put(clubKey("Preston North End FC"), "Preston North End");
        clubNames.put(clubKey("Wolverhampton Wanderers FC"), "Wolverhampton Wanderers");
        clubNames.put(clubKey("Coventry City FC"), "Coventry City");
        clubNames.put(clubKey("Hull City AFC"), "Hull City");
        clubNames.put(clubKey("Hull City FC"), "Hull City");
        clubNames.put(clubKey("Ipswich Town FC"), "Ipswich Town");
        CLUB_DISPLAY_NAMES = Collections.unmodifiableMap(clubNames);
    }

    public static Locale localeFor(String language) {
        if ("HR".equals(language)) return new Locale("hr", "HR");
        if ("DE".equals(language)) return Locale.GERMANY;
        if ("ES".equals(language)) return new Locale("es", "ES");
        if ("FR".equals(language)) return Locale.FRANCE;
        return Locale.ENGLISH;
    }

    public static String displayName(String team, String language) {
        if (team == null) return "";
        String clubDisplayName = CLUB_DISPLAY_NAMES.get(clubKey(team));
        if (clubDisplayName != null) return clubDisplayName;
        if ("England".equals(team)) return choose(language, "England", "Engleska", "England", "Inglaterra", "Angleterre");
        if ("Scotland".equals(team)) return choose(language, "Scotland", "Škotska", "Schottland", "Escocia", "Écosse");
        String code = COUNTRY_CODES.get(team);
        if (code == null) return team;
        String localized = new Locale("", code).getDisplayCountry(localeFor(language));
        return localized == null || localized.trim().isEmpty() ? team : localized;
    }

    private static String clubKey(String value) {
        if (value == null) return "";
        String lower = value.trim().toLowerCase(Locale.ROOT);
        StringBuilder key = new StringBuilder();
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if (Character.isLetterOrDigit(c)) key.append(c);
        }
        return key.toString();
    }

    private static String choose(String language, String en, String hr, String de, String es, String fr) {
        if ("HR".equals(language)) return hr;
        if ("DE".equals(language)) return de;
        if ("ES".equals(language)) return es;
        if ("FR".equals(language)) return fr;
        return en;
    }

    private TeamLocalizer() {}
}
