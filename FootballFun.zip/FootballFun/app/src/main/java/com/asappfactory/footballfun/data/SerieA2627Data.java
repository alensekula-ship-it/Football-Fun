package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Complete official Serie A 2026/27 fixture and club-identity fallback. */
public final class SerieA2627Data {
    private static final String COMPETITION_NAME = "Serie A";
    private static final String COMPETITION_CODE = "SA";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-22";
    private static final String LAST_DATE = "2027-05-30";

    private static final String DATA =
            // Matchdays 1-5 use the official Lega Serie A date/time publication
            // (C.U. n. 208, 24 June 2026). Later rounds retain official round
            // dates until their exact kick-off slots are published.
            "2026-08-22 18:30|1|Inter|Monza|Stadio Giuseppe Meazza|TIMED\n" +
            "2026-08-22 18:30|1|Udinese|Como|Bluenergy Stadium|TIMED\n" +
            "2026-08-22 20:45|1|Genoa|Napoli|Stadio Luigi Ferraris|TIMED\n" +
            "2026-08-22 20:45|1|Parma|Cagliari|Stadio Ennio Tardini|TIMED\n" +
            "2026-08-23 18:30|1|Frosinone|Juventus|Stadio Benito Stirpe|TIMED\n" +
            "2026-08-23 18:30|1|Venezia|Lecce|Stadio Pier Luigi Penzo|TIMED\n" +
            "2026-08-23 20:45|1|Atalanta|Sassuolo|New Balance Arena|TIMED\n" +
            "2026-08-23 20:45|1|Torino|Milan|Stadio Olimpico Grande Torino|TIMED\n" +
            "2026-08-24 18:30|1|Bologna|Lazio|Stadio Renato Dall'Ara|TIMED\n" +
            "2026-08-24 20:45|1|Roma|Fiorentina|Stadio Olimpico|TIMED\n" +
            "2026-08-28 20:45|2|Milan|Venezia|Stadio Giuseppe Meazza|TIMED\n" +
            "2026-08-29 18:30|2|Fiorentina|Frosinone|Stadio Artemio Franchi|TIMED\n" +
            "2026-08-29 18:30|2|Monza|Udinese|U-Power Stadium|TIMED\n" +
            "2026-08-29 18:30|2|Sassuolo|Torino|Mapei Stadium - Città del Tricolore|TIMED\n" +
            "2026-08-29 20:45|2|Juventus|Parma|Allianz Stadium|TIMED\n" +
            "2026-08-30 18:30|2|Napoli|Como|Stadio Diego Armando Maradona|TIMED\n" +
            "2026-08-30 20:45|2|Cagliari|Inter|Unipol Domus|TIMED\n" +
            "2026-08-30 20:45|2|Lazio|Genoa|Stadio Olimpico|TIMED\n" +
            "2026-08-31 18:30|2|Lecce|Roma|Stadio Ettore Giardiniero - Via del Mare|TIMED\n" +
            "2026-08-31 20:45|2|Atalanta|Bologna|New Balance Arena|TIMED\n" +
            "2026-09-04 20:45|3|Genoa|Como|Stadio Luigi Ferraris|TIMED\n" +
            "2026-09-05 15:00|3|Fiorentina|Torino|Stadio Artemio Franchi|TIMED\n" +
            "2026-09-05 18:00|3|Inter|Napoli|Stadio Giuseppe Meazza|TIMED\n" +
            "2026-09-05 20:45|3|Roma|Atalanta|Stadio Olimpico|TIMED\n" +
            "2026-09-06 15:00|3|Frosinone|Venezia|Stadio Benito Stirpe|TIMED\n" +
            "2026-09-06 15:00|3|Parma|Monza|Stadio Ennio Tardini|TIMED\n" +
            "2026-09-06 18:00|3|Bologna|Sassuolo|Stadio Renato Dall'Ara|TIMED\n" +
            "2026-09-06 20:45|3|Juventus|Milan|Allianz Stadium|TIMED\n" +
            "2026-09-07 18:30|3|Cagliari|Lecce|Unipol Domus|TIMED\n" +
            "2026-09-07 20:45|3|Udinese|Lazio|Bluenergy Stadium|TIMED\n" +
            "2026-09-11 20:45|4|Venezia|Fiorentina|Stadio Pier Luigi Penzo|TIMED\n" +
            "2026-09-12 15:00|4|Genoa|Frosinone|Stadio Luigi Ferraris|TIMED\n" +
            "2026-09-12 20:45|4|Atalanta|Cagliari|New Balance Arena|TIMED\n" +
            "2026-09-13 12:30|4|Torino|Roma|Stadio Olimpico Grande Torino|TIMED\n" +
            "2026-09-13 15:00|4|Como|Parma|Stadio Giuseppe Sinigaglia|TIMED\n" +
            "2026-09-13 15:00|4|Lecce|Monza|Stadio Ettore Giardiniero - Via del Mare|TIMED\n" +
            "2026-09-13 18:00|4|Napoli|Bologna|Stadio Diego Armando Maradona|TIMED\n" +
            // These two fixtures remain conditional on UEFA scheduling. Keep
            // the official round date but do not claim a confirmed kick-off.
            "2026-09-13|4|Lazio|Milan|Stadio Olimpico|SCHEDULED\n" +
            "2026-09-13|4|Sassuolo|Juventus|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-09-14 20:45|4|Inter|Udinese|Stadio Giuseppe Meazza|TIMED\n" +
            "2026-09-18 20:45|5|Monza|Sassuolo|U-Power Stadium|TIMED\n" +
            "2026-09-19 15:00|5|Bologna|Torino|Stadio Renato Dall'Ara|TIMED\n" +
            "2026-09-19 15:00|5|Udinese|Cagliari|Bluenergy Stadium|TIMED\n" +
            "2026-09-19 18:00|5|Roma|Inter|Stadio Olimpico|TIMED\n" +
            "2026-09-19 20:45|5|Venezia|Lazio|Stadio Pier Luigi Penzo|TIMED\n" +
            "2026-09-20 12:30|5|Fiorentina|Napoli|Stadio Artemio Franchi|TIMED\n" +
            "2026-09-20 15:00|5|Frosinone|Como|Stadio Benito Stirpe|TIMED\n" +
            "2026-09-20 15:00|5|Parma|Genoa|Stadio Ennio Tardini|TIMED\n" +
            "2026-09-20 18:00|5|Juventus|Atalanta|Allianz Stadium|TIMED\n" +
            "2026-09-20 20:45|5|Milan|Lecce|Stadio Giuseppe Meazza|TIMED\n" +
            "2026-10-11|6|Atalanta|Venezia|New Balance Arena|SCHEDULED\n" +
            "2026-10-11|6|Cagliari|Juventus|Unipol Domus|SCHEDULED\n" +
            "2026-10-11|6|Como|Roma|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-10-11|6|Genoa|Fiorentina|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-10-11|6|Inter|Parma|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-10-11|6|Lazio|Monza|Stadio Olimpico|SCHEDULED\n" +
            "2026-10-11|6|Lecce|Bologna|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-10-11|6|Napoli|Frosinone|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-10-11|6|Sassuolo|Milan|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-10-11|6|Torino|Udinese|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-10-18|7|Bologna|Inter|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2026-10-18|7|Fiorentina|Como|Stadio Artemio Franchi|SCHEDULED\n" +
            "2026-10-18|7|Frosinone|Sassuolo|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-10-18|7|Juventus|Lazio|Allianz Stadium|SCHEDULED\n" +
            "2026-10-18|7|Milan|Atalanta|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-10-18|7|Monza|Cagliari|U-Power Stadium|SCHEDULED\n" +
            "2026-10-18|7|Parma|Torino|Stadio Ennio Tardini|SCHEDULED\n" +
            "2026-10-18|7|Roma|Genoa|Stadio Olimpico|SCHEDULED\n" +
            "2026-10-18|7|Udinese|Lecce|Bluenergy Stadium|SCHEDULED\n" +
            "2026-10-18|7|Venezia|Napoli|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2026-10-25|8|Atalanta|Frosinone|New Balance Arena|SCHEDULED\n" +
            "2026-10-25|8|Cagliari|Bologna|Unipol Domus|SCHEDULED\n" +
            "2026-10-25|8|Como|Sassuolo|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-10-25|8|Genoa|Venezia|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-10-25|8|Inter|Fiorentina|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-10-25|8|Lazio|Parma|Stadio Olimpico|SCHEDULED\n" +
            "2026-10-25|8|Lecce|Juventus|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-10-25|8|Napoli|Roma|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-10-25|8|Torino|Monza|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-10-25|8|Udinese|Milan|Bluenergy Stadium|SCHEDULED\n" +
            "2026-10-28|9|Fiorentina|Atalanta|Stadio Artemio Franchi|SCHEDULED\n" +
            "2026-10-28|9|Frosinone|Lecce|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-10-28|9|Genoa|Juventus|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-10-28|9|Milan|Bologna|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-10-28|9|Monza|Napoli|U-Power Stadium|SCHEDULED\n" +
            "2026-10-28|9|Parma|Udinese|Stadio Ennio Tardini|SCHEDULED\n" +
            "2026-10-28|9|Roma|Cagliari|Stadio Olimpico|SCHEDULED\n" +
            "2026-10-28|9|Sassuolo|Lazio|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-10-28|9|Torino|Como|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-10-28|9|Venezia|Inter|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2026-11-01|10|Atalanta|Parma|New Balance Arena|SCHEDULED\n" +
            "2026-11-01|10|Bologna|Monza|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2026-11-01|10|Como|Venezia|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-11-01|10|Frosinone|Torino|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-11-01|10|Juventus|Napoli|Allianz Stadium|SCHEDULED\n" +
            "2026-11-01|10|Lazio|Cagliari|Stadio Olimpico|SCHEDULED\n" +
            "2026-11-01|10|Lecce|Genoa|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-11-01|10|Milan|Inter|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-11-01|10|Sassuolo|Fiorentina|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-11-01|10|Udinese|Roma|Bluenergy Stadium|SCHEDULED\n" +
            "2026-11-08|11|Cagliari|Frosinone|Unipol Domus|SCHEDULED\n" +
            "2026-11-08|11|Fiorentina|Juventus|Stadio Artemio Franchi|SCHEDULED\n" +
            "2026-11-08|11|Genoa|Milan|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-11-08|11|Inter|Como|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-11-08|11|Monza|Atalanta|U-Power Stadium|SCHEDULED\n" +
            "2026-11-08|11|Napoli|Lazio|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-11-08|11|Parma|Bologna|Stadio Ennio Tardini|SCHEDULED\n" +
            "2026-11-08|11|Roma|Sassuolo|Stadio Olimpico|SCHEDULED\n" +
            "2026-11-08|11|Torino|Lecce|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-11-08|11|Venezia|Udinese|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2026-11-22|12|Atalanta|Inter|New Balance Arena|SCHEDULED\n" +
            "2026-11-22|12|Bologna|Udinese|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2026-11-22|12|Como|Cagliari|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-11-22|12|Juventus|Venezia|Allianz Stadium|SCHEDULED\n" +
            "2026-11-22|12|Lazio|Lecce|Stadio Olimpico|SCHEDULED\n" +
            "2026-11-22|12|Milan|Frosinone|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-11-22|12|Monza|Fiorentina|U-Power Stadium|SCHEDULED\n" +
            "2026-11-22|12|Napoli|Torino|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-11-22|12|Parma|Roma|Stadio Ennio Tardini|SCHEDULED\n" +
            "2026-11-22|12|Sassuolo|Genoa|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-11-29|13|Cagliari|Milan|Unipol Domus|SCHEDULED\n" +
            "2026-11-29|13|Como|Juventus|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-11-29|13|Frosinone|Parma|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-11-29|13|Inter|Genoa|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-11-29|13|Lecce|Atalanta|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-11-29|13|Roma|Monza|Stadio Olimpico|SCHEDULED\n" +
            "2026-11-29|13|Sassuolo|Napoli|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-11-29|13|Torino|Lazio|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-11-29|13|Udinese|Fiorentina|Bluenergy Stadium|SCHEDULED\n" +
            "2026-11-29|13|Venezia|Bologna|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2026-12-06|14|Bologna|Roma|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2026-12-06|14|Fiorentina|Cagliari|Stadio Artemio Franchi|SCHEDULED\n" +
            "2026-12-06|14|Frosinone|Inter|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-12-06|14|Genoa|Torino|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-12-06|14|Juventus|Udinese|Allianz Stadium|SCHEDULED\n" +
            "2026-12-06|14|Lazio|Atalanta|Stadio Olimpico|SCHEDULED\n" +
            "2026-12-06|14|Milan|Parma|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-12-06|14|Monza|Como|U-Power Stadium|SCHEDULED\n" +
            "2026-12-06|14|Napoli|Lecce|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-12-06|14|Venezia|Sassuolo|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2026-12-13|15|Atalanta|Genoa|New Balance Arena|SCHEDULED\n" +
            "2026-12-13|15|Cagliari|Venezia|Unipol Domus|SCHEDULED\n" +
            "2026-12-13|15|Como|Bologna|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2026-12-13|15|Inter|Torino|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-12-13|15|Juventus|Monza|Allianz Stadium|SCHEDULED\n" +
            "2026-12-13|15|Lazio|Roma|Stadio Olimpico|SCHEDULED\n" +
            "2026-12-13|15|Lecce|Sassuolo|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-12-13|15|Napoli|Milan|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2026-12-13|15|Parma|Fiorentina|Stadio Ennio Tardini|SCHEDULED\n" +
            "2026-12-13|15|Udinese|Frosinone|Bluenergy Stadium|SCHEDULED\n" +
            "2026-12-20|16|Atalanta|Napoli|New Balance Arena|SCHEDULED\n" +
            "2026-12-20|16|Fiorentina|Bologna|Stadio Artemio Franchi|SCHEDULED\n" +
            "2026-12-20|16|Frosinone|Lazio|Stadio Benito Stirpe|SCHEDULED\n" +
            "2026-12-20|16|Genoa|Udinese|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2026-12-20|16|Lecce|Inter|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2026-12-20|16|Milan|Como|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2026-12-20|16|Roma|Juventus|Stadio Olimpico|SCHEDULED\n" +
            "2026-12-20|16|Sassuolo|Parma|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2026-12-20|16|Torino|Cagliari|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2026-12-20|16|Venezia|Monza|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-01-03|17|Bologna|Juventus|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-01-03|17|Cagliari|Genoa|Unipol Domus|SCHEDULED\n" +
            "2027-01-03|17|Como|Lecce|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-01-03|17|Fiorentina|Lazio|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-01-03|17|Inter|Sassuolo|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-03|17|Monza|Milan|U-Power Stadium|SCHEDULED\n" +
            "2027-01-03|17|Parma|Napoli|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-01-03|17|Roma|Frosinone|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-03|17|Torino|Venezia|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-01-03|17|Udinese|Atalanta|Bluenergy Stadium|SCHEDULED\n" +
            "2027-01-06|18|Atalanta|Como|New Balance Arena|SCHEDULED\n" +
            "2027-01-06|18|Frosinone|Bologna|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-01-06|18|Genoa|Monza|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-01-06|18|Juventus|Torino|Allianz Stadium|SCHEDULED\n" +
            "2027-01-06|18|Lazio|Inter|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-06|18|Lecce|Parma|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-01-06|18|Milan|Fiorentina|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-06|18|Napoli|Cagliari|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-01-06|18|Sassuolo|Udinese|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-01-06|18|Venezia|Roma|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-01-10|19|Bologna|Genoa|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-01-10|19|Cagliari|Sassuolo|Unipol Domus|SCHEDULED\n" +
            "2027-01-10|19|Como|Lazio|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-01-10|19|Fiorentina|Lecce|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-01-10|19|Inter|Juventus|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-10|19|Monza|Frosinone|U-Power Stadium|SCHEDULED\n" +
            "2027-01-10|19|Parma|Venezia|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-01-10|19|Roma|Milan|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-10|19|Torino|Atalanta|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-01-10|19|Udinese|Napoli|Bluenergy Stadium|SCHEDULED\n" +
            "2027-01-17|20|Atalanta|Roma|New Balance Arena|SCHEDULED\n" +
            "2027-01-17|20|Cagliari|Como|Unipol Domus|SCHEDULED\n" +
            "2027-01-17|20|Juventus|Genoa|Allianz Stadium|SCHEDULED\n" +
            "2027-01-17|20|Lazio|Bologna|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-17|20|Lecce|Udinese|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-01-17|20|Milan|Torino|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-17|20|Napoli|Fiorentina|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-01-17|20|Parma|Inter|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-01-17|20|Sassuolo|Monza|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-01-17|20|Venezia|Frosinone|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-01-24|21|Bologna|Atalanta|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-01-24|21|Como|Napoli|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-01-24|21|Fiorentina|Sassuolo|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-01-24|21|Frosinone|Milan|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-01-24|21|Genoa|Parma|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-01-24|21|Inter|Venezia|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-24|21|Juventus|Cagliari|Allianz Stadium|SCHEDULED\n" +
            "2027-01-24|21|Lecce|Torino|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-01-24|21|Monza|Lazio|U-Power Stadium|SCHEDULED\n" +
            "2027-01-24|21|Roma|Udinese|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-31|22|Atalanta|Fiorentina|New Balance Arena|SCHEDULED\n" +
            "2027-01-31|22|Cagliari|Parma|Unipol Domus|SCHEDULED\n" +
            "2027-01-31|22|Genoa|Lecce|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-01-31|22|Lazio|Venezia|Stadio Olimpico|SCHEDULED\n" +
            "2027-01-31|22|Milan|Juventus|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-01-31|22|Monza|Roma|U-Power Stadium|SCHEDULED\n" +
            "2027-01-31|22|Napoli|Inter|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-01-31|22|Sassuolo|Como|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-01-31|22|Torino|Frosinone|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-01-31|22|Udinese|Bologna|Bluenergy Stadium|SCHEDULED\n" +
            "2027-02-07|23|Atalanta|Lazio|New Balance Arena|SCHEDULED\n" +
            "2027-02-07|23|Bologna|Milan|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-02-07|23|Como|Monza|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-02-07|23|Fiorentina|Udinese|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-02-07|23|Inter|Cagliari|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-02-07|23|Juventus|Sassuolo|Allianz Stadium|SCHEDULED\n" +
            "2027-02-07|23|Lecce|Napoli|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-02-07|23|Parma|Frosinone|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-02-07|23|Roma|Torino|Stadio Olimpico|SCHEDULED\n" +
            "2027-02-07|23|Venezia|Genoa|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-02-14|24|Bologna|Como|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-02-14|24|Cagliari|Lazio|Unipol Domus|SCHEDULED\n" +
            "2027-02-14|24|Frosinone|Fiorentina|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-02-14|24|Genoa|Atalanta|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-02-14|24|Inter|Milan|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-02-14|24|Monza|Lecce|U-Power Stadium|SCHEDULED\n" +
            "2027-02-14|24|Napoli|Juventus|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-02-14|24|Roma|Parma|Stadio Olimpico|SCHEDULED\n" +
            "2027-02-14|24|Torino|Sassuolo|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-02-14|24|Udinese|Venezia|Bluenergy Stadium|SCHEDULED\n" +
            "2027-02-21|25|Atalanta|Monza|New Balance Arena|SCHEDULED\n" +
            "2027-02-21|25|Como|Torino|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-02-21|25|Fiorentina|Inter|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-02-21|25|Juventus|Bologna|Allianz Stadium|SCHEDULED\n" +
            "2027-02-21|25|Lazio|Napoli|Stadio Olimpico|SCHEDULED\n" +
            "2027-02-21|25|Lecce|Frosinone|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-02-21|25|Milan|Genoa|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-02-21|25|Sassuolo|Roma|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-02-21|25|Udinese|Parma|Bluenergy Stadium|SCHEDULED\n" +
            "2027-02-21|25|Venezia|Cagliari|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-02-28|26|Bologna|Lecce|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-02-28|26|Cagliari|Udinese|Unipol Domus|SCHEDULED\n" +
            "2027-02-28|26|Como|Milan|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-02-28|26|Frosinone|Napoli|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-02-28|26|Genoa|Lazio|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-02-28|26|Inter|Atalanta|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-02-28|26|Monza|Juventus|U-Power Stadium|SCHEDULED\n" +
            "2027-02-28|26|Parma|Sassuolo|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-02-28|26|Roma|Venezia|Stadio Olimpico|SCHEDULED\n" +
            "2027-02-28|26|Torino|Fiorentina|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-03-07|27|Atalanta|Torino|New Balance Arena|SCHEDULED\n" +
            "2027-03-07|27|Fiorentina|Venezia|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-03-07|27|Juventus|Roma|Allianz Stadium|SCHEDULED\n" +
            "2027-03-07|27|Lazio|Frosinone|Stadio Olimpico|SCHEDULED\n" +
            "2027-03-07|27|Lecce|Como|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-03-07|27|Milan|Cagliari|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-03-07|27|Monza|Genoa|U-Power Stadium|SCHEDULED\n" +
            "2027-03-07|27|Napoli|Parma|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-03-07|27|Sassuolo|Bologna|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-03-07|27|Udinese|Inter|Bluenergy Stadium|SCHEDULED\n" +
            "2027-03-14|28|Bologna|Napoli|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-03-14|28|Cagliari|Fiorentina|Unipol Domus|SCHEDULED\n" +
            "2027-03-14|28|Como|Udinese|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-03-14|28|Frosinone|Monza|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-03-14|28|Genoa|Roma|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-03-14|28|Lazio|Juventus|Stadio Olimpico|SCHEDULED\n" +
            "2027-03-14|28|Milan|Sassuolo|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-03-14|28|Parma|Lecce|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-03-14|28|Torino|Inter|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-03-14|28|Venezia|Atalanta|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-03-21|29|Atalanta|Milan|New Balance Arena|SCHEDULED\n" +
            "2027-03-21|29|Fiorentina|Genoa|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-03-21|29|Inter|Frosinone|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-03-21|29|Juventus|Como|Allianz Stadium|SCHEDULED\n" +
            "2027-03-21|29|Monza|Bologna|U-Power Stadium|SCHEDULED\n" +
            "2027-03-21|29|Napoli|Venezia|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-03-21|29|Parma|Lazio|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-03-21|29|Roma|Lecce|Stadio Olimpico|SCHEDULED\n" +
            "2027-03-21|29|Sassuolo|Cagliari|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-03-21|29|Udinese|Torino|Bluenergy Stadium|SCHEDULED\n" +
            "2027-04-04|30|Cagliari|Napoli|Unipol Domus|SCHEDULED\n" +
            "2027-04-04|30|Como|Fiorentina|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-04-04|30|Frosinone|Udinese|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-04-04|30|Genoa|Inter|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-04-04|30|Lecce|Lazio|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-04-04|30|Milan|Monza|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-04-04|30|Roma|Bologna|Stadio Olimpico|SCHEDULED\n" +
            "2027-04-04|30|Sassuolo|Atalanta|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-04-04|30|Torino|Juventus|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-04-04|30|Venezia|Parma|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-04-11|31|Bologna|Venezia|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-04-11|31|Cagliari|Atalanta|Unipol Domus|SCHEDULED\n" +
            "2027-04-11|31|Fiorentina|Milan|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-04-11|31|Frosinone|Genoa|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-04-11|31|Inter|Roma|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-04-11|31|Juventus|Lecce|Allianz Stadium|SCHEDULED\n" +
            "2027-04-11|31|Lazio|Torino|Stadio Olimpico|SCHEDULED\n" +
            "2027-04-11|31|Napoli|Sassuolo|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-04-11|31|Parma|Como|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-04-11|31|Udinese|Monza|Bluenergy Stadium|SCHEDULED\n" +
            "2027-04-18|32|Atalanta|Udinese|New Balance Arena|SCHEDULED\n" +
            "2027-04-18|32|Bologna|Cagliari|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-04-18|32|Como|Frosinone|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-04-18|32|Fiorentina|Parma|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-04-18|32|Milan|Napoli|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-04-18|32|Monza|Inter|U-Power Stadium|SCHEDULED\n" +
            "2027-04-18|32|Roma|Lazio|Stadio Olimpico|SCHEDULED\n" +
            "2027-04-18|32|Sassuolo|Lecce|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-04-18|32|Torino|Genoa|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-04-18|32|Venezia|Juventus|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-04-25|33|Cagliari|Monza|Unipol Domus|SCHEDULED\n" +
            "2027-04-25|33|Frosinone|Roma|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-04-25|33|Genoa|Sassuolo|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-04-25|33|Inter|Bologna|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-04-25|33|Juventus|Fiorentina|Allianz Stadium|SCHEDULED\n" +
            "2027-04-25|33|Lazio|Como|Stadio Olimpico|SCHEDULED\n" +
            "2027-04-25|33|Lecce|Milan|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-04-25|33|Napoli|Udinese|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-04-25|33|Parma|Atalanta|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-04-25|33|Venezia|Torino|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-05-02|34|Atalanta|Juventus|New Balance Arena|SCHEDULED\n" +
            "2027-05-02|34|Bologna|Fiorentina|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-05-02|34|Como|Inter|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-05-02|34|Lecce|Cagliari|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-05-02|34|Milan|Lazio|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-05-02|34|Monza|Venezia|U-Power Stadium|SCHEDULED\n" +
            "2027-05-02|34|Roma|Napoli|Stadio Olimpico|SCHEDULED\n" +
            "2027-05-02|34|Sassuolo|Frosinone|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-05-02|34|Torino|Parma|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-05-02|34|Udinese|Genoa|Bluenergy Stadium|SCHEDULED\n" +
            "2027-05-09|35|Fiorentina|Roma|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-05-09|35|Frosinone|Atalanta|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-05-09|35|Genoa|Cagliari|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-05-09|35|Inter|Lecce|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-05-09|35|Lazio|Sassuolo|Stadio Olimpico|SCHEDULED\n" +
            "2027-05-09|35|Napoli|Monza|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-05-09|35|Parma|Milan|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-05-09|35|Torino|Bologna|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-05-09|35|Udinese|Juventus|Bluenergy Stadium|SCHEDULED\n" +
            "2027-05-09|35|Venezia|Como|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-05-16|36|Bologna|Frosinone|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-05-16|36|Cagliari|Torino|Unipol Domus|SCHEDULED\n" +
            "2027-05-16|36|Como|Atalanta|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-05-16|36|Juventus|Inter|Allianz Stadium|SCHEDULED\n" +
            "2027-05-16|36|Lazio|Udinese|Stadio Olimpico|SCHEDULED\n" +
            "2027-05-16|36|Lecce|Fiorentina|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-05-16|36|Milan|Roma|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-05-16|36|Monza|Parma|U-Power Stadium|SCHEDULED\n" +
            "2027-05-16|36|Napoli|Genoa|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-05-16|36|Sassuolo|Venezia|Mapei Stadium - Città del Tricolore|SCHEDULED\n" +
            "2027-05-23|37|Atalanta|Lecce|New Balance Arena|SCHEDULED\n" +
            "2027-05-23|37|Fiorentina|Monza|Stadio Artemio Franchi|SCHEDULED\n" +
            "2027-05-23|37|Frosinone|Cagliari|Stadio Benito Stirpe|SCHEDULED\n" +
            "2027-05-23|37|Genoa|Bologna|Stadio Luigi Ferraris|SCHEDULED\n" +
            "2027-05-23|37|Inter|Lazio|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-05-23|37|Parma|Juventus|Stadio Ennio Tardini|SCHEDULED\n" +
            "2027-05-23|37|Roma|Como|Stadio Olimpico|SCHEDULED\n" +
            "2027-05-23|37|Torino|Napoli|Stadio Olimpico Grande Torino|SCHEDULED\n" +
            "2027-05-23|37|Udinese|Sassuolo|Bluenergy Stadium|SCHEDULED\n" +
            "2027-05-23|37|Venezia|Milan|Stadio Pier Luigi Penzo|SCHEDULED\n" +
            "2027-05-30|38|Bologna|Parma|Stadio Renato Dall'Ara|SCHEDULED\n" +
            "2027-05-30|38|Cagliari|Roma|Unipol Domus|SCHEDULED\n" +
            "2027-05-30|38|Como|Genoa|Stadio Giuseppe Sinigaglia|SCHEDULED\n" +
            "2027-05-30|38|Juventus|Frosinone|Allianz Stadium|SCHEDULED\n" +
            "2027-05-30|38|Lazio|Fiorentina|Stadio Olimpico|SCHEDULED\n" +
            "2027-05-30|38|Lecce|Venezia|Stadio Ettore Giardiniero - Via del Mare|SCHEDULED\n" +
            "2027-05-30|38|Milan|Udinese|Stadio Giuseppe Meazza|SCHEDULED\n" +
            "2027-05-30|38|Monza|Torino|U-Power Stadium|SCHEDULED\n" +
            "2027-05-30|38|Napoli|Atalanta|Stadio Diego Armando Maradona|SCHEDULED\n" +
            "2027-05-30|38|Sassuolo|Inter|Mapei Stadium - Città del Tricolore|SCHEDULED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        TLA.put("Atalanta", "ATA");
        TLA.put("Bologna", "BOL");
        TLA.put("Cagliari", "CAG");
        TLA.put("Como", "COM");
        TLA.put("Fiorentina", "FIO");
        TLA.put("Frosinone", "FRO");
        TLA.put("Genoa", "GEN");
        TLA.put("Inter", "INT");
        TLA.put("Juventus", "JUV");
        TLA.put("Lazio", "LAZ");
        TLA.put("Lecce", "LEC");
        TLA.put("Milan", "MIL");
        TLA.put("Monza", "MON");
        TLA.put("Napoli", "NAP");
        TLA.put("Parma", "PAR");
        TLA.put("Roma", "ROM");
        TLA.put("Sassuolo", "SAS");
        TLA.put("Torino", "TOR");
        TLA.put("Udinese", "UDI");
        TLA.put("Venezia", "VEN");

        CRESTS.put("Atalanta", "https://crests.football-data.org/102.png");
        CRESTS.put("Bologna", "https://crests.football-data.org/103.png");
        CRESTS.put("Cagliari", "https://crests.football-data.org/104.png");
        CRESTS.put("Como", "https://crests.football-data.org/7397.png");
        CRESTS.put("Fiorentina", "https://crests.football-data.org/99.png");
        CRESTS.put("Frosinone", "https://crests.football-data.org/470.png");
        CRESTS.put("Genoa", "https://crests.football-data.org/107.png");
        CRESTS.put("Inter", "https://crests.football-data.org/108.png");
        CRESTS.put("Juventus", "https://crests.football-data.org/109.png");
        CRESTS.put("Lazio", "https://crests.football-data.org/110.png");
        CRESTS.put("Lecce", "https://crests.football-data.org/5890.png");
        CRESTS.put("Milan", "https://crests.football-data.org/98.png");
        CRESTS.put("Monza", "https://crests.football-data.org/5911.png");
        CRESTS.put("Napoli", "https://crests.football-data.org/113.png");
        CRESTS.put("Parma", "https://crests.football-data.org/112.png");
        CRESTS.put("Roma", "https://crests.football-data.org/100.png");
        CRESTS.put("Sassuolo", "https://crests.football-data.org/471.png");
        CRESTS.put("Torino", "https://crests.football-data.org/586.png");
        CRESTS.put("Udinese", "https://crests.football-data.org/115.png");
        CRESTS.put("Venezia", "https://crests.football-data.org/454.png");

        VENUES.put("Atalanta", "New Balance Arena");
        VENUES.put("Bologna", "Stadio Renato Dall'Ara");
        VENUES.put("Cagliari", "Unipol Domus");
        VENUES.put("Como", "Stadio Giuseppe Sinigaglia");
        VENUES.put("Fiorentina", "Stadio Artemio Franchi");
        VENUES.put("Frosinone", "Stadio Benito Stirpe");
        VENUES.put("Genoa", "Stadio Luigi Ferraris");
        VENUES.put("Inter", "Stadio Giuseppe Meazza");
        VENUES.put("Juventus", "Allianz Stadium");
        VENUES.put("Lazio", "Stadio Olimpico");
        VENUES.put("Lecce", "Stadio Ettore Giardiniero - Via del Mare");
        VENUES.put("Milan", "Stadio Giuseppe Meazza");
        VENUES.put("Monza", "U-Power Stadium");
        VENUES.put("Napoli", "Stadio Diego Armando Maradona");
        VENUES.put("Parma", "Stadio Ennio Tardini");
        VENUES.put("Roma", "Stadio Olimpico");
        VENUES.put("Sassuolo", "Mapei Stadium - Città del Tricolore");
        VENUES.put("Torino", "Stadio Olimpico Grande Torino");
        VENUES.put("Udinese", "Bluenergy Stadium");
        VENUES.put("Venezia", "Stadio Pier Luigi Penzo");

        FOUNDED.put("Atalanta", 1907);
        FOUNDED.put("Bologna", 1909);
        FOUNDED.put("Cagliari", 1920);
        FOUNDED.put("Como", 1907);
        FOUNDED.put("Fiorentina", 1926);
        FOUNDED.put("Frosinone", 1912);
        FOUNDED.put("Genoa", 1893);
        FOUNDED.put("Inter", 1908);
        FOUNDED.put("Juventus", 1897);
        FOUNDED.put("Lazio", 1900);
        FOUNDED.put("Lecce", 1908);
        FOUNDED.put("Milan", 1899);
        FOUNDED.put("Monza", 1912);
        FOUNDED.put("Napoli", 1926);
        FOUNDED.put("Parma", 1913);
        FOUNDED.put("Roma", 1927);
        FOUNDED.put("Sassuolo", 1920);
        FOUNDED.put("Torino", 1906);
        FOUNDED.put("Udinese", 1896);
        FOUNDED.put("Venezia", 1907);

        WEBSITES.put("Atalanta", "https://www.atalanta.it");
        WEBSITES.put("Bologna", "https://www.bolognafc.it");
        WEBSITES.put("Cagliari", "https://www.cagliaricalcio.com");
        WEBSITES.put("Como", "https://comofootball.com");
        WEBSITES.put("Fiorentina", "https://www.acffiorentina.com");
        WEBSITES.put("Frosinone", "https://www.frosinonecalcio.com");
        WEBSITES.put("Genoa", "https://genoacfc.it");
        WEBSITES.put("Inter", "https://www.inter.it");
        WEBSITES.put("Juventus", "https://www.juventus.com");
        WEBSITES.put("Lazio", "https://www.sslazio.it");
        WEBSITES.put("Lecce", "https://www.uslecce.it");
        WEBSITES.put("Milan", "https://www.acmilan.com");
        WEBSITES.put("Monza", "https://www.acmonza.com");
        WEBSITES.put("Napoli", "https://sscnapoli.it");
        WEBSITES.put("Parma", "https://www.parmacalcio1913.com");
        WEBSITES.put("Roma", "https://www.asroma.com");
        WEBSITES.put("Sassuolo", "https://www.sassuolocalcio.it");
        WEBSITES.put("Torino", "https://www.torinofc.it");
        WEBSITES.put("Udinese", "https://www.udinese.it");
        WEBSITES.put("Venezia", "https://www.veneziafc.it");

        COLORS.put("Atalanta", "Blue / Black");
        COLORS.put("Bologna", "Red / Blue");
        COLORS.put("Cagliari", "Red / Navy Blue");
        COLORS.put("Como", "Blue / White");
        COLORS.put("Fiorentina", "Purple / White");
        COLORS.put("Frosinone", "Yellow / Blue");
        COLORS.put("Genoa", "Red / Navy Blue");
        COLORS.put("Inter", "Blue / Black");
        COLORS.put("Juventus", "Black / White");
        COLORS.put("Lazio", "Sky Blue / White");
        COLORS.put("Lecce", "Yellow / Red");
        COLORS.put("Milan", "Red / Black");
        COLORS.put("Monza", "Red / White");
        COLORS.put("Napoli", "Sky Blue / White");
        COLORS.put("Parma", "White / Black / Yellow / Blue");
        COLORS.put("Roma", "Maroon / Gold");
        COLORS.put("Sassuolo", "Green / Black");
        COLORS.put("Torino", "Maroon / White");
        COLORS.put("Udinese", "Black / White");
        COLORS.put("Venezia", "Orange / Black / Green");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutSerieA(root.optJSONArray("matches")));
            root.put("live", copyWithoutSerieA(root.optJSONArray("live")));
            root.put("finished", copyWithoutSerieA(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutSerieA(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");

            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // A malformed future manual edit must never block other competitions.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonSerieA(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "SA-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "SCHEDULED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "Lega Serie A official fixture calendar");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Serie A source"));
        } catch (Exception ignored) {}
    }

    /** Preserve compact official UI names while accepting richer connected metadata. */
    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"tla", "crest", "emblem", "logo", "venue", "address", "website", "clubColors", "founded"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            Object raw = richer.opt(key);
            String value = String.valueOf(raw).trim();
            if (value.length() > 0 && !"null".equalsIgnoreCase(value)) out.put(key, raw);
        }
        Object richerArea = richer.opt("area");
        if (richerArea instanceof JSONObject) out.put("area", richerArea);
        else if (richerArea != null && String.valueOf(richerArea).trim().length() > 0) {
            JSONObject area = new JSONObject();
            area.put("name", String.valueOf(richerArea).trim());
            out.put("area", area);
        }
        String name = out.optString("name", out.optString("shortName", ""));
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(name)) out.put("crest", CRESTS.get(name));
        return out;
    }

    private static JSONArray copyWithoutSerieA(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isSerieA(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonSerieA(JSONObject row) {
        if (!isSerieA(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    /** Exact matching avoids confusing Italy's Serie A with Brazil's Série A. */
    private static boolean isSerieA(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        String rawCode = "";
        String rawName = "";
        if (raw instanceof JSONObject) {
            JSONObject competition = (JSONObject) raw;
            rawCode = competition.optString("code", "");
            rawName = competition.optString("name", "");
        } else if (raw != null) rawName = String.valueOf(raw);
        String rowCode = row.optString("competitionCode", "");
        String rawCodeNormalized = normalize(rawCode);
        String rowCodeNormalized = normalize(rowCode);
        if (rawCodeNormalized.equals("sa") || rowCodeNormalized.equals("sa")) return true;
        // A different explicit code (for example Brazil's BSA) always wins over
        // an ambiguous translated competition name.
        if (rawCodeNormalized.length() > 0 || rowCodeNormalized.length() > 0) return false;
        String rowName = row.optString("competitionName", "");
        String rawNormalized = normalize(rawName);
        String rowNormalized = normalize(rowName);
        return rawNormalized.equals("sa") || rawNormalized.equals("seriea") || rawNormalized.equals("italyseriea") || rawNormalized.equals("serieaitaly") ||
                rowNormalized.equals("sa") || rowNormalized.equals("seriea") || rowNormalized.equals("italyseriea") || rowNormalized.equals("serieaitaly");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true);
        String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0;
        String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30;
        else if (isLive(status)) score += 25;
        else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2;
        if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") ||
                value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject();
        competition.put("code", COMPETITION_CODE);
        competition.put("name", COMPETITION_NAME);
        return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject();
        team.put("name", name);
        team.put("shortName", name);
        team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        JSONObject area = new JSONObject();
        area.put("name", "Italy");
        team.put("area", area);
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        if (VENUES.containsKey(name)) team.put("venue", VENUES.get(name));
        if (FOUNDED.containsKey(name)) team.put("founded", FOUNDED.get(name));
        if (WEBSITES.containsKey(name)) team.put("website", WEBSITES.get(name));
        if (COLORS.containsKey(name)) team.put("clubColors", COLORS.get(name));
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = source == null ? new JSONArray() : new JSONArray(source.toString());
        Map<String, Integer> positions = new HashMap<String, Integer>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (name.length() > 0) positions.put(clubKey(name), i);
        }
        for (String name : TLA.keySet()) {
            JSONObject fallback = teamObject(name);
            Integer position = positions.get(clubKey(name));
            if (position == null) teams.put(fallback);
            else {
                JSONObject richer = teams.optJSONObject(position);
                teams.put(position, mergeTeam(fallback, richer == null ? new JSONObject() : richer));
            }
        }
        root.put("teams", teams);
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE);
        if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        boolean current = start.startsWith("2026") && end.startsWith("2027");
        if (!current) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources");
        if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject serieA = sources.optJSONObject(COMPETITION_CODE);
        if (serieA == null) serieA = new JSONObject();
        serieA.put("status", "connected");
        serieA.put("provider", "Lega Serie A official fixture calendar + connected live source");
        serieA.put("season", SEASON);
        serieA.put("matchCount", matchCount);
        serieA.put("teamCount", TLA.size());
        serieA.put("roundCount", 38);
        sources.put(COMPETITION_CODE, serieA);
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("atalantabc")) return "atalanta";
        if (key.equals("bolognafc1909") || key.equals("bolognafc")) return "bologna";
        if (key.equals("cagliaricalcio")) return "cagliari";
        if (key.equals("como1907") || key.equals("como1907fc")) return "como";
        if (key.equals("acfiorentina")) return "fiorentina";
        if (key.equals("frosinonecalcio")) return "frosinone";
        if (key.equals("genoacfc")) return "genoa";
        if (key.equals("fcinternazionalemilano") || key.equals("internazionalemilano") || key.equals("intermilan")) return "inter";
        if (key.equals("juventusfc")) return "juventus";
        if (key.equals("sslazio")) return "lazio";
        if (key.equals("uslecce")) return "lecce";
        if (key.equals("acmilan")) return "milan";
        if (key.equals("acmonza")) return "monza";
        if (key.equals("sscnapoli")) return "napoli";
        if (key.equals("parmacalcio1913") || key.equals("parmacalcio")) return "parma";
        if (key.equals("asroma")) return "roma";
        if (key.equals("ussassuolocalcio") || key.equals("sassuolocalcio")) return "sassuolo";
        if (key.equals("torinofc")) return "torino";
        if (key.equals("udinesecalcio")) return "udinese";
        if (key.equals("veneziafc")) return "venezia";
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private SerieA2627Data() {}
}
