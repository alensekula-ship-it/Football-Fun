package com.asappfactory.footballfun.data;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** One canonical catalog for every competition shown by Football Fun. */
public final class CompetitionCatalog {
    public static final class Competition {
        public final String name;
        public final String apiCode;
        public final int teamCount;
        public final String regionKey;
        public final boolean nationalTeams;
        public final boolean footballDataSource;
        public final boolean roundBased;

        Competition(String name, String apiCode, int teamCount, String regionKey,
                    boolean nationalTeams, boolean footballDataSource, boolean roundBased) {
            this.name = name;
            this.apiCode = apiCode;
            this.teamCount = teamCount;
            this.regionKey = regionKey;
            this.nationalTeams = nationalTeams;
            this.footballDataSource = footballDataSource;
            this.roundBased = roundBased;
        }
    }

    private static final Map<String, Competition> COMPETITIONS;
    static {
        LinkedHashMap<String, Competition> items = new LinkedHashMap<String, Competition>();
        add(items, "HNL", "HNL", 10, "Croatia", false, false, true);
        add(items, "UEFA Champions League", "CL", 52, "Europe", false, true, false);
        add(items, "Premier League", "PL", 20, "England", false, true, true);
        add(items, "Championship", "ELC", 24, "England", false, true, true);
        add(items, "La Liga", "PD", 20, "Spain", false, true, true);
        add(items, "Bundesliga", "BL1", 18, "Germany", false, true, true);
        add(items, "Serie A", "SA", 20, "Italy", false, true, true);
        add(items, "Ligue 1", "FL1", 18, "France", false, true, true);
        add(items, "Eredivisie", "DED", 18, "Netherlands", false, true, true);
        add(items, "Primeira Liga", "PPL", 18, "Portugal", false, true, true);
        add(items, "Brasileirão Série A", "BSA", 20, "Brazil", false, true, true);
        add(items, "World Cup 2026", "WC", 48, "International", true, true, false);
        add(items, "UEFA European Championship", "EC", 24, "International", true, true, false);
        COMPETITIONS = Collections.unmodifiableMap(items);
    }

    private static void add(Map<String, Competition> items, String name, String apiCode,
                            int teamCount, String regionKey, boolean nationalTeams,
                            boolean footballDataSource, boolean roundBased) {
        items.put(name, new Competition(name, apiCode, teamCount, regionKey, nationalTeams, footballDataSource, roundBased));
    }

    public static Competition get(String name) {
        Competition competition = COMPETITIONS.get(name);
        if (competition != null) return competition;
        return new Competition(name, "", 20, "Europe", false, true, true);
    }

    public static Map<String, Competition> all() { return COMPETITIONS; }

    private CompetitionCatalog() {}
}
