package com.asappfactory.footballfun.match;

/**
 * Explicit availability state for detailed match data. Missing data is not zero.
 * The UI must only render a module when VERIFIED_AVAILABLE is returned.
 */
public enum MatchDataAvailability {
    VERIFIED_AVAILABLE,
    UNAVAILABLE;

    public static MatchDataAvailability fromText(String value) {
        if (value == null) return UNAVAILABLE;
        String clean = value.trim();
        if (clean.length() == 0) return UNAVAILABLE;
        String upper = clean.toUpperCase(java.util.Locale.US);
        if (upper.equals("NULL") || upper.equals("N/A") || upper.equals("NA") ||
                upper.equals("TBD") || upper.equals("TBA") || upper.equals("UNKNOWN") ||
                upper.equals("-") || upper.equals("?")) return UNAVAILABLE;
        return VERIFIED_AVAILABLE;
    }

    public boolean isAvailable() {
        return this == VERIFIED_AVAILABLE;
    }
}
