package com.asappfactory.footballfun.model;

/** Group-table row used by the World Cup module. */
public final class TeamRow {
    public String group;
    public String team;
    public int pts;
    public int gf;
    public int ga;
    public int w;
    public int d;
    public int l;
    public int p;

    public TeamRow(String group, String team) {
        this.group = group;
        this.team = team;
    }
}
