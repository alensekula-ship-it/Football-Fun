package com.asappfactory.footballfun.data;
import com.asappfactory.footballfun.model.ClubProfile;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
/** Central verified identity registry for every club bundled by Football Fun plus current UEFA 2026/27 participants. */
public final class ClubIdentityRegistry {
  private static final LinkedHashMap<String, ClubProfile> CANONICAL = new LinkedHashMap<String, ClubProfile>();
  private static final LinkedHashMap<String, String> ALIASES = new LinkedHashMap<String, String>();
  static {
    add("AFC Bournemouth", "Premier League", "England");
    add("Arsenal", "Premier League", "England");
    add("Aston Villa", "Premier League", "England");
    add("Brentford", "Premier League", "England");
    add("Brighton & Hove Albion", "Premier League", "England", "Brighton", "Brighton and Hove Albion", "Brighton Hove Albion");
    add("Chelsea", "Premier League", "England");
    add("Coventry City", "Premier League", "England", "Coventry City FC");
    add("Crystal Palace", "Premier League", "England");
    add("Everton", "Premier League", "England");
    add("Fulham", "Premier League", "England");
    add("Hull City", "Premier League", "England", "Hull City AFC", "Hull City FC");
    add("Ipswich Town", "Premier League", "England", "Ipswich Town FC");
    add("Leeds United", "Premier League", "England");
    add("Liverpool", "Premier League", "England");
    add("Manchester City", "Premier League", "England", "Man City");
    add("Manchester United", "Premier League", "England", "Man United", "Man Utd");
    add("Newcastle United", "Premier League", "England", "Newcastle");
    add("Nottingham Forest", "Premier League", "England", "Nottingham");
    add("Sunderland", "Premier League", "England");
    add("Tottenham Hotspur", "Premier League", "England", "Tottenham", "Spurs");
    add("Birmingham City", "Championship", "England");
    add("Blackburn Rovers", "Championship", "England");
    add("Bolton Wanderers", "Championship", "England");
    add("Bristol City", "Championship", "England");
    add("Burnley", "Championship", "England");
    add("Cardiff City", "Championship", "England");
    add("Charlton Athletic", "Championship", "England");
    add("Derby County", "Championship", "England");
    add("Lincoln City", "Championship", "England");
    add("Middlesbrough", "Championship", "England");
    add("Millwall", "Championship", "England");
    add("Norwich City", "Championship", "England");
    add("Portsmouth", "Championship", "England");
    add("Preston North End", "Championship", "England");
    add("Queens Park Rangers", "Championship", "England", "QPR");
    add("Sheffield United", "Championship", "England");
    add("Southampton", "Championship", "England");
    add("Stoke City", "Championship", "England");
    add("Swansea City", "Championship", "England");
    add("Watford", "Championship", "England");
    add("West Bromwich Albion", "Championship", "England", "West Brom");
    add("West Ham United", "Championship", "England");
    add("Wolverhampton Wanderers", "Championship", "England", "Wolves");
    add("Wrexham", "Championship", "England");
    add("Athletic Club", "La Liga", "Spain", "Athletic Bilbao");
    add("Atlético de Madrid", "La Liga", "Spain",
        "Atletico Madrid",
        "Atleti",
        "Club Atlético de Madrid",
        "Club Atletico de Madrid",
        "Atlético Madrid",
        "Atletico de Madrid");
    add("CA Osasuna", "La Liga", "Spain", "Osasuna");
    add("Celta de Vigo", "La Liga", "Spain", "Celta", "RC Celta", "Celta Vigo");
    add("Deportivo Alavés", "La Liga", "Spain", "Deportivo Alaves", "Alaves");
    add("Deportivo La Coruña", "La Liga", "Spain", "Deportivo La Coruna", "RC Deportivo");
    add("Elche CF", "La Liga", "Spain");
    add("FC Barcelona", "La Liga", "Spain", "Barcelona");
    add("Getafe CF", "La Liga", "Spain");
    add("Levante UD", "La Liga", "Spain");
    add("Málaga CF", "La Liga", "Spain");
    add("RCD Espanyol", "La Liga", "Spain", "Espanyol", "RCD Espanyol de Barcelona");
    add("Racing Santander", "La Liga", "Spain", "R. Racing Club", "Racing Club");
    add("Rayo Vallecano", "La Liga", "Spain",
        "Rayo Vallecano de Madrid",
        "Rayo Vallecano de Madrid S.A.D.",
        "Rayo Vallecano de Madrid SAD");
    add("Real Betis", "La Liga", "Spain", "Real Betis Balompié", "Real Betis Balompie");
    add("Real Madrid", "La Liga", "Spain", "Real Madrid CF", "Real Madrid C.F.");
    add("Real Sociedad", "La Liga", "Spain", "Real Sociedad de Fútbol", "Real Sociedad de Futbol");
    add("Sevilla FC", "La Liga", "Spain");
    add("Valencia CF", "La Liga", "Spain");
    add("Villarreal CF", "La Liga", "Spain", "Villarreal");
    add("1. FC Köln", "Bundesliga", "Germany");
    add("1. FC Union Berlin", "Bundesliga", "Germany", "Union Berlin");
    add("1. FSV Mainz 05", "Bundesliga", "Germany", "Mainz 05", "Mainz");
    add("Bayer 04 Leverkusen", "Bundesliga", "Germany");
    add("Borussia Dortmund", "Bundesliga", "Germany", "B. Dortmund", "Dortmund");
    add("Borussia Mönchengladbach", "Bundesliga", "Germany", "Borussia Monchengladbach", "Mgladbach");
    add("Eintracht Frankfurt", "Bundesliga", "Germany");
    add("FC Augsburg", "Bundesliga", "Germany");
    add("FC Bayern München", "Bundesliga", "Germany", "Bayern Munich", "Bayern München");
    add("FC Schalke 04", "Bundesliga", "Germany", "Schalke 04", "Schalke");
    add("Hamburger SV", "Bundesliga", "Germany");
    add("RB Leipzig", "Bundesliga", "Germany", "Leipzig");
    add("SC Paderborn 07", "Bundesliga", "Germany");
    add("SV Elversberg", "Bundesliga", "Germany");
    add("SV Werder Bremen", "Bundesliga", "Germany", "Werder Bremen");
    add("Sport-Club Freiburg", "Bundesliga", "Germany", "SC Freiburg", "Freiburg");
    add("TSG Hoffenheim", "Bundesliga", "Germany", "Hoffenheim");
    add("VfB Stuttgart", "Bundesliga", "Germany", "Stuttgart");
    add("Atalanta", "Serie A", "Italy", "Atalanta BC");
    add("Bologna", "Serie A", "Italy", "Bologna FC 1909");
    add("Cagliari", "Serie A", "Italy", "Cagliari Calcio");
    add("Como", "Serie A", "Italy", "Como 1907");
    add("Fiorentina", "Serie A", "Italy", "ACF Fiorentina");
    add("Frosinone", "Serie A", "Italy");
    add("Genoa", "Serie A", "Italy", "Genoa CFC");
    add("Inter", "Serie A", "Italy", "Inter Milan", "FC Internazionale Milano");
    add("Juventus", "Serie A", "Italy");
    add("Lazio", "Serie A", "Italy", "SS Lazio");
    add("Lecce", "Serie A", "Italy", "US Lecce");
    add("Milan", "Serie A", "Italy", "AC Milan");
    add("Monza", "Serie A", "Italy", "AC Monza");
    add("Napoli", "Serie A", "Italy", "SSC Napoli");
    add("Parma", "Serie A", "Italy", "Parma Calcio 1913");
    add("Roma", "Serie A", "Italy", "AS Roma");
    add("Sassuolo", "Serie A", "Italy", "US Sassuolo Calcio");
    add("Torino", "Serie A", "Italy", "Torino FC");
    add("Udinese", "Serie A", "Italy", "Udinese Calcio");
    add("Venezia", "Serie A", "Italy", "Venezia FC");
    add("Angers", "Ligue 1", "France", "Angers SCO");
    add("Auxerre", "Ligue 1", "France", "AJ Auxerre");
    add("Brest", "Ligue 1", "France", "Stade Brestois 29");
    add("Le Havre", "Ligue 1", "France", "Le Havre AC");
    add("Le Mans", "Ligue 1", "France", "Le Mans FC");
    add("Lens", "Ligue 1", "France", "RC Lens");
    add("Lille", "Ligue 1", "France", "LOSC", "LOSC Lille");
    add("Lorient", "Ligue 1", "France", "FC Lorient");
    add("Lyon", "Ligue 1", "France", "Olympique Lyonnais", "OL");
    add("Marseille", "Ligue 1", "France", "Olympique de Marseille", "OM");
    add("Monaco", "Ligue 1", "France", "AS Monaco");
    add("Nice", "Ligue 1", "France", "OGC Nice");
    add("Paris FC", "Ligue 1", "France");
    add("Paris Saint-Germain", "Ligue 1", "France", "PSG", "Paris");
    add("Rennes", "Ligue 1", "France", "Stade Rennais");
    add("Strasbourg", "Ligue 1", "France", "RC Strasbourg");
    add("Toulouse", "Ligue 1", "France", "Toulouse FC");
    add("Troyes", "Ligue 1", "France", "ESTAC Troyes");
    add("ADO Den Haag", "Eredivisie", "Netherlands");
    add("AZ", "Eredivisie", "Netherlands", "AZ Alkmaar", "AZ 67");
    add("Ajax", "Eredivisie", "Netherlands", "AFC Ajax", "Ajax Amsterdam");
    add("Excelsior Rotterdam", "Eredivisie", "Netherlands", "Excelsior", "SBV Excelsior");
    add("FC Groningen", "Eredivisie", "Netherlands", "Groningen");
    add("FC Twente", "Eredivisie", "Netherlands", "Twente");
    add("FC Utrecht", "Eredivisie", "Netherlands", "Utrecht");
    add("Feyenoord", "Eredivisie", "Netherlands");
    add("Fortuna Sittard", "Eredivisie", "Netherlands");
    add("Go Ahead Eagles", "Eredivisie", "Netherlands");
    add("N.E.C.", "Eredivisie", "Netherlands", "NEC", "N.E.C. Nijmegen", "NEC Nijmegen");
    add("PEC Zwolle", "Eredivisie", "Netherlands");
    add("PSV", "Eredivisie", "Netherlands", "PSV Eindhoven");
    add("SC Cambuur", "Eredivisie", "Netherlands", "Cambuur");
    add("SC Heerenveen", "Eredivisie", "Netherlands", "Heerenveen", "sc Heerenveen");
    add("Sparta Rotterdam", "Eredivisie", "Netherlands", "Sparta");
    add("Telstar", "Eredivisie", "Netherlands", "SC Telstar");
    add("Willem II", "Eredivisie", "Netherlands", "Willem 2");
    add("Académico", "Primeira Liga", "Portugal", "Academico", "Academico de Viseu");
    add("CD Nacional", "Primeira Liga", "Portugal", "Nacional", "Nacional Madeira");
    add("Casa Pia AC", "Primeira Liga", "Portugal", "Casa Pia");
    add("Estoril Praia", "Primeira Liga", "Portugal", "Estoril");
    add("Estrela Amadora", "Primeira Liga", "Portugal", "Estrela");
    add("FC Alverca", "Primeira Liga", "Portugal", "Alverca");
    add("FC Arouca", "Primeira Liga", "Portugal", "Arouca");
    add("FC Famalicão", "Primeira Liga", "Portugal", "Famalicao");
    add("FC Porto", "Primeira Liga", "Portugal", "Porto");
    add("Gil Vicente FC", "Primeira Liga", "Portugal", "Gil Vicente");
    add("Marítimo", "Primeira Liga", "Portugal", "Maritimo", "CS Maritimo");
    add("Moreirense FC", "Primeira Liga", "Portugal", "Moreirense");
    add("Rio Ave FC", "Primeira Liga", "Portugal", "Rio Ave");
    add("SC Braga", "Primeira Liga", "Portugal", "Braga");
    add("SL Benfica", "Primeira Liga", "Portugal", "Benfica");
    add("Santa Clara", "Primeira Liga", "Portugal", "CD Santa Clara");
    add("Sporting CP", "Primeira Liga", "Portugal", "Sporting", "Sporting Lisbon");
    add("Vitória SC", "Primeira Liga", "Portugal", "Vitoria SC", "Vitoria Guimaraes", "Guimaraes");
    add("Athletico Paranaense", "Brasileirão Série A", "Brazil", "Athletico-PR", "CAP");
    add("Atlético Mineiro", "Brasileirão Série A", "Brazil", "Atletico Mineiro", "Atletico-MG", "CAM");
    add("Bahia", "Brasileirão Série A", "Brazil", "EC Bahia");
    add("Botafogo", "Brasileirão Série A", "Brazil", "Botafogo FR");
    add("Chapecoense", "Brasileirão Série A", "Brazil", "Chapecoense AF");
    add("Corinthians", "Brasileirão Série A", "Brazil", "Sport Club Corinthians Paulista");
    add("Coritiba", "Brasileirão Série A", "Brazil", "Coritiba FC");
    add("Cruzeiro", "Brasileirão Série A", "Brazil", "Cruzeiro EC");
    add("Flamengo", "Brasileirão Série A", "Brazil", "CR Flamengo");
    add("Fluminense", "Brasileirão Série A", "Brazil", "Fluminense FC");
    add("Grêmio", "Brasileirão Série A", "Brazil", "Gremio", "Gremio FBPA");
    add("Internacional", "Brasileirão Série A", "Brazil", "SC Internacional");
    add("Mirassol", "Brasileirão Série A", "Brazil", "Mirassol FC");
    add("Palmeiras", "Brasileirão Série A", "Brazil", "SE Palmeiras");
    add("Red Bull Bragantino", "Brasileirão Série A", "Brazil", "RB Bragantino");
    add("Remo", "Brasileirão Série A", "Brazil", "Clube do Remo");
    add("Santos", "Brasileirão Série A", "Brazil", "Santos FC");
    add("São Paulo", "Brasileirão Série A", "Brazil", "Sao Paulo", "Sao Paulo FC");
    add("Vasco da Gama", "Brasileirão Série A", "Brazil", "CR Vasco da Gama");
    add("Vitória", "Brasileirão Série A", "Brazil", "Vitoria", "EC Vitoria");
    add("Dinamo Zagreb", "HNL", "Croatia", "GNK Dinamo", "GNK Dinamo Zagreb", "Dinamo");
    add("Gorica", "HNL", "Croatia", "HNK Gorica", "HNK Gorica s.d.d.");
    add("Hajduk Split", "HNL", "Croatia", "HNK Hajduk", "Hajduk");
    add("Istra 1961", "HNL", "Croatia", "NK Istra 1961");
    add("Lokomotiva Zagreb", "HNL", "Croatia", "NK Lokomotiva", "NK Lokomotiva (Z)", "Lokomotiva");
    add("Osijek", "HNL", "Croatia", "NK Osijek");
    add("Rijeka", "HNL", "Croatia", "HNK Rijeka");
    add("Rudeš", "HNL", "Croatia", "NK Rudeš", "Rudes");
    add("Slaven Belupo", "HNL", "Croatia", "NK Slaven Belupo");
    add("Varaždin", "HNL", "Croatia", "NK Varaždin", "Varazdin");
    add("Club Brugge", "Belgian Pro League", "Belgium", "Club Brugge KV");
    add("Galatasaray", "Süper Lig", "Turkey");
    add("Shakhtar Donetsk", "Ukrainian Premier League", "Ukraine", "Shakhtar");
    add("Slavia Praha", "Czech First League", "Czechia", "Slavia Prague");
    add("AEK Athens", "Super League Greece", "Greece", "AEK Athens FC");
    add("Bodø/Glimt", "Eliteserien", "Norway", "Bodo/Glimt", "FK Bodø/Glimt");
    add("Celje", "Slovenian PrvaLiga", "Slovenia", "NK Celje");
    add("Celtic", "Scottish Premiership", "Scotland", "Celtic FC");
    add("Fenerbahçe", "Süper Lig", "Turkey", "Fenerbahce", "Fenerbahçe SK");
    add("Hapoel Beer-Sheva", "Israeli Premier League", "Israel", "H. Beer-Sheva", "Hapoel Beer Sheva", "Hapoel Beer-Sheva FC");
    add("LASK", "Austrian Bundesliga", "Austria", "LASK Linz");
    add("Levski Sofia", "Bulgarian First League", "Bulgaria", "PFC Levski Sofia");
    add("Slovan Bratislava", "Slovak First Football League", "Slovakia", "S. Bratislava", "ŠK Slovan Bratislava");
    add("Sabah", "Azerbaijan Premier League", "Azerbaijan", "Sabah FC", "Sabah FK", "Sabah Baku");
    add("Viking", "Eliteserien", "Norway", "Viking FK");
    add("Aarhus", "Danish Superliga", "Denmark", "AGF Aarhus", "AGF");
    add("Ararat-Armenia", "Armenian Premier League", "Armenia", "FC Ararat-Armenia");
    add("Crvena Zvezda", "Serbian SuperLiga", "Serbia", "Red Star Belgrade", "FK Crvena Zvezda");
    add("Kairat Almaty", "Kazakhstan Premier League", "Kazakhstan", "FC Kairat Almaty");
    add("Kauno Žalgiris", "A Lyga", "Lithuania", "Kauno Zalgiris", "FK Kauno Žalgiris", "FK Kauno Zalgiris");
    add("Mjällby", "Allsvenskan", "Sweden", "Mjallby", "Mjällby AIF");
    add("Olympiacos", "Super League Greece", "Greece", "Olympiacos FC");
    add("Sparta Praha", "Czech First League", "Czechia", "Sparta Prague", "AC Sparta Praha");
    add("Sturm Graz", "Austrian Bundesliga", "Austria", "SK Sturm Graz");
    add("Union Saint-Gilloise", "Belgian Pro League", "Belgium", "Union SG", "USG", "RUSG", "R. Union Saint-Gilloise", "Royale Union Saint-Gilloise", "Union St.-Gilloise", "Union St Gilloise", "Union Saint Gilloise");
    add("Egnatia", "Kategoria Superiore", "Albania", "KF Egnatia", "Egnatia Rrogozhine");
    add("Górnik Zabrze", "Ekstraklasa", "Poland", "Gornik Zabrze");
    add("Hearts", "Scottish Premiership", "Scotland", "Heart of Midlothian");
    add("Iberia Tbilisi", "Erovnuli Liga", "Georgia");
    add("Klaksvík", "Faroe Islands Premier League", "Faroe Islands", "Klaksvik", "KÍ Klaksvík");
    add("KuPS Kuopio", "Veikkausliiga", "Finland", "KuPS");
    add("Lincoln Red Imps", "Gibraltar Football League", "Gibraltar", "L. Red Imps");
    add("Larne", "NIFL Premiership", "Northern Ireland", "Larne FC");
    add("Lech Poznań", "Ekstraklasa", "Poland", "Lech Poznan");
    add("Omonia", "Cypriot First Division", "Cyprus", "Omonia Nicosia");
    add("Shamrock Rovers", "League of Ireland Premier Division", "Ireland");
    add("Thun", "Swiss Super League", "Switzerland", "FC Thun");
    add("Universitatea Craiova", "Liga I", "Romania", "U. Craiova");
    add("Víkingur Reykjavík", "Besta deild", "Iceland", "Vikingur Reykjavik", "Víkingur R.");
    add("The New Saints", "Cymru Premier", "Wales", "TNS");
    add("Inter Escaldes", "Primera Divisió", "Andorra", "Inter Club d’Escaldes");
    add("Riga", "Virslīga", "Latvia", "Riga FC");
    add("Drita", "Kosovo Superleague", "Kosovo", "FC Drita");
    add("Vardar", "Macedonian First Football League", "North Macedonia", "FK Vardar");
    add("Floriana", "Maltese Premier League", "Malta", "Floriana FC");
    add("Tre Fiori", "Campionato Sammarinese", "San Marino", "SP Tre Fiori");
    add("Borac Banja Luka", "Premier League of Bosnia and Herzegovina", "Bosnia and Herzegovina", "Borac", "FK Borac");
    add("Atert Bissen", "Luxembourg National Division", "Luxembourg", "FC Atert Bissen");
    add("Győri ETO", "Nemzeti Bajnokság I", "Hungary", "Gyori ETO", "ETO FC Győr");
    add("Sutjeska", "Montenegrin First League", "Montenegro", "FK Sutjeska");
    add("Flora Tallinn", "Meistriliiga", "Estonia", "Flora", "FC Flora");
    add("Vitebsk", "Belarusian Premier League", "Belarus", "FC Vitebsk");
    add("ML Vitebsk", "Belarusian Premier League", "Belarus", "FC ML Vitebsk", "Maxline Vitebsk", "FC Maxline Vitebsk");
    add("Petrocub", "Moldovan Super Liga", "Moldova", "Petrocub Hîncești");
  }
  private static void add(String name,String competition,String country,String... aliases){ ClubProfile p=new ClubProfile(name,competition,country); CANONICAL.put(key(name),p); ALIASES.put(key(name),key(name)); if(aliases!=null)for(String a:aliases)if(a!=null&&a.trim().length()>0)ALIASES.put(key(a),key(name)); }
  public static List<ClubProfile> all(){ return Collections.unmodifiableList(new ArrayList<ClubProfile>(CANONICAL.values())); }
  public static ClubProfile resolve(String name){
    if(name==null)return null;
    String k=key(name);
    String canonical=ALIASES.get(k);
    if(canonical!=null){ ClubProfile p=CANONICAL.get(canonical); if(p!=null)return p; }
    ClubProfile exact=CANONICAL.get(k); if(exact!=null)return exact;
    // Providers often append generic legal/team suffixes ("Arsenal FC",
    // "Hull City AFC", "Ipswich Town FC") even when the canonical Football
    // Fun identity omits them. Resolve those variants centrally so fixtures,
    // standings, crests and Club Center all use one club identity.
    String[] suffixes={"footballclub","associationfootballclub","afc","fc"};
    for(String suffix:suffixes){
      if(k.endsWith(suffix)&&k.length()>suffix.length()+2){
        String base=k.substring(0,k.length()-suffix.length());
        String alias=ALIASES.get(base);
        if(alias!=null){ ClubProfile p=CANONICAL.get(alias); if(p!=null)return p; }
        ClubProfile p=CANONICAL.get(base); if(p!=null)return p;
      }
    }
    return null;
  }
  public static String canonicalName(String name){ ClubProfile p=resolve(name); return p==null?(name==null?"":name.trim()):p.name; }
  public static String key(String value){ if(value==null)return ""; String normalized=Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.US); return normalized.replaceAll("[^a-z0-9]",""); }
  private ClubIdentityRegistry(){}
}
