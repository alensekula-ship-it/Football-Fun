package com.asappfactory.footballfun;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import org.json.*;

import com.asappfactory.footballfun.core.AppConfig;
import com.asappfactory.footballfun.data.CompetitionCatalog;
import com.asappfactory.footballfun.data.ClubCatalog;
import com.asappfactory.footballfun.data.ClubCrestCache;
import com.asappfactory.footballfun.data.LiveDataClient;
import com.asappfactory.footballfun.data.UserPreferences;
import com.asappfactory.footballfun.data.WorldCupData;
import com.asappfactory.footballfun.domain.MatchStatus;
import com.asappfactory.footballfun.model.ClubProfile;
import com.asappfactory.footballfun.model.DetailEvent;
import com.asappfactory.footballfun.model.Match;
import com.asappfactory.footballfun.model.TeamRow;
import com.asappfactory.footballfun.presentation.MatchCenterFormatter;
import com.asappfactory.footballfun.presentation.TeamLocalizer;
import com.asappfactory.footballfun.notifications.MatchReminderScheduler;

public class MainActivity extends Activity {
    static final boolean ENABLE_PLAYER_DATA_MODULES = AppConfig.ENABLE_PLAYER_DATA_MODULES;
    static final boolean ENABLE_CARDS_LINEUPS_MODULES = AppConfig.ENABLE_CARDS_LINEUPS_MODULES;
    static final String APP_VERSION = BuildConfig.VERSION_NAME;
    static final int APP_BUILD_CODE = BuildConfig.VERSION_CODE;
    static final int TOURNAMENT_TOTAL_MATCHES = AppConfig.TOURNAMENT_TOTAL_MATCHES;
    static final int REQUEST_NOTIFICATION_PERMISSION = 5240;
    final int RED=Color.rgb(255,48,94), RED_DARK=Color.rgb(139,23,77), GOLD=Color.rgb(247,199,75), GREEN=Color.rgb(35,207,145), BLUE=Color.rgb(92,118,255);
    final int PURPLE=Color.rgb(115,67,255), PURPLE_DARK=Color.rgb(53,28,108), SURFACE=Color.rgb(18,21,31);
    int bg, cardBg, text, subText, navBg, chipBg, stroke;
    LinearLayout root, content, bottom;
    TextView title, subtitle;
    SharedPreferences prefs;
    UserPreferences userPreferences;
    WorldCupData data;
    final LiveDataClient liveDataClient=new LiveDataClient();
    ClubCrestCache clubCrestCache;
    volatile Map<String,String> clubCrestUrls=Collections.emptyMap();
    volatile List<ClubProfile> clubProfilesCache=null;
    volatile Map<String,ClubProfile> clubProfileIndex=Collections.emptyMap();
    volatile JSONObject onlineRootCache=null;
    volatile String onlineRootCacheRaw="";
    Handler handler=new Handler();
    boolean darkMode;
    String lang="EN", currentScreen="Home", myTeam="Croatia", favoriteClub="Dinamo Zagreb", profileName="Football Fan", profileCountry="Croatia", matchFilter="", groupFilter="All", matchStatusFilter="All", competitionFilter="All", matchDateFilter="TODAY";
    boolean matchFavoritesOnly=false;
    String favoriteClubSearch="", favoriteClubCompetitionFilter="ALL";
    int favoriteClubPickerLimit=30;
    Set<String> followedCompetitions=new LinkedHashSet<String>();
    Set<String> favoriteClubs=new LinkedHashSet<String>();
    boolean favoriteNotifications=true;
    int matchReminderMinutes=60;
    boolean competitionReminders=false;
    TextView onlineStatusView;
    TextView onlineLastUpdateView;
    String onlineStatus="🟢 Ready for live data";
    boolean onlineRefreshInProgress=false;
    Runnable autoOnlineRefreshRunnable;
    Runnable liveMatchDetailsRefreshRunnable;
    String openMatchHome="", openMatchAway="", openMatchDate="";
    int openMatchApiId=-1;

    public void onCreate(Bundle b){
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        userPreferences=new UserPreferences(this);
        clubCrestCache=new ClubCrestCache(this);
        prefs=userPreferences.raw();
        darkMode=userPreferences.darkMode();
        lang=userPreferences.language();
        myTeam=userPreferences.nationalTeam();
        favoriteClub=userPreferences.favoriteClub();
        profileName=userPreferences.profileName();
        profileCountry=userPreferences.profileCountry();
        favoriteClubs=userPreferences.favoriteClubs(favoriteClub);
        followedCompetitions=userPreferences.followedCompetitions();
        favoriteNotifications=userPreferences.favoriteNotifications();
        matchReminderMinutes=userPreferences.matchReminderMinutes();
        competitionReminders=userPreferences.competitionReminders();
        data=new WorldCupData(this,new WorldCupData.MatchRules(){
            public boolean isFinished(Match match){ return matchIsFinished(match); }
            public Match nextForTeam(String team){ return nextMatchForTeam(team); }
        });
        restoreCachedOnlineData();
        applyTheme();
        build();
        showHome();
        syncMatchReminders();
        handleNotificationIntent(getIntent());
        refreshOnlineSafe(false);
        startAutoOnlineRefresh();
    }

    @Override
    protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotificationIntent(intent);
    }

    void handleNotificationIntent(Intent intent){
        if(intent==null)return;
        if(intent.getBooleanExtra("open_match_reminder",false)){
            String home=intent.getStringExtra("reminder_home");
            String away=intent.getStringExtra("reminder_away");
            long kickoff=intent.getLongExtra("reminder_kickoff",0L);
            intent.removeExtra("open_match_reminder");
            intent.removeExtra("reminder_home");
            intent.removeExtra("reminder_away");
            intent.removeExtra("reminder_kickoff");
            Match match=findReminderMatch(home,away,kickoff);
            if(match!=null){showMatchDetails(match);return;}
            showNotificationCenter();
            return;
        }
        if(!intent.getBooleanExtra("open_notifications",false))return;
        intent.removeExtra("open_notifications");
        showNotificationCenter();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode!=REQUEST_NOTIFICATION_PERMISSION)return;
        if(notificationPermissionGranted()){
            syncMatchReminders();
            toast(t2("Notifications enabled","Obavijesti su uključene","Benachrichtigungen aktiviert","Notificaciones activadas","Notifications activées"));
        }else{
            toast(t2("Notification permission was not granted","Dozvola za obavijesti nije odobrena","Benachrichtigungsberechtigung wurde nicht erteilt","No se concedió el permiso de notificaciones","L’autorisation de notification n’a pas été accordée"));
        }
        if(currentScreen.equals("Notifications"))showNotificationCenter();
    }

    public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) hideSystemBars();
    }

    @Override
    protected void onDestroy(){
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            if(liveMatchDetailsRefreshRunnable!=null) handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        super.onDestroy();
    }

    void startAutoOnlineRefresh(){
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            autoOnlineRefreshRunnable=new Runnable(){ public void run(){
                try{
                    refreshOnlineSafe(false);
                    handler.postDelayed(this, AppConfig.AUTO_REFRESH_MS);
                }catch(Exception ignored){
                    handler.postDelayed(this, AppConfig.AUTO_REFRESH_MS);
                }
            }};
            handler.postDelayed(autoOnlineRefreshRunnable, AppConfig.AUTO_REFRESH_MS);
        }catch(Exception ignored){}
    }

    void hideSystemBars(){
        try{
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN|
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }catch(Exception e){}
    }

    void applyTheme(){
        bg=darkMode?Color.rgb(7,9,15):Color.rgb(246,247,250);
        cardBg=darkMode?Color.rgb(18,22,33):Color.WHITE;
        text=darkMode?Color.rgb(248,249,252):Color.rgb(20,24,32);
        subText=darkMode?Color.rgb(160,169,187):Color.rgb(92,99,112);
        navBg=darkMode?Color.rgb(11,13,21):Color.WHITE;
        chipBg=darkMode?Color.rgb(28,33,46):Color.rgb(238,241,246);
        stroke=darkMode?Color.rgb(43,50,68):Color.rgb(220,225,233);
    }

    String tr(String key){
        String en=key, hr=key, de=key, es=key, fr=key;
        if(key.equals("Home")){hr="Početna";de="Start";es="Inicio";fr="Accueil";}
        else if(key.equals("Matches")){hr="Utakmice";de="Spiele";es="Partidos";fr="Matchs";}
        else if(key.equals("Groups")){hr="Skupine";de="Gruppen";es="Grupos";fr="Groupes";}
        else if(key.equals("Predict")){hr="Prognoza";de="Tipp";es="Predicción";fr="Prono";}
        else if(key.equals("More")){hr="Više";de="Mehr";es="Más";fr="Plus";}
        else if(key.equals("Leagues")){hr="Natjecanja";de="Wettbewerbe";es="Competiciones";fr="Compétitions";}
        else if(key.equals("Favorites")){hr="Favoriti";de="Favoriten";es="Favoritos";fr="Favoris";}
        else if(key.equals("My Team")){hr="Moja reprezentacija";de="Mein Team";es="Mi equipo";fr="Mon équipe";}
        else if(key.equals("Start Simulator")){hr="Pokreni simulator";de="Simulator starten";es="Iniciar simulador";fr="Démarrer";}
        else if(key.equals("Team Hub")){hr="Centar reprezentacije";de="Team-Zentrale";es="Centro equipo";fr="Hub équipe";}
        else if(key.equals("Share Poster")){hr="Podijeli poster";de="Poster teilen";es="Compartir póster";fr="Partager poster";}
        else if(key.equals("Smart Match Center")){hr="Pametni centar utakmica";de="Match-Zentrale";es="Centro de partidos";fr="Centre matchs";}
        else if(key.equals("Search team, group or host city")){hr="Traži reprezentaciju, skupinu ili grad";de="Team, Gruppe oder Stadt suchen";es="Buscar equipo, grupo o ciudad";fr="Chercher équipe, groupe ou ville";}
        else if(key.equals("Apply Search")){hr="Primijeni pretragu";de="Suchen";es="Buscar";fr="Rechercher";}
        else if(key.equals("Save Result")){hr="Spremi rezultat";de="Ergebnis speichern";es="Guardar resultado";fr="Enregistrer";}
        else if(key.equals("Prediction Studio")){hr="Studio prognoze";de="Prognose-Studio";es="Estudio de predicción";fr="Studio prédiction";}
        else if(key.equals("Enter Scores")){hr="Upiši rezultate";de="Ergebnisse eingeben";es="Introducir marcadores";fr="Saisir scores";}
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Dream Final")){hr="Finale snova";de="Traumfinale";es="Final soñado";fr="Finale rêvée";}
        else if(key.equals("Reset Scores")){hr="Resetiraj rezultate";de="Zurücksetzen";es="Reiniciar";fr="Réinitialiser";}
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Austragungsorte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Statistics")){hr="Statistika";de="Statistiken";es="Estadísticas";fr="Statistiques";}
        else if(key.equals("Premium")){hr="Premium";de="Premium";es="Premium";fr="Premium";}
        else if(key.equals("Switch to Light Mode")){hr="Prebaci na svijetli način";de="Hellmodus";es="Modo claro";fr="Mode clair";}
        else if(key.equals("Switch to Dark Mode")){hr="Prebaci na tamni način";de="Dunkelmodus";es="Modo oscuro";fr="Mode sombre";}
        else if(key.equals("Language")){hr="Jezik";de="Sprache";es="Idioma";fr="Langue";}
        else if(key.equals(myTeam + " Road to Final")){hr="Hrvatska put do finala";de="Kroatien Weg ins Finale";es="Croacia camino a la final";fr="Croatie route finale";}
        else if(key.equals("Free vs Pro")){hr="Besplatno vs Pro";de="Gratis vs Pro";es="Gratis vs Pro";fr="Gratuit vs Pro";}
        else if(key.equals("Open")){hr="Otvori";de="Öffnen";es="Abrir";fr="Ouvrir";}
        
        else if(key.equals("Visual Bracket")){hr="Vizualni kostur";de="Turnierbaum";es="Cuadro visual";fr="Tableau visuel";}
        else if(key.equals("Golden Boot")){hr="Zlatna kopačka";de="Goldener Schuh";es="Bota de Oro";fr="Soulier d'Or";}
        else if(key.equals("MVP Prediction")){hr="MVP prognoza";de="MVP Prognose";es="Predicción MVP";fr="Prédiction MVP";}
        else if(key.equals("Compare Teams")){hr="Usporedi timove";de="Teams vergleichen";es="Comparar equipos";fr="Comparer équipes";}
        else if(key.equals("Export Backup")){hr="Izvoz kopije";de="Backup exportieren";es="Exportar copia";fr="Exporter sauvegarde";}
        else if(key.equals("PDF Poster Info")){hr="PDF poster info";de="PDF Poster Info";es="Info póster PDF";fr="Info poster PDF";}
        else if(key.equals("World Cup Quiz")){hr="SP kviz";de="WM Quiz";es="Quiz Mundial";fr="Quiz Coupe du Monde";}
        else if(key.equals("Stadium Guide")){hr="Vodič stadiona";de="Stadionführer";es="Guía de estadios";fr="Guide des stades";}
        else if(key.equals("City Guide Pro")){hr="Vodič gradova Pro";de="Städteführer Pro";es="Guía de ciudades Pro";fr="Guide des villes Pro";}
        else if(key.equals("Achievements")){hr="Postignuća";de="Erfolge";es="Logros";fr="Succès";}
        else if(key.equals("Tournament tree preview")){hr="Pregled turnirskog stabla";de="Vorschau Turnierbaum";es="Vista del cuadro";fr="Aperçu du tableau";}
        else if(key.equals("Golden Boot simulation")){hr="Simulacija zlatne kopačke";de="Goldener Schuh Simulation";es="Simulación Bota de Oro";fr="Simulation Soulier d'Or";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Team vs Team")){hr="Tim protiv tima";de="Team gegen Team";es="Equipo contra equipo";fr="Équipe contre équipe";}
        else if(key.equals("Export / Import prediction")){hr="Izvoz / uvoz prognoze";de="Prognose export/import";es="Exportar / importar predicción";fr="Exporter / importer pronostic";}
        else if(key.equals("Printable prediction poster")){hr="Poster prognoze za print";de="Druckbares Prognoseposter";es="Póster imprimible";fr="Poster imprimable";}
        else if(key.equals("Fan challenge")){hr="Navijački izazov";de="Fan Herausforderung";es="Reto de fans";fr="Défi des fans";}
        else if(key.equals("Host stadium notes")){hr="Bilješke o stadionima";de="Stadion Notizen";es="Notas de estadios";fr="Notes stades";}
        else if(key.equals("Fan travel notes")){hr="Navijačke putne bilješke";de="Fan Reisehinweise";es="Notas de viaje";fr="Notes voyage fans";}
        else if(key.equals("Badges and milestones")){hr="Značke i postignuća";de="Abzeichen und Meilensteine";es="Insignias e hitos";fr="Badges et étapes";}
        else if(key.equals("Launch readiness checklist")){hr="Popis spremnosti za objavu";de="Checkliste Veröffentlichung";es="Lista de lanzamiento";fr="Liste de lancement";}
        else if(key.equals("Privacy")){hr="Privatnost";de="Datenschutz";es="Privacidad";fr="Confidentialité";}
        else if(key.equals("Legal safety")){hr="Pravna sigurnost";de="Rechtliche Sicherheit";es="Seguridad legal";fr="Sécurité juridique";}

        
        else if(key.equals("Host Cities Pro")){hr="Gradovi domaćini Pro";de="Gastgeberstädte Pro";es="Ciudades sede Pro";fr="Villes hôtes Pro";}
        else if(key.equals("Team Hub Pro")){hr="Centar reprezentacije Pro";de="Team-Zentrale Pro";es="Centro equipo Pro";fr="Hub équipe Pro";}
        else if(key.equals("Onboarding Preview")){hr="Uvodni ekran";de="Einführung";es="Introducción";fr="Introduction";}
        else if(key.equals("Poster Export Plan")){hr="Plan izvoza postera";de="Poster-Export Plan";es="Plan exportar póster";fr="Plan export poster";}
        else if(key.equals("Tournament Rules")){hr="Pravila turnira";de="Turnierregeln";es="Reglas torneo";fr="Règles tournoi";}
        else if(key.equals("Monetization Plan")){hr="Plan zarade";de="Monetarisierung";es="Monetización";fr="Monétisation";}

        
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Players")){hr="Igrači";de="Spieler";es="Jugadores";fr="Joueurs";}
        else if(key.equals("Top scorers prediction")){hr="Prognoza najboljih strijelaca";de="Torschützen-Prognose";es="Predicción de goleadores";fr="Pronostic buteurs";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Star watch")){hr="Zvijezde turnira";de="Stars im Blick";es="Estrellas a seguir";fr="Stars à suivre";}
        else if(key.equals("Shortlist")){hr="🏆 MVP Power Ranking";de="Auswahlliste";es="Lista corta";fr="Liste courte";}
        else if(key.equals("goals")){hr="golova";de="Tore";es="goles";fr="buts";}
        else if(key.equals("Privacy / Legal")){hr="Privatnost / Pravno";de="Datenschutz / Rechtliches";es="Privacidad / Legal";fr="Confidentialité / Légal";}

        
        else if(key.equals("About App")){hr="O aplikaciji";de="Über die App";es="Acerca de la app";fr="À propos";}
        else if(key.equals("Privacy Policy")){hr="Pravila privatnosti";de="Datenschutzerklärung";es="Política de privacidad";fr="Politique de confidentialité";}
        else if(key.equals("App version")){hr="Verzija aplikacije";de="App-Version";es="Versión de la app";fr="Version de l'app";}
        else if(key.equals("Independent fan-made app")){hr="Nezavisna navijačka aplikacija";de="Unabhängige Fan-App";es="Aplicación independiente de fans";fr="Application indépendante de fans";}
        else if(key.equals("No login. No account. No personal profile.")){hr="Bez prijave. Bez računa. Bez osobnog profila.";de="Kein Login. Kein Konto. Kein persönliches Profil.";es="Sin inicio de sesión. Sin cuenta. Sin perfil personal.";fr="Pas de connexion. Pas de compte. Pas de profil personnel.";}
        else if(key.equals("Data is stored only on this device.")){hr="Podaci se spremaju samo na ovom uređaju.";de="Daten werden nur auf diesem Gerät gespeichert.";es="Los datos se guardan solo en este dispositivo.";fr="Les données sont stockées uniquement sur cet appareil.";}
        else if(key.equals("Scores, language, theme and selected team are saved locally.")){hr="Prognoze, jezik, tema i odabrana reprezentacija spremaju se lokalno na uređaju.";de="Prognosen, Sprache, Design und ausgewähltes Team werden lokal auf dem Gerät gespeichert.";es="Predicciones, idioma, tema y equipo elegido se guardan localmente en el dispositivo.";fr="Pronostics, langue, thème et équipe choisie sont enregistrés localement sur l’appareil.";}
        else if(key.equals("This app is not affiliated with FIFA.")){en="This app is not affiliated with, endorsed by, or sponsored by FIFA.";hr="Ova aplikacija nije povezana, odobrena niti sponzorirana od strane FIFA-e.";de="Diese App ist nicht mit FIFA verbunden, von FIFA genehmigt oder gesponsert.";es="Esta aplicación no está afiliada, aprobada ni patrocinada por la FIFA.";fr="Cette application n'est pas affiliée, approuvée ni sponsorisée par la FIFA.";}
        else if(key.equals("Independent fan app subtitle")){en="Independent app for following the 2026 World Cup.";hr="Neovisna aplikacija za praćenje Svjetskog prvenstva 2026.";de="Unabhängige App zur Verfolgung der Weltmeisterschaft 2026.";es="Aplicación independiente para seguir la Copa Mundial 2026.";fr="Application indépendante pour suivre la Coupe du Monde 2026.";}
        else if(key.equals("About feature line")){en="Live data • Groups • Predictions • Knockout stage • My Team • Share Poster";hr="Live podaci • Skupine • Prognoze • Nokaut faza • Moja reprezentacija • Poster za dijeljenje";de="Live-Daten • Gruppen • Prognosen • K.-o.-Runde • Mein Team • Poster teilen";es="Datos en vivo • Grupos • Predicciones • Eliminatorias • Mi equipo • Póster para compartir";fr="Données en direct • Groupes • Pronostics • Phase finale • Mon équipe • Poster à partager";}
        else if(key.equals("Legal")){hr="Pravno";de="Rechtliches";es="Legal";fr="Mentions légales";}
        else if(key.equals("Legal notice detail")){en="This independent fan app uses licensed or publicly supplied team identity data where available. It does not include official FIFA branding, player photos or live streaming.";hr="Ova neovisna navijačka aplikacija koristi licencirane ili javno dostupne podatke o identitetu klubova gdje su dostupni. Ne sadrži službeni FIFA brending, fotografije igrača ni prijenos uživo.";de="Diese App verwendet unabhängige Datenquellen und enthält keine offiziellen FIFA-Logos, keine offiziellen Teamwappen, keine Spielerfotos und kein Live-Streaming.";es="La aplicación utiliza fuentes de datos independientes y no incluye logotipos oficiales de FIFA, escudos oficiales de selecciones, fotos de jugadores ni transmisión en vivo.";fr="L'application utilise des sources de données indépendantes et ne contient aucun logo officiel de la FIFA, aucun écusson officiel d'équipe, aucune photo de joueur et aucun streaming en direct.";}
        else if(key.equals("Privacy info text")){en="World Cup Fan 2026 stores your selected team, language, theme and personal predictions on this device. Online results are loaded only to display match data inside the app. There is no login, user account or personal profile.";hr="World Cup Fan 2026 sprema odabranu reprezentaciju, jezik, temu i korisničke prognoze na ovom uređaju. Online rezultati se dohvaćaju samo za prikaz podataka u aplikaciji. Nema prijave, korisničkog računa ni osobnog profila.";de="World Cup Fan 2026 speichert das ausgewählte Team, die Sprache, das Design und deine Prognosen auf diesem Gerät. Online-Ergebnisse werden nur zur Anzeige in der App geladen. Keine Anmeldung, kein Konto und kein persönliches Profil.";es="World Cup Fan 2026 guarda el equipo elegido, el idioma, el tema y tus predicciones en este dispositivo. Los resultados en línea se cargan solo para mostrarlos en la aplicación. Sin inicio de sesión, sin cuenta y sin perfil personal.";fr="World Cup Fan 2026 enregistre l'équipe choisie, la langue, le thème et tes pronostics sur cet appareil. Les résultats en ligne sont chargés uniquement pour l'affichage dans l'application. Pas de connexion, pas de compte et pas de profil personnel.";}
        else if(key.equals("Legal safety text")){en="Independent fan app. Team identity data may be supplied by data providers. No official FIFA branding, player photos, live streaming, betting or gambling.";hr="Neovisna navijačka aplikacija. Podatke o identitetu klubova mogu isporučiti izvori podataka. Nema službeni FIFA brending, fotografije igrača, prijenos uživo, klađenje ni igre na sreću.";de="Unabhängige Fan-App. Keine offiziellen FIFA-Logos, keine offiziellen Wappen, keine Spielerfotos, kein Live-Streaming, keine Wetten und kein Glücksspiel.";es="Aplicación independiente de fans. Sin logotipos oficiales de FIFA, escudos oficiales, fotos de jugadores, transmisión en vivo, apuestas ni juegos de azar.";fr="Application indépendante de fans. Aucun logo officiel de la FIFA, aucun écusson officiel, aucune photo de joueur, aucun streaming en direct, aucun pari ni jeu d'argent.";}
        else if(key.equals("No betting streaming media")){hr="Aplikacija ne nudi klađenje, prijenos uživo ni službeni turnirski medijski sadržaj.";de="Die App bietet keine Wetten, kein Live-Streaming und keine offiziellen Turniermedien.";es="La aplicación no ofrece apuestas, transmisión en vivo ni contenido multimedia oficial del torneo.";fr="L'application ne propose aucun pari, aucun streaming en direct et aucun contenu média officiel du tournoi.";}

        
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Round of 32")){hr="Šesnaestina finala";de="Runde der 32";es="Dieciseisavos";fr="Seizièmes de finale";}
        else if(key.equals("Round of 16")){hr="Osmina finala";de="Achtelfinale";es="Octavos de final";fr="Huitièmes de finale";}
        else if(key.equals("Quarter-finals")){hr="Četvrtfinale";de="Viertelfinale";es="Cuartos de final";fr="Quarts de finale";}
        else if(key.equals("Semi-finals")){hr="Polufinale";de="Halbfinale";es="Semifinales";fr="Demi-finales";}
        else if(key.equals("Final")){hr="Finale";de="Finale";es="Final";fr="Finale";}
        else if(key.equals("Projected path from your group results.")){hr="Kostur prema upisanim rezultatima skupina.";de="Turnierweg nach deinen Gruppenergebnissen.";es="Camino según tus resultados de grupo.";fr="Parcours selon tes résultats de groupe.";}
        
        else if(key.equals("Tournament is live")){hr="Prvenstvo je u tijeku";de="Das Turnier läuft";es="El torneo está en marcha";fr="Le tournoi est en cours";}
        else if(key.equals("Day 1 of the World Cup")){hr="Dan 1 Svjetskog prvenstva";de="Tag 1 der Weltmeisterschaft";es="Día 1 del Mundial";fr="Jour 1 de la Coupe du Monde";}
        else if(key.equals("Global Edition")){hr="Globalno izdanje";de="Globale Ausgabe";es="Edición global";fr="Édition mondiale";}
        else if(key.equals("Progress")){hr="Napredak";de="Fortschritt";es="Progreso";fr="Progression";}
        else if(key.equals("Played")){hr="Odigrano";de="Gespielt";es="Jugados";fr="Joués";}
        else if(key.equals("Goals")){hr="Golovi";de="Tore";es="Goles";fr="Buts";}
        else if(key.equals("Road to Final")){hr="Put do finala";de="Weg ins Finale";es="Camino a la final";fr="Route vers la finale";}
        else if(key.equals("Scores to tables")){hr="Upiši rezultate, provjeri skupine i podijeli poster.";de="Tippe Ergebnisse ein, prüfe Gruppen und teile dein Poster.";es="Introduce resultados, revisa grupos y comparte tu póster.";fr="Entre les scores, vérifie les groupes et partage ton poster.";}
        else if(key.equals("Winner")){hr="Pobjednik";de="Sieger";es="Ganador";fr="Vainqueur";}
        else if(key.equals("Not selected")){hr="nije odabran";de="nicht gewählt";es="no seleccionado";fr="non choisi";}
        else if(key.equals("Question")){hr="Pitanje";de="Frage";es="Pregunta";fr="Question";}
        else if(key.equals("Score")){hr="Bodovi";de="Punkte";es="Puntuación";fr="Score";}
        else if(key.equals("Correct")){hr="Točno";de="Richtig";es="Correcto";fr="Correct";}
        else if(key.equals("Wrong")){hr="Netočno";de="Falsch";es="Incorrecto";fr="Incorrect";}
        else if(key.equals("Try again")){hr="Pokušaj ponovno";de="Erneut versuchen";es="Intentar de nuevo";fr="Réessayer";}

        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("16 host cities")){hr="16 gradova domaćina";de="16 Gastgeberstädte";es="16 ciudades sede";fr="16 villes hôtes";}
        else if(key.equals("Country")){hr="Država";de="Land";es="País";fr="Pays";}
        else if(key.equals("Capacity")){hr="Kapacitet";de="Kapazität";es="Capacidad";fr="Capacité";}
        else if(key.equals("Matches count")){hr="Broj utakmica";de="Anzahl Spiele";es="Número de partidos";fr="Nombre de matchs";}

        if(lang.equals("HR")) return hr; if(lang.equals("DE")) return de; if(lang.equals("ES")) return es; if(lang.equals("FR")) return fr; return en;
    }

    void build(){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        setContentView(root);
        hideSystemBars();

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(18),dp(8),dp(18),dp(6));
        header.setBackground(gradient(Color.rgb(20,22,38),PURPLE_DARK,0));
        header.setElevation(dp(6));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(82)));
        title=label("Football Fun",24,Color.WHITE,true);
        title.setLetterSpacing(0.01f);
        title.setGravity(Gravity.CENTER);
        subtitle=label("",12,Color.rgb(210,216,230),false);
        subtitle.setGravity(Gravity.CENTER);
        header.addView(title);
        header.addView(subtitle);

        ScrollView sv=new ScrollView(this);
        sv.setFillViewport(true);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(12),dp(12),dp(132));
        sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(dp(7),dp(6),dp(7),dp(6));
        bottom.setBackgroundColor(navBg);
        bottom.setElevation(dp(14));
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(72)));
        nav("🏠","Home"); nav("⚽","Matches"); nav("🏆","Leagues"); nav("⭐","Favorites"); nav("☰","More");
    }

    void nav(String icon,String name){
        boolean selected=currentScreen.equals(name)||(currentScreen.equals("MatchDetails")&&name.equals("Matches"))||(currentScreen.equals("DailyBrief")&&name.equals("Home"))||(currentScreen.equals("Notifications")&&name.equals("More"))||(currentScreen.equals("Predict")&&name.equals("Predict"));
        TextView b=label(icon+"\n"+tr(name),selected?12:11,selected?Color.WHITE:subText,true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(selected?gradient(PURPLE_DARK,RED,dp(20)):round(Color.TRANSPARENT,dp(20),0));
        if(selected){ b.setElevation(dp(4)); b.setScaleX(1.04f); b.setScaleY(1.04f); }
        b.setOnClickListener(v->{ if(name.equals("Home"))showHome(); else if(name.equals("Matches"))showMatches(); else if(name.equals("Leagues"))showLeagues(); else if(name.equals("Favorites"))showFavorites(); else showMore(); });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.setMargins(dp(3),0,dp(3),0);
        bottom.addView(b,lp);
    }

    void redraw(){
        applyTheme();
        build();
        if(currentScreen.equals("Home"))showHome();
        else if(currentScreen.equals("Matches"))showMatches();
        else if(currentScreen.equals("MatchDetails")){
            Match open=findOpenMatchDetails();
            if(open!=null)showMatchDetails(open); else showMatches();
        }
        else if(currentScreen.equals("Leagues"))showLeagues();
        else if(currentScreen.equals("Favorites"))showFavorites();
        else if(currentScreen.equals("DailyBrief"))showDailyBrief();
        else if(currentScreen.equals("Notifications"))showNotificationCenter();
        else showMore();
    }

    TextView label(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(dp(1),1.10f);t.setLetterSpacing(sp>=20?0.01f:0f);t.setPadding(dp(3),dp(5),dp(3),dp(5));if(bold)t.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(18),dp(11),dp(18),dp(11));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(gradient(PURPLE_DARK,RED,dp(18)));b.setElevation(dp(4));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.98f).scaleY(.98f).setDuration(80).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();}return false;});return b;}
    Button outline(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(text);b.setAllCaps(false);b.setMinHeight(dp(48));b.setPadding(dp(15),dp(10),dp(15),dp(10));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(round(chipBg,dp(18),1));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().alpha(.78f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().alpha(1f).setDuration(90).start();}return false;});return b;}
    TextView chip(String s){TextView t=label(s,13,text,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(13),dp(10),dp(13),dp(10));t.setBackground(round(chipBg,dp(18),1));return t;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(19),dp(18),dp(19),dp(18));l.setBackground(round(cardBg,dp(22),1));l.setElevation(dp(3));l.setClipToOutline(true);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(16));content.addView(l,lp);return l;}
    LinearLayout hrow(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    void clear(String h,String s,String key){
        if(!"MatchDetails".equals(key)) stopLiveMatchDetailsRefresh();
        currentScreen=key;
        title.setText(h);
        boolean hasSubtitle=s!=null && s.trim().length()>0;
        subtitle.setText(hasSubtitle?s:"");
        subtitle.setVisibility(hasSubtitle?View.VISIBLE:View.GONE);
        content.removeAllViews();
        content.setAlpha(0f);
        content.setTranslationY(dp(6));
        content.animate().alpha(1f).translationY(0f).setDuration(160).start();
        hideSystemBars();
    }

    String t2(String en,String hr,String de,String es,String fr){if(lang.equals("HR"))return hr;if(lang.equals("DE"))return de;if(lang.equals("ES"))return es;if(lang.equals("FR"))return fr;return en;}
    String lastUpdateLabel(String last){
        if(last!=null && last.trim().length()>0){
            String local=displayLocalDateTime(last);
            return t2("🕒 Last update: "+local,"🕒 Zadnje ažuriranje: "+local,"🕒 Letzte Aktualisierung: "+local,"🕒 Última actualización: "+local,"🕒 Dernière mise à jour : "+local);
        }
        return t2("🕒 Last update: not yet refreshed","🕒 Još nije ažurirano","🕒 Noch nicht aktualisiert","🕒 Aún no actualizado","🕒 Pas encore actualisé");
    }


    String displayTeamName(String team){
        return TeamLocalizer.displayName(team,lang);
    }

    TextView sectionHeading(String value){
        TextView h=label(value,19,text,true);
        h.setPadding(dp(5),dp(7),dp(5),dp(11));
        content.addView(h);
        return h;
    }

    LinearLayout homeStat(String value,String caption,View.OnClickListener listener){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5),dp(9),dp(5),dp(9));
        box.setBackground(round(chipBg,dp(18),1));
        TextView v=centerLabel(value,21,value.equals("0")?subText:RED,true);
        TextView c=centerLabel(caption,11,subText,true);
        box.addView(v); box.addView(c);
        if(listener!=null){box.setClickable(true);box.setOnClickListener(listener);}
        return box;
    }

    String friendlyCompetitionName(Match m){
        if(m==null)return "";
        String[] all={"HNL","UEFA Champions League","Premier League","Championship","La Liga","Bundesliga","Serie A","Ligue 1","Eredivisie","Primeira Liga","Brasileirão Série A","World Cup 2026","UEFA European Championship"};
        for(String c:all)if(matchBelongsToCompetition(m,c))return c;
        if(m.competition!=null && m.competition.trim().length()>0)return m.competition.trim();
        return t2("Football","Nogomet","Fußball","Fútbol","Football");
    }

    String competitionIcon(String competition){
        if(competition.equals("HNL"))return "🇭🇷";
        if(competition.equals("Premier League")||competition.equals("Championship"))return "🏴";
        if(competition.equals("La Liga"))return "🇪🇸";
        if(competition.equals("Bundesliga"))return "🇩🇪";
        if(competition.equals("Serie A"))return "🇮🇹";
        if(competition.equals("Ligue 1"))return "🇫🇷";
        if(competition.equals("Eredivisie"))return "🇳🇱";
        if(competition.equals("Primeira Liga"))return "🇵🇹";
        if(competition.equals("Brasileirão Série A"))return "🇧🇷";
        if(competition.equals("World Cup 2026"))return "🌍";
        if(competition.equals("UEFA European Championship"))return "🇪🇺";
        return "🏆";
    }

    boolean hnlDataConnected(){
        JSONObject root=cachedOnlineRoot();
        if(root!=null){
            JSONObject sources=root.optJSONObject("sources");
            JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
            if(hnl!=null&&hnl.optString("status","").equalsIgnoreCase("connected"))return true;
            JSONObject standings=root.optJSONObject("standings");
            if(standings!=null&&standings.optJSONObject("HNL")!=null)return true;
        }
        if(data!=null)for(Match match:data.matches)if(matchBelongsToCompetition(match,"HNL"))return true;
        return false;
    }

    String hnlSourceStatus(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return "";
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        return hnl==null?"":hnl.optString("status","");
    }

    int hnlOfficialMatchCount(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return 0;
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        int sourceCount=hnl==null?0:hnl.optInt("matchCount",0);
        if(sourceCount>0)return sourceCount;
        int count=0;
        JSONArray matches=root.optJSONArray("matches");
        if(matches!=null)for(int i=0;i<matches.length();i++){
            JSONObject match=matches.optJSONObject(i);if(match==null)continue;
            JSONObject competition=match.optJSONObject("competition");
            String code=competition==null?"":competition.optString("code",competition.optString("name",""));
            if("HNL".equalsIgnoreCase(code))count++;
        }
        return count;
    }

    String hnlLastSuccessfulUpdate(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return "";
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        return hnl==null?"":hnl.optString("lastSuccessfulUpdate","");
    }

    boolean competitionHasConnectedSource(String competition){
        return !"HNL".equals(competition)||hnlDataConnected();
    }

    int competitionStatusColor(String competition){
        return competitionHasConnectedSource(competition)?GREEN:Color.rgb(244,184,64);
    }

    String competitionDataStatus(String competition){
        if("HNL".equals(competition)){
            if(hnlDataConnected()){
                int count=hnlOfficialMatchCount();
                String state=hnlSourceStatus();
                if("degraded".equalsIgnoreCase(state))return t2("Official HNL data available from verified cache","Službeni HNL podaci dostupni iz provjerene kopije","Offizielle HNL-Daten aus geprüftem Cache","Datos HNL desde copia verificada","Données HNL depuis une copie vérifiée");
                return count>0
                        ?t2("Official HNL schedule connected • "+count+" matches","Službeni HNL raspored povezan • "+count+" utakmica","Offizieller HNL-Spielplan verbunden • "+count+" Spiele","Calendario HNL conectado • "+count+" partidos","Calendrier HNL connecté • "+count+" matchs")
                        :t2("Official HNL data connected","Službeni HNL podaci povezani","Offizielle HNL-Daten verbunden","Datos oficiales de HNL conectados","Données officielles HNL connectées");
            }
            return t2("Waiting for official HNL data","Čekanje službenih HNL podataka","Warten auf offizielle HNL-Daten","Esperando datos oficiales de HNL","En attente des données officielles HNL");
        }
        return t2("Live data available","Podaci uživo dostupni","Live-Daten verfügbar","Datos en vivo disponibles","Données en direct disponibles");
    }

    void addClubChoiceRow(LinearLayout parent,String left,String right){
        LinearLayout row=hrow();
        String[] clubs={left,right};
        for(String club:clubs){
            if(club==null||club.length()==0)continue;
            final String cn=club;
            boolean selected=favoriteClubs.contains(cn);
            Button b=selected?btn("✓ "+cn):outline("＋ "+cn);
            b.setTextSize(12);
            b.setOnClickListener(v->{
                if(favoriteClubs.contains(cn)){if(favoriteClubs.size()>1)favoriteClubs.remove(cn);}else favoriteClubs.add(cn);
                favoriteClub=favoriteClubs.iterator().next();
                userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
                syncMatchReminders();
                showFavorites();
            });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));
            row.addView(b,lp);
        }
        parent.addView(row);
    }

void showHome(){
        clear("Football Fun","","Home");

        String club=primaryFavoriteClub();
        String league=clubLeague(club);
        String country=clubCountry(club);
        String countryFlag=clubCountryFlag(club);

        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(17),dp(15),dp(17),dp(16));
        hero.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(224,18,75),dp(24)));
        hero.setElevation(dp(8));
        LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,-2);heroLp.setMargins(0,0,0,dp(14));content.addView(hero,heroLp);

        LinearLayout top=hrow();
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label(t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),12,Color.rgb(231,218,228),true));
        TextView clubName=label(twoLineClubName(club),29,Color.WHITE,true);clubName.setMaxLines(2);clubName.setLineSpacing(0,.95f);copy.addView(clubName);
        copy.addView(label(countryFlag+" "+country+"  •  "+league,14,Color.WHITE,true));
        top.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        View crest=homeTeamVisual(club,dp(116),true);crest.setElevation(dp(6));top.addView(crest,new LinearLayout.LayoutParams(dp(116),dp(116)));
        hero.addView(top);

        if(hasCompletedMatchForTeam(club)){
            LinearLayout form=hrow();
            form.addView(label(t2("FORM","FORMA","FORM","FORMA","FORME"),12,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
            for(String letter:recentForm(club,5)){
                int color=letter.equals("W")?Color.rgb(18,190,83):letter.equals("L")?Color.rgb(238,41,75):letter.equals("D")?Color.rgb(80,88,105):Color.rgb(55,60,74);
                TextView f=centerLabel(letter,12,Color.WHITE,true);f.setBackground(round(color,dp(18),0));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(34),dp(34));lp.setMargins(dp(4),dp(5),0,dp(7));form.addView(f,lp);
            }
            hero.addView(form);
        }else if(!dataContainsTeam(club)){
            TextView pending=label("● "+competitionDataStatus(league),13,Color.rgb(255,214,115),true);
            pending.setPadding(dp(12),dp(8),dp(12),dp(8));pending.setBackground(round(Color.argb(50,255,255,255),dp(16),0));
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,-2);pp.setMargins(0,dp(7),0,dp(9));hero.addView(pending,pp);
        }

        Match next=nextMatchForTeam(club);
        String nextOwner=club;
        if(next==null){next=nextMatchForTeam(myTeam);nextOwner=myTeam;}
        LinearLayout nextPanel=new LinearLayout(this);nextPanel.setOrientation(LinearLayout.VERTICAL);nextPanel.setPadding(dp(13),dp(11),dp(13),dp(12));nextPanel.setBackground(round(Color.rgb(8,12,22),dp(19),1));
        String nextTitle=t2("NEXT MATCH","SLJEDEĆA UTAKMICA","NÄCHSTES SPIEL","PRÓXIMO PARTIDO","PROCHAIN MATCH");
        if(next!=null&&!sameTeam(nextOwner,club))nextTitle+=" • "+displayTeamName(nextOwner);
        nextPanel.addView(label(nextTitle,12,Color.rgb(174,183,201),true));
        if(next!=null){
            final Match selected=next;
            LinearLayout matchup=hrow();matchup.setGravity(Gravity.CENTER);
            matchup.addView(dynamicTeamBlock(next.home,62),new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);
            center.addView(centerLabel(homeDateLabel(next),11,subText,false));
            boolean timeTba=isMatchTimeTba(next);
            TextView centerValue=centerLabel(homeCenterValue(next),timeTba?14:(matchIsLive(next)||matchIsFinished(next)?25:29),Color.WHITE,true);
            centerValue.setSingleLine(true);
            centerValue.setEllipsize(android.text.TextUtils.TruncateAt.END);
            center.addView(centerValue);
            center.addView(centerLabel(homeCenterStatus(next),13,matchIsLive(next)?RED:subText,true));
            matchup.addView(center,new LinearLayout.LayoutParams(dp(108),-2));
            matchup.addView(dynamicTeamBlock(next.away,62),new LinearLayout.LayoutParams(0,-2,1));
            matchup.setOnClickListener(v->showMatchDetails(selected));nextPanel.addView(matchup);
        }else{
            nextPanel.addView(label(t2("No upcoming match is available yet.","Još nema dostupne sljedeće utakmice.","Noch kein nächstes Spiel verfügbar.","Aún no hay próximo partido disponible.","Aucun prochain match disponible."),14,subText,false));
            Button open=outline(t2("Open all matches","Otvori sve utakmice","Alle Spiele öffnen","Abrir todos los partidos","Ouvrir tous les matchs"));open.setOnClickListener(v->{matchStatusFilter="All";matchDateFilter="ALL";showMatches();});nextPanel.addView(open);
        }
        hero.addView(nextPanel);

        LinearLayout snapshot=homeCard();
        LinearLayout snapshotHead=hrow();snapshotHead.addView(label(t2("MATCHDAY","DAN UTAKMICA","SPIELTAG","DÍA DE PARTIDO","JOUR DE MATCH"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=label("↻ "+t2("Refresh","Osvježi","Aktualisieren","Actualizar","Actualiser"),13,RED,true);refresh.setOnClickListener(v->refreshOnlineSafe(true));snapshotHead.addView(refresh);snapshot.addView(snapshotHead);
        LinearLayout stats=hrow();
        stats.addView(homeStat(String.valueOf(realLiveCount()),t2("Live","Uživo","Live","En vivo","Direct"),v->{matchStatusFilter="Live";matchDateFilter=dateKeyOffset(0);showMatches();}),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(7),0,dp(7),0);
        stats.addView(homeStat(String.valueOf(homeTodayCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),v->{matchStatusFilter="Today";matchDateFilter=dateKeyOffset(0);showMatches();}),mid);
        int tomorrowCount=0;for(Match m:data.matches)if(matchIsTomorrow(m))tomorrowCount++;
        stats.addView(homeStat(String.valueOf(tomorrowCount),t2("Tomorrow","Sutra","Morgen","Mañana","Demain"),v->{matchStatusFilter="Tomorrow";matchDateFilter=dateKeyOffset(1);showMatches();}),new LinearLayout.LayoutParams(0,-2,1));
        snapshot.addView(stats);

        LinearLayout dailyBrief=homeCard();
        dailyBrief.setBackground(gradient(Color.rgb(45,22,91),Color.rgb(145,22,91),dp(23)));
        LinearLayout briefHead=hrow();
        briefHead.addView(label("✨ "+t2("FOR YOUR FAVORITES","ZA TVOJE FAVORITE","FÜR DEINE FAVORITEN","PARA TUS FAVORITOS","POUR TES FAVORIS"),16,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView briefOpen=label(t2("Open  ›","Otvori  ›","Öffnen  ›","Abrir  ›","Ouvrir  ›"),13,Color.WHITE,true);briefHead.addView(briefOpen);dailyBrief.addView(briefHead);
        dailyBrief.addView(kpiRow(t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(personalLiveCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(personalTodayCount()),t2("Next 7 days","Sljedećih 7 dana","Nächste 7 Tage","Próximos 7 días","7 prochains jours"),String.valueOf(personalUpcomingCount(7)),true));
        Match briefNext=nextPersonalMatch();
        if(briefNext!=null){
            TextView briefSummary=label("⚽ "+displayTeamName(briefNext.home)+"  •  "+displayTeamName(briefNext.away)+"\n"+homeDateLabel(briefNext)+"  •  "+homeTimeLabel(briefNext),13,Color.WHITE,true);
            briefSummary.setPadding(dp(10),dp(8),dp(10),dp(8));briefSummary.setBackground(round(Color.argb(35,255,255,255),dp(15),0));dailyBrief.addView(briefSummary);
        }else dailyBrief.addView(label(t2("No verified personal match is available yet.","Još nema dostupne provjerene osobne utakmice.","Noch kein verifiziertes persönliches Spiel verfügbar.","Aún no hay un partido personal verificado.","Aucun match personnel vérifié n’est encore disponible."),13,Color.WHITE,false));
        dailyBrief.setOnClickListener(v->showDailyBrief());

        LinearLayout matches=homeCard();
        LinearLayout head=hrow();head.addView(label(t2("TODAY","DANAS","HEUTE","HOY","AUJOURD’HUI"),17,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView all=label(t2("All matches  ›","Sve utakmice  ›","Alle Spiele  ›","Todos  ›","Tous les matchs  ›"),13,RED,true);all.setOnClickListener(v->{matchStatusFilter="Today";matchDateFilter=dateKeyOffset(0);showMatches();});head.addView(all);matches.addView(head);
        ArrayList<Match> today=todaysMatches();
        if(today.isEmpty()){
            matches.addView(label(t2("No matches are scheduled today.","Danas nema zakazanih utakmica.","Heute sind keine Spiele angesetzt.","No hay partidos hoy.","Aucun match aujourd’hui."),15,subText,false));
            LinearLayout actions=hrow();
            Button tomorrow=outline(t2("Tomorrow","Sutra","Morgen","Mañana","Demain"));tomorrow.setOnClickListener(v->{matchStatusFilter="Tomorrow";matchDateFilter=dateKeyOffset(1);showMatches();});
            Button browse=outline(t2("Browse all","Pregledaj sve","Alle ansehen","Ver todos","Tout voir"));browse.setOnClickListener(v->{matchStatusFilter="All";matchDateFilter="ALL";showMatches();});
            actions.addView(tomorrow,new LinearLayout.LayoutParams(0,dp(50),1));actions.addView(browse,new LinearLayout.LayoutParams(0,dp(50),1));matches.addView(actions);
        }else{
            for(int i=0;i<Math.min(3,today.size());i++)addDynamicHomeMatch(matches,today.get(i));
        }

        LinearLayout following=homeCard();
        LinearLayout followHead=hrow();followHead.addView(label(t2("FOLLOWING","PRATIM","GEFOLGT","SIGUIENDO","SUIVI"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView manage=label(t2("Manage  ›","Uredi  ›","Verwalten  ›","Gestionar  ›","Gérer  ›"),13,RED,true);manage.setOnClickListener(v->showLeagues());followHead.addView(manage);following.addView(followHead);
        int shown=0;
        for(String comp:followedCompetitions){
            if(shown>=3)break;final String cn=comp;
            LinearLayout row=hrow();row.setPadding(dp(9),dp(8),dp(9),dp(8));row.setBackground(round(chipBg,dp(16),0));
            row.addView(label(competitionIcon(comp),20,text,true));
            LinearLayout rc=new LinearLayout(this);rc.setOrientation(LinearLayout.VERTICAL);rc.addView(label(comp,15,text,true));rc.addView(label(competitionDataStatus(comp),11,competitionStatusColor(comp),true));row.addView(rc,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(label("›",24,subText,true));row.setOnClickListener(v->showCompetitionHub(cn,competitionRegion(cn)));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(5),0,0);following.addView(row,rp);shown++;
        }
        if(shown==0)following.addView(label(t2("Follow competitions to build your personal feed.","Zaprati natjecanja kako bi složio osobni sadržaj.","Folge Wettbewerben für deinen Feed.","Sigue competiciones para crear tu contenido.","Suis des compétitions pour créer ton fil."),14,subText,false));
    }

    void showFavoriteLeagueStatus(String league,String country,String club){
        clear(league,country,"Leagues");
        LinearLayout hero=card();
        hero.setBackground(gradient(RED_DARK,RED,dp(24)));
        hero.addView(label("🏆 "+league,26,Color.WHITE,true));
        hero.addView(label(clubCountryFlag(club)+" "+club,19,Color.WHITE,true));
        hero.addView(label(t2("Favourite club competition","Natjecanje omiljenog kluba","Wettbewerb des Lieblingsklubs","Competición del club favorito","Compétition du club favori"),14,Color.WHITE,false));

        LinearLayout status=card();
        status.addView(label("🌐 "+t2("Verified data source","Provjereni izvor podataka","Verifizierte Datenquelle","Fuente de datos verificada","Source de données vérifiée"),22,text,true));
        if(competitionHasConnectedSource(league)){
            status.addView(label(t2(
                    "Matches, results, live statuses and standings use a verified connected source. Football Fun displays only published data.",
                    "Utakmice, rezultati, statusi uživo i tablica koriste provjereni povezani izvor. Football Fun prikazuje samo objavljene podatke.",
                    "Spiele, Ergebnisse, Live-Status und Tabelle nutzen eine verifizierte verbundene Quelle. Football Fun zeigt nur veröffentlichte Daten.",
                    "Los partidos, resultados, estados en vivo y la clasificación usan una fuente conectada y verificada. Football Fun muestra solo datos publicados.",
                    "Les matchs, résultats, statuts en direct et le classement utilisent une source connectée vérifiée. Football Fun n’affiche que les données publiées."),15,subText,false));
            Button matches=btn("⚽ "+t2("Open competition matches","Otvori utakmice natjecanja","Wettbewerbsspiele öffnen","Abrir partidos de la competición","Ouvrir les matchs de la compétition"));
            matches.setOnClickListener(v->{competitionFilter=league;matchStatusFilter="All";matchDateFilter="ALL";showMatches();});
            status.addView(matches);
            Button standings=outline("📊 "+t2("Open verified standings","Otvori provjerenu tablicu","Verifizierte Tabelle öffnen","Abrir clasificación verificada","Ouvrir le classement vérifié"));
            standings.setOnClickListener(v->showLeagueStandings(league));
            status.addView(standings);
        }else{
            status.addView(label(t2(
                    "Official HNL data has not reached this device yet. Refresh after the updater completes; no placeholder data is shown.",
                    "Službeni HNL podaci još nisu stigli na ovaj uređaj. Osvježi nakon završetka updatera; ne prikazujemo demonstracijske podatke.",
                    "Offizielle HNL-Daten sind noch nicht auf diesem Gerät angekommen. Nach dem Updater erneut laden; keine Demo-Daten.",
                    "Los datos oficiales de HNL aún no han llegado al dispositivo. Actualiza después del updater; no se muestran datos de demostración.",
                    "Les données officielles HNL ne sont pas encore arrivées sur cet appareil. Actualise après l’updater; aucune donnée fictive."),15,subText,false));
            Button pending=outline("🇭🇷 "+t2("Waiting for official HNL data","Čekanje službenih HNL podataka","Warten auf offizielle HNL-Daten","Esperando datos oficiales HNL","En attente des données officielles HNL"));
            pending.setEnabled(false);
            status.addView(pending);
        }
        Button competitions=outline(t2("View all competitions","Pogledaj sva natjecanja","Alle Wettbewerbe anzeigen","Ver todas las competiciones","Voir toutes les compétitions"));
        competitions.setOnClickListener(v->showLeagues());
        status.addView(competitions);
    }


    String primaryFavoriteClub(){
        if(favoriteClub!=null && favoriteClub.trim().length()>0) return favoriteClub.trim();
        if(favoriteClubs!=null && !favoriteClubs.isEmpty()) return favoriteClubs.iterator().next();
        return "Dinamo Zagreb";
    }

    String twoLineClubName(String name){
        if(name==null) return "Football Club";
        String n=displayTeamName(name).trim();
        if(n.length()<=12) return n;
        int split=n.lastIndexOf(' ');
        if(split>3) return n.substring(0,split)+"\n"+n.substring(split+1);
        return n;
    }

    String clubLogoResource(String club,boolean hero){
        String k=teamKey(club);
        if(k.equals("dinamozagreb")||k.equals("dinamo")) return hero?"logo_dinamo":"logo_dinamo_match";
        if(k.equals("hajduksplit")||k.equals("hajduk")) return hero?"logo_hajduk_hero":"logo_hajduk_match";
        if(k.equals("gorica")) return "logo_gorica";
        if(k.equals("istra1961")) return "logo_istra_1961";
        if(k.equals("lokomotivazagreb")) return "logo_lokomotiva";
        if(k.equals("osijek")) return "logo_osijek";
        if(k.equals("rijeka")) return "logo_rijeka";
        if(k.equals("rudes")) return "logo_rudes";
        if(k.equals("slavenbelupo")) return "logo_slaven_belupo";
        if(k.equals("varazdin")) return "logo_varazdin";
        if(k.equals("realmadrid")) return hero?"logo_real_madrid_hero":"logo_real_madrid";
        if(k.equals("bayernmunich")||k.equals("bayernmunchen")||k.equals("bayern")) return hero?"logo_bayern_hero":"logo_bayern";
        if(k.equals("liverpool")) return hero?"logo_liverpool_hero":"logo_liverpool";
        if(k.equals("arsenal")) return hero?"logo_arsenal_hero":"logo_arsenal";
        if(k.equals("barcelona")||k.equals("fcbarcelona")) return hero?"logo_barcelona_hero":"logo_barcelona";
        if(k.equals("atleticomadrid")||k.equals("atletico")) return hero?"logo_atletico_hero":"logo_atletico";
        return "";
    }

    void rebuildClubCrestIndex(JSONObject root){
        if(root==null){clubCrestUrls=Collections.emptyMap();return;}
        LinkedHashMap<String,String> found=new LinkedHashMap<String,String>();
        JSONArray matches=root.optJSONArray("matches");
        if(matches!=null)for(int i=0;i<matches.length();i++){
            JSONObject match=matches.optJSONObject(i);if(match==null)continue;
            indexClubCrest(found,match.optJSONObject("homeTeam"));
            indexClubCrest(found,match.optJSONObject("awayTeam"));
        }
        JSONObject allStandings=root.optJSONObject("standings");
        if(allStandings!=null){
            Iterator<String> codes=allStandings.keys();
            while(codes.hasNext()){
                JSONObject entry=allStandings.optJSONObject(codes.next());if(entry==null)continue;
                JSONArray blocks=entry.optJSONArray("standings");if(blocks==null)continue;
                for(int i=0;i<blocks.length();i++){
                    JSONObject block=blocks.optJSONObject(i);JSONArray table=block==null?null:block.optJSONArray("table");if(table==null)continue;
                    for(int j=0;j<table.length();j++){
                        JSONObject row=table.optJSONObject(j);if(row!=null)indexClubCrest(found,row.optJSONObject("team"));
                    }
                }
            }
        }
        clubCrestUrls=Collections.unmodifiableMap(found);
    }

    void indexClubCrest(Map<String,String> target,JSONObject team){
        if(target==null||team==null)return;
        String url=team.optString("crest",team.optString("emblem",team.optString("logo",""))).trim();
        if(url.length()==0||!url.startsWith("https://"))return;
        String[] names={team.optString("name",""),team.optString("shortName",""),team.optString("tla","")};
        for(String name:names){String key=teamKey(name);if(key.length()>0&&!target.containsKey(key))target.put(key,url);}
    }

    String crestUrlForClub(String club){
        if(club==null)return "";
        String direct=clubCrestUrls.get(teamKey(club));
        if(direct!=null)return direct;
        for(Map.Entry<String,String> entry:clubCrestUrls.entrySet()){
            if(sameTeam(entry.getKey(),club))return entry.getValue();
        }
        return "";
    }

    View remoteClubVisual(String team,String url,int sizePx,boolean hero){
        FrameLayout frame=new FrameLayout(this);
        TextView fallback=centerLabel(clubInitials(team),hero?28:18,Color.WHITE,true);
        fallback.setGravity(Gravity.CENTER);
        fallback.setBackground(round(Color.rgb(39,44,61),dp(hero?34:24),1));
        frame.addView(fallback,new FrameLayout.LayoutParams(-1,-1));
        ImageView crest=new ImageView(this);
        crest.setVisibility(View.INVISIBLE);
        crest.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        int inset=dp(hero?4:3);crest.setPadding(inset,inset,inset,inset);
        frame.addView(crest,new FrameLayout.LayoutParams(-1,-1));
        if(clubCrestCache!=null)clubCrestCache.load(crest,teamKey(team),url);
        return frame;
    }

    void invalidateClubProfileCache(){
        clubProfilesCache=null;
        clubProfileIndex=Collections.emptyMap();
    }

    ArrayList<ClubProfile> availableClubProfiles(){
        List<ClubProfile> cached=clubProfilesCache;
        if(cached!=null)return new ArrayList<ClubProfile>(cached);
        synchronized(this){
            cached=clubProfilesCache;
            if(cached==null){
                ArrayList<ClubProfile> base=new ArrayList<ClubProfile>(ClubCatalog.build(data==null?null:data.matches,favoriteClubs));
                LinkedHashMap<String,ClubProfile> merged=new LinkedHashMap<String,ClubProfile>();
                for(ClubProfile club:base)merged.put(teamKey(club.name),club);
                for(String competitionName:CompetitionCatalog.all().keySet()){
                    CompetitionCatalog.Competition meta=CompetitionCatalog.get(competitionName);
                    if(meta.nationalTeams)continue;
                    JSONArray table=verifiedTotalStandingTable(competitionName);
                    if(table==null)continue;
                    for(int i=0;i<table.length();i++){
                        JSONObject row=table.optJSONObject(i);if(row==null)continue;
                        JSONObject team=row.optJSONObject("team");if(team==null)continue;
                        String name=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();
                        if(name.length()==0)continue;
                        String key=teamKey(name);
                        if(!merged.containsKey(key))merged.put(key,new ClubProfile(name,competitionName,meta.regionKey));
                    }
                }
                ArrayList<ClubProfile> result=new ArrayList<ClubProfile>(merged.values());
                Collections.sort(result,(a,b)->{int c=a.competition.compareToIgnoreCase(b.competition);return c!=0?c:a.name.compareToIgnoreCase(b.name);});
                LinkedHashMap<String,ClubProfile> index=new LinkedHashMap<String,ClubProfile>();
                for(ClubProfile profile:result)index.put(teamKey(profile.name),profile);
                clubProfilesCache=Collections.unmodifiableList(new ArrayList<ClubProfile>(result));
                clubProfileIndex=Collections.unmodifiableMap(index);
                cached=clubProfilesCache;
            }
        }
        return new ArrayList<ClubProfile>(cached);
    }

    ClubProfile availableClubProfile(String club){
        if(club==null||club.trim().length()==0)return null;
        if(clubProfilesCache==null)availableClubProfiles();
        ClubProfile direct=clubProfileIndex.get(teamKey(club));
        if(direct!=null)return direct;
        return ClubCatalog.find(availableClubProfiles(),club);
    }

    String clubLeague(String club){
        String k=teamKey(club);
        if(k.equals("dinamozagreb")||k.equals("hajduksplit")||k.equals("rijeka")||k.equals("osijek")||k.equals("gorica")||k.equals("istra1961")||k.equals("lokomotivazagreb")||k.equals("rudes")||k.equals("slavenbelupo")||k.equals("varazdin")) return "HNL";
        if(k.equals("realmadrid")||k.contains("barcelona")||k.contains("atletico")) return "La Liga";
        if(k.contains("manchestercity")||k.equals("liverpool")||k.equals("arsenal")) return "Premier League";
        if(k.contains("bayern")||k.contains("borussiadortmund")) return "Bundesliga";
        if(k.equals("inter")||k.equals("intermilan")||k.equals("milan")||k.equals("acmilan")||k.equals("juventus")) return "Serie A";
        if(k.contains("parissaintgermain")||k.equals("psg")) return "Ligue 1";
        ClubProfile profile=availableClubProfile(club);
        if(profile!=null&&profile.competition.length()>0)return profile.competition;
        if(data!=null)for(Match match:data.matches){
            if(sameTeam(match.home,club)||sameTeam(match.away,club)){
                String competition=friendlyCompetitionName(match);
                if(!isNationalCompetition(competition))return competition;
            }
        }
        return t2("Club competition","Klupsko natjecanje","Klubwettbewerb","Competición de clubes","Compétition de clubs");
    }

    String clubCountry(String club){
        String league=clubLeague(club);
        if(league.equals("HNL")) return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(league.equals("La Liga")) return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(league.equals("Premier League")||league.equals("Championship")) return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(league.equals("Bundesliga")) return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(league.equals("Serie A")) return t2("Italy","Italija","Italien","Italia","Italie");
        if(league.equals("Ligue 1")) return t2("France","Francuska","Frankreich","Francia","France");
        if(league.equals("Eredivisie")) return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(league.equals("Primeira Liga")) return t2("Portugal","Portugal","Portugal","Portugal","Portugal");
        if(league.equals("Brasileirão Série A")) return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        return competitionRegion(league);
    }

    String clubCountryFlag(String club){
        String league=clubLeague(club);
        if(league.equals("HNL")) return "🇭🇷";
        if(league.equals("La Liga")) return "🇪🇸";
        if(league.equals("Premier League")||league.equals("Championship")) return "🇬🇧";
        if(league.equals("Bundesliga")) return "🇩🇪";
        if(league.equals("Serie A")) return "🇮🇹";
        if(league.equals("Ligue 1")) return "🇫🇷";
        if(league.equals("Eredivisie")) return "🇳🇱";
        if(league.equals("Primeira Liga")) return "🇵🇹";
        if(league.equals("Brasileirão Série A")) return "🇧🇷";
        return "⚽";
    }

    View leagueVisual(String league,String fallbackFlag,int size){
        if("Premier League".equals(league)) return homeLogo("logo_premier_league",dp(size));
        TextView badge=centerLabel(fallbackFlag,44,Color.WHITE,true);
        badge.setBackground(round(Color.rgb(28,33,46),dp(24),1));
        return badge;
    }

    String clubInitials(String team){
        if(team==null||team.trim().length()==0)return "FC";
        String[] parts=team.trim().split("\\s+");
        StringBuilder out=new StringBuilder();
        for(String part:parts){
            if(part.length()==0||part.equalsIgnoreCase("FC")||part.equalsIgnoreCase("CF"))continue;
            out.append(Character.toUpperCase(part.charAt(0)));
            if(out.length()>=2)break;
        }
        if(out.length()==0)out.append("FC");
        return out.toString();
    }

    View homeTeamVisual(String team,int sizePx,boolean hero){
        String logo=clubLogoResource(team,hero);
        if(logo.length()>0) return homeLogo(logo,sizePx);
        String symbol=flag(team);
        boolean national=!symbol.equals("🏳");
        if(!national){
            String remote=crestUrlForClub(team);
            if(remote.length()>0)return remoteClubVisual(team,remote,sizePx,hero);
        }
        TextView badge=centerLabel(national?symbol:clubInitials(team),hero?(national?58:28):(national?38:19),Color.WHITE,true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(national?Color.TRANSPARENT:Color.rgb(39,44,61),dp(hero?34:24),1));
        return badge;
    }

    LinearLayout dynamicTeamBlock(String team,int sizeDp){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(sizeDp),false);
        visual.setElevation(dp(5));
        box.addView(visual,new LinearLayout.LayoutParams(dp(sizeDp),dp(sizeDp)));
        TextView n=centerLabel(shortName(team),14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    LinearLayout dynamicCompactTeamBlock(String team){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(52),false);
        visual.setElevation(dp(4));
        box.addView(visual,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView teamName=centerLabel(shortName(team),12,text,true);
        teamName.setMaxLines(2);
        teamName.setMinLines(2);
        teamName.setEllipsize(null);
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(2),dp(3),dp(2),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(40)));
        return box;
    }

    void addDynamicHomeMatch(LinearLayout parent,Match m){
        final Match selected=m;
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(12),dp(10),dp(12));
        row.setBackground(round(Color.rgb(16,21,33),dp(19),1));
        row.setElevation(dp(2));
        row.addView(dynamicCompactTeamBlock(m.home),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        String badgeText=matchIsLive(m)?t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT"):matchIsFinished(m)?t2("FT","KRAJ","ENDE","FINAL","FIN"):homeTimeLabel(m);
        TextView b=centerLabel(badgeText,11,Color.WHITE,true);
        b.setPadding(dp(8),dp(3),dp(8),dp(3));
        b.setBackground(round(matchIsLive(m)?Color.rgb(240,18,75):Color.rgb(66,74,92),dp(9),0));
        mid.addView(b,new LinearLayout.LayoutParams(dp(86),dp(26)));
        String center=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" - "+m.awayGoals:"VS";
        TextView scoreView=centerLabel(center,center.equals("VS")?23:30,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        mid.addView(scoreView);
        if(matchIsLive(m) && m.minute!=null && m.minute.trim().length()>0) mid.addView(centerLabel(m.minute.replace("'","")+"′",12,RED,true));
        row.addView(mid,new LinearLayout.LayoutParams(dp(94),-2));
        row.addView(dynamicCompactTeamBlock(m.away),new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatchDetails(selected));
        row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(11),0,0);
        parent.addView(row,lp);
    }

    boolean dataContainsTeam(String team){
        if(team==null) return false;
        for(Match m:data.matches) if(sameTeam(m.home,team)||sameTeam(m.away,team)) return true;
        return false;
    }

    Date localMatchDate(Match m){
        if(m==null || m.date==null) return null;
        String d=displayLocalDateTime(m.date).trim();
        try{
            if(d.length()>=16) return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(d.substring(0,16));
            if(d.length()>=10) return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d.substring(0,10));
        }catch(Exception ignored){}
        return null;
    }

    String localDateKey(Match m){
        Date d=localMatchDate(m);
        return d==null?"":new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);
    }

    boolean matchIsLive(Match m){ return m!=null && isLiveStatus(m.status); }
    boolean matchIsFinished(Match m){
        if(m==null) return false;
        if(matchIsLive(m)) return false;
        if(isFinishedStatus(m.status) && m.status!=null && m.status.trim().length()>0) return m.homeGoals>=0&&m.awayGoals>=0;
        return m.homeGoals>=0&&m.awayGoals>=0;
    }
    boolean matchIsUpcoming(Match m){ return m!=null && !matchIsLive(m) && !matchIsFinished(m); }

    boolean matchIsToday(Match m){
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        return today.equals(localDateKey(m));
    }

    boolean matchIsTomorrow(Match m){
        Calendar c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,1);
        String tomorrow=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
        return tomorrow.equals(localDateKey(m));
    }

    ArrayList<Match> todaysMatches(){
        ArrayList<Match> out=new ArrayList<>();
        for(Match m:data.matches) if(matchIsToday(m)) out.add(m);
        Collections.sort(out,(a,b)->{
            Date da=localMatchDate(a), db=localMatchDate(b);
            if(da==null&&db==null)return 0; if(da==null)return 1; if(db==null)return -1; return da.compareTo(db);
        });
        return out;
    }

    Match nextMatchForTeam(String team){
        if(team==null || team.trim().length()==0) return null;
        Match best=null;
        Date bestDate=null;
        long now=System.currentTimeMillis();
        for(Match m:data.matches){
            if(!sameTeam(m.home,team)&&!sameTeam(m.away,team)) continue;
            if(matchIsLive(m)) return m;
            if(!matchIsUpcoming(m)) continue;
            Date d=localMatchDate(m);
            if(d==null)continue;
            boolean dateOnly=displayLocalDateTime(m.date).length()<16;
            long effectiveTime=d.getTime()+(dateOnly?24L*60L*60L*1000L-1L:0L);
            if(effectiveTime<now-AppConfig.MATCH_START_GRACE_MS)continue;
            if(best==null||bestDate==null||d.before(bestDate)){best=m;bestDate=d;}
        }
        return best;
    }

    String[] recentForm(String team,int count){
        ArrayList<Match> finished=new ArrayList<>();
        for(Match m:data.matches) if(matchIsFinished(m)&&(sameTeam(m.home,team)||sameTeam(m.away,team))) finished.add(m);
        Collections.sort(finished,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
        String[] out=new String[count];
        Arrays.fill(out,"–");
        for(int i=0;i<Math.min(count,finished.size());i++){
            Match m=finished.get(i);
            int own=sameTeam(m.home,team)?m.homeGoals:m.awayGoals;
            int opp=sameTeam(m.home,team)?m.awayGoals:m.homeGoals;
            out[count-1-i]=own>opp?"W":own<opp?"L":"D";
        }
        return out;
    }


    String recentFormDisplay(String team){
        String[] f=recentForm(team,5);
        return f[0]+" • "+f[1]+" • "+f[2]+" • "+f[3]+" • "+f[4];
    }

    String homeDateLabel(Match m){
        Date d=localMatchDate(m);
        if(d==null) return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        return new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(d);
    }

    boolean hasConfirmedKickoffTime(Match m){
        if(m==null)return false;
        if(matchIsLive(m)||matchIsFinished(m))return true;
        String status=m.status==null?"":m.status.trim().toUpperCase(Locale.US);
        if(status.equals("TIMED")||status.equals("CONFIRMED"))return true;
        if(status.equals("SCHEDULED")||status.equals("UPCOMING")||status.equals("NOT_STARTED")||status.equals("NOT STARTED"))return false;
        return m.date!=null&&displayLocalDateTime(m.date).length()>=16;
    }

    boolean isMatchTimeTba(Match m){
        return m==null || localMatchDate(m)==null || m.date==null || displayLocalDateTime(m.date).length()<16 || !hasConfirmedKickoffTime(m);
    }

    String homeTimeLabel(Match m){
        Date d=localMatchDate(m);
        if(isMatchTimeTba(m)) return t2("Time TBA","Naknadno","Offen","Pendiente","À confirmer");
        return new SimpleDateFormat("HH:mm",Locale.US).format(d);
    }

    boolean hasCompletedMatchForTeam(String team){
        if(team==null || team.trim().length()==0) return false;
        for(Match m:data.matches){
            if(matchIsFinished(m) && (sameTeam(m.home,team) || sameTeam(m.away,team))) return true;
        }
        return false;
    }

    Locale homeLocale(){
        return TeamLocalizer.localeFor(lang);
    }

    String homeCenterValue(Match m){
        if(m.homeGoals>=0&&m.awayGoals>=0) return m.homeGoals+" - "+m.awayGoals;
        return homeTimeLabel(m);
    }

    String homeCenterStatus(Match m){
        if(m==null) return "VS";
        String value=MatchCenterFormatter.status(m.status,m.minute,matchIsLive(m),matchIsFinished(m),lang);
        return value.length()>0?value:"VS";
    }

    LinearLayout homeCard(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(15),dp(16),dp(15));
        l.setBackground(round(Color.rgb(12,16,26),dp(23),1)); l.setElevation(dp(5));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(16)); content.addView(l,lp); return l;
    }

    ImageView homeLogo(String name,int size){
        ImageView iv=new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); iv.setAdjustViewBounds(true);
        int id=getResources().getIdentifier(name,"drawable",getPackageName()); if(id!=0) iv.setImageResource(id);
        iv.setPadding(dp(2),dp(2),dp(2),dp(2)); return iv;
    }

    TextView centerLabel(String s,int sp,int color,boolean bold){ TextView t=label(s,sp,color,bold); t.setGravity(Gravity.CENTER); return t; }

    LinearLayout teamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(72));
        crest.setElevation(dp(5));
        box.addView(crest,new LinearLayout.LayoutParams(dp(72),dp(72)));
        TextView n=centerLabel(name,14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    void addPremiumMatch(LinearLayout parent,String leftLogo,String leftName,String score,String rightName,String rightLogo,String badge,String minute){
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(12),dp(10),dp(12));
        row.setBackground(round(Color.rgb(16,21,33),dp(19),1));
        row.setElevation(dp(2));

        LinearLayout leftTeam=compactTeamBlock(leftLogo,leftName);
        row.addView(leftTeam,new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        if(badge!=null&&!badge.isEmpty()){
            TextView b=centerLabel(badge,11,Color.WHITE,true);
            b.setPadding(dp(12),dp(3),dp(12),dp(3));
            b.setBackground(round(badge.equals("LIVE")?Color.rgb(240,18,75):Color.rgb(66,74,92),dp(9),0));
            b.setElevation(dp(3));
            mid.addView(b,new LinearLayout.LayoutParams(dp(86),dp(26)));
        }
        TextView scoreView=centerLabel(score,30,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        mid.addView(scoreView);
        if(minute!=null&&!minute.isEmpty())mid.addView(centerLabel(minute,12,subText,false));
        row.addView(mid,new LinearLayout.LayoutParams(dp(94),-2));

        LinearLayout rightTeam=compactTeamBlock(rightLogo,rightName);
        row.addView(rightTeam,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatches());
        row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(11),0,0);
        parent.addView(row,lp);
    }

    LinearLayout compactTeamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(52));
        crest.setElevation(dp(4));
        box.addView(crest,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView teamName=centerLabel(name,12,text,true);
        teamName.setMaxLines(2);
        teamName.setMinLines(2);
        teamName.setEllipsize(null);
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(2),dp(3),dp(2),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(40)));
        return box;
    }


    int realLiveCount(){ int c=0; for(Match m:data.matches) if(matchIsLive(m)) c++; return c; }
    Match firstLiveMatch(){ for(Match m:data.matches) if(matchIsLive(m)) return m; return null; }
    String primaryFollowedCompetition(){ if(followedCompetitions!=null&&!followedCompetitions.isEmpty())return followedCompetitions.iterator().next(); return "HNL"; }
    String competitionTeams(String c){ return String.valueOf(CompetitionCatalog.get(c).teamCount); }
    String competitionApiCode(String c){ return CompetitionCatalog.get(c).apiCode; }
    boolean competitionUsesFootballData(String c){ return CompetitionCatalog.get(c).footballDataSource; }
    boolean isNationalCompetition(String c){ return CompetitionCatalog.get(c).nationalTeams; }
    String competitionRound(String c){ if(isNationalCompetition(c))return t2("Tournament","Turnir","Turnier","Torneo","Tournoi"); return t2("League season","Ligaška sezona","Ligasaison","Temporada de liga","Saison de ligue"); }
    String competitionRegion(String c){
        String region=CompetitionCatalog.get(c).regionKey;
        if(region.equals("Croatia"))return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(region.equals("England"))return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(region.equals("Spain"))return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(region.equals("Italy"))return t2("Italy","Italija","Italien","Italia","Italie");
        if(region.equals("Germany"))return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(region.equals("France"))return t2("France","Francuska","Frankreich","Francia","France");
        if(region.equals("Netherlands"))return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(region.equals("Portugal"))return "Portugal";
        if(region.equals("Brazil"))return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        if(region.equals("International"))return t2("International","Međunarodno","International","Internacional","International");
        return t2("Europe","Europa","Europa","Europa","Europe");
    }
    String competitionMeta(String c){
        String sourceLabel;
        if("HNL".equals(c)) sourceLabel=hnlDataConnected()?t2("Official HNL source","Službeni HNL izvor","Offizielle HNL-Quelle","Fuente oficial de HNL","Source officielle HNL"):t2("HNL source is connecting","HNL izvor se povezuje","HNL-Quelle wird verbunden","Conectando fuente HNL","Connexion de la source HNL");
        else sourceLabel=t2("Live data","Podaci uživo","Live-Daten","Datos en vivo","Données en direct");
        return competitionRegion(c)+"  •  "+competitionTeams(c)+" "+t2(isNationalCompetition(c)?"teams":"clubs",isNationalCompetition(c)?"reprezentacija":"klubova",isNationalCompetition(c)?"Teams":"Klubs",isNationalCompetition(c)?"selecciones":"clubes",isNationalCompetition(c)?"équipes":"clubs")+"  •  "+sourceLabel;
    }
    boolean matchBelongsToCompetition(Match m,String selected){
        if(selected==null||selected.equals("All"))return true;
        String raw=(m.competition==null?"":m.competition).toLowerCase(Locale.US);
        String name=selected.toLowerCase(Locale.US);
        String code=competitionApiCode(selected).toLowerCase(Locale.US);
        if(raw.equals(code)||raw.contains(name))return true;
        if(selected.equals("World Cup 2026"))return raw.contains("world cup")||raw.equals("wc");
        if(selected.equals("UEFA European Championship"))return raw.contains("european championship")||raw.contains("euro")||raw.equals("ec");
        if(selected.equals("La Liga"))return raw.contains("primera division")||raw.contains("primera división")||raw.equals("pd");
        if(selected.equals("Brasileirão Série A"))return raw.contains("brasileiro")||raw.contains("brazil")||raw.equals("bsa");
        return false;
    }
    Match lastFavoriteResult(){
        String preferred=dataContainsTeam(primaryFavoriteClub())?primaryFavoriteClub():myTeam;
        ArrayList<Match> found=new ArrayList<>();
        for(Match m:data.matches) if(matchIsFinished(m)&&(sameTeam(m.home,preferred)||sameTeam(m.away,preferred))) found.add(m);
        Collections.sort(found,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);});
        return found.isEmpty()?null:found.get(0);
    }
    void addResultRow(LinearLayout parent,Match m){ LinearLayout row=hrow(); row.setPadding(dp(10),dp(10),dp(10),dp(10)); row.setBackground(round(chipBg,dp(16),0)); TextView left=label(flag(m.home)+" "+safeTeam(m.home),15,text,true); TextView score=label(m.homeGoals+" : "+m.awayGoals,18,RED,true); TextView right=label(flag(m.away)+" "+safeTeam(m.away),15,text,true); right.setGravity(Gravity.RIGHT); row.addView(left,new LinearLayout.LayoutParams(0,-2,1)); row.addView(score); row.addView(right,new LinearLayout.LayoutParams(0,-2,1)); parent.addView(row); }

    void addHomeMatchRow(LinearLayout parent,Match m,boolean highlight){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(12),dp(10),dp(12),dp(10));
        row.setBackground(round(highlight?Color.argb(46,255,48,94):chipBg,dp(18),highlight?1:0));
        TextView meta=label(displayLocalDateTime(m.date)+(m.venue!=null&&m.venue.length()>0?" • "+m.venue:""),12,subText,true); row.addView(meta);
        LinearLayout teams=hrow();
        String homeName=safeTeam(m.home), awayName=safeTeam(m.away);
        TextView left=label(flag(homeName)+" "+homeName,15,text,true); TextView right=label(flag(awayName)+" "+awayName,15,text,true); right.setGravity(Gravity.RIGHT);
        teams.addView(left,new LinearLayout.LayoutParams(0,-2,1)); TextView versus=label("VS",12,Color.WHITE,true); versus.setGravity(Gravity.CENTER); versus.setPadding(dp(9),dp(4),dp(9),dp(4)); versus.setBackground(gradient(PURPLE_DARK,RED,dp(12))); teams.addView(versus); teams.addView(right,new LinearLayout.LayoutParams(0,-2,1)); row.addView(teams);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); parent.addView(row,lp);
    }

    int favoriteCoverageScore(){
        int score=20;
        if(myTeam!=null&&!myTeam.trim().isEmpty())score+=25;
        if(favoriteClubs!=null&&!favoriteClubs.isEmpty())score+=30;
        if(followedCompetitions!=null&&!followedCompetitions.isEmpty())score+=25;
        return Math.min(100,score);
    }


    int homeLiveCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsLive(m)) c++;
        return c;
    }

    boolean isFinalStageLabel(String s){
        if(s==null)return false;
        String x=s.toLowerCase(Locale.US);
        return x.contains("final") || x.contains("round") || x.contains("group") || x.contains("stadium") || x.contains("arena");
    }

    int homeTodayCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsToday(m)) c++;
        return c;
    }

    Match nextFavoriteMatch(){
        Match clubMatch=nextMatchForTeam(primaryFavoriteClub());
        return clubMatch!=null?clubMatch:nextMatchForTeam(myTeam);
    }

    LinearLayout pathPreview(String team){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(0,dp(6),0,dp(8));
        String[] rounds={"Round of 32","Round of 16","Quarter-final","Semi-final","Final"};
        String[] steps={
            "✅ Group "+groupOfTeam(team),
            (hasWonStage(team,"Round of 32")?"✅ ":"⬜ ")+"Round of 32",
            (hasWonStage(team,"Round of 16")?"✅ ":"⬜ ")+"Round of 16",
            (hasWonStage(team,"Quarter-final")?"✅ ":"⬜ ")+"Quarter-final",
            (hasWonStage(team,"Semi-final")?"✅ ":"⬜ ")+"Semi-final",
            (hasWonStage(team,"Final")?"🏆 ":"🏆 ")+"Final"
        };
        for(String s:steps)p.addView(label("   "+s,15,subText,false));
        return p;
    }

    LinearLayout kpiRow(String a,String av,String b,String bv,String c,String cv,boolean light){
        LinearLayout r=hrow();r.setPadding(0,dp(10),0,0);
        r.addView(kpi(a,av,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(b,bv,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(c,cv,light),new LinearLayout.LayoutParams(0,dp(72),1));return r;
    }
    LinearLayout kpi(String n,String v,boolean light){LinearLayout k=new LinearLayout(this);k.setOrientation(LinearLayout.VERTICAL);k.setGravity(Gravity.CENTER);k.setPadding(dp(4),dp(4),dp(4),dp(4));k.setBackground(round(light?Color.argb(45,255,255,255):chipBg,dp(18),0));TextView val=label(v,22,light?Color.WHITE:RED,true);val.setGravity(Gravity.CENTER);TextView name=label(n,11,light?Color.WHITE:subText,false);name.setGravity(Gravity.CENTER);k.addView(val);k.addView(name);return k;}
    String daysTo(String date){try{Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(date);long diff=d.getTime()-System.currentTimeMillis();return String.valueOf(Math.max(0,diff/86400000));}catch(Exception e){return "0";}}

    void showLeagues(){
        clear(t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"),t2("Follow the football that matters to you","Prati nogomet koji ti je važan","Folge deinem Fußball","Sigue el fútbol que te importa","Suis le football qui compte"),"Leagues");

        LinearLayout summary=card();
        summary.setBackground(gradient(Color.rgb(46,24,92),Color.rgb(139,23,77),dp(22)));
        summary.addView(label("🏆 "+t2("Your competition hub","Tvoj centar natjecanja","Deine Wettbewerbszentrale","Tu centro de competiciones","Ton centre de compétitions"),22,Color.WHITE,true));
        LinearLayout numbers=hrow();
        numbers.addView(homeStat(String.valueOf(followedCompetitions.size()),t2("Following","Pratim","Gefolgt","Siguiendo","Suivi"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(0,-2,1);mlp.setMargins(dp(7),0,dp(7),0);
        numbers.addView(homeStat(String.valueOf(realLiveCount()),t2("Live now","Uživo","Jetzt live","En vivo","Direct"),null),mlp);
        numbers.addView(homeStat("13",t2("Available","Dostupno","Verfügbar","Disponibles","Disponibles"),null),new LinearLayout.LayoutParams(0,-2,1));
        summary.addView(numbers);
        summary.addView(label(t2("Pin competitions for faster access and personalized alerts.","Prati natjecanja za brži pristup i personalizirane obavijesti.","Hefte Wettbewerbe für schnellen Zugriff an.","Fija competiciones para acceso rápido.","Épingle des compétitions pour un accès rapide."),13,Color.WHITE,false));

        if(followedCompetitions!=null&&!followedCompetitions.isEmpty()){
            sectionHeading(t2("Following","Pratim","Gefolgt","Siguiendo","Suivi"));
            for(String c:new ArrayList<String>(followedCompetitions))addCompetitionCard(competitionIcon(c),c);
        }
        sectionHeading(t2("Club competitions","Klupska natjecanja","Klubwettbewerbe","Competiciones de clubes","Compétitions de clubs"));
        String[][] clubs={{"🏆","UEFA Champions League"},{"🏴","Premier League"},{"🏴","Championship"},{"🇪🇸","La Liga"},{"🇩🇪","Bundesliga"},{"🇮🇹","Serie A"},{"🇫🇷","Ligue 1"},{"🇳🇱","Eredivisie"},{"🇵🇹","Primeira Liga"},{"🇧🇷","Brasileirão Série A"},{"🇭🇷","HNL"}};
        for(String[] x:clubs)if(!followedCompetitions.contains(x[1]))addCompetitionCard(x[0],x[1]);
        sectionHeading(t2("National teams","Reprezentacije","Nationalteams","Selecciones","Équipes nationales"));
        String[][] national={{"🌍","World Cup 2026"},{"🇪🇺","UEFA European Championship"}};
        for(String[] x:national)if(!followedCompetitions.contains(x[1]))addCompetitionCard(x[0],x[1]);
    }

    void addCompetitionSection(String sectionTitle,String[][] comps){
        sectionHeading(sectionTitle);
        for(String[] x:comps)addCompetitionCard(x[0],x[1]);
    }

    void addCompetitionCard(String icon,String competitionName){
        final String cn=competitionName;
        final String rg=competitionRegion(competitionName);
        boolean followed=followedCompetitions.contains(cn);
        LinearLayout c=card();
        c.setPadding(dp(15),dp(13),dp(13),dp(13));
        LinearLayout row=hrow();
        TextView badge=centerLabel(icon,26,Color.WHITE,true);badge.setBackground(round(chipBg,dp(18),1));row.addView(badge,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(5),0);
        copy.addView(label(competitionName,19,text,true));
        copy.addView(label(rg+"  •  "+competitionTeams(competitionName)+" "+t2(isNationalCompetition(competitionName)?"teams":"clubs",isNationalCompetition(competitionName)?"reprezentacija":"klubova",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"selecciones":"clubes",isNationalCompetition(competitionName)?"équipes":"clubs"),13,subText,false));
        copy.addView(label("● "+competitionDataStatus(competitionName),12,competitionStatusColor(competitionName),true));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView follow=centerLabel(followed?"★":"☆",25,followed?GOLD:subText,true);follow.setBackground(round(chipBg,dp(18),1));
        follow.setOnClickListener(v->{if(followedCompetitions.contains(cn))followedCompetitions.remove(cn);else followedCompetitions.add(cn);userPreferences.saveFollowedCompetitions(followedCompetitions);syncMatchReminders();showLeagues();});
        row.addView(follow,new LinearLayout.LayoutParams(dp(50),dp(50)));
        c.addView(row);
        TextView open=label(t2("Open competition  ›","Otvori natjecanje  ›","Wettbewerb öffnen  ›","Abrir competición  ›","Ouvrir la compétition  ›"),13,RED,true);open.setGravity(Gravity.RIGHT);c.addView(open);
        c.setClickable(true);c.setOnClickListener(v->showCompetitionHub(cn,rg));
    }

    void showCompetitionHub(final String competitionName,final String region){
        clear(displayCompetitionName(competitionName),competitionIcon(competitionName)+" "+region,"Leagues");
        boolean connected=competitionHasConnectedSource(competitionName);
        ArrayList<Match> competitionMatches=matchesForCompetition(competitionName);
        ArrayList<Match> live=new ArrayList<Match>();
        ArrayList<Match> upcoming=new ArrayList<Match>();
        ArrayList<Match> finished=new ArrayList<Match>();
        int todayCount=0;
        for(Match match:competitionMatches){
            if(matchIsLive(match))live.add(match);
            else if(matchIsUpcoming(match))upcoming.add(match);
            else if(matchIsFinished(match))finished.add(match);
            if(matchIsToday(match))todayCount++;
        }
        Collections.sort(finished,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });

        LinearLayout hero=card();
        hero.setBackground(gradient(Color.rgb(58,18,91),Color.rgb(241,31,87),dp(24)));
        LinearLayout heroTop=hrow();heroTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView badge=centerLabel(competitionIcon(competitionName),34,Color.WHITE,true);
        badge.setBackground(round(Color.argb(48,255,255,255),dp(22),1));
        heroTop.addView(badge,new LinearLayout.LayoutParams(dp(68),dp(68)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(13),0,dp(8),0);
        heroCopy.addView(label(t2("COMPETITION CENTER","CENTAR NATJECANJA","WETTBEWERBSZENTRALE","CENTRO DE COMPETICIÓN","CENTRE DE COMPÉTITION"),11,Color.WHITE,true));
        heroCopy.addView(label(displayCompetitionName(competitionName),24,Color.WHITE,true));
        heroCopy.addView(label(region+"  •  "+competitionParticipantLabel(competitionName),13,Color.WHITE,false));
        heroTop.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));
        boolean followed=followedCompetitions.contains(competitionName);
        TextView follow=centerLabel(followed?"★":"☆",28,followed?GOLD:Color.WHITE,true);
        follow.setContentDescription(followed?t2("Stop following","Prestani pratiti","Nicht mehr folgen","Dejar de seguir","Ne plus suivre"):t2("Follow competition","Prati natjecanje","Wettbewerb folgen","Seguir competición","Suivre la compétition"));
        follow.setBackground(round(Color.argb(45,255,255,255),dp(20),1));
        follow.setOnClickListener(v->{
            if(followedCompetitions.contains(competitionName))followedCompetitions.remove(competitionName);else followedCompetitions.add(competitionName);
            userPreferences.saveFollowedCompetitions(followedCompetitions);
            syncMatchReminders();
            showCompetitionHub(competitionName,region);
        });
        heroTop.addView(follow,new LinearLayout.LayoutParams(dp(56),dp(56)));
        hero.addView(heroTop);
        TextView sourcePill=label("● "+competitionDataStatus(competitionName),12,connected?Color.rgb(166,255,220):Color.rgb(255,221,135),true);
        sourcePill.setPadding(dp(12),dp(7),dp(12),dp(7));sourcePill.setBackground(round(Color.argb(35,255,255,255),dp(15),0));
        LinearLayout.LayoutParams sourceLp=new LinearLayout.LayoutParams(-2,-2);sourceLp.setMargins(0,dp(11),0,0);hero.addView(sourcePill,sourceLp);
        hero.addView(kpiRow(
                t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(live.size()),
                t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(todayCount),
                t2("Upcoming","Slijedi","Bevorstehend","Próximos","À venir"),String.valueOf(upcoming.size()),true));

        LinearLayout navigation=card();
        navigation.addView(label("⚡ "+t2("Quick access","Brzi pristup","Schnellzugriff","Acceso rápido","Accès rapide"),20,text,true));
        LinearLayout navRow=hrow();
        Button standings=btn("📊 "+t2("Table","Tablica","Tabelle","Tabla","Classement"));
        standings.setOnClickListener(v->showLeagueStandings(competitionName));
        Button rounds=outline("📅 "+t2("Rounds","Kola","Spieltage","Jornadas","Journées"));
        rounds.setOnClickListener(v->showCompetitionRounds(competitionName));
        navRow.addView(standings,new LinearLayout.LayoutParams(0,dp(56),1));
        LinearLayout.LayoutParams navGap=new LinearLayout.LayoutParams(0,dp(56),1);navGap.setMargins(dp(8),0,0,0);navRow.addView(rounds,navGap);
        navigation.addView(navRow);
        LinearLayout navRow2=hrow();
        Button results=outline("✅ "+t2("Results","Rezultati","Ergebnisse","Resultados","Résultats"));
        results.setOnClickListener(v->showCompetitionResults(competitionName));
        Button clubs=outline("🏆 "+t2(isNationalCompetition(competitionName)?"Best teams":"Best clubs",isNationalCompetition(competitionName)?"Najbolje reprezentacije":"Najbolji klubovi",isNationalCompetition(competitionName)?"Beste Teams":"Beste Klubs",isNationalCompetition(competitionName)?"Mejores selecciones":"Mejores clubes",isNationalCompetition(competitionName)?"Meilleures équipes":"Meilleurs clubs"));
        clubs.setOnClickListener(v->showCompetitionTopClubs(competitionName));
        navRow2.addView(results,new LinearLayout.LayoutParams(0,dp(56),1));
        LinearLayout.LayoutParams navGap2=new LinearLayout.LayoutParams(0,dp(56),1);navGap2.setMargins(dp(8),0,0,0);navRow2.addView(clubs,navGap2);
        LinearLayout.LayoutParams row2lp=new LinearLayout.LayoutParams(-1,-2);row2lp.setMargins(0,dp(8),0,0);navigation.addView(navRow2,row2lp);
        if(competitionName.equals("World Cup 2026")){
            Button groups=outline("🌍 "+t2("World Cup groups","Skupine Svjetskog prvenstva","WM-Gruppen","Grupos del Mundial","Groupes de la Coupe du monde"));
            groups.setOnClickListener(v->showGroups());navigation.addView(groups);
        }

        if(!connected){
            LinearLayout unavailable=card();
            unavailable.addView(label("🟠 "+t2("Waiting for the verified source","Čekanje provjerenog izvora","Warten auf verifizierte Quelle","Esperando la fuente verificada","En attente de la source vérifiée"),21,text,true));
            unavailable.addView(label(t2(
                    "Official data has not reached this device yet. Run the updater and refresh the app; Football Fun will not invent fixtures or standings.",
                    "Službeni podaci još nisu stigli na ovaj uređaj. Pokreni updater i osvježi aplikaciju; Football Fun neće izmišljati utakmice ni tablicu.",
                    "Offizielle Daten sind noch nicht auf diesem Gerät angekommen. Updater ausführen und App aktualisieren; Football Fun erfindet keine Spiele oder Tabellen.",
                    "Los datos oficiales aún no han llegado al dispositivo. Ejecuta el updater y actualiza la app; Football Fun no inventará partidos ni clasificaciones.",
                    "Les données officielles ne sont pas encore arrivées sur cet appareil. Lance l’updater puis actualise l’application; Football Fun n’inventera aucun match ni classement."),15,subText,false));
            return;
        }

        addCompetitionSeasonOverview(competitionName,competitionMatches,finished.size(),upcoming.size());
        if(!live.isEmpty())addCompetitionMatchPreview(competitionName,t2("Live now","Uživo sada","Jetzt live","En vivo ahora","En direct"),"🔴",live,3);
        if(!upcoming.isEmpty())addCompetitionMatchPreview(competitionName,t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),"📅",upcoming,5);
        if(!finished.isEmpty())addCompetitionMatchPreview(competitionName,t2("Latest results","Zadnji rezultati","Letzte Ergebnisse","Últimos resultados","Derniers résultats"),"✅",finished,3);

        if(competitionMatches.isEmpty()){
            LinearLayout empty=card();
            empty.addView(label("⚽ "+t2("No published matches yet","Još nema objavljenih utakmica","Noch keine veröffentlichten Spiele","Aún no hay partidos publicados","Aucun match publié"),21,text,true));
            empty.addView(label(t2("The center will populate automatically after the connected source publishes fixtures.","Centar će se automatski popuniti kada povezani izvor objavi raspored.","Das Zentrum füllt sich automatisch, sobald die Quelle Spielpläne veröffentlicht.","El centro se completará automáticamente cuando la fuente publique el calendario.","Le centre se remplira automatiquement lorsque la source publiera le calendrier."),15,subText,false));
        }

        addCompetitionStandingsPreview(competitionName);
        addCompetitionRoundPreview(competitionName,competitionMatches);
        addCompetitionTopClubsPreview(competitionName);

        LinearLayout trust=card();
        trust.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),20,text,true));
        trust.addView(label(lastUpdateLabel(prefs.getString("online_lastUpdate","")),13,subText,true));
        trust.addView(label(t2("Fixtures, results and standings are shown exactly as published by the connected source. Unconfirmed kick-off times are marked as Time TBA.","Raspored, rezultati i tablica prikazuju se točno kako ih objavi povezani izvor. Nepotvrđene satnice označene su kao Naknadno.","Spielpläne, Ergebnisse und Tabellen werden wie von der Quelle veröffentlicht angezeigt. Unbestätigte Anstoßzeiten werden als Offen markiert.","Calendario, resultados y clasificación se muestran tal como los publica la fuente. Las horas no confirmadas se marcan como Pendiente.","Calendrier, résultats et classement sont affichés tels que publiés par la source. Les horaires non confirmés sont indiqués À confirmer."),13,subText,false));
    }

    String competitionParticipantLabel(String competitionName){
        int published=competitionParticipantNames(competitionName).size();
        int count=published>0?published:CompetitionCatalog.get(competitionName).teamCount;
        return count+" "+t2(isNationalCompetition(competitionName)?"teams":"clubs",isNationalCompetition(competitionName)?"reprezentacija":"klubova",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"selecciones":"clubes",isNationalCompetition(competitionName)?"équipes":"clubs");
    }

    int competitionCurrentMatchday(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);if(entry==null)return 0;
        JSONObject season=entry.optJSONObject("season");return season==null?0:season.optInt("currentMatchday",0);
    }

    String competitionSeasonLabel(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);if(entry==null)return t2("Current season","Aktualna sezona","Aktuelle Saison","Temporada actual","Saison actuelle");
        JSONObject season=entry.optJSONObject("season");if(season==null)return t2("Current season","Aktualna sezona","Aktuelle Saison","Temporada actual","Saison actuelle");
        String start=season.optString("startDate","");String end=season.optString("endDate","");
        if(start.length()>=4&&end.length()>=4){
            String a=start.substring(0,4),b=end.substring(0,4);
            return a.equals(b)?a:a+"/"+b.substring(2);
        }
        return t2("Current season","Aktualna sezona","Aktuelle Saison","Temporada actual","Saison actuelle");
    }

    void addCompetitionSeasonOverview(String competitionName,ArrayList<Match> matches,int finishedCount,int upcomingCount){
        LinearLayout season=card();
        LinearLayout head=hrow();
        head.addView(label("📈 "+t2("Season overview","Pregled sezone","Saisonübersicht","Resumen de temporada","Aperçu de la saison"),21,text,true),new LinearLayout.LayoutParams(0,-2,1));
        head.addView(label(competitionSeasonLabel(competitionName),13,RED,true));season.addView(head);
        int total=matches==null?0:matches.size();int progress=total<=0?0:Math.min(100,Math.round((finishedCount*100f)/total));
        LinearLayout numbers=hrow();
        numbers.addView(homeStat(String.valueOf(finishedCount),t2("Played","Odigrano","Gespielt","Jugados","Joués"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        int matchday=competitionCurrentMatchday(competitionName);
        numbers.addView(homeStat(matchday>0?String.valueOf(matchday):"—",t2("Matchday","Kolo","Spieltag","Jornada","Journée"),null),middle);
        numbers.addView(homeStat(String.valueOf(upcomingCount),t2("Upcoming","Slijedi","Bevorstehend","Próximos","À venir"),null),new LinearLayout.LayoutParams(0,-2,1));
        season.addView(numbers);
        LinearLayout progressTrack=new LinearLayout(this);progressTrack.setOrientation(LinearLayout.HORIZONTAL);progressTrack.setBackground(round(chipBg,dp(7),0));
        View fill=new View(this);fill.setBackground(gradient(PURPLE_DARK,RED,dp(7)));progressTrack.addView(fill,new LinearLayout.LayoutParams(0,dp(10),progress));
        View rest=new View(this);progressTrack.addView(rest,new LinearLayout.LayoutParams(0,dp(10),Math.max(1,100-progress)));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(10));pp.setMargins(0,dp(12),0,dp(7));season.addView(progressTrack,pp);
        season.addView(label(progress+"%  "+t2("of published fixtures completed","objavljenog rasporeda završeno","der veröffentlichten Spiele abgeschlossen","del calendario publicado completado","du calendrier publié terminé"),12,subText,true));
    }

    String competitionRoundKey(Match match){
        if(match==null)return "";
        if(match.matchday>0)return t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+match.matchday;
        if(match.roundName!=null&&match.roundName.trim().length()>0)return match.roundName.trim();
        String stage=stageLabel(match);
        if(stage!=null&&stage.trim().length()>0)return stage.trim();
        if(match.group!=null&&match.group.trim().length()>0)return t2("Group ","Skupina ","Gruppe ","Grupo ","Groupe ")+match.group.trim();
        return t2("Published fixtures","Objavljeni raspored","Veröffentlichte Spiele","Calendario publicado","Calendrier publié");
    }

    LinkedHashMap<String,ArrayList<Match>> competitionMatchesByRound(String competitionName,boolean finishedOnly){
        LinkedHashMap<String,ArrayList<Match>> grouped=new LinkedHashMap<String,ArrayList<Match>>();
        for(Match match:matchesForCompetition(competitionName)){
            if(finishedOnly&&!matchIsFinished(match))continue;
            String key=competitionRoundKey(match);
            ArrayList<Match> list=grouped.get(key);
            if(list==null){list=new ArrayList<Match>();grouped.put(key,list);}
            list.add(match);
        }
        return grouped;
    }

    void addCompetitionRoundPreview(final String competitionName,ArrayList<Match> matches){
        LinearLayout preview=card();
        preview.addView(label("📅 "+t2("Fixtures by round","Raspored po kolima","Spielplan nach Spieltagen","Calendario por jornadas","Calendrier par journées"),22,text,true));
        LinkedHashMap<String,ArrayList<Match>> rounds=competitionMatchesByRound(competitionName,false);
        if(rounds.isEmpty())preview.addView(label(t2("No verified round data is available yet.","Još nema dostupnog provjerenog rasporeda po kolima.","Noch keine verifizierten Spieltagsdaten verfügbar.","Aún no hay jornadas verificadas disponibles.","Aucune journée vérifiée n’est encore disponible."),14,subText,false));
        else{
            int shown=0;
            for(Map.Entry<String,ArrayList<Match>> entry:rounds.entrySet()){
                TextView row=label(entry.getKey()+"  •  "+entry.getValue().size()+" "+t2("matches","utakmica","Spiele","partidos","matchs")+"   ›",15,text,true);
                row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(round(chipBg,dp(15),1));
                row.setOnClickListener(v->showCompetitionRounds(competitionName));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));preview.addView(row,lp);
                if(++shown>=3)break;
            }
        }
        Button all=outline(t2("Open full schedule by rounds","Otvori cijeli raspored po kolima","Vollständigen Spielplan öffnen","Abrir calendario completo por jornadas","Ouvrir le calendrier complet par journées"));
        all.setOnClickListener(v->showCompetitionRounds(competitionName));preview.addView(all);
    }

    void showCompetitionRounds(final String competitionName){
        clear(displayCompetitionName(competitionName),t2("Fixtures by round","Raspored po kolima","Spielplan nach Spieltagen","Calendario por jornadas","Calendrier par journées"),"Leagues");
        LinkedHashMap<String,ArrayList<Match>> rounds=competitionMatchesByRound(competitionName,false);
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));
        hero.addView(label("📅 "+displayCompetitionName(competitionName),24,Color.WHITE,true));
        hero.addView(label(rounds.size()+" "+t2("published rounds or stages","objavljenih kola ili faza","veröffentlichte Spieltage oder Phasen","jornadas o fases publicadas","journées ou phases publiées"),14,Color.WHITE,false));
        if(rounds.isEmpty()){
            LinearLayout empty=card();empty.addView(label(t2("The verified source has not published round information yet.","Provjereni izvor još nije objavio podatke o kolima.","Die verifizierte Quelle hat noch keine Spieltagsdaten veröffentlicht.","La fuente verificada aún no ha publicado las jornadas.","La source vérifiée n’a pas encore publié les journées."),15,subText,false));return;
        }
        for(Map.Entry<String,ArrayList<Match>> entry:rounds.entrySet()){
            LinearLayout section=card();
            LinearLayout head=hrow();head.addView(label(entry.getKey(),20,text,true),new LinearLayout.LayoutParams(0,-2,1));head.addView(label(String.valueOf(entry.getValue().size()),13,RED,true));section.addView(head);
            for(Match match:entry.getValue())addDynamicHomeMatch(section,match);
        }
    }

    void showCompetitionResults(final String competitionName){
        clear(displayCompetitionName(competitionName),t2("Results","Rezultati","Ergebnisse","Resultados","Résultats"),"Leagues");
        LinkedHashMap<String,ArrayList<Match>> rounds=competitionMatchesByRound(competitionName,true);
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));
        int count=0;for(ArrayList<Match> list:rounds.values())count+=list.size();
        hero.addView(label("✅ "+displayCompetitionName(competitionName),24,Color.WHITE,true));
        hero.addView(label(count+" "+t2("verified results","provjerenih rezultata","verifizierte Ergebnisse","resultados verificados","résultats vérifiés"),14,Color.WHITE,false));
        if(rounds.isEmpty()){
            LinearLayout empty=card();empty.addView(label(t2("No verified results are available yet.","Još nema dostupnih provjerenih rezultata.","Noch keine verifizierten Ergebnisse verfügbar.","Aún no hay resultados verificados.","Aucun résultat vérifié n’est disponible."),15,subText,false));return;
        }
        ArrayList<Map.Entry<String,ArrayList<Match>>> entries=new ArrayList<Map.Entry<String,ArrayList<Match>>>(rounds.entrySet());
        Collections.reverse(entries);
        for(Map.Entry<String,ArrayList<Match>> entry:entries){
            LinearLayout section=card();section.addView(label(entry.getKey(),20,text,true));
            ArrayList<Match> list=new ArrayList<Match>(entry.getValue());Collections.reverse(list);
            for(Match match:list)addDynamicHomeMatch(section,match);
        }
    }

    void addCompetitionTopClubsPreview(final String competitionName){
        LinearLayout preview=card();
        preview.addView(label("🏆 "+t2(isNationalCompetition(competitionName)?"Best teams":"Best clubs",isNationalCompetition(competitionName)?"Najbolje reprezentacije":"Najbolji klubovi",isNationalCompetition(competitionName)?"Beste Teams":"Beste Klubs",isNationalCompetition(competitionName)?"Mejores selecciones":"Mejores clubes",isNationalCompetition(competitionName)?"Meilleures équipes":"Meilleurs clubs"),22,text,true));
        JSONArray table=verifiedTotalStandingTable(competitionName);
        if(table==null||table.length()==0)preview.addView(label(t2("Top clubs will appear when the verified table is available.","Najbolji klubovi prikazat će se kada bude dostupna provjerena tablica.","Die besten Klubs erscheinen, sobald die verifizierte Tabelle verfügbar ist.","Los mejores clubes aparecerán cuando esté disponible la tabla verificada.","Les meilleurs clubs apparaîtront lorsque le classement vérifié sera disponible."),14,subText,false));
        else for(int i=0;i<Math.min(3,table.length());i++){JSONObject row=table.optJSONObject(i);if(row!=null)preview.addView(verifiedStandingRow(row));}
        Button all=outline(t2("Open best clubs","Otvori najbolje klubove","Beste Klubs öffnen","Abrir mejores clubes","Ouvrir les meilleurs clubs"));all.setOnClickListener(v->showCompetitionTopClubs(competitionName));preview.addView(all);
    }

    void showCompetitionTopClubs(final String competitionName){
        clear(displayCompetitionName(competitionName),t2(isNationalCompetition(competitionName)?"Best teams":"Best clubs",isNationalCompetition(competitionName)?"Najbolje reprezentacije":"Najbolji klubovi",isNationalCompetition(competitionName)?"Beste Teams":"Beste Klubs",isNationalCompetition(competitionName)?"Mejores selecciones":"Mejores clubes",isNationalCompetition(competitionName)?"Meilleures équipes":"Meilleurs clubs"),"Leagues");
        JSONArray table=verifiedTotalStandingTable(competitionName);
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));hero.addView(label("🏆 "+displayCompetitionName(competitionName),24,Color.WHITE,true));hero.addView(label(t2("Ranking based only on the verified competition table.","Poredak se temelji isključivo na provjerenoj tablici natjecanja.","Rangliste nur auf Basis der verifizierten Tabelle.","Clasificación basada solo en la tabla verificada.","Classement fondé uniquement sur le tableau vérifié."),14,Color.WHITE,false));
        if(table==null||table.length()==0){LinearLayout empty=card();empty.addView(label(t2("The verified table is not available yet.","Provjerena tablica još nije dostupna.","Die verifizierte Tabelle ist noch nicht verfügbar.","La tabla verificada aún no está disponible.","Le classement vérifié n’est pas encore disponible."),15,subText,false));return;}
        LinearLayout podium=card();podium.addView(verifiedStandingHeader());for(int i=0;i<table.length();i++){JSONObject row=table.optJSONObject(i);if(row!=null)podium.addView(verifiedStandingRow(row));}
    }

    ArrayList<String> competitionParticipantNames(String competitionName){
        LinkedHashSet<String> names=new LinkedHashSet<String>();
        JSONArray table=verifiedTotalStandingTable(competitionName);
        if(table!=null)for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);JSONObject team=row==null?null:row.optJSONObject("team");
            if(team==null)continue;String name=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();if(name.length()>0)names.add(name);
        }
        ArrayList<String> extras=new ArrayList<String>();
        for(Match match:matchesForCompetition(competitionName)){
            if(match.home!=null&&match.home.trim().length()>0&&!containsSameTeam(names,match.home))extras.add(match.home.trim());
            if(match.away!=null&&match.away.trim().length()>0&&!containsSameTeam(names,match.away))extras.add(match.away.trim());
        }
        Collections.sort(extras,(a,b)->displayTeamName(a).compareToIgnoreCase(displayTeamName(b)));
        for(String name:extras)if(!containsSameTeam(names,name))names.add(name);
        return new ArrayList<String>(names);
    }

    boolean containsSameTeam(Collection<String> names,String candidate){
        if(names==null||candidate==null)return false;for(String name:names)if(sameTeam(name,candidate))return true;return false;
    }

    int competitionStandingPosition(String competitionName,String teamName){
        JSONArray table=verifiedTotalStandingTable(competitionName);if(table==null)return 0;
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);JSONObject team=row==null?null:row.optJSONObject("team");if(team==null)continue;
            String name=team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(name,teamName))return row.optInt("position",i+1);
        }
        return 0;
    }

    void addCompetitionParticipantsPreview(final String competitionName){
        ArrayList<String> names=competitionParticipantNames(competitionName);
        LinearLayout preview=card();
        String title=t2(isNationalCompetition(competitionName)?"Teams":"Clubs",isNationalCompetition(competitionName)?"Reprezentacije":"Klubovi",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"Selecciones":"Clubes",isNationalCompetition(competitionName)?"Équipes":"Clubs");
        LinearLayout head=hrow();head.addView(label((isNationalCompetition(competitionName)?"🌍 ":"🛡️ ")+title,21,text,true),new LinearLayout.LayoutParams(0,-2,1));head.addView(label(String.valueOf(names.size()),13,RED,true));preview.addView(head);
        if(names.isEmpty())preview.addView(label(t2("Participants have not been published yet.","Sudionici još nisu objavljeni.","Teilnehmer wurden noch nicht veröffentlicht.","Los participantes aún no se han publicado.","Les participants ne sont pas encore publiés."),14,subText,false));
        else{
            int limit=Math.min(6,names.size());
            for(int i=0;i<limit;i++)addCompetitionParticipantRow(preview,competitionName,names.get(i),false);
        }
        Button all=outline(t2(isNationalCompetition(competitionName)?"View all teams":"View all clubs",isNationalCompetition(competitionName)?"Pogledaj sve reprezentacije":"Pogledaj sve klubove",isNationalCompetition(competitionName)?"Alle Teams anzeigen":"Alle Klubs anzeigen",isNationalCompetition(competitionName)?"Ver todas las selecciones":"Ver todos los clubes",isNationalCompetition(competitionName)?"Voir toutes les équipes":"Voir tous les clubs"));
        all.setOnClickListener(v->showCompetitionParticipants(competitionName));preview.addView(all);
    }

    void addCompetitionParticipantRow(LinearLayout parent,final String competitionName,final String participant,boolean full){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(full?11:8),dp(9),dp(full?11:8));row.setBackground(round(chipBg,dp(17),1));
        View crest=homeTeamVisual(participant,dp(full?52:40),false);row.addView(crest,new LinearLayout.LayoutParams(dp(full?52:40),dp(full?52:40)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(11),0,dp(5),0);copy.addView(label(displayTeamName(participant),full?16:14,text,true));
        int position=competitionStandingPosition(competitionName,participant);String meta=position>0?"#"+position+"  •  "+displayCompetitionName(competitionName):displayCompetitionName(competitionName);copy.addView(label(meta,11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        if(!isNationalCompetition(competitionName)&&full){
            boolean favorite=isFavoriteClubName(participant);TextView star=centerLabel(favorite?"★":"☆",23,favorite?GOLD:subText,true);star.setBackground(round(Color.rgb(29,34,48),dp(17),1));
            star.setOnClickListener(v->{toggleFavoriteClub(participant);showCompetitionParticipants(competitionName);});row.addView(star,new LinearLayout.LayoutParams(dp(48),dp(48)));
        }
        TextView arrow=centerLabel("›",23,RED,true);row.addView(arrow,new LinearLayout.LayoutParams(dp(34),dp(44)));
        row.setOnClickListener(v->{
            if(isNationalCompetition(competitionName)){competitionFilter=competitionName;matchFilter=participant;matchDateFilter="ALL";matchStatusFilter="All";matchFavoritesOnly=false;showMatches();}
            else showClubCenter(participant);
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    void showCompetitionParticipants(final String competitionName){
        String title=t2(isNationalCompetition(competitionName)?"Teams":"Clubs",isNationalCompetition(competitionName)?"Reprezentacije":"Klubovi",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"Selecciones":"Clubes",isNationalCompetition(competitionName)?"Équipes":"Clubs");
        ArrayList<String> names=competitionParticipantNames(competitionName);
        clear(title,displayCompetitionName(competitionName)+"  •  "+names.size(),"Leagues");
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(53,19,88),Color.rgb(221,28,87),dp(24)));
        hero.addView(label((isNationalCompetition(competitionName)?"🌍 ":"🛡️ ")+displayCompetitionName(competitionName),24,Color.WHITE,true));
        hero.addView(label(names.size()+" "+title.toLowerCase(homeLocale())+"  •  "+competitionDataStatus(competitionName),14,Color.WHITE,false));
        if(!isNationalCompetition(competitionName))hero.addView(label(t2("Tap a star to follow a club. Open any row for its full club center.","Dodirni zvjezdicu za praćenje kluba. Otvori redak za puni centar kluba.","Tippe auf den Stern, um einem Klub zu folgen. Öffne die Zeile für das Klubzentrum.","Toca la estrella para seguir un club. Abre la fila para ver su centro.","Touche l’étoile pour suivre un club. Ouvre la ligne pour son centre."),13,Color.WHITE,false));
        LinearLayout list=card();list.addView(label("⭐ "+title,21,text,true));
        if(names.isEmpty())list.addView(label(t2("No verified participants are available yet.","Još nema dostupnih provjerenih sudionika.","Noch keine verifizierten Teilnehmer verfügbar.","Aún no hay participantes verificados.","Aucun participant vérifié disponible."),14,subText,false));
        else for(String name:names)addCompetitionParticipantRow(list,competitionName,name,true);
    }

    ArrayList<Match> matchesForCompetition(String competitionName){
        ArrayList<Match> out=new ArrayList<>();
        for(Match m:data.matches)if(matchBelongsToCompetition(m,competitionName))out.add(m);
        Collections.sort(out,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return out;
    }

    void addCompetitionMatchPreview(String competitionName,String heading,String icon,ArrayList<Match> matches,int limit){
        LinearLayout section=card();
        section.addView(label(icon+" "+heading,22,text,true));
        int shown=0;
        for(Match m:matches){
            addDynamicHomeMatch(section,m);
            shown++;
            if(shown>=limit)break;
        }
        if(matches.size()>shown)section.addView(label("+"+(matches.size()-shown)+" "+t2("more matches","još utakmica","weitere Spiele","partidos más","matchs supplémentaires"),13,subText,true));
        Button all=outline(t2("View all competition matches","Pogledaj sve utakmice natjecanja","Alle Wettbewerbsspiele anzeigen","Ver todos los partidos","Voir tous les matchs"));
        all.setOnClickListener(v->{competitionFilter=competitionName;matchStatusFilter="All";matchDateFilter="ALL";matchFilter="";showMatches();});
        section.addView(all);
    }

    JSONArray verifiedTotalStandingTable(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null)return null;
        JSONArray standings=entry.optJSONArray("standings");
        if(standings==null)return null;
        for(int i=0;i<standings.length();i++){
            JSONObject standing=standings.optJSONObject(i);
            if(standing==null)continue;
            String type=standing.optString("type","");
            if(type.length()>0&&!type.equalsIgnoreCase("TOTAL"))continue;
            JSONArray table=standing.optJSONArray("table");
            if(table!=null&&table.length()>0)return table;
        }
        return null;
    }

    void addCompetitionStandingsPreview(String competitionName){
        JSONArray table=verifiedTotalStandingTable(competitionName);
        LinearLayout preview=card();
        preview.addView(label("📊 "+t2("Table snapshot","Sažetak tablice","Tabellenausschnitt","Resumen de tabla","Aperçu du classement"),22,text,true));
        if(table==null){
            preview.addView(label(t2("The verified table is still synchronizing. No placeholder positions are shown.","Provjerena tablica još se sinkronizira. Privremene ili izmišljene pozicije ne prikazuju se.","Die verifizierte Tabelle wird noch synchronisiert. Es werden keine Platzhalterpositionen gezeigt.","La tabla verificada aún se está sincronizando. No se muestran posiciones ficticias.","Le classement vérifié est encore en cours de synchronisation. Aucune position fictive n’est affichée."),15,subText,false));
        }else{
            preview.addView(verifiedStandingHeader());
            for(int i=0;i<Math.min(5,table.length());i++){
                JSONObject row=table.optJSONObject(i);
                if(row!=null)preview.addView(verifiedStandingRow(row));
            }
        }
        Button full=outline(t2("Open full verified table","Otvori cijelu provjerenu tablicu","Vollständige verifizierte Tabelle öffnen","Abrir tabla verificada completa","Ouvrir le classement vérifié complet"));
        full.setOnClickListener(v->showLeagueStandings(competitionName));
        preview.addView(full);
    }

    JSONObject cachedOnlineRoot(){
        try{
            String raw=prefs.getString("online_rawJson","");
            if(raw==null||raw.trim().length()==0)return null;
            JSONObject cached=onlineRootCache;
            if(cached!=null&&raw.equals(onlineRootCacheRaw))return cached;
            synchronized(this){
                cached=onlineRootCache;
                if(cached==null||!raw.equals(onlineRootCacheRaw)){
                    cached=new JSONObject(raw);
                    onlineRootCache=cached;
                    onlineRootCacheRaw=raw;
                }
            }
            return cached;
        }catch(Exception ignored){return null;}
    }

    JSONObject verifiedStandingsEntry(String competitionName){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return null;
        JSONObject all=root.optJSONObject("standings");
        if(all==null)return null;
        JSONObject entry=all.optJSONObject(competitionApiCode(competitionName));
        if(entry==null)return null;
        JSONArray tables=entry.optJSONArray("standings");
        return tables!=null&&tables.length()>0?entry:null;
    }

    boolean hasVerifiedStandings(String competitionName){return verifiedStandingsEntry(competitionName)!=null;}

    void showLeagueStandings(String competitionName){
        clear(competitionName,t2("Verified standings","Provjerena tablica","Verifizierte Tabelle","Clasificación verificada","Classement vérifié"),"Leagues");

        LinearLayout source=card();
        source.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),22,text,true));
        source.addView(label(t2(
                "Football Fun never fills missing positions or statistics with demo values.",
                "Football Fun nikada ne popunjava nedostajuća mjesta ili statistiku demonstracijskim vrijednostima.",
                "Football Fun füllt fehlende Plätze oder Statistiken niemals mit Demo-Werten.",
                "Football Fun nunca rellena posiciones o estadísticas faltantes con valores de demostración.",
                "Football Fun ne remplit jamais les données manquantes avec des valeurs de démonstration."),15,subText,false));

        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null){
            LinearLayout empty=card();
            if(competitionUsesFootballData(competitionName)){
                empty.addView(label("📊 "+t2("Standings are being synchronized","Tablica se sinkronizira","Tabelle wird synchronisiert","La clasificación se está sincronizando","Le classement se synchronise"),23,text,true));
                empty.addView(label(t2(
                        "Competition tables synchronize gradually. Refresh again later; no invented standings are shown while waiting.",
                        "Tablice natjecanja sinkroniziraju se postupno. Osvježi ponovno kasnije; dok čekamo, ne prikazujemo izmišljene pozicije.",
                        "Wettbewerbstabellen werden schrittweise synchronisiert. Aktualisiere später erneut; es werden keine erfundenen Tabellen angezeigt.",
                        "Las clasificaciones se sincronizan gradualmente. Actualiza más tarde; no se muestran tablas inventadas.",
                        "Les classements se synchronisent progressivement. Actualise plus tard; aucun faux classement n’est affiché."),15,subText,false));
                Button refresh=btn("🔄 "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"));
                refresh.setOnClickListener(v->refreshOnlineSafe(true));
                empty.addView(refresh);
            }else{
                empty.addView(label("🇭🇷 "+t2("Official HNL table is waiting to synchronize","Čekanje sinkronizacije službene HNL tablice","Offizielle HNL-Tabelle wartet auf Synchronisierung","Esperando la tabla oficial de HNL","Classement officiel HNL en attente"),23,text,true));
                empty.addView(label(t2("Run the data updater and refresh the app. Existing verified data is kept if the official page is temporarily unavailable.","Pokreni podatkovni updater i osvježi aplikaciju. Postojeći provjereni podaci ostaju sačuvani ako službena stranica privremeno nije dostupna.","Daten-Updater ausführen und App aktualisieren. Verifizierte Daten bleiben bei vorübergehendem Ausfall erhalten.","Ejecuta el updater y actualiza la app. Los datos verificados se conservan si la página oficial no está disponible.","Lance l’updater puis actualise l’application. Les données vérifiées sont conservées si la page officielle est indisponible."),15,subText,false));
            }
            return;
        }

        if(competitionName.equals("HNL"))source.addView(label("🛡️ "+t2("Official SuperSport HNL / HNS table","Službena tablica SuperSport HNL / HNS","Offizielle SuperSport-HNL-/HNS-Tabelle","Tabla oficial SuperSport HNL / HNS","Classement officiel SuperSport HNL / HNS"),13,GREEN,true));
        String updated=entry.optString("updatedAt",prefs.getString("online_lastUpdate",""));
        JSONObject season=entry.optJSONObject("season");
        int matchday=season==null?0:season.optInt("currentMatchday",0);
        source.addView(label(t2("Verified standings","Provjerena tablica","Verifizierte Tabelle","Clasificación verificada","Classement vérifié")+(matchday>0?"  •  "+t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+matchday:"")+"\n"+lastUpdateLabel(updated),13,subText,false));

        JSONArray standings=entry.optJSONArray("standings");
        boolean rendered=false;
        for(int i=0;i<standings.length();i++){
            JSONObject standing=standings.optJSONObject(i);
            if(standing==null)continue;
            String type=standing.optString("type","");
            if(type.length()>0&&!type.equalsIgnoreCase("TOTAL"))continue;
            JSONArray table=standing.optJSONArray("table");
            if(table==null||table.length()==0)continue;
            rendered=true;
            String group=standing.optString("group","");
            String stage=normalizeStage(standing.optString("stage",""));
            LinearLayout tableCard=card();
            String heading=(group!=null&&group.trim().length()>0)?group.replace('_',' '):(stage.length()>0?stage:t2("Overall table","Ukupna tablica","Gesamttabelle","Tabla general","Classement général"));
            tableCard.addView(label("🏆 "+heading,21,text,true));
            tableCard.addView(verifiedStandingHeader());
            for(int j=0;j<table.length();j++){
                JSONObject row=table.optJSONObject(j);
                if(row!=null)tableCard.addView(verifiedStandingRow(row));
            }
        }

        if(!rendered){
            LinearLayout empty=card();
            empty.addView(label(t2("The source returned no overall table for this competition.","Izvor nije vratio ukupnu tablicu za ovo natjecanje.","Die Quelle lieferte keine Gesamttabelle für diesen Wettbewerb.","La fuente no devolvió una tabla general para esta competición.","La source n’a fourni aucun classement général pour cette compétition."),15,subText,false));
        }
    }

    LinearLayout verifiedStandingHeader(){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(8),dp(6),dp(8));
        row.setBackground(round(chipBg,dp(12),0));
        row.addView(standingCell("#",11,subText,true,dp(30),0));
        row.addView(standingCell(t2("TEAM","KLUB","TEAM","EQUIPO","ÉQUIPE"),11,subText,true,0,1));
        row.addView(standingCell("P",11,subText,true,dp(34),0));
        row.addView(standingCell("GD",11,subText,true,dp(42),0));
        row.addView(standingCell("PTS",11,subText,true,dp(44),0));
        return row;
    }

    LinearLayout verifiedStandingRow(JSONObject item){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(9),dp(6),dp(9));
        JSONObject team=item.optJSONObject("team");
        String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
        boolean favourite=sameTeam(teamName,primaryFavoriteClub());
        if(favourite)row.setBackground(round(Color.argb(42,255,48,94),dp(12),1));
        row.addView(standingCell(String.valueOf(item.optInt("position",0)),13,favourite?RED:subText,true,dp(30),0));
        row.addView(standingCell(teamName,14,text,favourite,0,1));
        row.addView(standingCell(String.valueOf(item.optInt("playedGames",0)),13,text,false,dp(34),0));
        int gd=item.optInt("goalDifference",0);
        row.addView(standingCell((gd>0?"+":"")+gd,13,gd>0?GREEN:(gd<0?RED:subText),true,dp(42),0));
        row.addView(standingCell(String.valueOf(item.optInt("points",0)),14,text,true,dp(44),0));
        return row;
    }

    TextView standingCell(String value,int sp,int color,boolean bold,int widthDp,int weight){
        TextView view=label(value,sp,color,bold);
        view.setGravity(widthDp>0?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        view.setSingleLine(true);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp=weight>0?new LinearLayout.LayoutParams(0,dp(38),weight):new LinearLayout.LayoutParams(widthDp,dp(38));
        view.setLayoutParams(lp);
        return view;
    }

    void showLeagueStats(String competitionName){
        clear(competitionName,t2("Verified competition statistics","Provjerena statistika natjecanja","Verifizierte Wettbewerbsstatistik","Estadísticas verificadas","Statistiques vérifiées"),"Leagues");
        LinearLayout c=card();
        c.addView(label("🛡️ "+t2("No placeholder statistics","Bez izmišljene statistike","Keine Platzhalter-Statistik","Sin estadísticas inventadas","Aucune statistique fictive"),23,text,true));
        c.addView(label(t2("Top scorers, assists and trends will appear only after the connected source publishes them.","Najbolji strijelci, asistencije i trendovi pojavit će se tek kada ih povezani izvor objavi.","Torschützen, Assists und Trends erscheinen erst, wenn die verbundene Quelle sie veröffentlicht.","Goleadores, asistencias y tendencias aparecerán solo cuando la fuente conectada los publique.","Buteurs, passes décisives et tendances apparaîtront uniquement lorsque la source les publiera."),15,subText,false));
    }

    String followedCompetitionText(){
        if(followedCompetitions==null || followedCompetitions.isEmpty()) return t2("No competitions followed yet","Još ne pratiš nijedno natjecanje","Noch keine Wettbewerbe gefolgt","Aún no sigues competiciones","Aucune compétition suivie");
        StringBuilder b=new StringBuilder();
        for(String c:followedCompetitions){if(b.length()>0)b.append("  •  ");b.append(c);}
        return b.toString();
    }

    String favoriteClubText(){
        if(favoriteClubs==null || favoriteClubs.isEmpty()) return favoriteClub;
        StringBuilder b=new StringBuilder(); int i=0;
        for(String c:favoriteClubs){ if(i>0)b.append(" • "); b.append(displayTeamName(c)); i++; if(i>=3){ if(favoriteClubs.size()>3)b.append(" +").append(favoriteClubs.size()-3); break; } }
        return b.toString();
    }

    void toggleFavoriteClub(String club){
        if(club==null||club.trim().length()==0)return;
        String name=club.trim();
        if(favoriteClubs.contains(name)){
            if(favoriteClubs.size()<=1){
                toast(t2("Keep at least one favorite club","Zadrži barem jedan omiljeni klub","Behalte mindestens einen Lieblingsklub","Mantén al menos un club favorito","Garde au moins un club favori"));
                return;
            }
            favoriteClubs.remove(name);
            if(sameTeam(name,favoriteClub))favoriteClub=favoriteClubs.iterator().next();
        }else favoriteClubs.add(name);
        userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
        invalidateClubProfileCache();
        syncMatchReminders();
    }

    void makePrimaryClub(String club){
        if(club==null||club.trim().length()==0)return;
        String name=club.trim();
        favoriteClubs.add(name);
        favoriteClub=name;
        userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
        userPreferences.savePrimaryClub(favoriteClub);
        invalidateClubProfileCache();
        syncMatchReminders();
    }

    ArrayList<String> clubCompetitionOptions(ArrayList<ClubProfile> clubs){
        LinkedHashSet<String> values=new LinkedHashSet<String>();
        for(ClubProfile club:clubs)if(club.competition!=null&&club.competition.length()>0)values.add(club.competition);
        return new ArrayList<String>(values);
    }

    boolean clubMatchesPicker(ClubProfile club,String query,String competition){
        if(club==null)return false;
        if(competition!=null&&!competition.equals("ALL")&&!competition.equals(club.competition))return false;
        String q=query==null?"":query.trim().toLowerCase(homeLocale());
        if(q.length()==0)return true;
        String hay=(club.name+" "+displayTeamName(club.name)+" "+club.competition+" "+club.country).toLowerCase(homeLocale());
        return hay.contains(q);
    }

    boolean isFavoriteClubName(String name){
        if(name==null||favoriteClubs==null)return false;
        for(String favorite:favoriteClubs)if(sameTeam(favorite,name))return true;
        return false;
    }

    String compactCompetitionName(String competition){
        if(competition==null||competition.trim().length()==0)return t2("Club","Klub","Klub","Club","Club");
        if(competition.equals("UEFA Champions League"))return t2("Champions League","Liga prvaka","Champions League","Champions League","Ligue des champions");
        if(competition.equals("Brasileirão Série A"))return "Brasileirão A";
        if(competition.equals("UEFA European Championship"))return t2("European Championship","Europsko prvenstvo","Europameisterschaft","Eurocopa","Championnat d’Europe");
        return displayCompetitionName(competition);
    }

    TextView clubPickerSectionLabel(String value){
        TextView heading=label(value,12,subText,true);
        heading.setAllCaps(true);
        heading.setPadding(dp(4),dp(12),dp(4),dp(5));
        return heading;
    }

    void renderClubPicker(LinearLayout target){
        target.removeAllViews();
        ArrayList<ClubProfile> clubs=availableClubProfiles();
        ArrayList<ClubProfile> filtered=new ArrayList<ClubProfile>();
        for(ClubProfile club:clubs)if(clubMatchesPicker(club,favoriteClubSearch,favoriteClubCompetitionFilter))filtered.add(club);
        Collections.sort(filtered,(a,b)->{
            boolean ap=sameTeam(a.name,favoriteClub),bp=sameTeam(b.name,favoriteClub);
            if(ap!=bp)return ap?-1:1;
            boolean af=isFavoriteClubName(a.name),bf=isFavoriteClubName(b.name);
            if(af!=bf)return af?-1:1;
            int byCompetition=a.competition.compareToIgnoreCase(b.competition);
            return byCompetition!=0?byCompetition:a.name.compareToIgnoreCase(b.name);
        });
        if(filtered.isEmpty()){
            LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(24),dp(12),dp(18));
            empty.addView(centerLabel("⚽",34,text,true));
            empty.addView(centerLabel(t2("No clubs found","Nema pronađenih klubova","Keine Klubs gefunden","No se encontraron clubes","Aucun club trouvé"),16,text,true));
            empty.addView(centerLabel(t2("Try another name or competition.","Pokušaj drugi naziv ili natjecanje.","Versuche einen anderen Namen oder Wettbewerb.","Prueba otro nombre o competición.","Essaie un autre nom ou une autre compétition."),12,subText,false));
            target.addView(empty);
            return;
        }

        int shown=Math.min(favoriteClubPickerLimit,filtered.size());
        boolean broad=favoriteClubSearch.trim().length()==0&&favoriteClubCompetitionFilter.equals("ALL");
        boolean followingHeadingShown=false,allHeadingShown=false;
        int followedVisible=0;for(int i=0;i<shown;i++)if(isFavoriteClubName(filtered.get(i).name))followedVisible++;
        for(int i=0;i<shown;i++){
            ClubProfile profile=filtered.get(i);
            boolean followed=isFavoriteClubName(profile.name);
            if(broad&&followed&&!followingHeadingShown){
                target.addView(clubPickerSectionLabel(t2("Following","Pratim","Gefolgt","Siguiendo","Suivis")+"  "+followedVisible));
                followingHeadingShown=true;
            }
            if(broad&&!followed&&!allHeadingShown){
                target.addView(clubPickerSectionLabel(t2("All clubs","Svi klubovi","Alle Klubs","Todos los clubes","Tous les clubs")));
                allHeadingShown=true;
            }
            target.addView(favoriteClubPickerRow(profile));
        }
        if(filtered.size()>shown){
            Button more=outline(t2("Show more clubs","Prikaži još klubova","Mehr Klubs anzeigen","Mostrar más clubes","Afficher plus de clubs")+"  +"+(filtered.size()-shown));
            more.setOnClickListener(v->{favoriteClubPickerLimit+=30;renderClubPicker(target);});
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(50));mp.setMargins(0,dp(8),0,0);target.addView(more,mp);
        }
        TextView count=label(shown+" / "+filtered.size()+" "+t2("clubs shown","klubova prikazano","Klubs angezeigt","clubes mostrados","clubs affichés"),11,subText,false);
        count.setPadding(dp(4),dp(9),dp(4),0);target.addView(count);
    }

    LinearLayout favoriteClubPickerRow(ClubProfile profile){
        final String clubName=profile.name;
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(9),dp(9),dp(9));
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(round(chipBg,dp(18),1));
        row.setClickable(true);
        row.setOnClickListener(v->showClubCenter(clubName));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(4),0,dp(4));row.setLayoutParams(rp);

        View visual=homeTeamVisual(clubName,dp(54),false);
        row.addView(visual,new LinearLayout.LayoutParams(dp(54),dp(54)));

        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(5),0);
        String visibleClubName=displayTeamName(clubName);
        TextView name=label(visibleClubName,visibleClubName.length()>24?13:15,text,true);
        name.setSingleLine(false);name.setMaxLines(2);name.setEllipsize(null);name.setLineSpacing(0,0.94f);
        copy.addView(name);
        boolean primary=sameTeam(clubName,favoriteClub);
        String meta=(primary?"★ "+t2("Primary","Glavni","Haupt","Principal","Principal")+"  •  ":clubCountryFlag(clubName)+" ")+compactCompetitionName(profile.competition);
        TextView metaView=label(meta,11,primary?RED:subText,primary);metaView.setSingleLine(true);metaView.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(metaView);
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));

        boolean selected=isFavoriteClubName(clubName);
        Button follow=selected?btn("✓"):outline("＋");follow.setTextSize(17);follow.setPadding(0,0,0,0);
        follow.setContentDescription(selected?t2("Stop following club","Prestani pratiti klub","Klub nicht mehr folgen","Dejar de seguir club","Ne plus suivre le club"):t2("Follow club","Prati klub","Klub folgen","Seguir club","Suivre le club"));
        follow.setOnClickListener(v->{toggleFavoriteClub(clubName);showFavorites();});
        row.addView(follow,new LinearLayout.LayoutParams(dp(50),dp(50)));

        Button primaryButton=outline(primary?"★":"☆");primaryButton.setTextSize(20);primaryButton.setPadding(0,0,0,0);
        primaryButton.setEnabled(!primary);primaryButton.setContentDescription(t2("Set as primary club","Postavi kao glavni klub","Als Hauptklub festlegen","Establecer como club principal","Définir comme club principal"));
        primaryButton.setOnClickListener(v->{makePrimaryClub(clubName);showFavorites();});
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(50),dp(50));pp.setMargins(dp(6),0,0,0);row.addView(primaryButton,pp);
        return row;
    }

    ArrayList<Match> clubMatches(String club){
        ArrayList<Match> matches=new ArrayList<Match>();
        if(data!=null)for(Match match:data.matches)if(sameTeam(match.home,club)||sameTeam(match.away,club))matches.add(match);
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return matches;
    }

    Match lastResultForClub(String club){
        Match result=null;
        for(Match match:clubMatches(club))if(matchIsFinished(match))result=match;
        return result;
    }

    String clubStandingPosition(String club){
        String league=clubLeague(club);
        JSONArray table=verifiedTotalStandingTable(league);
        if(table==null)return "—";
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);if(row==null)continue;
            JSONObject team=row.optJSONObject("team");
            String name=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(name,club))return String.valueOf(row.optInt("position",i+1))+".";
        }
        return "—";
    }

    JSONObject clubStandingRow(String club){
        JSONArray table=verifiedTotalStandingTable(clubLeague(club));
        if(table==null)return null;
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);if(row==null)continue;
            JSONObject team=row.optJSONObject("team");
            String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(teamName,club))return row;
        }
        return null;
    }

    String signedNumber(int value){return value>0?"+"+value:String.valueOf(value);}

    String clubResultCode(Match match,String club){
        if(match==null||!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)return "—";
        if(match.homeGoals==match.awayGoals)return "D";
        boolean home=sameTeam(match.home,club);
        boolean won=home?match.homeGoals>match.awayGoals:match.awayGoals>match.homeGoals;
        return won?"W":"L";
    }

    ArrayList<Match> finishedClubMatches(String club){
        ArrayList<Match> finished=new ArrayList<Match>();
        for(Match match:clubMatches(club))if(matchIsFinished(match))finished.add(match);
        return finished;
    }

    void addClubFormStrip(LinearLayout target,String club){
        ArrayList<Match> finished=finishedClubMatches(club);
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);
        int first=Math.max(0,finished.size()-5);
        if(first>=finished.size()){
            row.addView(label(t2("Verified form is not available yet.","Provjerena forma još nije dostupna.","Verifizierte Form ist noch nicht verfügbar.","La forma verificada aún no está disponible.","La forme vérifiée n’est pas encore disponible."),13,subText,false));
        }else{
            for(int i=first;i<finished.size();i++){
                String code=clubResultCode(finished.get(i),club);
                int color=code.equals("W")?GREEN:(code.equals("L")?RED:Color.rgb(113,124,145));
                TextView chip=centerLabel(code,14,Color.WHITE,true);chip.setBackground(round(color,dp(22),1));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(44),dp(44));if(i>first)lp.setMargins(dp(8),0,0,0);row.addView(chip,lp);
            }
        }
        target.addView(row);
    }


    void addClubMatchSection(String titleText,String icon,ArrayList<Match> matches,int limit){
        LinearLayout section=card();section.addView(label(icon+" "+titleText,21,text,true));
        if(matches.isEmpty())section.addView(label(t2("No verified matches are available yet.","Još nema dostupnih provjerenih utakmica.","Noch keine verifizierten Spiele verfügbar.","Aún no hay partidos verificados.","Aucun match vérifié disponible."),14,subText,false));
        else{
            int shown=0;
            for(Match match:matches){addDynamicHomeMatch(section,match);if(++shown>=limit)break;}
        }
    }

    void showClubCenter(String club){
        String name=club==null?primaryFavoriteClub():club;
        String league=clubLeague(name);
        clear(displayTeamName(name),clubCountryFlag(name)+" "+clubCountry(name)+"  •  "+league,"Favorites");

        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(55,16,82),Color.rgb(235,31,86),dp(24)));
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);
        View visual=homeTeamVisual(name,dp(96),true);row.addView(visual,new LinearLayout.LayoutParams(dp(96),dp(96)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(14),0,0,0);
        copy.addView(label(sameTeam(name,favoriteClub)?t2("PRIMARY CLUB","GLAVNI KLUB","HAUPTKLUB","CLUB PRINCIPAL","CLUB PRINCIPAL"):t2("CLUB CENTER","CENTAR KLUBA","KLUBZENTRUM","CENTRO DEL CLUB","CENTRE DU CLUB"),12,Color.WHITE,true));
        copy.addView(label(displayTeamName(name),25,Color.WHITE,true));
        copy.addView(label(clubCountryFlag(name)+" "+league,14,Color.WHITE,true));
        copy.addView(label("● "+competitionDataStatus(league),12,Color.rgb(255,224,133),true));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(row);

        LinearLayout actions=hrow();
        Button follow=isFavoriteClubName(name)?outline("✓ "+t2("Following","Pratim","Gefolgt","Siguiendo","Suivi")):btn("＋ "+t2("Follow club","Prati klub","Klub folgen","Seguir club","Suivre le club"));
        follow.setOnClickListener(v->{toggleFavoriteClub(name);showClubCenter(name);});actions.addView(follow,new LinearLayout.LayoutParams(0,dp(52),1));
        Button primary=sameTeam(name,favoriteClub)?outline("★ "+t2("Primary","Glavni","Haupt","Principal","Principal")):outline("☆ "+t2("Set primary","Postavi kao glavni","Als Hauptklub","Hacer principal","Définir principal"));
        primary.setEnabled(!sameTeam(name,favoriteClub));primary.setOnClickListener(v->{makePrimaryClub(name);showClubCenter(name);});
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(52),1);ap.setMargins(dp(8),0,0,0);actions.addView(primary,ap);hero.addView(actions);

        LinearLayout quick=card();quick.addView(label("⚡ "+t2("Quick access","Brzi pristup","Schnellzugriff","Acceso rápido","Accès rapide"),21,text,true));
        LinearLayout quickRow=hrow();
        Button matches=outline("⚽ "+t2("Matches","Utakmice","Spiele","Partidos","Matchs"));
        matches.setOnClickListener(v->{matchFilter=name;competitionFilter="All";matchDateFilter="ALL";matchStatusFilter="All";showMatches();});quickRow.addView(matches,new LinearLayout.LayoutParams(0,dp(52),1));
        Button table=outline("📊 "+t2("Table","Tablica","Tabelle","Tabla","Classement"));
        table.setEnabled(hasVerifiedStandings(league));table.setOnClickListener(v->showLeagueStandings(league));
        LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(52),1);qp.setMargins(dp(7),0,dp(7),0);quickRow.addView(table,qp);
        Button competition=outline("🏆 "+t2("League","Liga","Liga","Liga","Ligue"));competition.setOnClickListener(v->showCompetitionHub(league,competitionRegion(league)));quickRow.addView(competition,new LinearLayout.LayoutParams(0,dp(52),1));quick.addView(quickRow);

        JSONObject standing=clubStandingRow(name);
        LinearLayout season=card();season.addView(label("📈 "+t2("Season overview","Pregled sezone","Saisonübersicht","Resumen de temporada","Aperçu de la saison"),21,text,true));
        LinearLayout statsTop=hrow();
        String position=standing==null?"—":String.valueOf(standing.optInt("position",0))+".";
        String played=standing==null?"—":String.valueOf(standing.optInt("playedGames",0));
        String points=standing==null?"—":String.valueOf(standing.optInt("points",0));
        String gd=standing==null?"—":signedNumber(standing.optInt("goalDifference",0));
        statsTop.addView(homeStat(position,t2("Position","Pozicija","Position","Posición","Position"),standing==null?null:v->showLeagueStandings(league)),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams sm=new LinearLayout.LayoutParams(0,-2,1);sm.setMargins(dp(7),0,dp(7),0);
        statsTop.addView(homeStat(played,t2("Played","Odigrano","Gespielt","Jugados","Joués"),null),sm);
        statsTop.addView(homeStat(points,t2("Points","Bodovi","Punkte","Puntos","Points"),null),new LinearLayout.LayoutParams(0,-2,1));season.addView(statsTop);
        LinearLayout statsBottom=hrow();
        statsBottom.addView(homeStat(gd,t2("Goal diff.","Gol-razlika","Tordifferenz","Dif. goles","Diff. buts"),null),new LinearLayout.LayoutParams(0,-2,1));
        String record=standing==null?"—":standing.optInt("won",0)+"-"+standing.optInt("draw",0)+"-"+standing.optInt("lost",0);
        LinearLayout.LayoutParams rm=new LinearLayout.LayoutParams(0,-2,2);rm.setMargins(dp(7),0,0,0);
        statsBottom.addView(homeStat(record,t2("W-D-L","P-N-I","S-U-N","G-E-P","V-N-D"),null),rm);season.addView(statsBottom);
        season.addView(label(t2("Last five verified matches","Zadnjih pet provjerenih utakmica","Letzte fünf verifizierte Spiele","Últimos cinco partidos verificados","Cinq derniers matchs vérifiés"),13,subText,true));
        addClubFormStrip(season,name);
        if(standing==null)season.addView(label(t2("The verified table is still synchronizing; no temporary statistics are shown.","Provjerena tablica još se sinkronizira; privremena statistika se ne prikazuje.","Die verifizierte Tabelle wird noch synchronisiert; keine temporären Statistiken werden angezeigt.","La tabla verificada aún se sincroniza; no se muestran estadísticas temporales.","Le classement vérifié se synchronise encore; aucune statistique temporaire n’est affichée."),12,subText,false));

        Match next=nextMatchForTeam(name);
        LinearLayout nextCard=card();nextCard.addView(label("⏭️ "+t2("Next match","Sljedeća utakmica","Nächstes Spiel","Próximo partido","Prochain match"),21,text,true));
        if(next!=null)addDynamicHomeMatch(nextCard,next);else nextCard.addView(label(t2("No upcoming verified match is available.","Nema dostupne sljedeće provjerene utakmice.","Kein nächstes verifiziertes Spiel verfügbar.","No hay próximo partido verificado.","Aucun prochain match vérifié disponible."),14,subText,false));

        ArrayList<Match> recent=new ArrayList<Match>();
        ArrayList<Match> upcoming=new ArrayList<Match>();
        for(Match match:clubMatches(name)){if(matchIsFinished(match))recent.add(0,match);else if(!matchIsLive(match))upcoming.add(match);}
        if(recent.size()>5)recent=new ArrayList<Match>(recent.subList(0,5));
        if(upcoming.size()>5)upcoming=new ArrayList<Match>(upcoming.subList(0,5));
        addClubMatchSection(t2("Recent results","Zadnji rezultati","Letzte Ergebnisse","Resultados recientes","Résultats récents"),"✅",recent,5);
        addClubMatchSection(t2("Upcoming fixtures","Nadolazeće utakmice","Kommende Spiele","Próximos partidos","Prochains matchs"),"📅",upcoming,5);

        LinearLayout competitionCard=card();competitionCard.addView(label("🏆 "+displayCompetitionName(league),21,text,true));
        competitionCard.addView(label(clubCountryFlag(name)+" "+clubCountry(name)+"  •  "+competitionDataStatus(league),14,subText,false));
        Button open=outline(t2("Open competition center","Otvori centar natjecanja","Wettbewerbszentrum öffnen","Abrir competición","Ouvrir la compétition"));open.setOnClickListener(v->showCompetitionHub(league,competitionRegion(league)));competitionCard.addView(open);
    }

    void showFavorites(){
        clear(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),t2("Your personal football feed","Tvoj osobni nogometni sadržaj","Dein persönlicher Fußball-Feed","Tu contenido personalizado","Ton fil football personnel"),"Favorites");
        String club=primaryFavoriteClub();

        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(69,18,88),Color.rgb(245,36,91),dp(24)));
        LinearLayout heroRow=hrow();
        View clubLogo=homeTeamVisual(club,dp(86),true);heroRow.addView(clubLogo,new LinearLayout.LayoutParams(dp(86),dp(86)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(12),0,0,0);
        heroCopy.addView(label(t2("PRIMARY FAVORITE","GLAVNI FAVORIT","HAUPTFAVORIT","FAVORITO PRINCIPAL","FAVORI PRINCIPAL"),12,Color.WHITE,true));
        heroCopy.addView(label(displayTeamName(club),24,Color.WHITE,true));
        heroCopy.addView(label(clubCountryFlag(club)+" "+clubLeague(club),15,Color.WHITE,true));
        heroRow.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(heroRow);
        Button openClub=outline(t2("Open club center","Otvori centar kluba","Klubzentrum öffnen","Abrir centro del club","Ouvrir le centre du club"));openClub.setOnClickListener(v->showClubCenter(club));hero.addView(openClub);

        LinearLayout selectedClubs=card();selectedClubs.addView(label("⭐ "+t2("Clubs you follow","Klubovi koje pratiš","Gefolgte Klubs","Clubes que sigues","Clubs suivis"),21,text,true));
        for(String selectedClub:favoriteClubs){
            final String selectedName=selectedClub;
            LinearLayout selectedRow=hrow();selectedRow.setPadding(dp(9),dp(9),dp(9),dp(9));selectedRow.setGravity(Gravity.CENTER_VERTICAL);selectedRow.setBackground(round(chipBg,dp(17),1));
            View selectedVisual=homeTeamVisual(selectedName,dp(46),false);selectedRow.addView(selectedVisual,new LinearLayout.LayoutParams(dp(46),dp(46)));
            LinearLayout selectedCopy=new LinearLayout(this);selectedCopy.setOrientation(LinearLayout.VERTICAL);selectedCopy.setPadding(dp(11),0,0,0);selectedCopy.addView(label(displayTeamName(selectedName),15,text,true));selectedCopy.addView(label((sameTeam(selectedName,favoriteClub)?"★ "+t2("Primary","Glavni","Haupt","Principal","Principal")+"  •  ":"")+clubLeague(selectedName),12,sameTeam(selectedName,favoriteClub)?RED:subText,true));selectedRow.addView(selectedCopy,new LinearLayout.LayoutParams(0,-2,1));
            TextView openSelected=label("›",25,RED,true);openSelected.setGravity(Gravity.CENTER);selectedRow.addView(openSelected,new LinearLayout.LayoutParams(dp(42),dp(42)));selectedRow.setOnClickListener(v->showClubCenter(selectedName));
            LinearLayout.LayoutParams selectedLp=new LinearLayout.LayoutParams(-1,-2);selectedLp.setMargins(0,dp(4),0,dp(4));selectedClubs.addView(selectedRow,selectedLp);
        }

        LinearLayout followed=card();followed.addView(label("🏆 "+t2("Followed competitions","Natjecanja koja pratiš","Gefolgte Wettbewerbe","Competiciones seguidas","Compétitions suivies"),21,text,true));
        if(followedCompetitions.isEmpty())followed.addView(label(t2("No competitions followed yet.","Još ne pratiš nijedno natjecanje.","Noch keine Wettbewerbe gefolgt.","Aún no sigues competiciones.","Aucune compétition suivie."),14,subText,false));
        else for(String comp:followedCompetitions){final String cn=comp;TextView competitionRow=label(competitionIcon(comp)+"  "+displayCompetitionName(comp)+"   ›",15,text,true);competitionRow.setPadding(dp(10),dp(11),dp(10),dp(11));competitionRow.setBackground(round(chipBg,dp(15),0));competitionRow.setOnClickListener(v->showCompetitionHub(cn,competitionRegion(cn)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));followed.addView(competitionRow,lp);}

        LinearLayout choose=card();
        choose.addView(label("⭐ "+t2("Club directory","Imenik klubova","Klubverzeichnis","Directorio de clubes","Annuaire des clubs"),21,text,true));
        choose.addView(label(t2("Search verified clubs, follow several and choose one primary club. Every change is saved automatically.","Pretraži dostupne klubove, prati ih više i odaberi jedan glavni klub. Svaka promjena sprema se automatski.","Suche verfügbare Klubs, folge mehreren und wähle einen Hauptklub. Jede Änderung wird automatisch gespeichert.","Busca clubes, sigue varios y elige uno principal. Cada cambio se guarda automáticamente.","Recherche des clubs, suis-en plusieurs et choisis un club principal. Chaque modification est enregistrée automatiquement."),13,subText,false));
        LinearLayout actionLegend=hrow();actionLegend.setPadding(dp(4),dp(7),dp(4),dp(8));
        TextView followLegend=label("＋ "+t2("Follow","Prati","Folgen","Seguir","Suivre"),11,subText,true);actionLegend.addView(followLegend,new LinearLayout.LayoutParams(0,-2,1));
        TextView primaryLegend=label("☆ "+t2("Set as primary","Postavi kao glavni","Als Hauptklub","Como principal","Comme principal"),11,subText,true);primaryLegend.setGravity(Gravity.RIGHT);actionLegend.addView(primaryLegend,new LinearLayout.LayoutParams(0,-2,1));choose.addView(actionLegend);

        EditText search=new EditText(this);search.setHint(t2("Search club","Traži klub","Klub suchen","Buscar club","Rechercher un club"));search.setText(favoriteClubSearch);search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(subText);search.setTextSize(14);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(chipBg,dp(16),1));choose.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));

        ArrayList<ClubProfile> profiles=availableClubProfiles();
        ArrayList<String> competitionValues=clubCompetitionOptions(profiles);
        ArrayList<String> competitionLabels=new ArrayList<String>();competitionLabels.add(t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"));competitionLabels.addAll(competitionValues);
        Spinner competitionSpinner=spinner(competitionLabels,favoriteClubCompetitionFilter.equals("ALL")?competitionLabels.get(0):favoriteClubCompetitionFilter);choose.addView(competitionSpinner,new LinearLayout.LayoutParams(-1,dp(54)));

        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);choose.addView(results);
        renderClubPicker(results);

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence value,int start,int count,int after){}
            public void onTextChanged(CharSequence value,int start,int before,int count){favoriteClubSearch=value==null?"":value.toString();favoriteClubPickerLimit=30;renderClubPicker(results);}
            public void afterTextChanged(Editable editable){}
        });
        competitionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> parent){}
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){favoriteClubCompetitionFilter=position<=0?"ALL":competitionValues.get(position-1);favoriteClubPickerLimit=30;renderClubPicker(results);}
        });

        LinearLayout teamCard=card();teamCard.addView(label("🌍 "+t2("National team","Reprezentacija","Nationalteam","Selección","Équipe nationale"),21,text,true));
        teamCard.addView(label(t2("The selected national team is saved automatically.","Odabrana reprezentacija sprema se automatski.","Das gewählte Nationalteam wird automatisch gespeichert.","La selección se guarda automáticamente.","L’équipe nationale est enregistrée automatiquement."),13,subText,false));
        Spinner team=spinner(data.teams,myTeam);teamCard.addView(team);
        final boolean[] initial={true};
        team.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> parent){}
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){
                if(initial[0]){initial[0]=false;return;}
                String selected=parent.getItemAtPosition(position).toString();
                if(!sameTeam(selected,myTeam)){myTeam=selected;userPreferences.saveNationalTeam(myTeam);syncMatchReminders();toast(t2("Saved automatically","Automatski spremljeno","Automatisch gespeichert","Guardado automáticamente","Enregistré automatiquement"));}
            }
        });

        LinearLayout honesty=card();honesty.addView(label("🔔 "+t2("Notifications","Obavijesti","Benachrichtigungen","Notificaciones","Notifications"),21,text,true));
        honesty.addView(label(t2("Favorites already personalize Home and Match Center. The in-app notification center now shows real alerts from synchronized data. Reliable background push delivery will be added only with a dedicated tested service.","Favoriti već prilagođavaju početnu i Centar utakmica. Centar obavijesti u aplikaciji sada prikazuje stvarne obavijesti iz sinkroniziranih podataka. Pouzdane pozadinske push obavijesti dodat ćemo tek uz poseban testirani sustav.","Favoriten personalisieren bereits Startseite und Match Center. Die In-App-Zentrale zeigt echte Hinweise aus synchronisierten Daten. Zuverlässige Push-Zustellung folgt erst mit einem getesteten Dienst.","Los favoritos ya personalizan Inicio y el centro de partidos. El centro en la app muestra avisos reales de datos sincronizados. Las alertas push llegarán con un servicio probado.","Les favoris personnalisent déjà l’accueil et le centre des matchs. Le centre intégré affiche de vraies alertes issues des données synchronisées. Les push viendront avec un service testé."),14,subText,false));
        Button notificationCenter=outline(t2("Open notification center","Otvori centar obavijesti","Benachrichtigungen öffnen","Abrir centro de avisos","Ouvrir les notifications"));notificationCenter.setOnClickListener(v->showNotificationCenter());honesty.addView(notificationCenter);
    }

    void showMatches(){
        normalizeMatchCenterFilters();
        clear(tr("Matches"),t2("Live scores, fixtures and results","Rezultati uživo, raspored i završene utakmice","Live-Ergebnisse, Spielplan und Resultate","Resultados en vivo, calendario y resultados","Scores en direct, calendrier et résultats"),"Matches");

        LinearLayout sync=card();sync.setPadding(dp(14),dp(10),dp(14),dp(10));
        LinearLayout sr=hrow();String last=prefs.getString("online_lastUpdate","");
        LinearLayout sc=new LinearLayout(this);sc.setOrientation(LinearLayout.VERTICAL);
        sc.addView(label("● "+t2("Data connected","Podaci povezani","Daten verbunden","Datos conectados","Données connectées"),13,GREEN,true));
        sc.addView(label(lastUpdateLabel(last).replace("🕒 ",""),11,subText,false));
        sr.addView(sc,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=label("↻ "+t2("Refresh","Osvježi","Aktualisieren","Actualizar","Actualiser"),13,RED,true);
        refresh.setPadding(dp(12),dp(9),dp(12),dp(9));refresh.setBackground(round(chipBg,dp(16),1));refresh.setOnClickListener(v->refreshOnlineSafe(true));sr.addView(refresh);sync.addView(sr);

        addMatchDateSelector();
        addMatchCenterFilters();

        String f=matchFilter.toLowerCase(homeLocale()).trim();
        ArrayList<Match> shown=new ArrayList<>();
        for(Match m:data.matches){
            if(!matchBelongsToCompetition(m,competitionFilter))continue;
            if(!groupFilter.equals("All")&&!m.group.equals(groupFilter))continue;
            if(!matchDateFilter.equals("ALL")&&!matchDateFilter.equals(localDateKey(m)))continue;
            if(matchFavoritesOnly&&!matchMatchesFavorites(m))continue;
            String hay=(m.group+" "+m.home+" "+m.away+" "+displayTeamName(m.home)+" "+displayTeamName(m.away)+" "+m.venue+" "+m.competition+" "+friendlyCompetitionName(m)+" "+displayCompetitionName(friendlyCompetitionName(m))).toLowerCase(homeLocale());
            if(f.length()>0&&!hay.contains(f))continue;
            if(matchStatusFilter.equals("Finished")&&!matchIsFinished(m))continue;
            if(matchStatusFilter.equals("Live")&&!matchIsLive(m))continue;
            shown.add(m);
        }
        Collections.sort(shown,(a,b)->compareMatchCenterOrder(a,b));

        if(shown.isEmpty()){
            LinearLayout empty=card();empty.setGravity(Gravity.CENTER);
            empty.addView(centerLabel("⚽",34,text,true));
            empty.addView(centerLabel(t2("No matches for these filters","Nema utakmica za odabrane filtre","Keine Spiele für diese Filter","No hay partidos para estos filtros","Aucun match pour ces filtres"),20,text,true));
            empty.addView(centerLabel(t2("Choose another date, competition or turn off Favorites.","Odaberi drugi datum ili natjecanje, ili isključi Favoriti.","Wähle ein anderes Datum oder einen anderen Wettbewerb.","Elige otra fecha o competición.","Choisis une autre date ou compétition."),13,subText,false));
            LinearLayout actions=hrow();
            Button reset=btn(t2("Reset filters","Poništi filtre","Filter zurücksetzen","Restablecer filtros","Réinitialiser"));
            reset.setOnClickListener(v->{matchDateFilter="ALL";matchStatusFilter="All";matchFavoritesOnly=false;matchFilter="";competitionFilter="All";showMatches();});
            actions.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));empty.addView(actions);
            return;
        }

        LinkedHashMap<String,ArrayList<Match>> days=new LinkedHashMap<>();
        for(Match match:shown){String day=localDateKey(match);if(!days.containsKey(day))days.put(day,new ArrayList<Match>());days.get(day).add(match);}
        for(ArrayList<Match> dayMatches:days.values())addMatchDaySection(dayMatches);
    }

    void normalizeMatchCenterFilters(){
        if(matchDateFilter==null||matchDateFilter.length()==0||matchDateFilter.equals("TODAY"))matchDateFilter=dateKeyOffset(0);
        if(matchStatusFilter.equals("Today")){matchDateFilter=dateKeyOffset(0);matchStatusFilter="All";}
        if(matchStatusFilter.equals("Tomorrow")){matchDateFilter=dateKeyOffset(1);matchStatusFilter="All";}
        if(!matchStatusFilter.equals("All")&&!matchStatusFilter.equals("Live")&&!matchStatusFilter.equals("Finished"))matchStatusFilter="All";
    }

    String dateKeyOffset(int offset){
        Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,offset);
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
    }

    void addMatchDateSelector(){
        LinearLayout dateCard=card();dateCard.setPadding(dp(12),dp(11),dp(12),dp(11));
        LinearLayout head=hrow();head.addView(label(t2("MATCHDAY","DAN UTAKMICA","SPIELTAG","JORNADA","JOURNÉE"),14,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView allDates=label(t2("All dates","Svi datumi","Alle Daten","Todas las fechas","Toutes les dates"),12,matchDateFilter.equals("ALL")?RED:subText,true);
        allDates.setOnClickListener(v->{matchDateFilter="ALL";showMatches();});head.addView(allDates);dateCard.addView(head);
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(0,dp(4),0,0);
        final TextView[] selectedChip=new TextView[1];
        TextView allChip=addMatchDateChip(row,"ALL",t2("ALL\nDATES","SVI\nDATUMI","ALLE\nDATEN","TODAS\nFECHAS","TOUTES\nDATES"));
        if("ALL".equals(matchDateFilter)) selectedChip[0]=allChip;
        for(int offset=-2;offset<=5;offset++){
            Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,offset);
            String key=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
            String caption;
            if(offset==-1)caption=t2("YESTERDAY","JUČER","GESTERN","AYER","HIER")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else if(offset==0)caption=t2("TODAY","DANAS","HEUTE","HOY","AUJOURD’HUI")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else if(offset==1)caption=t2("TOMORROW","SUTRA","MORGEN","MAÑANA","DEMAIN")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else caption=MatchCenterFormatter.dateChip(c.getTime(),lang);
            TextView chip=addMatchDateChip(row,key,caption);
            if(key.equals(matchDateFilter)) selectedChip[0]=chip;
        }
        scroll.addView(row);dateCard.addView(scroll,new LinearLayout.LayoutParams(-1,dp(69)));
        scroll.post(()->{
            TextView target=selectedChip[0];
            if(target==null)return;
            int x=target.getLeft()-(scroll.getWidth()-target.getWidth())/2;
            scroll.scrollTo(Math.max(0,x),0);
        });
    }

    TextView addMatchDateChip(LinearLayout row,String key,String caption){
        boolean selected=key.equals(matchDateFilter);
        TextView chip=centerLabel(caption,11,selected?Color.WHITE:subText,true);chip.setGravity(Gravity.CENTER);chip.setSingleLine(false);chip.setMinLines(2);
        chip.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        chip.setOnClickListener(v->{matchDateFilter=key;showMatches();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(86),dp(58));lp.setMargins(dp(3),dp(3),dp(3),dp(3));row.addView(chip,lp);
        return chip;
    }

    void addMatchCenterFilters(){
        LinearLayout filters=card();filters.setPadding(dp(14),dp(13),dp(14),dp(13));
        LinearLayout quick=hrow();
        addMatchStatusChip(quick,"All",t2("All","Sve","Alle","Todos","Tous"));
        addMatchStatusChip(quick,"Live",t2("Live","Uživo","Live","En vivo","Direct"));
        addMatchStatusChip(quick,"Finished",t2("Finished","Završeno","Beendet","Finalizados","Terminés"));
        TextView favorites=centerLabel("★ "+t2("My","Moji","Meine","Mis","Mes"),11,matchFavoritesOnly?Color.WHITE:text,true);
        favorites.setSingleLine(true);favorites.setBackground(matchFavoritesOnly?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        favorites.setOnClickListener(v->{matchFavoritesOnly=!matchFavoritesOnly;showMatches();});
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(44),1);fp.setMargins(dp(2),dp(3),dp(2),dp(3));quick.addView(favorites,fp);filters.addView(quick);

        LinearLayout selectors=hrow();
        TextView competition=label("🏆 "+(competitionFilter.equals("All")?t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"):displayCompetitionName(competitionFilter))+"  ▾",13,text,true);
        competition.setSingleLine(true);competition.setEllipsize(android.text.TextUtils.TruncateAt.END);competition.setGravity(Gravity.CENTER_VERTICAL);competition.setPadding(dp(13),0,dp(13),0);competition.setBackground(round(chipBg,dp(16),1));competition.setOnClickListener(v->showMatchCompetitionDialog());
        selectors.addView(competition,new LinearLayout.LayoutParams(0,dp(50),1));filters.addView(selectors);

        LinearLayout searchRow=hrow();
        EditText search=new EditText(this);search.setHint(t2("Search team or competition","Traži klub, reprezentaciju ili natjecanje","Team oder Wettbewerb suchen","Buscar equipo o competición","Chercher équipe ou compétition"));search.setText(matchFilter);search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(subText);search.setTextSize(14);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(chipBg,dp(16),1));
        Button apply=btn("⌕");apply.setTextSize(19);apply.setOnClickListener(v->{matchFilter=search.getText().toString().trim();showMatches();});
        Button clear=outline("✕");clear.setTextSize(16);clear.setOnClickListener(v->{matchFilter="";showMatches();});
        searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(50),1));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(54),dp(50));ap.setMargins(dp(5),0,0,0);searchRow.addView(apply,ap);
        if(matchFilter.trim().length()>0){LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(54),dp(50));cp.setMargins(dp(5),0,0,0);searchRow.addView(clear,cp);}
        filters.addView(searchRow);
    }

    void addMatchStatusChip(LinearLayout row,String key,String caption){
        boolean selected=key.equals(matchStatusFilter);
        TextView chip=centerLabel(caption,11,selected?Color.WHITE:text,true);chip.setSingleLine(true);chip.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        chip.setOnClickListener(v->{matchStatusFilter=key;if(key.equals("Finished"))matchDateFilter="ALL";showMatches();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(chip,lp);
    }

    void showMatchCompetitionDialog(){
        ArrayList<String> values=new ArrayList<>();values.add("All");values.addAll(CompetitionCatalog.all().keySet());
        String[] labels=new String[values.size()];int checked=0;
        for(int i=0;i<values.size();i++){
            String value=values.get(i);labels[i]=value.equals("All")?t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"):displayCompetitionName(value);
            if(value.equals(competitionFilter))checked=i;
        }
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle(t2("Choose competition","Odaberi natjecanje","Wettbewerb wählen","Elegir competición","Choisir une compétition"))
                .setSingleChoiceItems(labels,checked,(d,which)->{competitionFilter=values.get(which);matchDateFilter="ALL";d.dismiss();showMatches();})
                .setNegativeButton(t2("Cancel","Odustani","Abbrechen","Cancelar","Annuler"),null)
                .create();
        dialog.show();
    }

    boolean matchMatchesFavorites(Match m){
        if(m==null)return false;
        if(sameTeam(m.home,myTeam)||sameTeam(m.away,myTeam))return true;
        if(favoriteClubs!=null)for(String club:favoriteClubs)if(sameTeam(m.home,club)||sameTeam(m.away,club))return true;
        String competition=friendlyCompetitionName(m);
        return followedCompetitions!=null&&followedCompetitions.contains(competition);
    }

    int compareMatchCenterOrder(Match a,Match b){
        Date da=localMatchDate(a),db=localMatchDate(b);
        if(!matchDateFilter.equals("ALL")){
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        }
        int pa=matchIsLive(a)?0:matchIsUpcoming(a)?1:2;
        int pb=matchIsLive(b)?0:matchIsUpcoming(b)?1:2;
        if(pa!=pb)return pa-pb;
        if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;
        return pa==2?db.compareTo(da):da.compareTo(db);
    }

    void addMatchDaySection(ArrayList<Match> matches){
        if(matches==null||matches.isEmpty())return;
        Match first=matches.get(0);Date date=localMatchDate(first);
        String heading=displayMatchDayHeading(first);
        LinearLayout dayHead=hrow();TextView name=label(heading,18,text,true);dayHead.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        dayHead.addView(label(matches.size()+" "+(matches.size()==1?t2("match","utakmica","Spiel","partido","match"):t2("matches","utakmice","Spiele","partidos","matchs")),11,subText,true));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.setMargins(dp(4),dp(8),dp(4),dp(7));content.addView(dayHead,hp);

        LinkedHashMap<String,ArrayList<Match>> groups=new LinkedHashMap<>();
        for(Match m:matches){String competition=friendlyCompetitionName(m);if(!groups.containsKey(competition))groups.put(competition,new ArrayList<Match>());groups.get(competition).add(m);}
        for(Map.Entry<String,ArrayList<Match>> entry:groups.entrySet())addCompetitionMatchCard(entry.getKey(),entry.getValue());
    }

    LinearLayout compactMatchTeamLine(String team){
        LinearLayout line=hrow();
        line.setGravity(Gravity.CENTER_VERTICAL);
        View crest=homeTeamVisual(team,dp(22),false);
        line.addView(crest,new LinearLayout.LayoutParams(dp(22),dp(22)));
        TextView name=label(displayTeamName(team),14,text,true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(28),1);
        np.setMargins(dp(8),0,0,0);
        line.addView(name,np);
        return line;
    }

    String displayMatchDayHeading(Match m){
        Date d=localMatchDate(m);if(d==null)return t2("Matches","Utakmice","Spiele","Partidos","Matchs");
        String key=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);
        if(key.equals(dateKeyOffset(0)))return t2("Today","Danas","Heute","Hoy","Aujourd’hui")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        if(key.equals(dateKeyOffset(1)))return t2("Tomorrow","Sutra","Morgen","Mañana","Demain")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        if(key.equals(dateKeyOffset(-1)))return t2("Yesterday","Jučer","Gestern","Ayer","Hier")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        return MatchCenterFormatter.dayHeading(d,lang);
    }

    void addCompetitionMatchCard(String competition,ArrayList<Match> matches){
        LinearLayout group=card();group.setPadding(dp(13),dp(11),dp(13),dp(8));
        LinearLayout head=hrow();
        head.addView(label(competitionIcon(competition)+" "+displayCompetitionName(competition),14,text,true),new LinearLayout.LayoutParams(0,-2,1));
        int live=0;for(Match m:matches)if(matchIsLive(m))live++;
        TextView count=label(live>0?"● "+live+" "+t2("live","uživo","live","en vivo","direct"):String.valueOf(matches.size()),11,live>0?RED:subText,true);head.addView(count);group.addView(head);
        for(int i=0;i<matches.size();i++){
            if(i>0){View divider=new View(this);divider.setBackgroundColor(stroke);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(1));dl.setMargins(0,dp(5),0,dp(5));group.addView(divider,dl);}
            addCompactMatchRow(group,matches.get(i));
        }
    }

    void addCompactMatchRow(LinearLayout parent,Match m){
        final Match selected=m;
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(1),dp(7),dp(1),dp(7));row.setClickable(true);row.setOnClickListener(v->showMatchDetails(selected));
        LinearLayout main=hrow();main.setGravity(Gravity.CENTER_VERTICAL);

        String leftStatus=compactMatchStatus(m);
        TextView status=centerLabel(leftStatus,11,matchIsLive(m)?RED:subText,true);status.setSingleLine(true);main.addView(status,new LinearLayout.LayoutParams(dp(63),dp(54)));

        LinearLayout teams=new LinearLayout(this);teams.setOrientation(LinearLayout.VERTICAL);teams.setPadding(dp(5),0,dp(5),0);
        teams.addView(compactMatchTeamLine(m.home),new LinearLayout.LayoutParams(-1,dp(29)));
        teams.addView(compactMatchTeamLine(m.away),new LinearLayout.LayoutParams(-1,dp(29)));
        main.addView(teams,new LinearLayout.LayoutParams(0,dp(58),1));

        LinearLayout scores=new LinearLayout(this);scores.setOrientation(LinearLayout.VERTICAL);scores.setGravity(Gravity.CENTER);
        String hs=m.homeGoals>=0?String.valueOf(m.homeGoals):"–";String as=m.awayGoals>=0?String.valueOf(m.awayGoals):"–";
        scores.addView(centerLabel(hs,17,matchIsLive(m)?RED:text,true),new LinearLayout.LayoutParams(dp(32),dp(28)));
        scores.addView(centerLabel(as,17,matchIsLive(m)?RED:text,true),new LinearLayout.LayoutParams(dp(32),dp(28)));
        main.addView(scores,new LinearLayout.LayoutParams(dp(36),dp(58)));
        TextView arrow=centerLabel("›",20,subText,true);main.addView(arrow,new LinearLayout.LayoutParams(dp(22),dp(54)));row.addView(main);
        String phase=stageLabel(m);if(phase.length()>0){TextView phaseView=label(phase,11,subText,false);phaseView.setPadding(dp(68),0,dp(5),0);row.addView(phaseView);}
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }

    String compactMatchStatus(Match m){
        if(matchIsLive(m)){
            String minute=m.minute==null?"":m.minute.replace("'","").replace("′","").trim();
            return minute.length()>0?minute+"′":t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT");
        }
        if(matchIsFinished(m))return t2("FT","KRAJ","ENDE","FINAL","FIN");
        return homeTimeLabel(m);
    }

    String matchDetailDateLabel(Match m){
        Date date=localMatchDate(m);if(date==null)return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        if(!isMatchTimeTba(m))return MatchCenterFormatter.fullDate(date,lang);
        String value=new SimpleDateFormat("EEEE, d. MMMM",homeLocale()).format(date);
        if(value.length()>0)value=Character.toUpperCase(value.charAt(0))+value.substring(1);
        return value+"  •  "+t2("Time TBA","Vrijeme naknadno","Zeit offen","Hora pendiente","Horaire à confirmer");
    }

    String displayCompetitionName(String competition){
        if(competition==null)return "";
        if(competition.equals("World Cup 2026"))return t2("World Cup 2026","Svjetsko prvenstvo 2026","Weltmeisterschaft 2026","Mundial 2026","Coupe du monde 2026");
        if(competition.equals("UEFA European Championship"))return t2("UEFA European Championship","UEFA Europsko prvenstvo","UEFA-Europameisterschaft","Campeonato Europeo de la UEFA","Championnat d’Europe UEFA");
        return competition;
    }

    LinearLayout matchDetailTeamBlock(String team){
        LinearLayout block=new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER);

        View crest=homeTeamVisual(team,dp(72),false);
        crest.setElevation(dp(5));
        block.addView(crest,new LinearLayout.LayoutParams(dp(72),dp(72)));

        TextView name=centerLabel(displayTeamName(team),16,Color.WHITE,true);
        name.setMaxLines(2);
        name.setMinLines(2);
        name.setGravity(Gravity.CENTER);
        name.setPadding(dp(2),dp(4),dp(2),0);
        block.addView(name,new LinearLayout.LayoutParams(-1,-2));
        return block;
    }

    void showMatchDetails(Match m){
        if(m==null){showMatches();return;}
        rememberOpenMatch(m);
        clear(displayCompetitionName(friendlyCompetitionName(m)),stageLabel(m),"MatchDetails");

        LinearLayout hero=card();hero.setPadding(dp(16),dp(17),dp(16),dp(16));hero.setBackground(gradient(Color.rgb(62,15,82),Color.rgb(237,29,83),dp(24)));
        LinearLayout teams=hrow();
        LinearLayout home=matchDetailTeamBlock(m.home);
        LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);
        String result=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" : "+m.awayGoals:"VS";center.addView(centerLabel(result,result.equals("VS")?24:34,Color.WHITE,true));
        String status=matchIsUpcoming(m)?homeTimeLabel(m):homeCenterStatus(m);TextView statusView=centerLabel(status,11,Color.WHITE,true);statusView.setPadding(dp(10),dp(4),dp(10),dp(4));statusView.setBackground(round(Color.argb(55,255,255,255),dp(13),0));center.addView(statusView);
        LinearLayout away=matchDetailTeamBlock(m.away);
        teams.addView(home,new LinearLayout.LayoutParams(0,-2,1));teams.addView(center,new LinearLayout.LayoutParams(dp(96),-2));teams.addView(away,new LinearLayout.LayoutParams(0,-2,1));hero.addView(teams);

        ArrayList<String> metaParts=new ArrayList<>();
        metaParts.add(matchDetailDateLabel(m));
        if(m.actualVenue!=null&&m.actualVenue.trim().length()>0)metaParts.add(m.actualVenue.trim());
        TextView meta=centerLabel(joinParts(metaParts," • "),12,Color.WHITE,false);hero.addView(meta);
        if(m.halfTimeScore!=null&&m.halfTimeScore.length()>0&&(matchIsLive(m)||matchIsFinished(m)))hero.addView(centerLabel(t2("Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps")+": "+m.halfTimeScore,11,Color.WHITE,false));
        ArrayList<String> officialParts=new ArrayList<>();
        if(m.refereeText!=null&&m.refereeText.length()>0)officialParts.add("🧑‍⚖️ "+m.refereeText);
        if(m.attendance>0)officialParts.add("👥 "+String.format(homeLocale(),"%,d",m.attendance));
        if(!officialParts.isEmpty())hero.addView(centerLabel(joinParts(officialParts,"   •   "),11,Color.WHITE,false));
        if(matchIsLive(m))hero.addView(centerLabel("● "+t2("Live updates every minute","Osvježavanje uživo svake minute","Live-Aktualisierung jede Minute","Actualización en vivo cada minuto","Actualisation en direct chaque minute"),11,Color.rgb(255,230,150),true));

        boolean hasEvents=m.eventsText!=null&&m.eventsText.trim().length()>0;
        boolean hasStats=m.statsText!=null&&m.statsText.trim().length()>0;
        boolean hasLineups=(m.homeLineupText!=null&&m.homeLineupText.trim().length()>0)||(m.awayLineupText!=null&&m.awayLineupText.trim().length()>0);

        LinearLayout availability=card();availability.setPadding(dp(13),dp(11),dp(13),dp(11));
        availability.addView(label(t2("MATCH DATA","PODACI UTAKMICE","SPIELDATEN","DATOS DEL PARTIDO","DONNÉES DU MATCH"),13,text,true));
        LinearLayout availableRow=hrow();
        availableRow.addView(detailAvailabilityChip("⚡ "+t2("Timeline","Tijek","Verlauf","Cronología","Chronologie"),hasEvents),new LinearLayout.LayoutParams(0,dp(43),1));
        availableRow.addView(detailAvailabilityChip("📊 "+t2("Stats","Statistika","Statistik","Estadísticas","Stats"),hasStats),new LinearLayout.LayoutParams(0,dp(43),1));
        availableRow.addView(detailAvailabilityChip("👕 "+t2("Lineups","Sastavi","Aufstellungen","Alineaciones","Compos"),hasLineups),new LinearLayout.LayoutParams(0,dp(43),1));
        availability.addView(availableRow);
        if(!hasEvents&&!hasStats&&!hasLineups){
            availability.addView(label(matchIsLive(m)?t2("The live score is available. Additional details will appear automatically when the source publishes them.","Rezultat uživo je dostupan. Dodatni detalji pojavit će se automatski kada ih izvor objavi.","Der Live-Spielstand ist verfügbar. Weitere Details erscheinen automatisch.","El marcador en vivo está disponible. Los detalles aparecerán automáticamente.","Le score en direct est disponible. Les détails apparaîtront automatiquement."):t2("The connected source has not published detailed match data.","Povezani izvor još nije objavio detaljne podatke utakmice.","Die verbundene Quelle hat noch keine Detaildaten veröffentlicht.","La fuente aún no ha publicado datos detallados.","La source n’a pas encore publié les données détaillées."),13,subText,false));
            Button refresh=outline("↻ "+t2("Refresh details","Osvježi detalje","Details aktualisieren","Actualizar detalles","Actualiser les détails"));refresh.setOnClickListener(v->refreshOnlineSafe(true));availability.addView(refresh);
        }

        if(hasEvents){LinearLayout events=card();events.addView(label("⚡ "+t2("Timeline","Tijek utakmice","Spielverlauf","Cronología","Chronologie"),21,text,true));events.addView(label(m.eventsText,14,text,false));}
        if(hasStats){LinearLayout stats=card();stats.addView(label("📊 "+t2("Match statistics","Statistika utakmice","Spielstatistik","Estadísticas","Statistiques"),21,text,true));stats.addView(label(m.statsText,14,text,false));}
        if(hasLineups){
            LinearLayout lineups=card();lineups.addView(label("👕 "+t2("Lineups","Sastavi","Aufstellungen","Alineaciones","Compositions"),21,text,true));
            if(m.homeLineupText!=null&&m.homeLineupText.length()>0){lineups.addView(label(flag(m.home)+" "+displayTeamName(m.home)+(m.homeFormation.length()>0?" • "+m.homeFormation:""),16,RED,true));lineups.addView(label(m.homeLineupText,14,text,false));}
            if(m.awayLineupText!=null&&m.awayLineupText.length()>0){lineups.addView(label("\n"+flag(m.away)+" "+displayTeamName(m.away)+(m.awayFormation.length()>0?" • "+m.awayFormation:""),16,RED,true));lineups.addView(label(m.awayLineupText,14,text,false));}
        }

        if(hasRecentFormData(m.home)||hasRecentFormData(m.away)){
            LinearLayout form=card();form.addView(label("📈 "+t2("Recent form","Nedavna forma","Aktuelle Form","Forma reciente","Forme récente"),20,text,true));
            form.addView(label(flag(m.home)+" "+displayTeamName(m.home)+"   "+recentFormDisplay(m.home)+"\n"+flag(m.away)+" "+displayTeamName(m.away)+"   "+recentFormDisplay(m.away),14,subText,false));
        }
        startLiveMatchDetailsRefresh(m);
    }

    TextView detailAvailabilityChip(String caption,boolean available){
        TextView chip=centerLabel((available?"● ":"○ ")+caption,10,available?GREEN:subText,true);chip.setSingleLine(true);chip.setBackground(round(chipBg,dp(15),1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(43),1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));chip.setLayoutParams(lp);return chip;
    }

    boolean hasRecentFormData(String team){
        String[] form=recentForm(team,5);for(String value:form)if(!"–".equals(value))return true;return false;
    }

    String joinParts(List<String> parts,String separator){
        StringBuilder sb=new StringBuilder();
        for(String part:parts){
            if(part==null||part.trim().length()==0)continue;
            if(sb.length()>0)sb.append(separator);
            sb.append(part.trim());
        }
        return sb.toString();
    }

    void populateMatchDetails(Match m,JSONObject o){
        if(m==null||o==null)return;
        m.apiId=o.optInt("id",m.apiId);
        m.actualVenue=o.optString("venue",m.actualVenue==null?"":m.actualVenue);
        m.attendance=o.optInt("attendance",m.attendance);
        JSONObject homeObj=o.optJSONObject("homeTeam");
        JSONObject awayObj=o.optJSONObject("awayTeam");
        if(homeObj!=null){
            m.homeFormation=homeObj.optString("formation","");
            m.homeLineupText=formatLineup(homeObj);
        }
        if(awayObj!=null){
            m.awayFormation=awayObj.optString("formation","");
            m.awayLineupText=formatLineup(awayObj);
        }
        m.eventsText=formatMatchEvents(o);
        m.statsText=formatMatchStatistics(homeObj,awayObj,m.home,m.away);
        m.refereeText=formatReferees(o.optJSONArray("referees"));
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject half=score.optJSONObject("halfTime");
            if(half!=null && !half.isNull("home") && !half.isNull("away")) m.halfTimeScore=half.optInt("home")+" : "+half.optInt("away");
        }
        m.detailsAvailable=(m.eventsText.length()>0||m.statsText.length()>0||m.homeLineupText.length()>0||m.awayLineupText.length()>0||m.refereeText.length()>0);
    }

    String formatLineup(JSONObject team){
        if(team==null)return "";
        JSONArray lineup=team.optJSONArray("lineup");
        JSONArray bench=team.optJSONArray("bench");
        StringBuilder sb=new StringBuilder();
        appendPlayers(sb,lineup,t2("Starting XI","Početnih 11","Startelf","Once inicial","Onze de départ"));
        appendPlayers(sb,bench,t2("Bench","Klupa","Bank","Suplentes","Remplaçants"));
        return sb.toString().trim();
    }

    void appendPlayers(StringBuilder sb,JSONArray players,String heading){
        if(players==null||players.length()==0)return;
        if(sb.length()>0)sb.append("\n\n");
        sb.append(heading).append("\n");
        for(int i=0;i<players.length();i++){
            JSONObject p=players.optJSONObject(i); if(p==null)continue;
            int number=p.optInt("shirtNumber",-1);
            String name=p.optString("name","");
            String position=p.optString("position","");
            if(number>0)sb.append(number).append(". ");
            sb.append(name);
            if(position.length()>0)sb.append(" — ").append(position);
            if(i<players.length()-1)sb.append("\n");
        }
    }

    String formatMatchEvents(JSONObject match){
        ArrayList<DetailEvent> all=new ArrayList<>();
        JSONArray goals=match.optJSONArray("goals");
        if(goals!=null)for(int i=0;i<goals.length();i++){
            JSONObject g=goals.optJSONObject(i); if(g==null)continue;
            int minute=g.optInt("minute",0), injury=g.optInt("injuryTime",0);
            JSONObject scorer=g.optJSONObject("scorer"), assist=g.optJSONObject("assist"), team=g.optJSONObject("team");
            String text="⚽ "+minuteLabel(minute,injury)+" "+objectName(scorer);
            if(assist!=null&&objectName(assist).length()>0)text+=" ("+t2("assist","asistencija","Vorlage","asistencia","passe")+": "+objectName(assist)+")";
            if(team!=null&&objectName(team).length()>0)text+=" • "+displayTeamName(objectName(team));
            all.add(new DetailEvent(minute,text));
        }
        JSONArray bookings=match.optJSONArray("bookings");
        if(bookings!=null)for(int i=0;i<bookings.length();i++){
            JSONObject b=bookings.optJSONObject(i); if(b==null)continue;
            int minute=b.optInt("minute",0);
            String card=b.optString("card","").toUpperCase(Locale.US);
            String icon=card.contains("RED")?"🟥":"🟨";
            String text=icon+" "+minuteLabel(minute,0)+" "+objectName(b.optJSONObject("player"));
            String team=objectName(b.optJSONObject("team")); if(team.length()>0)text+=" • "+displayTeamName(team);
            all.add(new DetailEvent(minute,text));
        }
        JSONArray substitutions=match.optJSONArray("substitutions");
        if(substitutions!=null)for(int i=0;i<substitutions.length();i++){
            JSONObject sub=substitutions.optJSONObject(i); if(sub==null)continue;
            int minute=sub.optInt("minute",0);
            String text="🔄 "+minuteLabel(minute,0)+" "+objectName(sub.optJSONObject("playerIn"))+" ↔ "+objectName(sub.optJSONObject("playerOut"));
            String team=objectName(sub.optJSONObject("team")); if(team.length()>0)text+=" • "+displayTeamName(team);
            all.add(new DetailEvent(minute,text));
        }
        Collections.sort(all,(a,b)->a.minute-b.minute);
        StringBuilder sb=new StringBuilder();
        for(DetailEvent e:all){if(sb.length()>0)sb.append("\n");sb.append(e.text);}
        return sb.toString();
    }

    String minuteLabel(int minute,int injury){
        if(injury>0)return minute+"+"+injury+"′";
        return minute>0?minute+"′":"";
    }

    String objectName(JSONObject o){return o==null?"":o.optString("name",o.optString("shortName",""));}

    String formatMatchStatistics(JSONObject homeObj,JSONObject awayObj,String home,String away){
        if(homeObj==null||awayObj==null)return "";
        JSONObject hs=homeObj.optJSONObject("statistics"), as=awayObj.optJSONObject("statistics");
        if(hs==null||as==null)return "";
        StringBuilder sb=new StringBuilder();
        sb.append(flag(home)).append(" ").append(displayTeamName(home)).append("     ").append(flag(away)).append(" ").append(displayTeamName(away));
        appendStat(sb,hs,as,"ball_possession",t2("Possession","Posjed","Ballbesitz","Posesión","Possession"),"%");
        appendStat(sb,hs,as,"shots",t2("Shots","Udarci","Schüsse","Tiros","Tirs"),"");
        appendStat(sb,hs,as,"shots_on_goal",t2("Shots on target","U okvir","Schüsse aufs Tor","A puerta","Cadrés"),"");
        appendStat(sb,hs,as,"corner_kicks",t2("Corners","Korneri","Ecken","Córners","Corners"),"");
        appendStat(sb,hs,as,"offsides",t2("Offsides","Zaleđa","Abseits","Fueras de juego","Hors-jeu"),"");
        appendStat(sb,hs,as,"fouls",t2("Fouls","Prekršaji","Fouls","Faltas","Fautes"),"");
        appendStat(sb,hs,as,"saves",t2("Saves","Obrane","Paraden","Paradas","Arrêts"),"");
        appendStat(sb,hs,as,"yellow_cards",t2("Yellow cards","Žuti kartoni","Gelbe Karten","Amarillas","Cartons jaunes"),"");
        appendStat(sb,hs,as,"red_cards",t2("Red cards","Crveni kartoni","Rote Karten","Rojas","Cartons rouges"),"");
        return sb.toString();
    }

    void appendStat(StringBuilder sb,JSONObject home,JSONObject away,String key,String label,String suffix){
        if(!home.has(key)&&!away.has(key))return;
        String h=home.isNull(key)?"-":home.optString(key,"-");
        String a=away.isNull(key)?"-":away.optString(key,"-");
        if(suffix.length()>0){if(!h.equals("-"))h+=suffix;if(!a.equals("-"))a+=suffix;}
        sb.append("\n").append(h).append("   ").append(label).append("   ").append(a);
    }

    String formatReferees(JSONArray refs){
        if(refs==null)return "";
        for(int i=0;i<refs.length();i++){
            JSONObject r=refs.optJSONObject(i); if(r==null)continue;
            String type=r.optString("type","");
            if(type.equals("REFEREE")||type.equals("MAIN_REFEREE"))return r.optString("name","");
        }
        return "";
    }

    int change(int v,int d){if(v<0)v=0;v+=d;if(v<0)v=0;return v;} String display(int v){return v>=0?""+v:"-";}
    TextView scoreLabel(int v){TextView t=label(display(v),21,text,true);t.setGravity(Gravity.CENTER);t.setBackground(round(chipBg,dp(14),0));return t;} String shortName(String s){return s;}

    void showGroups(){
        clear(tr("Groups"),"P/W/D/L/GD/Pts","Groups");
        addOnlineCard();
        Map<String,List<TeamRow>> map=data.standings();
        for(String g:data.groups){LinearLayout c=card();c.addView(label("Group "+g,23,RED,true));c.addView(tableRow("#","Team","P","W","D","L","GD","Pts",true,subText));List<TeamRow> rows=map.get(g);for(int i=0;i<rows.size();i++){TeamRow r=rows.get(i);int col=i<2?GREEN:(i==2?GOLD:subText);c.addView(tableRow((i+1)+"",flag(r.team)+" "+r.team,r.p+"",r.w+"",r.d+"",r.l+"",(r.gf-r.ga)+"",r.pts+"",false,col));}}
        LinearLayout third=card();third.addView(label("🥉 Best third-placed teams",22,text,true));List<TeamRow> th=data.bestThirds();for(int i=0;i<th.size();i++){TeamRow r=th.get(i);third.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,i<8?GREEN:subText,false));}
    }
    LinearLayout tableRow(String pos,String team,String p,String w,String d,String l,String gd,String pts,boolean bold,int color){LinearLayout r=hrow();r.setPadding(0,dp(4),0,dp(4));r.addView(cell(pos,.45f,bold,color));r.addView(cell(team,2.4f,bold,color));r.addView(cell(p,.55f,bold,color));r.addView(cell(w,.55f,bold,color));r.addView(cell(d,.55f,bold,color));r.addView(cell(l,.55f,bold,color));r.addView(cell(gd,.7f,bold,color));r.addView(cell(pts,.8f,true,color));return r;}
    TextView cell(String s,float w,boolean bold,int color){TextView t=label(s,12,color,bold);t.setGravity(Gravity.CENTER_VERTICAL);t.setSingleLine(true);t.setTextSize(s.length()>14?10:12);t.setLayoutParams(new LinearLayout.LayoutParams(0,dp(34),w));return t;}

    
    String groupLineFor(String team) {
        if (team == null) return "";
        for (String g : data.groups) {
            ArrayList<String> names = new ArrayList<>();
            for (Match m : data.matches) {
                if (m.group.equals(g)) {
                    if (!names.contains(m.home)) names.add(m.home);
                    if (!names.contains(m.away)) names.add(m.away);
                }
            }
            if (names.contains(team)) {
                String line = "Group " + g + ": ";
                for (int i=0; i<names.size(); i++) {
                    if (i>0) line += ", ";
                    line += names.get(i);
                }
                return line;
            }
        }
        return "";
    }

    String groupOfTeam(String team) {
        if (team == null) return "";
        for (Match m : data.matches) {
            if ((m.home.equals(team) || m.away.equals(team)) && isGroupLetter(m.group)) return m.group;
        }
        return "";
    }

    boolean isGroupLetter(String g){
        return g!=null && g.length()==1 && g.compareTo("A")>=0 && g.compareTo("L")<=0;
    }

    String canonicalStageLabel(Match m){
        if(m==null) return "";
        if(isGroupLetter(m.group)) return "Group "+m.group;
        return normalizeStage(m.venue);
    }

    String stageLabel(Match m){
        if(m==null) return "";
        return MatchCenterFormatter.stage(m.group,m.venue,lang);
    }

    String normalizeStage(String raw){
        if(raw==null) return "";
        String x=raw.trim();
        if(x.length()==0 || x.equalsIgnoreCase("null") || x.equals("?")) return "";
        String u=x.replace("-","_").replace(" ","_").toUpperCase(Locale.US);
        if(u.equals("GROUP") || u.equals("GROUP_STAGE") || u.equals("REGULAR_SEASON")) return "";
        if(u.contains("ROUND_OF_32") || u.contains("LAST_32") || u.contains("R32")) return "Round of 32";
        if(u.contains("ROUND_OF_16") || u.contains("LAST_16") || u.contains("R16")) return "Round of 16";
        if(u.contains("QUARTER")) return "Quarter-final";
        if(u.contains("SEMI")) return "Semi-final";
        if(u.contains("FINAL")) return "Final";
        if(x.toLowerCase(Locale.US).startsWith("round of 32")) return "Round of 32";
        if(x.toLowerCase(Locale.US).startsWith("round of 16")) return "Round of 16";
        return x;
    }

    boolean hasWonStage(String team,String stage){
        if(team==null || stage==null) return false;
        for(Match m:data.matches){
            if(!stage.equals(canonicalStageLabel(m))) continue;
            if(!matchIsFinished(m)) continue;
            if(sameTeam(m.home,team) && m.homeGoals>m.awayGoals) return true;
            if(sameTeam(m.away,team) && m.awayGoals>m.homeGoals) return true;
        }
        return false;
    }


    void addOnlineCard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online update",23,text,true));
        onlineStatusView=label(onlineStatus,14,subText,false);
        c.addView(onlineStatusView);
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0){
            onlineLastUpdateView=label(lastUpdateLabel(last),13,subText,false);
        }else{
            onlineLastUpdateView=label(lastUpdateLabel(""),13,subText,false);
        }
        c.addView(onlineLastUpdateView);
        Button r=outline(t2("🔄 Refresh Live Data","🔄 Osvježi podatke","🔄 Live-Daten aktualisieren","🔄 Actualizar datos","🔄 Actualiser les données"));
        r.setOnClickListener(v->refreshOnlineSafe(true));
        c.addView(r);
    }
    void addFinishedMatchesCard(){
        addOnlineMatchCenterCard(false);
    }

    void addOnlineMatchCenterCard(boolean compact){
        String live=prefs.getString("online_liveMatches","");
        String jsonUpcoming=prefs.getString("online_upcomingMatches","");
        LinearLayout c=card();
        c.addView(label("⚽ Online match center",23,text,true));
        int liveCount=lineCount(live);
        int finished=displayPlayedCount();
        int upcoming=displayUpcomingCount();
        c.addView(label("🔴 Live: "+liveCount+"   ✅ Finished: "+finished+"   📅 Upcoming: "+upcoming,14,subText,false));

        if(live!=null && live.trim().length()>0){
            c.addView(label("🔴 Live matches",18,RED,true));
            c.addView(label(limitLines(live, compact?3:10),15,subText,false));
        }

        c.addView(label("✅ Finished matches",18,RED,true));
        String onlineFinished=prefs.getString("online_finishedMatches","");
        if(onlineFinished!=null && onlineFinished.trim().length()>0){
            c.addView(label(limitLines(onlineFinished, compact?8:9999),15,subText,false));
            int fc=lineCount(onlineFinished);
            if(compact && fc>8)c.addView(label("+"+(fc-8)+" more finished matches",14,subText,false));
        }else{
            int count=0;
            for(Match m:data.matches){
                if(matchIsFinished(m)){
                    count++;
                    if(!compact || count<=8)c.addView(label(flag(m.home)+" "+m.home+" "+m.homeGoals+" - "+m.awayGoals+" "+flag(m.away)+" "+m.away+" • Group "+m.group,14,subText,false));
                }
            }
            if(count==0)c.addView(label("No finished matches yet.",15,subText,false));
            else if(compact && count>8)c.addView(label("+"+(count-8)+" more finished matches",14,subText,false));
        }

        c.addView(label("📅 Upcoming matches",18,RED,true));
        if(jsonUpcoming!=null && jsonUpcoming.trim().length()>0){
            c.addView(label(limitLines(jsonUpcoming, compact?4:8),15,subText,false));
        }else{
            int shown=0;
            for(Match m:data.matches){
                if(matchIsUpcoming(m)){
                    shown++;
                    if(!compact || shown<=5)c.addView(label(displayLocalDateTime(m.date)+" • Group "+m.group+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away,14,subText,false));
                }
            }
            if(shown==0)c.addView(label("No upcoming matches.",15,subText,false));
            else if(compact && shown>5)c.addView(label("+"+(shown-5)+" more upcoming matches",14,subText,false));
        }
    }

    void addHomeOnlineDashboard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online dashboard",23,text,true));
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        int live=lineCount(prefs.getString("online_liveMatches",""));
        c.addView(kpiRow("Live",""+live,"Finished",""+displayPlayedCount(),"Upcoming",""+displayUpcomingCount(),false));
        if(ENABLE_PLAYER_DATA_MODULES){
            String topScorer=firstRankingLine(gb,t2("Scorer stats coming soon","Statistika strijelaca uskoro","Torschützenstatistik folgt","Estadística de goleadores pronto","Statistiques buteurs bientôt"));
            String topMvp=firstRankingLine(mv,t2("MVP ranking coming soon","MVP poredak uskoro","MVP-Rangliste folgt","Ranking MVP pronto","Classement MVP bientôt"));
            c.addView(label("🥇 "+topScorer,15,subText,false));
            c.addView(label("⭐ "+topMvp,15,subText,false));
        }else{
            c.addView(label(t2("Live matches, results and tables are active.","Rezultati, utakmice i tablice su online.","Live-Spiele, Ergebnisse und Tabellen sind aktiv.","Partidos, resultados y tablas en vivo activos.","Matchs, résultats et tableaux en direct actifs."),15,subText,false));
        }
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0)c.addView(label(lastUpdateLabel(last),13,subText,false));
    }

    int countUpcoming(){int c=0;for(Match m:data.matches)if(matchIsUpcoming(m))c++;return c;}
    int lineCount(String s){if(s==null || s.trim().length()==0)return 0;return s.split("\\n").length;}
    String firstRankingLine(String s,String fallback){if(s==null || s.trim().length()==0)return fallback;String[] lines=s.split("\\n");if(lines.length==0)return fallback;String first=lines[0].trim();first=first.replaceFirst("^\\d+\\.\\s*","");return first.length()>0?first:fallback;}
    int displayPlayedCount(){int v=prefs.getInt("online_playedCount",-1);return v>=0?v:data.playedCount();}
    int displayTotalGoals(){int v=prefs.getInt("online_totalGoals",-1);return v>=0?v:data.totalGoals();}
    int displayUpcomingCount(){int v=prefs.getInt("online_upcomingCount",-1);return v>=0?v:countUpcoming();}
    int displayTotalMatches(){int v=prefs.getInt("online_totalMatches",TOURNAMENT_TOTAL_MATCHES);return v>0?v:TOURNAMENT_TOTAL_MATCHES;}
    int displayProgressPercent(){return (int)Math.round(displayPlayedCount()*100.0/displayTotalMatches());}

    int onlineTotalMatches(JSONObject root){
        if(root==null) return TOURNAMENT_TOTAL_MATCHES;
        JSONObject rs=root.optJSONObject("resultSet");
        if(rs!=null && rs.optInt("count",0)>0) return rs.optInt("count",TOURNAMENT_TOTAL_MATCHES);
        JSONArray arr=root.optJSONArray("matches");
        if(arr!=null && arr.length()>72) return arr.length();
        return TOURNAMENT_TOTAL_MATCHES;
    }
    int onlineFinishedCount(JSONObject root){
        if(root==null) return 0;
        JSONObject rs=root.optJSONObject("resultSet");
        if(rs!=null && rs.optInt("played",0)>0) return rs.optInt("played",0);
        JSONArray fin=root.optJSONArray("finished");
        if(fin!=null) return fin.length();
        JSONArray arr=root.optJSONArray("matches");
        int c=0;
        if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null && isFinishedStatus(o.optString("status","")) && jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0)c++;}
        return c;
    }
    int onlineUpcomingCount(JSONObject root){
        if(root==null) return -1;
        JSONArray up=root.optJSONArray("upcoming");
        if(up!=null) return up.length();
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) return -1;
        int c=0;
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null && isUpcomingStatus(o.optString("status","")))c++;}
        return c;
    }
    int onlineTotalGoals(JSONObject root){
        if(root==null) return 0;
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) arr=root.optJSONArray("finished");
        int g=0;
        if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); int h=jsonHomeGoals(o), a=jsonAwayGoals(o); if(h>=0 && a>=0 && isFinishedStatus(o.optString("status",""))) g+=h+a;}
        return g;
    }

    String limitLines(String s,int max){if(s==null)return "";String[] lines=s.split("\\n");StringBuilder sb=new StringBuilder();for(int i=0;i<lines.length && i<max;i++){if(i>0)sb.append("\n");sb.append(lines[i]);}if(lines.length>max)sb.append("\n+").append(lines.length-max).append(" more");return sb.toString();}

    void addOnlineRankingsPreview(){
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        if((gb==null || gb.trim().length()==0) && (mv==null || mv.trim().length()==0)) return;
        LinearLayout c=card();
        c.addView(label("🌐 Online rankings",23,text,true));
        if(gb!=null && gb.trim().length()>0){
            c.addView(label("🥇 "+tr("Golden Boot"),18,RED,true));
            c.addView(label(gb,15,subText,false));
        }
        if(mv!=null && mv.trim().length()>0){
            c.addView(label("⭐ "+tr("MVP Prediction"),18,RED,true));
            c.addView(label(mv,15,subText,false));
        }
    }


    void restoreCachedOnlineData(){
        String cached=prefs.getString("online_rawJson","");
        if(cached==null || cached.trim().length()==0) return;
        try{
            applyOnlineJson(cached);
            onlineStatus="🟢 Cached data loaded";
        }catch(Exception ignored){}
    }


    void refreshOnlineSafe(){
        refreshOnlineSafe(true);
    }

    void refreshOnlineSafe(final boolean showToast){
        if(onlineRefreshInProgress) return;
        onlineRefreshInProgress=true;
        onlineStatus="Refreshing online data...";
        if(onlineStatusView!=null) onlineStatusView.setText(onlineStatus);
        new Thread(new Runnable(){ public void run(){
            String result;
            String last="";
            try{
                String json=liveDataClient.downloadLatest();
                if(json==null || json.trim().length()==0) throw new Exception("Empty online file");
                int applied=applyOnlineJson(json);
                last=prefs.getString("online_lastUpdate","");
                result="🟢 Connected • data updated";
            }catch(Exception e){
                result="Online data unavailable • "+safeMsg(e);
            }
            final String msg=result;
            final String lastText=last;
            runOnUiThread(new Runnable(){ public void run(){
                onlineRefreshInProgress=false;
                onlineStatus=msg;
                if(onlineStatusView!=null) onlineStatusView.setText(msg);
                if(onlineLastUpdateView!=null){
                    String lu=prefs.getString("online_lastUpdate",lastText);
                    onlineLastUpdateView.setText(lastUpdateLabel(lu));
                }
                if(showToast) toast(msg);
                if(msg.startsWith("🟢 Connected")){
                    syncMatchReminders();
                    if(currentScreen.equals("Home")) showHome();
                    else if(currentScreen.equals("MatchDetails")){
                        Match refreshed=findOpenMatchDetails();
                        if(refreshed!=null) showMatchDetails(refreshed); else showMatches();
                    }
                    else if(currentScreen.equals("Matches")) showMatches();
                    else if(currentScreen.equals("Groups")) showGroups();
                    else if(currentScreen.equals("DailyBrief")) showDailyBrief();
                    else if(currentScreen.equals("Notifications")) showNotificationCenter();
                    else if(currentScreen.equals("More")) {
                        /* Keep current More sub-screen stable; online rankings update when opened again. */
                    }
                }
            }});
        }}).start();
    }


    void rememberOpenMatch(Match m){
        if(m==null)return;
        openMatchApiId=m.apiId;
        openMatchHome=m.home==null?"":m.home;
        openMatchAway=m.away==null?"":m.away;
        openMatchDate=m.date==null?"":m.date;
    }

    Match findOpenMatchDetails(){
        if(data==null||data.matches==null)return null;
        for(Match m:data.matches){
            if(openMatchApiId>0 && m.apiId==openMatchApiId)return m;
        }
        for(Match m:data.matches){
            boolean samePair=(sameTeam(m.home,openMatchHome)&&sameTeam(m.away,openMatchAway))||(sameTeam(m.home,openMatchAway)&&sameTeam(m.away,openMatchHome));
            if(!samePair)continue;
            if(openMatchDate.length()==0||m.date==null||m.date.equals(openMatchDate)||m.date.startsWith(openMatchDate.length()>=10?openMatchDate.substring(0,10):openMatchDate))return m;
        }
        return null;
    }

    void stopLiveMatchDetailsRefresh(){
        try{
            if(liveMatchDetailsRefreshRunnable!=null)handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        liveMatchDetailsRefreshRunnable=null;
    }

    void startLiveMatchDetailsRefresh(Match m){
        stopLiveMatchDetailsRefresh();
        if(m==null||!matchIsLive(m)||!"MatchDetails".equals(currentScreen))return;
        rememberOpenMatch(m);
        liveMatchDetailsRefreshRunnable=new Runnable(){ public void run(){
            if(!"MatchDetails".equals(currentScreen))return;
            Match open=findOpenMatchDetails();
            if(open==null){showMatches();return;}
            if(!matchIsLive(open)){showMatchDetails(open);return;}
            refreshOnlineSafe(false);
            handler.postDelayed(this,AppConfig.LIVE_MATCH_REFRESH_MS);
        }};
        handler.postDelayed(liveMatchDetailsRefreshRunnable,AppConfig.LIVE_MATCH_REFRESH_MS);
    }

    String safeMsg(Exception e){
        if(e==null || e.getMessage()==null) return "check connection";
        String s=e.getMessage();
        return s.length()>70?s.substring(0,70):s;
    }

    String teamKey(String s){
        if(s==null) return "";
        String k=Normalizer.normalize(s.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","").replace("č","c").replace("ć","c").replace("š","s").replace("ž","z").replace("đ","d");
        k=k.replace("côte d’ivoire","ivorycoast").replace("côte d'ivoire","ivorycoast").replace("cote d’ivoire","ivorycoast").replace("cote d'ivoire","ivorycoast");
        k=k.replace("curaçao","curacao").replace("united states","usa").replace("u.s.a.","usa").replace("u.s.a","usa");
        k=k.replace("south korea","korearepublic").replace("republic of korea","korearepublic");
        k=k.replace("cape verde islands","capeverde").replace("capeverdeislands","capeverde");
        k=k.replace("democratic republic of congo","drcongo").replace("d r congo","drcongo").replace("congo dr","drcongo").replace("drc","drcongo");
        k=k.replace("bosnia & herzegovina","bosniaherzegovina").replace("bosnia and herzegovina","bosniaherzegovina").replace("bosnia-herzegovina","bosniaherzegovina").replace("bosnia herzegovina","bosniaherzegovina");
        k=k.replaceAll("[^a-z0-9]","");
        if(k.equals("dinamo")||k.equals("gnkdinamo")||k.equals("dinamozagreb"))return "dinamozagreb";
        if(k.equals("hajduk")||k.equals("hnkhajduk")||k.equals("hnkhajduksplit")||k.equals("hajduksplit"))return "hajduksplit";
        if(k.equals("lokomotiva")||k.equals("nklokomotiva")||k.equals("nklokomotivaz")||k.equals("lokomotivazagreb"))return "lokomotivazagreb";
        if(k.equals("rudes")||k.equals("nkrudes"))return "rudes";
        if(k.equals("varazdin")||k.equals("nkvarazdin"))return "varazdin";
        if(k.equals("gorica")||k.equals("hnkgorica")||k.equals("hnkgoricasdd"))return "gorica";
        if(k.equals("rijeka")||k.equals("hnkrijeka"))return "rijeka";
        if(k.equals("osijek")||k.equals("nkosijek"))return "osijek";
        if(k.equals("istra1961")||k.equals("nkistra1961")||k.equals("istr1961"))return "istra1961";
        if(k.equals("slavenbelupo")||k.equals("nkslavenbelupo"))return "slavenbelupo";
        if(k.equals("botafogofr")||k.equals("botafogo"))return "botafogo";
        if(k.equals("camineiro")||k.equals("atleticomineiro"))return "atleticomineiro";
        if(k.equals("chapecoenseaf")||k.equals("chapecoense"))return "chapecoense";
        if(k.equals("coritibafbc")||k.equals("coritiba"))return "coritiba";
        if(k.equals("crvascodagama")||k.equals("vascodagama"))return "vascodagama";
        if(k.equals("crflamengo")||k.equals("flamengo"))return "flamengo";
        if(k.equals("fluminensefc")||k.equals("fluminense"))return "fluminense";
        if(k.equals("sepalmeiras")||k.equals("palmeiras"))return "palmeiras";
        if(k.equals("saopaulofc")||k.equals("saopaulo"))return "saopaulo";
        if(k.equals("scinternacional")||k.equals("internacional"))return "internacional";
        if(k.equals("gremiofbpa")||k.equals("gremio"))return "gremio";
        if(k.equals("ecbahia")||k.equals("bahia"))return "bahia";
        if(k.equals("ecvitoria")||k.equals("vitoria"))return "vitoria";
        if(k.equals("cruzeiroec")||k.equals("cruzeiro"))return "cruzeiro";
        if(k.equals("fortalezaec")||k.equals("fortaleza"))return "fortaleza";
        if(k.equals("santosfc")||k.equals("santos"))return "santos";
        return k;
    }
    boolean sameTeam(String a,String b){
        String x=teamKey(a), y=teamKey(b);
        if(x.equals(y)) return true;
        if((x.equals("ivorycoast")&&y.equals("cotedivoire"))||(y.equals("ivorycoast")&&x.equals("cotedivoire"))) return true;
        if((x.equals("korearepublic")&&y.equals("korea"))||(y.equals("korearepublic")&&x.equals("korea"))) return true;
        if((x.equals("bosniaherzegovina")&&y.equals("bosniaandherzegovina"))||(y.equals("bosniaherzegovina")&&x.equals("bosniaandherzegovina"))) return true;
        return false;
    }

    boolean isLiveStatus(String st){ return MatchStatus.isLive(st); }

    boolean isFinishedStatus(String st){ return MatchStatus.isFinished(st); }

    boolean isUpcomingStatus(String st){ return MatchStatus.isUpcoming(st); }

    String nowStamp(){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());
    }

    int applyOnlineJson(String json) throws Exception{
        JSONObject root=new JSONObject(json);
        onlineRootCache=root;
        onlineRootCacheRaw=json;
        int applied=0;
        JSONArray arr=root.optJSONArray("matches");
        JSONArray finishedArr=root.optJSONArray("finished");

        // v13.44: one source of truth. When football-data.org returns the full
        // competition match list, rebuild the in-app match list from that JSON.
        // This prevents the simulator/predict screens from showing old local APK
        // fixtures while the online match center shows fresh data.
        if(arr!=null && arr.length()>0){
            applied += rebuildMatchesFromOnlineArray(arr);
        }else{
            if(finishedArr!=null) applied+=applyResultsFromArray(finishedArr, true);
        }
        if(applied>0)data.save();
        String live=formatMatchFeed(root.optJSONArray("live"));
        String upcoming=formatMatchFeed(root.optJSONArray("upcoming"));
        if(arr!=null){
            StringBuilder liveSb=new StringBuilder();
            StringBuilder upSb=new StringBuilder();
            for(int i=0;i<arr.length();i++){
                JSONObject o=arr.optJSONObject(i);
                if(o==null) continue;
                String st=o.optString("status","").toLowerCase(Locale.US);
                boolean hasScore=jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0;
                if(isLiveStatus(st)){ if(liveSb.length()>0)liveSb.append("\n"); liveSb.append(formatOneMatch(o,false)); }
                else if((isUpcomingStatus(st)) && !hasScore){ if(upSb.length()>0)upSb.append("\n"); upSb.append(formatOneMatch(o,true)); }
            }
            if(live.length()==0)live=liveSb.toString();
            if(upcoming.length()==0)upcoming=upSb.toString();
        }
        String finishedFeed=formatMatchFeed(root.optJSONArray("finished"));
        int onlinePlayed=onlineFinishedCount(root);
        int onlineGoals=onlineTotalGoals(root);
        int onlineUpcoming=onlineUpcomingCount(root);
        int onlineTotal=onlineTotalMatches(root);
        if(onlinePlayed<=0) onlinePlayed=data.playedCount();
        if(onlineGoals<=0) onlineGoals=data.totalGoals();
        if(onlineUpcoming<0) onlineUpcoming=countUpcoming();
        String updated=root.optString("lastUpdate",root.optString("updated",""));
        if(updated==null || updated.trim().length()==0) updated=nowStamp();
        prefs.edit()
            .putString("online_lastUpdate",updated)
            .putString("online_rawJson",json)
            .putString("online_finishedMatches",finishedFeed)
            .putInt("online_playedCount",onlinePlayed)
            .putInt("online_totalGoals",onlineGoals)
            .putInt("online_upcomingCount",onlineUpcoming)
            .putInt("online_totalMatches",onlineTotal)
            .putString("online_goldenBoot",formatRanking(root.optJSONArray("goldenBoot"),"goals"))
            .putString("online_mvp",formatRanking(root.optJSONArray("mvp")!=null?root.optJSONArray("mvp"):root.optJSONArray("mvpRanking"),"points"))
            .putString("online_liveMatches",live)
            .putString("online_upcomingMatches",upcoming)
            .apply();
        rebuildClubCrestIndex(root);
        invalidateClubProfileCache();
        return applied;
    }


    int rebuildMatchesFromOnlineArray(JSONArray arr){
        if(arr==null || arr.length()==0) return 0;
        ArrayList<Match> fresh=new ArrayList<>();
        LinkedHashSet<String> freshTeams=new LinkedHashSet<>();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0 || away.length()==0) continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0) stage="Group stage";

            Match m=new Match(jsonGroup, home, away, jsonDate, stage);
            applyRoundMetadata(m,o);
            m.status=o.optString("status","");
            m.minute=o.optString("minute",o.optString("matchMinute",""));
            m.competition=competitionNameFromJson(o);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=m.status.toLowerCase(Locale.US);
            // Only official live/finished matches get scores. Scheduled matches stay blank.
            if(hg>=0 && ag>=0 && (isFinishedStatus(st) || isLiveStatus(st))){
                m.homeGoals=hg;
                m.awayGoals=ag;
            }else{
                m.homeGoals=-1;
                m.awayGoals=-1;
            }
            populateMatchDetails(m,o);
            fresh.add(m);
            freshTeams.add(home);
            freshTeams.add(away);
        }
        if(fresh.size()==0) return 0;
        data.matches.clear();
        data.matches.addAll(fresh);
        data.teams.clear();
        data.teams.addAll(freshTeams);
        Collections.sort(data.teams);
        return fresh.size();
    }


    int syncMatchesFromArray(JSONArray arr){
        if(arr==null) return 0;
        int changed=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0 || away.length()==0) continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            if(jsonGroup.length()==0) jsonGroup=groupOfTeam(home);
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0) stage="Group stage";

            Match target=null;
            for(Match m:data.matches){
                if((sameTeam(m.home,home)&&sameTeam(m.away,away)) || (sameTeam(m.home,away)&&sameTeam(m.away,home))){
                    target=m;
                    break;
                }
            }

            if(target==null){
                target=new Match(jsonGroup,home,away,jsonDate,stage);
                data.matches.add(target);
                changed++;
            }else{
                if(jsonGroup.length()==1 && !target.group.equals(jsonGroup)){target.group=jsonGroup; changed++;}
                if(stage.length()>0 && !target.venue.equals(stage)){target.venue=stage; changed++;}
                if(jsonDate.length()>=10 && !target.date.equals(jsonDate)){target.date=jsonDate; changed++;}
            }

            applyRoundMetadata(target,o);
            target.status=o.optString("status",target.status);
            target.minute=o.optString("minute",o.optString("matchMinute",target.minute));
            target.competition=competitionNameFromJson(o);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=target.status.toLowerCase(Locale.US);
            if(hg>=0 && ag>=0 && (isFinishedStatus(st)||isLiveStatus(st))){
                if(sameTeam(target.home,home)){
                    if(target.homeGoals!=hg || target.awayGoals!=ag){target.homeGoals=hg; target.awayGoals=ag; changed++;}
                }else{
                    if(target.homeGoals!=ag || target.awayGoals!=hg){target.homeGoals=ag; target.awayGoals=hg; changed++;}
                }
            }
            populateMatchDetails(target,o);
        }
        return changed;
    }

    int applyResultsFromArray(JSONArray arr, boolean forceFinished){
        if(arr==null) return 0;
        int applied=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=o.optString("status","").toLowerCase(Locale.US);
            boolean finalResult = forceFinished || isFinishedStatus(st);
            if(home.length()==0 || away.length()==0 || hg<0 || ag<0 || !finalResult) continue;
            boolean found=false;
            for(Match m:data.matches){
                if((sameTeam(m.home,home)&&sameTeam(m.away,away)) || (sameTeam(m.home,away)&&sameTeam(m.away,home))){
                    if(sameTeam(m.home,home)){m.homeGoals=hg;m.awayGoals=ag;}else{m.homeGoals=ag;m.awayGoals=hg;}
                    String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                    if(jsonGroup.length()==1) m.group=jsonGroup;
                    String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                    if(stage.length()==0) stage="Group stage";
                    if(stage.length()>0) m.venue=stage;
                    String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                    if(jsonDate.length()>=10) m.date=jsonDate;
                    m.status=o.optString("status","FINISHED");
                    m.minute=o.optString("minute",o.optString("matchMinute",""));
                    m.competition=competitionNameFromJson(o);
                    populateMatchDetails(m,o);
                    found=true;
                    applied++;
                    break;
                }
            }
            if(!found){
                String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                if(stage.length()==0) stage="Group stage";
                Match extra=new Match(jsonGroup,home,away,jsonDate,stage);
                applyRoundMetadata(extra,o);
                extra.status=o.optString("status","FINISHED");
                extra.minute=o.optString("minute",o.optString("matchMinute",""));
                extra.competition=competitionNameFromJson(o);
                extra.homeGoals=hg;
                extra.awayGoals=ag;
                populateMatchDetails(extra,o);
                data.matches.add(extra);
                applied++;
            }
        }
        return applied;
    }

    void applyRoundMetadata(Match match,JSONObject source){
        if(match==null||source==null)return;
        match.matchday=source.optInt("matchday",source.optInt("roundNumber",source.optInt("week",0)));
        match.roundName=source.optString("roundName",source.optString("matchdayName",source.optString("round",""))).trim();
        if(match.roundName.equalsIgnoreCase("null"))match.roundName="";
    }

    String teamNameFromJson(JSONObject o, boolean home){
        String a=home?o.optString("home",""):o.optString("away","");
        if(a.length()>0) return a;
        JSONObject obj=home?o.optJSONObject("homeTeam"):o.optJSONObject("awayTeam");
        if(obj!=null){
            a=obj.optString("name",obj.optString("shortName",obj.optString("tla","")));
            if(a.length()>0) return a;
        }
        a=home?o.optString("homeTeam",""):o.optString("awayTeam","");
        if(a.length()>0 && !a.trim().startsWith("{")) return a;
        a=home?o.optString("home_name",""):o.optString("away_name","");
        if(a.length()>0) return a;
        return "";
    }


    String competitionNameFromJson(JSONObject o){
        if(o==null) return "";
        String c=o.optString("competitionName",o.optString("competition",""));
        if(c!=null && c.length()>0 && !c.trim().startsWith("{")) return c;
        JSONObject competition=o.optJSONObject("competition");
        if(competition!=null) return competition.optString("name",competition.optString("code",""));
        return "";
    }


    int jsonHomeGoals(JSONObject o){
        if(o==null) return -1;
        if(o.has("homeGoals")) return o.optInt("homeGoals",-1);
        if(o.has("homeScore")) return o.optInt("homeScore",-1);
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject ft=score.optJSONObject("fullTime");
            if(ft!=null && !ft.isNull("home")) return ft.optInt("home",-1);
            JSONObject rt=score.optJSONObject("regularTime");
            if(rt!=null && !rt.isNull("home")) return rt.optInt("home",-1);
        }
        return -1;
    }

    int jsonAwayGoals(JSONObject o){
        if(o==null) return -1;
        if(o.has("awayGoals")) return o.optInt("awayGoals",-1);
        if(o.has("awayScore")) return o.optInt("awayScore",-1);
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject ft=score.optJSONObject("fullTime");
            if(ft!=null && !ft.isNull("away")) return ft.optInt("away",-1);
            JSONObject rt=score.optJSONObject("regularTime");
            if(rt!=null && !rt.isNull("away")) return rt.optInt("away",-1);
        }
        return -1;
    }

    String cleanGroup(String g){
        if(g==null) return "";
        g=g.trim();
        if(g.length()==0 || g.equalsIgnoreCase("null") || g.equals("?")) return "";
        if(g.startsWith("GROUP_")) g=g.substring(6);
        if(g.startsWith("Group ")) g=g.substring(6);
        if(g.equals("GROUP_STAGE") || g.equalsIgnoreCase("Group stage")) return "";
        return isGroupLetter(g)?g:"";
    }

    String cleanDate(String d){
        if(d==null) return "";
        d=d.trim();
        if(d.length()==0) return "";
        // API utcDate example: 2026-06-26T19:00:00Z -> 2026-06-26 19:00 UTC
        if(d.contains("T")){
            try{
                String x=d.replace("T"," ").replace("Z","");
                if(x.length()>=16) return x.substring(0,16)+" UTC";
            }catch(Exception ignored){}
        }
        return d;
    }

    String tournamentDateLine(){
        String last=prefs.getString("online_lastUpdate","");
        String local=displayLocalDateTime(last);
        String date=(local!=null && local.length()>=10)?local.substring(0,10):"";
        if(date.length()==0) date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        try{
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);
            String pretty=new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(d);
            return t2("Live data • updated "+pretty, "Podaci uživo • ažurirano "+pretty, "Live-Daten • aktualisiert "+pretty, "Datos en vivo • actualizado "+pretty, "Données en direct • mis à jour "+pretty);
        }catch(Exception e){
            return t2("Live tournament data", "Podaci prvenstva uživo", "Live-Turnierdaten", "Datos del torneo en vivo", "Données du tournoi en direct");
        }
    }

    String formatMatchFeed(JSONArray arr){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            if(sb.length()>0) sb.append("\n");
            sb.append(formatOneMatch(o,false));
        }
        return sb.toString();
    }

    String formatOneMatch(JSONObject o, boolean noScore){
        String home=teamNameFromJson(o,true);
        String away=teamNameFromJson(o,false);
        String group=cleanGroup(o.optString("group",o.optString("stage","")));
        String date=displayLocalDateTime(cleanDate(o.optString("date",o.optString("time",o.optString("utcDate","")))));
        String status=o.optString("status","");
        String minute=o.optString("minute",o.optString("matchMinute",""));
        int hg=jsonHomeGoals(o);
        int ag=jsonAwayGoals(o);
        String st=status.toLowerCase(Locale.US);
        boolean live=isLiveStatus(st);
        StringBuilder sb=new StringBuilder();

        if(live) sb.append(liveLabelFromJson(status, minute));
        else if(isFinishedStatus(st)) sb.append("✅ ").append(t2("FT","KRAJ","ENDE","FINAL","FIN"));
        else if(noScore || isUpcomingStatus(st)) sb.append("📅");

        if(!live && minute!=null && minute.trim().length()>0){
            if(sb.length()>0) sb.append(" ");
            sb.append(minute.trim());
        }
        if(date.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(date);
        }
        String phase=group.length()>0?("Group "+group):normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName",""))));
        if(phase.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(phase);
        }
        if(sb.length()>0) sb.append(" • ");
        sb.append(flag(home)).append(" ").append(home);
        if(!noScore && hg>=0 && ag>=0) sb.append(" ").append(hg).append(" - ").append(ag).append(" ");
        else sb.append(" vs ");
        sb.append(flag(away)).append(" ").append(away);
        return sb.toString();
    }


    String formatRanking(JSONArray arr,String valueKey){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        boolean isMvp=valueKey!=null && valueKey.equals("points");
        String[] medal={"🥇 ","🥈 ","🥉 ","4️⃣ ","5️⃣ "};
        for(int i=0;i<arr.length() && i<5;i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String name=o.optString("name",o.optString("player",""));
            String team=o.optString("team","");
            String value=o.has(valueKey)?String.valueOf(o.opt(valueKey)):"";
            if(name.length()==0) continue;
            if(isMvp){
                sb.append(medal[i]).append(name);
            }else{
                sb.append(i+1).append(". ").append(name);
            }
            if(team.length()>0) sb.append(" • ").append(flag(team)).append(" ").append(team);
            if(value.length()>0) sb.append(" • ").append(value);
            if(valueKey.equals("goals") && value.length()>0) sb.append(" goals");
            if(valueKey.equals("points") && value.length()>0) sb.append(" pts");
            sb.append("\n");
        }
        return sb.toString().trim();
    }

void showPredictor(){
        clear(tr("Predict"),tr("Prediction Studio"),"Predict");
        LinearLayout c=card();c.addView(label("🔮 "+tr("Prediction Studio"),25,text,true));c.addView(label("Scores → tables → best thirds → bracket → champion → share poster.",15,subText,false));
        Button s=btn(tr("Enter Scores"));s.setOnClickListener(v->showMatches());c.addView(s);Button br=btn(tr("Pro Bracket"));br.setOnClickListener(v->showKnockout());c.addView(br);Button poster=btn(tr("Share Poster"));poster.setOnClickListener(v->showPoster());c.addView(poster);Button df=btn(tr("Dream Final"));df.setOnClickListener(v->showDreamFinal());c.addView(df);
        LinearLayout q=card();q.addView(label("✅ Qualified teams preview",22,text,true));List<TeamRow> qual=data.qualified();for(int i=0;i<Math.min(qual.size(),16);i++){TeamRow r=qual.get(i);q.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,subText,false));}
    }

    String bracketTeam(ArrayList<String> q,int index){if(q==null||q.size()==0)return "TBD";return q.get(index%q.size());}


    ArrayList<String[]> bracketPairs(){
        ArrayList<String> q=new ArrayList<>();
        for(TeamRow r:data.qualified())q.add(r.team);
        if(q.size()<32){
            for(String t:data.teams){ if(!q.contains(t)) q.add(t); if(q.size()>=32)break; }
        }
        ArrayList<String[]> pairs=new ArrayList<>();
        for(int i=0;i<16;i++)pairs.add(new String[]{bracketTeam(q,i*2),bracketTeam(q,i*2+1)});
        return pairs;
    }
    void addBracketPair(LinearLayout parent,String a,String b,boolean withPlaceholder){
        LinearLayout box=inner(parent);
        box.addView(label(flag(a)+" "+a,16,text,true));
        if(withPlaceholder)box.addView(label("        "+tr("Winner")+": —",14,subText,false));
        else box.addView(label("        │",12,subText,false));
        box.addView(label(flag(b)+" "+b,16,text,true));
    }
    void addVisualPair(LinearLayout parent,String a,String b){
        LinearLayout box=inner(parent);
        box.addView(label("┌ "+flag(a)+" "+a,16,text,false));
        box.addView(label("├─ VS",16,subText,false));
        box.addView(label("└ "+flag(b)+" "+b,16,text,false));
    }
void showKnockout(){
        clear(tr("Pro Bracket"),tr("Round of 32")+" → "+tr("Final"),"Predict");
        LinearLayout intro=card();
        intro.setBackground(gradient(RED_DARK,RED,dp(24)));
        intro.addView(label("🏆 "+tr("Pro Bracket"),26,Color.WHITE,true));
        intro.addView(label(tr("Projected path from your group results."),15,Color.WHITE,false));
        LinearLayout c=card();
        c.addView(label(tr("Round of 32"),23,RED,true));
        for(String[] p:bracketPairs())addBracketPair(c,p[0],p[1],true);
    }
    LinearLayout inner(LinearLayout p){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(12),dp(10),dp(12),dp(10));l.setBackground(round(chipBg,dp(18),0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));p.addView(l,lp);return l;}
    String winner(String a,String b){if(a.equals(myTeam))return a;if(b.equals(myTeam))return b;return a.compareTo(b)<=0?a:b;}

    void showPoster(){
        clear(tr("Share Poster"),"Social prediction card","Predict");
        LinearLayout p=card();p.setBackground(gradient(RED_DARK,RED,dp(24)));p.addView(label("WORLD CUP FAN 2026",25,Color.WHITE,true));p.addView(label("MY TOURNAMENT PREDICTION",17,Color.WHITE,false));p.addView(label(flag(myTeam)+" "+tr("My Team")+": "+myTeam,22,Color.WHITE,true));List<TeamRow> q=data.qualified();String champ=q.size()>0?q.get(0).team:myTeam;p.addView(label("🏆 Champion: "+flag(champ)+" "+champ,25,GOLD,true));p.addView(label("Top 4\n"+topLines(4),16,Color.WHITE,false));p.addView(label("Made with World Cup Fan 2026",13,Color.WHITE,false));Button share=btn(tr("Share Poster"));share.setOnClickListener(v->sharePrediction());p.addView(share);
    }
    String topLines(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++)s+=(i+1)+". "+flag(q.get(i).team)+" "+q.get(i).team+"\n";return s.length()==0?"TBD":s;}
    String topInline(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++){if(i>0)s+=" • ";s+=flag(q.get(i).team)+" "+q.get(i).team;}return s.length()==0?"TBD":s;}

    void showDreamFinal(){clear(tr("Dream Final"),"Build a fan final","Predict");LinearLayout c=card();c.addView(label("🏆 "+tr("Dream Final"),25,text,true));Spinner left=spinner(data.teams,myTeam), right=spinner(data.teams,"Brazil");c.addView(label("Finalist 1",13,subText,true));c.addView(left);c.addView(label("Finalist 2",13,subText,true));c.addView(right);Button share=btn(tr("Share Poster"));share.setOnClickListener(v->{String a=left.getSelectedItem().toString(),b=right.getSelectedItem().toString();shareText("🏆 Dream Final 2026\n\n"+flag(a)+" "+a+" vs "+flag(b)+" "+b+"\n\nFootball Fun");});c.addView(share);}
    Spinner spinner(ArrayList<String> items,String sel){Spinner sp=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);sp.setAdapter(ad);int pos=items.indexOf(sel);if(pos>=0)sp.setSelection(pos);return sp;}

    void showMyTeam(){
        clear(tr("My Team"),"Team hub","More");
        LinearLayout c=card();
        c.addView(label(flag(myTeam)+" "+myTeam,28,RED,true));
        Spinner sp=spinner(data.teams,myTeam);
        c.addView(sp);
        Button save=btn("Save");
        save.setOnClickListener(v->{myTeam = sp.getSelectedItem().toString(); userPreferences.saveNationalTeam(myTeam); syncMatchReminders(); toast("My Team saved"); showHome();});
        c.addView(save);

        LinearLayout path=card();
        path.addView(label("Road to Final",22,text,true));
        path.addView(pathPreview(myTeam));

        LinearLayout m=card();
        m.addView(label("⚽ "+tr("Matches"),22,text,true));
        int shown=0;
        for(Match ma:data.matches){
            if(sameTeam(ma.home,myTeam)||sameTeam(ma.away,myTeam)){
                m.addView(label(myTeamMatchLine(ma),14,subText,false));
                shown++;
            }
        }
        if(shown==0)m.addView(label("No matches found for "+myTeam,14,subText,false));
    }

    String myTeamMatchLine(Match ma){
        String date=myTeamDisplayDate(ma.date);
        String score=(ma.homeGoals>=0 && ma.awayGoals>=0)?(" "+ma.homeGoals+" - "+ma.awayGoals+" "):" vs ";
        String status=(ma.homeGoals>=0 && ma.awayGoals>=0)?("✅ "+t2("FT","KRAJ","ENDE","FINAL","FIN")+" • "):"📅 ";
        StringBuilder sb=new StringBuilder();
        sb.append(status);
        if(date.length()>0)sb.append(date).append(" • ");
        String phase=stageLabel(ma);
        if(phase.length()>0)sb.append(phase).append(" • ");
        sb.append(flag(ma.home)).append(" ").append(ma.home).append(score).append(flag(ma.away)).append(" ").append(ma.away);
        return sb.toString();
    }

    String myTeamDisplayDate(String raw){
        if(raw==null)return "";
        String d=raw.trim();
        if(d.length()==0)return "";
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC");
        d=d.replace("UTC","").trim();
        if(d.length()<16)return d;
        return displayLocalDateTime(raw);
    }

    String displayLocalDateTime(String raw){
        if(raw==null)return "";
        String d=raw.trim();
        if(d.length()==0)return "";
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC") || d.endsWith("Z");
        d=d.replace("UTC","").replace("Z","").trim();
        if(d.length()<16)return d;
        // football-data.org returns UTC. Show match times in the phone's local timezone.
        // Local fallback schedules are already stored in local display time, so do not shift them.
        if(!hasUtc)return d;
        try{
            SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date parsed=in.parse(d.substring(0,16));
            SimpleDateFormat out=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
            out.setTimeZone(TimeZone.getDefault());
            return out.format(parsed);
        }catch(Exception ignored){
            return d;
        }
    }
    void showCities(){clear(tr("Host Cities"),"USA • Mexico • Canada","More");String[][] cities={{"🇲🇽 Mexico City","Opening match energy and historic football culture."},{"🇨🇦 Toronto","Canada showcase city."},{"🇺🇸 Los Angeles","Entertainment capital and massive fan base."},{"🇺🇸 New York/New Jersey","Final atmosphere and huge global audience."},{"🇺🇸 Dallas","Huge stadium, huge matches."},{"🇺🇸 Miami","Latin football culture."},{"🇨🇦 Vancouver","West coast Canadian host."},{"🇺🇸 Atlanta","Modern stadium and fan festival city."},{"🇺🇸 Houston","International city."},{"🇺🇸 Kansas City","American soccer heartland."},{"🇺🇸 Boston","Historic sports city."},{"🇺🇸 Seattle","Strong supporter culture."}};for(String[] ci:cities){LinearLayout c=card();c.addView(label(ci[0],22,text,true));c.addView(label(ci[1],15,subText,false));}}

    
    void showVisualBracket(){
        clear(tr("Visual Bracket"),tr("Tournament tree preview"),"More");
        LinearLayout c=card();
        c.addView(label("🏆 "+tr("Round of 32"),24,RED,true));
        for(String[] p:bracketPairs())addVisualPair(c,p[0],p[1]);
    }

    String projectedWinner(String a, String b) {
        if (a.equals(myTeam)) return a;
        if (b.equals(myTeam)) return b;
        int aa = teamPower(a), bb = teamPower(b);
        if (aa == bb) return a.compareTo(b) <= 0 ? a : b;
        return aa > bb ? a : b;
    }

    int teamPower(String t) {
        String elite = "Brazil Argentina France England Spain Germany Portugal Netherlands Belgium Croatia";
        String strong = "Uruguay Colombia Morocco Switzerland Denmark USA Mexico Japan Senegal";
        if (elite.contains(t)) return 90;
        if (strong.contains(t)) return 78;
        return 65;
    }

    void showScorers(){
        clear(tr("Golden Boot"),tr("Top scorers prediction"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.addView(label("🏆 Top Scorers 2026",25,text,true));
        c.addView(label(scorersIntro(),15,subText,false));
        String gb=prefs.getString("online_goldenBoot","");
        if(gb!=null && gb.trim().length()>0){
            c.addView(label(gb,15,subText,false));
            return;
        }
        String[][] scorers={
            {"Kylian Mbappé","France","7"},
            {"Harry Kane","England","6"},
            {"Lionel Messi","Argentina","5"},
            {"Vinícius Jr","Brazil","5"},
            {"Cristiano Ronaldo","Portugal","4"},
            {"Luka Modrić","Croatia","3"},
            {"Erling Haaland","Norway","3"},
            {"Mohamed Salah","Egypt","3"}
        };
        for(int i=0;i<scorers.length;i++){
            String[] s=scorers[i];
            c.addView(label((i+1)+". "+s[0]+" • "+flag(s[1])+" "+s[1]+" • "+s[2]+" "+tr("goals"),15,i<3?RED:subText,i<3));
        }
    }

    void showMvp(){
        clear(tr("MVP Prediction"),tr("Player of the tournament"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.setBackground(gradient(RED_DARK,RED,dp(24)));
        c.addView(label("⭐ "+tr("MVP Prediction"),26,Color.WHITE,true));
        c.addView(label(flag(myTeam)+" "+myTeam+" MVP Candidate",23,GOLD,true));
        c.addView(label(mvpIntro(),15,Color.WHITE,false));
        LinearLayout list=card();
        list.addView(label("🏆 MVP Power Ranking",22,text,true));
        String mv=prefs.getString("online_mvp","");
        if(mv!=null && mv.trim().length()>0){
            list.addView(label(mv,15,subText,false));
        }else{
            list.addView(label("🥇 "+flag(myTeam)+" "+myTeam+" Leader\n🥈 🇫🇷 France Star\n🥉 🇧🇷 Brazil Star\n4️⃣ 🇬🇧 England Star\n5️⃣ 🇦🇷 Argentina Star",15,subText,false));
        }
    }

    void showCompareTeams() {
        clear(tr("Compare Teams"), tr("Team vs Team"), "More");
        LinearLayout c = card();
        c.addView(label("⚔️ " + tr("Compare Teams"), 25, text, true));
        Spinner a = spinner(data.teams, myTeam);
        Spinner b = spinner(data.teams, "Brazil");
        c.addView(label("Team A", 13, subText, true)); c.addView(a);
        c.addView(label("Team B", 13, subText, true)); c.addView(b);
        Button compare = btn(tr("Compare Teams"));
        compare.setOnClickListener(v -> {
            String ta = a.getSelectedItem().toString();
            String tb = b.getSelectedItem().toString();
            showCompareResult(ta, tb);
        });
        c.addView(compare);
    }

    void showCompareResult(String a, String b) {
        clear("Compare", a + " vs " + b, "More");
        LinearLayout c = card();
        c.addView(label(flag(a) + " " + a + " vs " + flag(b) + " " + b, 22, text, true));
        int pa = teamPower(a), pb = teamPower(b);
        c.addView(label(a + " power: " + pa, 17, pa>=pb?GREEN:subText, true));
        c.addView(label(b + " power: " + pb, 17, pb>=pa?GREEN:subText, true));
        String pick = projectedWinner(a,b);
        c.addView(label("Projected winner: " + flag(pick) + " " + pick, 20, RED, true));
    }

    void showBackupExport() {
        clear(tr("Export Backup"), tr("Export / Import prediction"), "More");
        LinearLayout c = card();
        c.addView(label("💾 " + tr("Export Backup"), 24, text, true));
        c.addView(label("Export code lets fans save or send their prediction. Import can be added later when we move the app from MVP to full account-free backup.", 15, subText, false));
        Button export = btn("Share Backup Code");
        export.setOnClickListener(v -> shareText(buildBackupCode()));
        c.addView(export);
    }

    String buildBackupCode() {
        String code = "WCF2026|" + myTeam + "|" + displayPlayedCount() + "|" + displayTotalGoals() + "|" + displayProgressPercent();
        return "My World Cup Fan 2026 backup code:\n\n" + code + "\n\nSave this text for later.";
    }

    void showPdfPosterInfo() {
        clear(tr("PDF Poster Info"), tr("Printable prediction poster"), "More");
        LinearLayout c = card();
        c.addView(label("🖨️ " + tr("PDF Poster Info"), 24, text, true));
        c.addView(label("The app already has the poster layout. Next technical step is Android PDF export. For now, Share Poster creates a clean shareable prediction text/card.", 15, subText, false));
        Button open = btn("Open Share Poster");
        open.setOnClickListener(v -> showPoster());
        c.addView(open);
    }

    void showQuiz() {
        clear(tr("World Cup Quiz"), tr("Fan challenge"), "More");
        LinearLayout c = card();
        c.addView(label("🧠 " + tr("World Cup Quiz"), 25, text, true));
        final int[] score = new int[]{0};
        final int[] answered = new int[]{0};
        TextView scoreView = label(tr("Score") + ": 0/5", 18, RED, true);
        c.addView(scoreView);
        String[][] qa = {
            {"How many teams play in 2026?","48","32","36","40"},
            {"How many groups are there?","12","8","10","16"},
            {"How many teams are in each group?","4","3","5","6"},
            {"Which group is Croatia in?","L","A","D","H"},
            {"How many third-placed teams go through?","8","4","6","12"}
        };
        for (String[] q : qa) {
            LinearLayout box = inner(c);
            box.addView(label("❓ " + q[0], 16, text, true));
            ArrayList<String> opts = new ArrayList<>();
            opts.add(q[1]); opts.add(q[2]); opts.add(q[3]); opts.add(q[4]);
            Collections.shuffle(opts);
            final boolean[] done = new boolean[]{false};
            TextView result = label("", 14, subText, true);
            for(String opt:opts){
                Button b=outline(opt);
                b.setOnClickListener(v->{
                    if(done[0])return;
                    done[0]=true; answered[0]++;
                    if(((Button)v).getText().toString().equals(q[1])){score[0]++; result.setText("✅ "+tr("Correct")); result.setTextColor(GREEN);} 
                    else {result.setText("❌ "+tr("Wrong")+" • "+q[1]); result.setTextColor(RED);} 
                    scoreView.setText(tr("Score")+": "+score[0]+"/5");
                });
                box.addView(b);
            }
            box.addView(result);
        }
        Button again=btn(tr("Try again")); again.setOnClickListener(v->showQuiz()); c.addView(again);
    }

    void showStadiumGuide() {
        clear(tr("Stadium Guide"), tr("Host stadium notes"), "More");
        String[][] stadiums = {
            {"Azteca Stadium","Mexico City • iconic opening venue"},
            {"MetLife Stadium","New York/New Jersey • final-level stadium"},
            {"AT&T Stadium","Dallas • huge capacity"},
            {"SoFi Stadium","Los Angeles • modern showpiece"},
            {"Hard Rock Stadium","Miami • global fan city"},
            {"BC Place","Vancouver • Canadian west coast"}
        };
        for (String[] s : stadiums) {
            LinearLayout c = card();
            c.addView(label("🏟️ " + s[0], 22, text, true));
            c.addView(label(s[1], 15, subText, false));
        }
    }

    void showCityGuidePro() {
        clear(tr("City Guide Pro"), tr("Fan travel notes"), "More");
        String[][] cities = {
            {"Mexico City","Opening energy, football history, altitude factor."},
            {"Los Angeles","Entertainment, big stadium, global fan base."},
            {"New York/New Jersey","Final atmosphere and media center."},
            {"Dallas","Massive stadium and high-scoring indoor-style matches."},
            {"Miami","Latin football culture and beach city vibe."},
            {"Toronto","Canada showcase and multicultural fan base."}
        };
        for (String[] city : cities) {
            LinearLayout c = card();
            c.addView(label("🌎 " + city[0], 22, text, true));
            c.addView(label(city[1], 15, subText, false));
        }
    }

    void showAchievements() {
        clear(tr("Achievements"), tr("Badges and milestones"), "More");
        LinearLayout c = card();
        c.addView(label("🏅 " + tr("Achievements"), 25, text, true));
        int played = displayPlayedCount();
        c.addView(label((played>=1?"✅":"⬜") + " First Prediction", 17, played>=1?GREEN:subText, true));
        c.addView(label((played>=10?"✅":"⬜") + " Group Stage Analyst", 17, played>=10?GREEN:subText, true));
        c.addView(label((played>=24?"✅":"⬜") + " Tournament Expert", 17, played>=24?GREEN:subText, true));
        c.addView(label((displayProgressPercent()>=100?"✅":"⬜") + " Prediction Master", 17, displayProgressPercent()>=100?GOLD:subText, true));
        c.addView(label("My Team badge: " + flag(myTeam) + " " + myTeam + " Fan", 17, RED, true));
    }


    void showHostCityDetails(){
        clear(tr("Host Cities"),tr("16 host cities"),"More");
        String[][] cities={
            {"🇺🇸 Atlanta","Atlanta Stadium","United States","71,000","8","Modern host city, huge airport hub and strong sports culture.","Moderan grad domaćin, veliki zračni čvor i jaka sportska kultura.","Moderner Gastgeber, großer Flughafen-Hub und starke Sportkultur.","Ciudad moderna, gran aeropuerto y fuerte cultura deportiva.","Ville moderne, grand hub aérien et forte culture sportive."},
            {"🇺🇸 Boston","Boston Stadium","United States","65,000","7","Historic sports market with passionate East Coast fans.","Povijesni sportski grad s vatrenim navijačima istočne obale.","Historischer Sportmarkt mit leidenschaftlichen Fans der Ostküste.","Ciudad deportiva histórica con aficionados apasionados.","Marché sportif historique avec fans passionnés."},
            {"🇨🇦 Toronto","Toronto Stadium","Canada","45,000","6","Canada's biggest city and a multicultural football hub.","Najveći kanadski grad i multikulturalno nogometno središte.","Kanadas größte Stadt und multikulturelles Fußballzentrum.","La ciudad más grande de Canadá y centro multicultural del fútbol.","Plus grande ville du Canada et hub football multiculturel."},
            {"🇺🇸 Dallas","Dallas Stadium","United States","80,000","9","One of the biggest venues of the tournament.","Jedan od najvećih stadiona turnira.","Eine der größten Spielstätten des Turniers.","Una de las sedes más grandes del torneo.","L'une des plus grandes enceintes du tournoi."},
            {"🇲🇽 Guadalajara","Guadalajara Stadium","Mexico","49,000","4","Classic Mexican football city with deep local culture.","Klasični meksički nogometni grad s jakom lokalnom kulturom.","Klassische mexikanische Fußballstadt mit tiefer lokaler Kultur.","Ciudad clásica del fútbol mexicano con gran cultura local.","Ville classique du football mexicain avec forte culture locale."},
            {"🇺🇸 Houston","Houston Stadium","United States","72,000","7","Diverse global city with strong Latin football energy.","Raznolik globalni grad s jakom latino nogometnom energijom.","Vielfältige Weltstadt mit starker lateinamerikanischer Fußballenergie.","Ciudad global diversa con fuerte energía futbolera latina.","Ville mondiale diverse avec forte énergie football latino."},
            {"🇺🇸 Kansas City","Kansas City Stadium","United States","76,000","6","Known for loud crowds and supporter culture.","Poznat po glasnim navijačima i jakoj navijačkoj kulturi.","Bekannt für laute Fans und starke Supporter-Kultur.","Conocida por su afición ruidosa y cultura de seguidores.","Connue pour ses foules bruyantes et sa culture supporters."},
            {"🇺🇸 Los Angeles","Los Angeles Stadium","United States","70,000","8","Entertainment capital and premium stadium destination.","Prijestolnica zabave i premium stadionska destinacija.","Entertainment-Hauptstadt und Premium-Stadionziel.","Capital del entretenimiento y sede premium.","Capitale du divertissement et destination stade premium."},
            {"🇺🇸 Miami","Miami Stadium","United States","65,000","7","Beach city, Latin football culture and fan travel appeal.","Grad plaža, latino nogometne kulture i velika navijačka destinacija.","Strandstadt mit lateinamerikanischer Fußballkultur.","Ciudad de playa, cultura latina y gran atractivo para fans.","Ville de plage, culture football latino et forte attractivité fans."},
            {"🇲🇽 Mexico City","Mexico City Stadium","Mexico","87,000","5","Opening-match atmosphere and iconic football history.","Atmosfera utakmice otvaranja i legendarna nogometna povijest.","Eröffnungsspiel-Atmosphäre und ikonische Fußballgeschichte.","Ambiente inaugural e historia futbolística icónica.","Ambiance d'ouverture et histoire football iconique."},
            {"🇲🇽 Monterrey","Monterrey Stadium","Mexico","53,000","4","Modern stadium and intense football culture.","Moderan stadion i intenzivna nogometna kultura.","Modernes Stadion und intensive Fußballkultur.","Estadio moderno y cultura futbolera intensa.","Stade moderne et culture football intense."},
            {"🇺🇸 New York/New Jersey","New York/New Jersey Stadium","United States","82,500","8","Global media capital and final-stage atmosphere.","Globalna medijska prijestolnica i atmosfera završnice.","Globale Medienhauptstadt und Final-Atmosphäre.","Capital mediática global y ambiente de final.","Capitale médiatique mondiale et ambiance de finale."},
            {"🇺🇸 Philadelphia","Philadelphia Stadium","United States","69,000","6","Historic city with passionate sports fans.","Povijesni grad s vrlo strastvenim sportskim navijačima.","Historische Stadt mit leidenschaftlichen Sportfans.","Ciudad histórica con aficionados deportivos intensos.","Ville historique avec fans de sport passionnés."},
            {"🇺🇸 San Francisco Bay Area","Bay Area Stadium","United States","68,500","6","Tech-region host with strong tourism appeal.","Domaćin iz tehnološke regije s velikim turističkim potencijalom.","Tech-Region mit starker touristischer Anziehung.","Región tecnológica con gran atractivo turístico.","Région tech avec fort attrait touristique."},
            {"🇺🇸 Seattle","Seattle Stadium","United States","69,000","6","One of the strongest U.S. soccer cultures.","Jedna od najjačih nogometnih kultura u SAD-u.","Eine der stärksten Fußballkulturen der USA.","Una de las culturas futboleras más fuertes de EE.UU.","Une des plus fortes cultures soccer des États-Unis."},
            {"🇨🇦 Vancouver","Vancouver Stadium","Canada","54,500","7","Beautiful west-coast host city with tourism appeal.","Prekrasan grad domaćin na zapadnoj obali s jakim turizmom.","Schöne Gastgeberstadt an der Westküste mit Tourismus-Reiz.","Hermosa ciudad de la costa oeste con atractivo turístico.","Belle ville hôte de la côte ouest avec attrait touristique."}
        };
        for(String[] x:cities){
            LinearLayout c=card();
            c.addView(label(x[0],23,text,true));
            c.addView(label("🏟️ "+x[1],16,RED,true));
            c.addView(label(tr("Country")+": "+x[2]+"  •  "+tr("Capacity")+": "+x[3]+"  •  "+tr("Matches count")+": "+x[4],14,subText,false));
            c.addView(label(cityDesc(x[5],x[6],x[7],x[8],x[9]),15,subText,false));
        }
    }

    void showTeamHubPro() {
        clear("Team Hub Pro", "Detailed national team view", "More");
        LinearLayout top=card();
        top.addView(label(flag(myTeam)+" "+myTeam,30,RED,true));
        top.addView(label("Group "+groupOfTeam(myTeam)+" • saved My Team • Road to Final ready",16,subText,false));
        top.addView(label("Power rating: "+teamPower(myTeam)+"/100",18,GREEN,true));
        LinearLayout games=card();
        games.addView(label("⚽ Matches",23,text,true));
        for(Match m:data.matches){
            if(m.home.equals(myTeam)||m.away.equals(myTeam)){
                games.addView(label(displayLocalDateTime(m.date)+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away+" • "+m.venue,14,subText,false));
            }
        }
        LinearLayout notes=card();
        notes.addView(label("🔎 Fan notes",22,text,true));
        notes.addView(label("Use this screen later for squad, coach, form, star player and qualification story. It is now ready as the Team Hub base.",15,subText,false));
    }

    void showOnboardingPreview() {
        clear("Onboarding", "First launch preview", "More");
        LinearLayout a=card(); a.setBackground(gradient(RED_DARK, RED, dp(24)));
        a.addView(label("1/3  Pick your team",24,Color.WHITE,true));
        a.addView(label("Choose your national team and follow the road to the final.",16,Color.WHITE,false));
        LinearLayout b=card(); b.addView(label("2/3  Predict results",24,text,true));
        b.addView(label("Enter scores, calculate standings and build the knockout path.",16,subText,false));
        LinearLayout c=card(); c.addView(label("3/3  Share your poster",24,text,true));
        c.addView(label("Create a fan prediction and share it with friends before every matchday.",16,subText,false));
    }

    void showShareImagePlan() {
        clear("Poster Export", "Image/PDF export plan", "More");
        LinearLayout c=card();
        c.addView(label("🖼️ Share Poster Pro",24,text,true));
        c.addView(label("Current version shares prediction text/card. Next native step is PNG generation from the poster view, then PDF export for printable brackets.",15,subText,false));
        Button open=btn("Open Share Poster"); open.setOnClickListener(v->showPoster()); c.addView(open);
        LinearLayout roadmap=card();
        roadmap.addView(label("Export roadmap",22,RED,true));
        roadmap.addView(label("1. Poster preview\n2. Render as bitmap\n3. Save PNG\n4. Android share sheet\n5. PDF bracket export",15,subText,false));
    }

    void showKnockoutRules() {
        clear("Tournament Rules", "48-team format explained", "More");
        LinearLayout c=card();
        c.addView(label("📘 2026 format",24,text,true));
        c.addView(label("48 teams play in 12 groups of four. The top two teams from each group advance, plus the eight best third-placed teams. The knockout stage starts with a Round of 32.",16,subText,false));
        LinearLayout r=card();
        r.addView(label("App logic",22,RED,true));
        r.addView(label("The app calculates group tables from your scores, ranks third-placed teams and builds a predicted knockout path.",15,subText,false));
    }

    void showMonetizationPlan() {
        clear("Monetization", "Free vs Pro plan", "More");
        LinearLayout c=card(); c.setBackground(gradient(RED_DARK, RED, dp(24)));
        c.addView(label("💎 Pro plan",28,Color.WHITE,true));
        c.addView(label("Suggested: Free app + Pro unlock (€1.99–€4.99).",17,GOLD,true));
        c.addView(label("Free: scores, tables, basic prediction.\nPro: multiple predictions, poster export, PDF bracket, custom tournaments, achievements, no ads.",16,Color.WHITE,false));
        LinearLayout n=card();
        n.addView(label("Commercial focus",22,text,true));
        n.addView(label("The strongest paid feature is shareable prediction content: fans want to show their champion, final, bracket and team path.",15,subText,false));
    }


    String cityDesc(String en, String hr, String de, String es, String fr){
        if(lang.equals("HR"))return hr;
        if(lang.equals("DE"))return de;
        if(lang.equals("ES"))return es;
        if(lang.equals("FR"))return fr;
        return en;
    }
    String playerIntro(){
        if(lang.equals("HR"))return "Centar za Zlatnu kopačku, MVP prognozu i glavne zvijezde turnira.";
        if(lang.equals("DE"))return "Bereich für Goldener Schuh, MVP-Prognose und Turnierstars.";
        if(lang.equals("ES"))return "Sección para Bota de Oro, predicción MVP y estrellas del torneo.";
        if(lang.equals("FR"))return "Section Soulier d'Or, pronostic MVP et stars du tournoi.";
        return "Players hub for Golden Boot, MVP prediction and star-player watch.";
    }
    String scorersIntro(){
        if(lang.equals("HR"))return "Navijačka prognoza najboljih strijelaca. Kasnije se može povezati sa stvarnom statistikom utakmica.";
        if(lang.equals("DE"))return "Fan-Prognose der besten Torschützen. Später kann sie mit echten Spielstatistiken verbunden werden.";
        if(lang.equals("ES"))return "Predicción de goleadores para fans. Luego se puede conectar con estadísticas reales.";
        if(lang.equals("FR"))return "Pronostic des meilleurs buteurs. Plus tard, il pourra être relié aux vraies statistiques.";
        return "Fan prediction list for top scorers. Later this can be connected to real match statistics.";
    }
    String mvpIntro(){
        if(lang.equals("HR"))return "MVP prognoza prati tvoju odabranu reprezentaciju i trenutni navijački kostur.";
        if(lang.equals("DE"))return "Die MVP-Prognose folgt deinem gewählten Team und deinem aktuellen Turnierbaum.";
        if(lang.equals("ES"))return "La predicción MVP sigue tu selección elegida y tu cuadro actual.";
        if(lang.equals("FR"))return "Le pronostic MVP suit ton équipe choisie et ton tableau actuel.";
        return "MVP prediction follows your selected team and current fan bracket.";
    }

void showPlayersHub(){
        if(!ENABLE_PLAYER_DATA_MODULES){
            clear(tr("Players"),tr("Premium"),"More");
            LinearLayout locked=card();
            locked.addView(label("🔒 "+tr("Players"),24,text,true));
            locked.addView(label(t2("Player details, cards, line-ups and scorer tables are prepared in code, but hidden until the higher API plan is activated.","Detalji igrača, kartoni, sastavi i strijelci su pripremljeni u kodu, ali su sakriveni dok se ne aktivira veći API paket.","Spielerdetails, Karten, Aufstellungen und Torschützen sind im Code vorbereitet, aber bis zum höheren API-Paket ausgeblendet.","Detalles de jugadores, tarjetas, alineaciones y goleadores están preparados en el código, pero ocultos hasta activar el plan API superior.","Détails joueurs, cartons, compositions et buteurs sont prêts dans le code, mais masqués jusqu'au forfait API supérieur."),15,subText,false));
            return;
        }
        clear(tr("Players"),tr("Golden Boot"),"More");
        LinearLayout c=card();
        c.addView(label("⚽ "+tr("Players"),24,text,true));
        c.addView(label(playerIntro(),15,subText,false));
        Button scorers=btn(tr("Golden Boot")); scorers.setOnClickListener(v->showScorers()); c.addView(scorers);
        Button mvp=btn(tr("MVP Prediction")); mvp.setOnClickListener(v->showMvp()); c.addView(mvp);
        LinearLayout stars=card();
        stars.addView(label("⭐ "+tr("Star watch"),22,text,true));
        stars.addView(label("France • Mbappé\nArgentina • Messi\nEngland • Kane\nPortugal • Ronaldo\nBrazil • Vinícius Jr\nCroatia • Modrić\nNorway • Haaland\nEgypt • Salah",15,subText,false));
    }

    void showAboutApp(){
        clear(tr("About App"), tr("Independent fan app subtitle"), "More");
        LinearLayout c=card();
        c.addView(label("⚽ World Cup Fan 2026",26,text,true));
        c.addView(label(tr("Independent fan app subtitle"),18,RED,true));
        c.addView(label(tr("App version")+": "+APP_VERSION,16,subText,false));
        c.addView(label(tr("About feature line"),15,subText,false));
        LinearLayout tools=card(); tools.addView(label("🧰 "+t2("App tools","Alati aplikacije","App-Werkzeuge","Herramientas","Outils"),22,text,true));
        Button backup=outline(t2("Backup favorites","Sigurnosna kopija favorita","Favoriten sichern","Copia de favoritos","Sauvegarder les favoris")); backup.setOnClickListener(v->shareText("Football Fun backup: "+favoriteClubText()+" | "+followedCompetitionText())); tools.addView(backup);
        Button feedback=outline(t2("Send feedback","Pošalji povratnu informaciju","Feedback senden","Enviar comentarios","Envoyer un avis")); feedback.setOnClickListener(v->shareText("Football Fun feedback")); tools.addView(feedback);
        Button rate=outline(t2("Rate Football Fun","Ocijeni Football Fun","Football Fun bewerten","Valorar Football Fun","Noter Football Fun")); rate.setOnClickListener(v->toast(t2("Store rating opens after public release.","Ocjenjivanje se otvara nakon javne objave.","Bewertung nach Veröffentlichung.","La valoración se abrirá tras el lanzamiento.","La notation sera disponible après publication."))); tools.addView(rate);

        LinearLayout l=card();
        l.addView(label(tr("Legal"),22,text,true));
        l.addView(label(tr("This app is not affiliated with FIFA."),15,subText,false));
        l.addView(label(tr("Legal notice detail"),15,subText,false));
    }

    void showPrivacyPolicy(){
        clear(tr("Privacy Policy"), tr("No login. No account. No personal profile."), "More");
        LinearLayout c=card();
        c.addView(label("🔒 "+tr("Privacy Policy"),26,text,true));
        c.addView(label(tr("No login. No account. No personal profile."),16,subText,false));
        c.addView(label(tr("Data is stored only on this device."),16,subText,false));
        c.addView(label(tr("Scores, language, theme and selected team are saved locally."),16,subText,false));
        LinearLayout legal=card();
        legal.addView(label(tr("Legal safety"),22,RED,true));
        legal.addView(label(tr("This app is not affiliated with FIFA."),15,subText,false));
        legal.addView(label(tr("No betting streaming media"),15,subText,false));
    }

    boolean matchMatchesPersonalTeams(Match match){
        if(match==null)return false;
        if(sameTeam(match.home,myTeam)||sameTeam(match.away,myTeam))return true;
        if(favoriteClubs!=null)for(String club:favoriteClubs)if(sameTeam(match.home,club)||sameTeam(match.away,club))return true;
        return false;
    }

    void sortMatchesAscending(List<Match> matches){
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
    }

    void sortMatchesDescending(List<Match> matches){
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
    }

    Match nextPersonalMatch(){
        Match best=null;Date bestDate=null;long now=System.currentTimeMillis();
        for(Match match:data.matches){
            if(!matchMatchesPersonalTeams(match))continue;
            if(matchIsLive(match))return match;
            if(!matchIsUpcoming(match))continue;
            Date date=localMatchDate(match);if(date==null)continue;
            boolean dateOnly=match.date==null||displayLocalDateTime(match.date).length()<16;
            long effectiveTime=date.getTime()+(dateOnly?24L*60L*60L*1000L-1L:0L);
            if(effectiveTime<now-AppConfig.MATCH_START_GRACE_MS)continue;
            if(best==null||bestDate==null||date.before(bestDate)){best=match;bestDate=date;}
        }
        return best;
    }

    int personalLiveCount(){int count=0;for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsLive(match))count++;return count;}
    int personalTodayCount(){int count=0;for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsToday(match))count++;return count;}

    int personalUpcomingCount(int days){
        int count=0;long now=System.currentTimeMillis();long end=now+Math.max(1,days)*24L*60L*60L*1000L;
        for(Match match:data.matches){
            if(!matchMatchesPersonalTeams(match)||!matchIsUpcoming(match))continue;
            Date date=localMatchDate(match);if(date!=null&&date.getTime()>=now-AppConfig.MATCH_START_GRACE_MS&&date.getTime()<=end)count++;
        }
        return count;
    }

    ArrayList<Match> personalMatchesToday(){
        ArrayList<Match> result=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsToday(match))result.add(match);
        sortMatchesAscending(result);return result;
    }

    ArrayList<Match> recentPersonalResults(int limit){
        ArrayList<Match> result=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsFinished(match))result.add(match);
        sortMatchesDescending(result);
        if(result.size()>limit)return new ArrayList<Match>(result.subList(0,limit));
        return result;
    }

    int competitionLiveCount(String competition){int count=0;for(Match match:data.matches)if(matchBelongsToCompetition(match,competition)&&matchIsLive(match))count++;return count;}
    int competitionTodayCount(String competition){int count=0;for(Match match:data.matches)if(matchBelongsToCompetition(match,competition)&&matchIsToday(match))count++;return count;}
    int competitionUpcomingCount(String competition,int days){
        int count=0;long now=System.currentTimeMillis();long end=now+Math.max(1,days)*24L*60L*60L*1000L;
        for(Match match:data.matches){
            if(!matchBelongsToCompetition(match,competition)||!matchIsUpcoming(match))continue;
            Date date=localMatchDate(match);if(date!=null&&date.getTime()>=now-AppConfig.MATCH_START_GRACE_MS&&date.getTime()<=end)count++;
        }
        return count;
    }

    boolean matchWithinHours(Match match,int hours){
        Date date=localMatchDate(match);if(date==null)return false;
        long distance=date.getTime()-System.currentTimeMillis();
        return distance>=-AppConfig.MATCH_START_GRACE_MS&&distance<=Math.max(1,hours)*60L*60L*1000L;
    }

    boolean resultWithinHours(Match match,int hours){
        Date date=localMatchDate(match);if(date==null)return false;
        long age=System.currentTimeMillis()-date.getTime();
        return age>=0&&age<=Math.max(1,hours)*60L*60L*1000L;
    }

    String personalMatchKey(Match match){
        if(match==null)return "";
        if(match.apiId>0)return "id:"+match.apiId;
        return teamKey(match.home)+"|"+teamKey(match.away)+"|"+(match.date==null?"":match.date);
    }

    int personalAlertCount(){
        if(!favoriteNotifications)return 0;
        LinkedHashSet<String> keys=new LinkedHashSet<String>();
        for(Match match:data.matches){
            if(!matchMatchesPersonalTeams(match))continue;
            if(matchIsLive(match)||(matchIsUpcoming(match)&&matchIsToday(match))||(matchIsFinished(match)&&resultWithinHours(match,24)))keys.add(personalMatchKey(match));
        }
        Match next=nextPersonalMatch();if(next!=null&&matchWithinHours(next,48))keys.add(personalMatchKey(next));
        return keys.size();
    }

    LinearLayout briefSectionHeader(String icon,String heading,String action,View.OnClickListener listener){
        LinearLayout row=hrow();
        row.addView(label(icon+" "+heading,20,text,true),new LinearLayout.LayoutParams(0,-2,1));
        if(action!=null&&action.length()>0){TextView open=label(action+"  ›",12,RED,true);if(listener!=null)open.setOnClickListener(listener);row.addView(open);}
        return row;
    }

    void addBriefEmpty(LinearLayout parent,String message){
        TextView empty=label(message,14,subText,false);empty.setPadding(dp(10),dp(10),dp(10),dp(10));empty.setBackground(round(chipBg,dp(16),0));parent.addView(empty);
    }

    void addCompetitionPulseRow(LinearLayout parent,String competition){
        final String selected=competition;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(chipBg,dp(16),1));
        TextView icon=label(competitionIcon(competition),20,text,true);row.addView(icon);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(9),0,0,0);
        copy.addView(label(displayCompetitionName(competition),14,text,true));
        String pulse=t2("Live","Uživo","Live","En vivo","Direct")+" "+competitionLiveCount(competition)+"  •  "+t2("Today","Danas","Heute","Hoy","Aujourd’hui")+" "+competitionTodayCount(competition)+"  •  7d "+competitionUpcomingCount(competition,7);
        copy.addView(label(pulse,11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",22,RED,true));
        row.setOnClickListener(v->showCompetitionHub(selected,competitionRegion(selected)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    void showDailyBrief(){
        clear(t2("Your football day","Tvoj nogometni dan","Dein Fußballtag","Tu día de fútbol","Ta journée football"),t2("Verified updates selected for you","Provjerene informacije odabrane za tebe","Verifizierte Updates für dich","Actualizaciones verificadas para ti","Informations vérifiées pour toi"),"DailyBrief");

        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(39,18,84),Color.rgb(197,25,91),dp(24)));
        hero.addView(label("✨ "+new SimpleDateFormat("EEEE, d. MMMM",homeLocale()).format(new Date()),14,Color.WHITE,true));
        hero.addView(label(t2("For your favorites","Za tvoje favorite","Für deine Favoriten","Para tus favoritos","Pour tes favoris"),27,Color.WHITE,true));
        hero.addView(label(displayTeamName(primaryFavoriteClub())+"  •  "+displayTeamName(myTeam),15,Color.WHITE,false));
        hero.addView(kpiRow(t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(personalLiveCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(personalTodayCount()),t2("Next 7 days","Sljedećih 7 dana","Nächste 7 Tage","Próximos 7 días","7 prochains jours"),String.valueOf(personalUpcomingCount(7)),true));

        Match next=nextPersonalMatch();
        LinearLayout priority=card();priority.addView(briefSectionHeader("⚽",t2("Next priority match","Sljedeća važna utakmica","Nächstes wichtiges Spiel","Próximo partido prioritario","Prochain match prioritaire"),t2("All matches","Sve utakmice","Alle Spiele","Todos","Tous"),v->{matchDateFilter="ALL";matchStatusFilter="All";showMatches();}));
        if(next!=null)addDynamicHomeMatch(priority,next);else addBriefEmpty(priority,t2("No upcoming verified match for your selected clubs or national team.","Nema nadolazeće provjerene utakmice za odabrane klubove ili reprezentaciju.","Kein kommendes verifiziertes Spiel für deine Auswahl.","No hay próximo partido verificado para tus selecciones.","Aucun prochain match vérifié pour tes sélections."));

        LinearLayout today=card();today.addView(briefSectionHeader("📅",t2("Today for you","Danas za tebe","Heute für dich","Hoy para ti","Aujourd’hui pour toi"),t2("Open Match Center","Otvori Centar utakmica","Match Center öffnen","Abrir centro de partidos","Ouvrir le centre des matchs"),v->{matchDateFilter=dateKeyOffset(0);matchStatusFilter="All";matchFavoritesOnly=true;showMatches();}));
        ArrayList<Match> todayMatches=personalMatchesToday();
        if(todayMatches.isEmpty())addBriefEmpty(today,t2("None of your selected teams play today.","Danas ne igra nijedan od tvojih odabranih timova.","Keines deiner ausgewählten Teams spielt heute.","Ninguno de tus equipos seleccionados juega hoy.","Aucune de tes équipes sélectionnées ne joue aujourd’hui."));
        else for(int i=0;i<Math.min(4,todayMatches.size());i++)addDynamicHomeMatch(today,todayMatches.get(i));

        LinearLayout results=card();results.addView(briefSectionHeader("✅",t2("Latest verified results","Zadnji provjereni rezultati","Letzte verifizierte Ergebnisse","Últimos resultados verificados","Derniers résultats vérifiés"),"",null));
        ArrayList<Match> recent=recentPersonalResults(3);
        if(recent.isEmpty())addBriefEmpty(results,t2("No completed verified result is available yet.","Još nema dostupnog završenog provjerenog rezultata.","Noch kein verifiziertes Ergebnis verfügbar.","Aún no hay resultados verificados.","Aucun résultat vérifié n’est encore disponible."));
        else for(Match match:recent)addDynamicHomeMatch(results,match);

        LinearLayout competitions=card();competitions.addView(briefSectionHeader("🏆",t2("Competition pulse","Pregled natjecanja","Wettbewerbs-Puls","Pulso de competiciones","Pouls des compétitions"),t2("Manage","Uredi","Verwalten","Gestionar","Gérer"),v->showLeagues()));
        if(followedCompetitions==null||followedCompetitions.isEmpty())addBriefEmpty(competitions,t2("Follow competitions to add them to your daily brief.","Zaprati natjecanja kako bi se prikazivala u dnevnom pregledu.","Folge Wettbewerben für deinen Tagesbrief.","Sigue competiciones para añadirlas a tu resumen.","Suis des compétitions pour les ajouter à ton brief."));
        else{int shown=0;for(String competition:followedCompetitions){if(shown++>=5)break;addCompetitionPulseRow(competitions,competition);}}

        LinearLayout notifications=card();notifications.setBackground(gradient(Color.rgb(26,33,54),Color.rgb(61,38,91),dp(22)));
        LinearLayout notificationHead=hrow();
        LinearLayout notificationCopy=new LinearLayout(this);notificationCopy.setOrientation(LinearLayout.VERTICAL);notificationCopy.addView(label("🔔 "+t2("Reminders and alerts","Podsjetnici i obavijesti","Erinnerungen und Hinweise","Recordatorios y avisos","Rappels et alertes"),19,Color.WHITE,true));notificationCopy.addView(label(t2("Android match reminders and verified in-app alerts","Android podsjetnici za utakmice i provjerene obavijesti u aplikaciji","Android-Spielerinnerungen und geprüfte In-App-Hinweise","Recordatorios Android y avisos verificados en la app","Rappels Android et alertes vérifiées dans l’app"),12,Color.rgb(219,222,234),false));notificationHead.addView(notificationCopy,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=centerLabel(String.valueOf(MatchReminderScheduler.scheduledCount(this)),17,Color.WHITE,true);count.setBackground(round(RED,dp(18),0));notificationHead.addView(count,new LinearLayout.LayoutParams(dp(42),dp(42)));notifications.addView(notificationHead);
        Button openNotifications=outline(t2("Open reminders","Otvori podsjetnike","Erinnerungen öffnen","Abrir recordatorios","Ouvrir les rappels"));openNotifications.setOnClickListener(v->showNotificationCenter());notifications.addView(openNotifications);
    }

    boolean notificationPermissionGranted(){
        return MatchReminderScheduler.hasNotificationPermission(this);
    }

    void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT<33){
            syncMatchReminders();
            return;
        }
        if(notificationPermissionGranted())return;
        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATION_PERMISSION);
    }

    boolean matchMatchesFollowedCompetition(Match match){
        if(match==null||followedCompetitions==null||followedCompetitions.isEmpty())return false;
        for(String competition:followedCompetitions)if(matchBelongsToCompetition(match,competition))return true;
        return false;
    }

    int syncMatchReminders(){
        ArrayList<MatchReminderScheduler.Reminder> reminders=new ArrayList<MatchReminderScheduler.Reminder>();
        if(data==null||data.matches==null){
            return MatchReminderScheduler.replaceAll(this,reminders,favoriteNotifications,matchReminderMinutes);
        }
        long now=System.currentTimeMillis();
        long personalHorizon=now+120L*24L*60L*60L*1000L;
        long competitionHorizon=now+21L*24L*60L*60L*1000L;
        LinkedHashMap<String,MatchReminderScheduler.Reminder> unique=new LinkedHashMap<String,MatchReminderScheduler.Reminder>();
        for(Match match:data.matches){
            if(match==null||!matchIsUpcoming(match)||isMatchTimeTba(match))continue;
            Date kickoff=localMatchDate(match);
            if(kickoff==null||kickoff.getTime()<=now)continue;
            boolean personal=matchMatchesPersonalTeams(match);
            boolean followed=competitionReminders&&matchMatchesFollowedCompetition(match);
            if(!personal&&!followed)continue;
            long horizon=personal?personalHorizon:competitionHorizon;
            if(kickoff.getTime()>horizon)continue;
            String key=personalMatchKey(match);
            String competition=friendlyCompetitionName(match);
            unique.put(key,new MatchReminderScheduler.Reminder(
                    key,
                    displayTeamName(match.home),
                    displayTeamName(match.away),
                    displayCompetitionName(competition),
                    kickoff.getTime()
            ));
        }
        reminders.addAll(unique.values());
        return MatchReminderScheduler.replaceAll(this,reminders,favoriteNotifications,matchReminderMinutes);
    }

    Match findReminderMatch(String home,String away,long kickoffMillis){
        if(data==null||data.matches==null)return null;
        Match best=null;
        long bestDistance=Long.MAX_VALUE;
        for(Match match:data.matches){
            if(match==null)continue;
            boolean samePair=(sameTeam(match.home,home)&&sameTeam(match.away,away))||(sameTeam(match.home,away)&&sameTeam(match.away,home));
            if(!samePair)continue;
            Date kickoff=localMatchDate(match);
            long distance=kickoff==null||kickoffMillis<=0?0L:Math.abs(kickoff.getTime()-kickoffMillis);
            if(best==null||distance<bestDistance){best=match;bestDistance=distance;}
        }
        if(bestDistance>36L*60L*60L*1000L&&kickoffMillis>0)return null;
        return best;
    }

    String scheduledReminderDateLabel(long kickoffMillis){
        if(kickoffMillis<=0)return "";
        Date kickoff=new Date(kickoffMillis);
        String day=new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(kickoff);
        String time=new SimpleDateFormat("HH:mm",homeLocale()).format(kickoff);
        return day+"  •  "+time;
    }

    void addScheduledReminderRow(LinearLayout parent,MatchReminderScheduler.ScheduledReminder reminder){
        if(reminder==null)return;
        final MatchReminderScheduler.ScheduledReminder selected=reminder;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackground(round(chipBg,dp(17),1));
        TextView icon=centerLabel("🔔",20,Color.WHITE,true);icon.setBackground(round(Color.rgb(45,50,68),dp(17),0));row.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);
        copy.addView(label(selected.home+"  •  "+selected.away,14,text,true));
        String meta=scheduledReminderDateLabel(selected.kickoffMillis)+"  •  "+reminderLeadLabel(selected.leadMinutes)+" "+t2("before","prije","vorher","antes","avant");
        if(selected.competition.length()>0)meta+="\n"+selected.competition;
        copy.addView(label(meta,11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",23,RED,true));
        row.setOnClickListener(v->{Match match=findReminderMatch(selected.home,selected.away,selected.kickoffMillis);if(match!=null)showMatchDetails(match);else showNotificationCenter();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    String reminderLeadLabel(int minutes){
        if(minutes>=1440)return t2("1 day","1 dan","1 Tag","1 día","1 jour");
        if(minutes==60)return t2("1 hour","1 sat","1 Stunde","1 hora","1 heure");
        return minutes+" min";
    }

    void addReminderLeadOption(LinearLayout row,int minutes){
        boolean selected=matchReminderMinutes==minutes;
        TextView option=centerLabel(reminderLeadLabel(minutes),11,selected?Color.WHITE:subText,true);
        option.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        option.setOnClickListener(v->{
            matchReminderMinutes=minutes;
            userPreferences.saveMatchReminderMinutes(minutes);
            syncMatchReminders();
            showNotificationCenter();
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
        lp.setMargins(dp(2),0,dp(2),0);
        row.addView(option,lp);
    }

    void addNotificationAlert(LinearLayout parent,String icon,String heading,Match match){
        final Match selected=match;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackground(round(chipBg,dp(17),1));
        TextView symbol=centerLabel(icon,21,Color.WHITE,true);symbol.setBackground(round(Color.rgb(45,50,68),dp(17),0));row.addView(symbol,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);copy.addView(label(heading,13,RED,true));copy.addView(label(displayTeamName(match.home)+"  •  "+displayTeamName(match.away),14,text,true));copy.addView(label(homeDateLabel(match)+"  •  "+homeCenterValue(match),11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",23,subText,true));row.setOnClickListener(v->showMatchDetails(selected));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    void showNotificationCenter(){
        clear(t2("Notifications","Obavijesti","Benachrichtigungen","Notificaciones","Notifications"),t2("Match reminders and verified alerts","Podsjetnici za utakmice i provjerene obavijesti","Spielerinnerungen und geprüfte Hinweise","Recordatorios y avisos verificados","Rappels de match et alertes vérifiées"),"Notifications");

        int scheduled=syncMatchReminders();
        boolean permission=notificationPermissionGranted();

        LinearLayout control=card();control.setBackground(gradient(Color.rgb(47,23,92),Color.rgb(230,31,96),dp(23)));
        LinearLayout row=hrow();
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label("🔔 "+t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"),21,Color.WHITE,true));
        copy.addView(label(t2("Android reminders for your clubs and national team","Android podsjetnici za tvoje klubove i reprezentaciju","Android-Erinnerungen für deine Klubs und Nationalmannschaft","Recordatorios Android para tus clubes y selección","Rappels Android pour tes clubs et ta sélection"),12,Color.WHITE,false));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        Switch enabled=new Switch(this);enabled.setChecked(favoriteNotifications);enabled.setContentDescription(t2("Enable match reminders","Uključi podsjetnike za utakmice","Spielerinnerungen aktivieren","Activar recordatorios","Activer les rappels"));row.addView(enabled);control.addView(row);
        enabled.setOnCheckedChangeListener((button,isChecked)->{
            favoriteNotifications=isChecked;
            userPreferences.saveFavoriteNotifications(isChecked);
            syncMatchReminders();
            if(isChecked&&!notificationPermissionGranted())requestNotificationPermission();
            else showNotificationCenter();
        });
        TextView permissionState=label("● "+(permission?t2("Notification permission granted","Dozvola za obavijesti odobrena","Benachrichtigungen erlaubt","Permiso concedido","Autorisation accordée"):t2("Notification permission required","Potrebna dozvola za obavijesti","Berechtigung erforderlich","Permiso necesario","Autorisation requise")),13,permission?Color.rgb(166,255,220):Color.rgb(255,225,142),true);
        permissionState.setPadding(dp(12),dp(7),dp(12),dp(7));permissionState.setBackground(round(Color.argb(35,255,255,255),dp(15),0));control.addView(permissionState);
        if(!permission){
            Button allow=outline(t2("Allow notifications","Dopusti obavijesti","Benachrichtigungen erlauben","Permitir notificaciones","Autoriser les notifications"));
            allow.setOnClickListener(v->requestNotificationPermission());control.addView(allow);
        }

        LinearLayout timing=card();
        timing.addView(label("⏱️ "+t2("Reminder timing","Vrijeme podsjetnika","Erinnerungszeit","Momento del recordatorio","Moment du rappel"),20,text,true));
        timing.addView(label(t2("Notify me before the match starts","Obavijesti me prije početka utakmice","Vor Spielbeginn benachrichtigen","Avisarme antes del partido","Me prévenir avant le match"),13,subText,false));
        LinearLayout leadRow=hrow();addReminderLeadOption(leadRow,15);addReminderLeadOption(leadRow,30);addReminderLeadOption(leadRow,60);addReminderLeadOption(leadRow,1440);timing.addView(leadRow);

        LinearLayout compRow=hrow();compRow.setPadding(0,dp(10),0,dp(5));
        LinearLayout compCopy=new LinearLayout(this);compCopy.setOrientation(LinearLayout.VERTICAL);
        compCopy.addView(label("🏆 "+t2("Followed competitions too","I utakmice praćenih natjecanja","Auch gefolgte Wettbewerbe","También competiciones seguidas","Aussi les compétitions suivies"),15,text,true));
        compCopy.addView(label(t2("Off by default to avoid too many alerts","Isključeno je zadano kako ne bi bilo previše obavijesti","Standardmäßig aus, um zu viele Hinweise zu vermeiden","Desactivado por defecto para evitar demasiados avisos","Désactivé par défaut pour éviter trop d’alertes"),11,subText,false));
        compRow.addView(compCopy,new LinearLayout.LayoutParams(0,-2,1));
        Switch competitionSwitch=new Switch(this);competitionSwitch.setChecked(competitionReminders);compRow.addView(competitionSwitch);timing.addView(compRow);
        competitionSwitch.setOnCheckedChangeListener((button,isChecked)->{competitionReminders=isChecked;userPreferences.saveCompetitionReminders(isChecked);syncMatchReminders();showNotificationCenter();});

        timing.addView(label(t2("Scheduled reminders","Zakazani podsjetnici","Geplante Erinnerungen","Recordatorios programados","Rappels programmés")+": "+scheduled,14,text,true));
        List<MatchReminderScheduler.ScheduledReminder> scheduledItems=MatchReminderScheduler.scheduledReminders(this);
        if(!scheduledItems.isEmpty()){
            timing.addView(label("📅 "+t2("Next reminders","Sljedeći podsjetnici","Nächste Erinnerungen","Próximos recordatorios","Prochains rappels"),15,text,true));
            int visible=Math.min(5,scheduledItems.size());
            for(int i=0;i<visible;i++)addScheduledReminderRow(timing,scheduledItems.get(i));
            if(scheduledItems.size()>visible)timing.addView(label("+"+(scheduledItems.size()-visible)+" "+t2("more scheduled","još zakazano","weitere geplant","más programados","autres programmés"),11,subText,false));
        }else{
            timing.addView(label(t2("No reminder can be scheduled until a selected match has a confirmed kickoff time.","Podsjetnik se može zakazati tek kada odabrana utakmica ima potvrđeno vrijeme početka.","Eine Erinnerung ist erst mit bestätigter Anstoßzeit möglich.","El recordatorio se programa cuando el partido tiene hora confirmada.","Le rappel est programmé quand l’heure du match est confirmée."),11,subText,false));
        }
        LinearLayout actions=hrow();
        Button reschedule=outline("↻ "+t2("Reschedule","Ponovno zakaži","Neu planen","Reprogramar","Reprogrammer"));reschedule.setOnClickListener(v->{int count=syncMatchReminders();toast(t2("Reminders updated: ","Podsjetnici ažurirani: ","Erinnerungen aktualisiert: ","Recordatorios actualizados: ","Rappels actualisés : ")+count);showNotificationCenter();});actions.addView(reschedule,new LinearLayout.LayoutParams(0,dp(52),1));
        Button test=outline("✓ "+t2("Test","Test","Test","Prueba","Test"));test.setOnClickListener(v->{if(!favoriteNotifications){toast(t2("Enable reminders first","Prvo uključi podsjetnike","Aktiviere zuerst Erinnerungen","Activa primero los recordatorios","Active d’abord les rappels"));return;}if(!notificationPermissionGranted()){requestNotificationPermission();return;}if(MatchReminderScheduler.showTestNotification(this))toast(t2("Test notification sent","Testna obavijest poslana","Testbenachrichtigung gesendet","Notificación de prueba enviada","Notification de test envoyée"));});LinearLayout.LayoutParams testLp=new LinearLayout.LayoutParams(0,dp(52),1);testLp.setMargins(dp(7),0,0,0);actions.addView(test,testLp);timing.addView(actions);

        LinearLayout alerts=card();alerts.addView(label("⚡ "+t2("What needs your attention","Što ti je važno sada","Was jetzt wichtig ist","Lo importante ahora","Ce qui compte maintenant"),21,text,true));
        if(!favoriteNotifications){
            addBriefEmpty(alerts,t2("Reminders are turned off. Your favorites and match data remain saved.","Podsjetnici su isključeni. Favoriti i podaci o utakmicama ostaju spremljeni.","Erinnerungen sind deaktiviert. Favoriten und Spieldaten bleiben gespeichert.","Los recordatorios están desactivados. Tus favoritos y datos siguen guardados.","Les rappels sont désactivés. Tes favoris et données restent enregistrés."));
        }else{
            LinkedHashSet<String> shown=new LinkedHashSet<String>();int count=0;
            for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsLive(match)&&shown.add(personalMatchKey(match))){addNotificationAlert(alerts,"🔴",t2("Live now","Uživo sada","Jetzt live","En vivo ahora","En direct"),match);count++;}
            ArrayList<Match> today=personalMatchesToday();for(Match match:today)if(matchIsUpcoming(match)&&shown.add(personalMatchKey(match))){addNotificationAlert(alerts,"📅",t2("Match today","Utakmica danas","Spiel heute","Partido hoy","Match aujourd’hui"),match);count++;}
            Match next=nextPersonalMatch();if(next!=null&&matchWithinHours(next,48)&&shown.add(personalMatchKey(next))){addNotificationAlert(alerts,"⏳",t2("Coming within 48 hours","Počinje unutar 48 sati","Beginnt in 48 Stunden","Empieza en 48 horas","Commence sous 48 heures"),next);count++;}
            for(Match match:recentPersonalResults(4))if(resultWithinHours(match,24)&&shown.add(personalMatchKey(match))){addNotificationAlert(alerts,"✅",t2("Final result","Konačni rezultat","Endergebnis","Resultado final","Résultat final"),match);count++;}
            if(count==0)addBriefEmpty(alerts,t2("There are no current alerts for your selected clubs or national team.","Trenutačno nema obavijesti za odabrane klubove ili reprezentaciju.","Derzeit keine Hinweise für deine Auswahl.","No hay avisos actuales para tus selecciones.","Aucune alerte actuelle pour tes sélections."));
        }

        LinearLayout delivery=card();delivery.addView(label("🛡️ "+t2("Reliable delivery","Pouzdana isporuka","Zuverlässige Zustellung","Entrega fiable","Diffusion fiable"),20,text,true));
        delivery.addView(label(t2("Reminders are scheduled directly on this phone and restored after a restart or app update. Android can delay them slightly during aggressive battery saving. Goal alerts will be added only with a separately tested background service.","Podsjetnici se zakazuju izravno na ovom telefonu i vraćaju nakon ponovnog pokretanja ili ažuriranja aplikacije. Android ih može malo odgoditi pri jakoj štednji baterije. Obavijesti o golovima dodat ćemo tek uz posebno testiran pozadinski sustav.","Erinnerungen werden direkt auf diesem Telefon geplant und nach Neustart oder Update wiederhergestellt. Starke Akkusparmodi können sie leicht verzögern. Tor-Hinweise folgen erst mit einem separat getesteten Hintergrunddienst.","Los recordatorios se programan en este teléfono y se restauran tras reiniciar o actualizar. El ahorro de batería puede retrasarlos un poco. Los avisos de gol llegarán solo con un servicio probado.","Les rappels sont programmés sur ce téléphone et restaurés après redémarrage ou mise à jour. L’économie de batterie peut les retarder légèrement. Les alertes de but viendront avec un service testé."),13,subText,false));
    }

    void showTransferCenter(){
        clear(t2("Transfer center","Transfer centar","Transferzentrum","Centro de fichajes","Centre des transferts"),t2("Official deals, loans and rumours","Službeni transferi, posudbe i glasine","Offizielle Deals, Leihen und Gerüchte","Operaciones, cesiones y rumores","Transferts, prêts et rumeurs"),"More");
        String[][] rows={{"✅","Official","New signing added to the followed-club watchlist."},{"🔄","Rumour","Midfielder linked with a summer move."},{"📤","Outgoing","Loan option being monitored."},{"🧭","Scout watch","Three targets match the club profile."}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+t2(r[1],r[1].equals("Official")?"Službeno":r[1].equals("Rumour")?"Glasina":r[1].equals("Outgoing")?"Odlazak":"Praćenje skauta",r[1],r[1],r[1]),21,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showInjuryCenter(){
        clear(t2("Injuries & suspensions","Ozljede i suspenzije","Verletzungen & Sperren","Lesiones y sanciones","Blessures et suspensions"),favoriteClub,"More");
        LinearLayout summary=card(); summary.addView(kpiRow(t2("Injured","Ozlijeđeni","Verletzt","Lesionados","Blessés"),"2",t2("Doubtful","Upitni","Fraglich","Dudosos","Incertain"),"1",t2("Suspended","Suspendirani","Gesperrt","Sancionados","Suspendus"),"0",false));
        String[][] rows={{"🩹","First-team forward",t2("Expected return: 12 days","Povratak: 12 dana","Rückkehr: 12 Tage","Regreso: 12 días","Retour : 12 jours")},{"⚠️","Central midfielder",t2("Late fitness test","Kasni test spremnosti","Später Fitnesstest","Prueba física tardía","Test physique tardif")}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+r[1],20,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showAiDailySummary(){
        clear("Football Fun AI+",t2("Your personalized football summary","Tvoj personalizirani nogometni sažetak","Deine personalisierte Fußball-Zusammenfassung","Tu resumen personalizado","Ton résumé personnalisé"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(17,48,90),Color.rgb(84,32,142),dp(24))); hero.addView(label("🤖 "+t2("Today in your football","Danas u tvom nogometu","Heute in deinem Fußball","Hoy en tu fútbol","Aujourd'hui dans ton football"),24,Color.WHITE,true));
        hero.addView(label("• "+favoriteClub+" "+t2("remains your top priority.","ostaje tvoj glavni prioritet.","bleibt deine Top-Priorität.","sigue siendo tu prioridad.","reste ta priorité.")+"\n• "+myTeam+" "+t2("alerts are enabled.","obavijesti su uključene.","Benachrichtigungen sind aktiv.","tiene alertas activadas.","a les alertes activées.")+"\n• "+primaryFollowedCompetition()+" "+t2("is ready for the next round.","spreman je za sljedeće kolo.","ist bereit für die nächste Runde.","está listo para la próxima jornada.","est prêt pour la prochaine journée."),16,Color.WHITE,false));
        LinearLayout chance=card(); chance.addView(label("📊 "+t2("AI match probability","AI procjena utakmice","KI-Spielwahrscheinlichkeit","Probabilidad IA","Probabilité IA"),22,text,true)); chance.addView(kpiRow(favoriteClub,"62%",t2("Draw","Neriješeno","Unentschieden","Empate","Nul"),"24%",t2("Opponent","Protivnik","Gegner","Rival","Adversaire"),"14%",false)); chance.addView(label(t2("Based on saved form and available app data. Not betting advice.","Na temelju spremljene forme i dostupnih podataka. Nije savjet za klađenje.","Basierend auf gespeicherter Form. Keine Wettberatung.","Basado en la forma guardada. No es consejo de apuestas.","Basé sur la forme enregistrée. Pas un conseil de pari."),13,subText,false));
    }

    void showSmartTeamComparison(){
        clear(t2("Smart team comparison","Pametna usporedba timova","Intelligenter Teamvergleich","Comparación inteligente","Comparaison intelligente"),t2("Form, absences, value and history","Forma, izostanci, vrijednost i povijest","Form, Ausfälle, Wert und Historie","Forma, bajas, valor e historial","Forme, absences, valeur et historique"),"More");
        LinearLayout c=card(); c.addView(label(favoriteClub+"  VS  "+t2("Next opponent","Sljedeći protivnik","Nächster Gegner","Próximo rival","Prochain adversaire"),23,text,true)); c.addView(kpiRow(t2("Form","Forma","Form","Forma","Forme"),"W W D W L",t2("Squad value","Vrijednost","Kaderwert","Valor","Valeur"),"€92M",t2("AI edge","AI prednost","KI-Vorteil","Ventaja IA","Avantage IA"),"62%",false));
        LinearLayout h=card(); h.addView(label("📚 "+t2("Head-to-head","Međusobni omjer","Direkter Vergleich","Cara a cara","Face-à-face"),22,text,true)); h.addView(label(t2("Last 5: 3 wins • 1 draw • 1 loss","Zadnjih 5: 3 pobjede • 1 remi • 1 poraz","Letzte 5: 3 Siege • 1 Remis • 1 Niederlage","Últimos 5: 3 victorias • 1 empate • 1 derrota","5 derniers : 3 victoires • 1 nul • 1 défaite"),16,subText,false));
    }

    void showFootballCalendar(){
        clear(t2("Football calendar","Nogometni kalendar","Fußballkalender","Calendario de fútbol","Calendrier football"),t2("Your clubs and teams by date","Tvoji klubovi i reprezentacije po datumima","Deine Klubs und Teams nach Datum","Tus clubes y selecciones por fecha","Tes clubs et équipes par date"),"More");
        Calendar now=Calendar.getInstance(); String[] days={"MON","TUE","WED","THU","FRI","SAT","SUN"};
        LinearLayout month=card(); month.addView(label(new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(now.getTime()),24,text,true));
        LinearLayout head=hrow(); for(String d:days){TextView t=label(d,11,subText,true);t.setGravity(Gravity.CENTER);head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));} month.addView(head);
        for(int r=0;r<5;r++){LinearLayout week=hrow();for(int i=0;i<7;i++){int n=r*7+i+1;TextView d=chip(String.valueOf(n));d.setGravity(Gravity.CENTER);if(n==10||n==14||n==18)d.setText("⚽\n"+n);week.addView(d,new LinearLayout.LayoutParams(0,dp(58),1));}month.addView(week);} 
        LinearLayout upcoming=card(); upcoming.addView(label("📅 "+t2("Upcoming for you","Uskoro za tebe","Demnächst für dich","Próximamente para ti","À venir pour toi"),22,text,true)); Match m=nextFavoriteMatch(); if(m!=null)addHomeMatchRow(upcoming,m,true);
    }

    void showFanJourney(){
        clear(t2("Fan journey","Navijački put","Fan-Reise","Camino del aficionado","Parcours de fan"),t2("Profile, streaks and achievements","Profil, nizovi i postignuća","Profil, Serien und Erfolge","Perfil, rachas y logros","Profil, séries et succès"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24))); hero.addView(label("🏅 "+profileName,25,Color.WHITE,true)); hero.addView(label("🔥 12 "+t2("day streak","dana u nizu","Tage Serie","días de racha","jours de série"),18,Color.WHITE,true)); hero.addView(kpiRow(t2("Matches","Utakmice","Spiele","Partidos","Matchs"),String.valueOf(displayPlayedCount()),t2("Predictions","Prognoze","Tipps","Pronósticos","Pronostics"),"84",t2("Leagues","Lige","Ligen","Ligas","Ligues"),String.valueOf(followedCompetitions.size()),true));
        String[] badges={"🏆 "+t2("First competition followed","Prvo praćeno natjecanje","Erster Wettbewerb","Primera competición","Première compétition"),"💯 "+t2("100 match explorer","Istraživač 100 utakmica","100-Spiele-Entdecker","Explorador de 100 partidos","Explorateur de 100 matchs"),"🎯 "+t2("Prediction specialist","Specijalist prognoza","Prognose-Spezialist","Especialista en pronósticos","Spécialiste des pronostics"),"👑 "+t2("Fan of the year progress","Napredak prema navijaču godine","Fan-des-Jahres-Fortschritt","Progreso fan del año","Progression fan de l'année")};
        for(String b:badges){LinearLayout c=card();c.addView(label(b,19,text,true));c.addView(label("████████░░ 80%",15,RED,true));}
    }

void showMore(){
        clear(tr("More"),t2("Settings, data and support","Postavke, podaci i podrška","Einstellungen, Daten und Hilfe","Ajustes, datos y soporte","Réglages, données et assistance"),"More");

        LinearLayout settings=card();settings.addView(label("⚙️ "+t2("Quick settings","Brze postavke","Schnelleinstellungen","Ajustes rápidos","Réglages rapides"),21,text,true));
        settings.addView(label("🌍 "+tr("Language"),14,subText,true));
        LinearLayout langs=hrow();for(String l:new String[]{"EN","HR","DE","ES","FR"}){TextView cc=chip(l);if(l.equals(lang)){cc.setTextColor(Color.WHITE);cc.setBackground(gradient(RED_DARK,RED,dp(18)));}cc.setOnClickListener(v->{lang=((TextView)v).getText().toString();userPreferences.saveLanguage(lang);syncMatchReminders();redraw();});langs.addView(cc,new LinearLayout.LayoutParams(0,dp(42),1));}settings.addView(langs);
        LinearLayout notifyRow=hrow();notifyRow.setPadding(0,dp(7),0,dp(7));notifyRow.setClickable(true);notifyRow.setBackground(round(chipBg,dp(16),1));
        LinearLayout notifyCopy=new LinearLayout(this);notifyCopy.setOrientation(LinearLayout.VERTICAL);notifyCopy.setPadding(dp(9),0,0,0);notifyCopy.addView(label("🔔 "+t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"),16,text,true));notifyCopy.addView(label(t2("Choose timing and test Android notifications","Odaberi vrijeme i testiraj Android obavijesti","Zeit wählen und Android-Hinweise testen","Elige el momento y prueba las notificaciones","Choisis le moment et teste les notifications"),12,subText,false));notifyRow.addView(notifyCopy,new LinearLayout.LayoutParams(0,-2,1));
        TextView alertBadge=centerLabel(favoriteNotifications?String.valueOf(MatchReminderScheduler.scheduledCount(this)):t2("OFF","ISKLJ.","AUS","OFF","OFF"),favoriteNotifications?13:10,Color.WHITE,true);alertBadge.setPadding(dp(9),dp(7),dp(9),dp(7));alertBadge.setBackground(round(favoriteNotifications?RED:Color.rgb(83,89,104),dp(14),0));notifyRow.addView(alertBadge);notifyRow.setOnClickListener(v->showNotificationCenter());settings.addView(notifyRow);
        Button mode=outline(darkMode?t2("☀️ Light theme","☀️ Svijetla tema","☀️ Helles Design","☀️ Tema claro","☀️ Thème clair"):t2("🌙 Dark theme","🌙 Tamna tema","🌙 Dunkles Design","🌙 Tema oscuro","🌙 Thème sombre"));mode.setOnClickListener(v->{darkMode=!darkMode;userPreferences.saveDarkMode(darkMode);redraw();});settings.addView(mode);

        LinearLayout personal=card();personal.addView(label("⭐ "+t2("Personalization","Personalizacija","Personalisierung","Personalización","Personnalisation"),21,text,true));
        LinearLayout pr1=hrow();Button fav=outline(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"));fav.setOnClickListener(v->showFavorites());Button team=outline(tr("My Team"));team.setOnClickListener(v->showMyTeam());pr1.addView(fav,new LinearLayout.LayoutParams(0,dp(52),1));pr1.addView(team,new LinearLayout.LayoutParams(0,dp(52),1));personal.addView(pr1);Button profile=outline("👤 "+t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil"));profile.setOnClickListener(v->showProfile());personal.addView(profile);

        LinearLayout dataCard=card();dataCard.addView(label("↻ "+t2("Data center","Centar podataka","Datenzentrale","Centro de datos","Centre de données"),21,text,true));
        dataCard.addView(label("● "+t2("Connected and ready","Povezano i spremno","Verbunden und bereit","Conectado y listo","Connecté et prêt"),14,GREEN,true));dataCard.addView(label(lastUpdateLabel(prefs.getString("online_lastUpdate","")),12,subText,false));Button refresh=outline(t2("Refresh football data","Osvježi nogometne podatke","Fußballdaten aktualisieren","Actualizar datos","Actualiser les données"));refresh.setOnClickListener(v->refreshOnlineSafe(true));dataCard.addView(refresh);

        LinearLayout premium=card();premium.setBackground(gradient(PURPLE_DARK,Color.rgb(174,34,118),dp(22)));LinearLayout proRow=hrow();LinearLayout proCopy=new LinearLayout(this);proCopy.setOrientation(LinearLayout.VERTICAL);proCopy.addView(label("💎 Football Fun PRO",22,Color.WHITE,true));proCopy.addView(label(t2("Ad-free and extra convenience","Bez oglasa i dodatna praktičnost","Werbefrei und komfortabler","Sin anuncios y más comodidad","Sans publicité et plus pratique"),13,Color.WHITE,false));proRow.addView(proCopy,new LinearLayout.LayoutParams(0,-2,1));TextView proOpen=label(t2("Explore  ›","Istraži  ›","Entdecken  ›","Explorar  ›","Découvrir  ›"),13,Color.WHITE,true);proOpen.setOnClickListener(v->showPremium());proRow.addView(proOpen);premium.addView(proRow);

        LinearLayout help=card();help.addView(label("💬 "+t2("Help & information","Pomoć i informacije","Hilfe & Informationen","Ayuda e información","Aide et informations"),21,text,true));
        LinearLayout h1=hrow();Button support=outline(t2("Support","Podrška","Hilfe","Soporte","Assistance"));support.setOnClickListener(v->openSupportEmail("Football Fun support"));Button about=outline(t2("About","O aplikaciji","Über","Acerca de","À propos"));about.setOnClickListener(v->showAboutApp());h1.addView(support,new LinearLayout.LayoutParams(0,dp(52),1));h1.addView(about,new LinearLayout.LayoutParams(0,dp(52),1));help.addView(h1);
        LinearLayout h2=hrow();Button privacy=outline("🔒 "+t2("Privacy","Privatnost","Datenschutz","Privacidad","Confidentialité"));privacy.setOnClickListener(v->showPrivacyPolicy());Button terms=outline("📄 "+t2("Terms","Uvjeti","Bedingungen","Términos","Conditions"));terms.setOnClickListener(v->showTermsOfUse());h2.addView(privacy,new LinearLayout.LayoutParams(0,dp(52),1));h2.addView(terms,new LinearLayout.LayoutParams(0,dp(52),1));help.addView(h2);

        LinearLayout version=card();version.setPadding(dp(14),dp(11),dp(14),dp(11));LinearLayout vr=hrow();vr.addView(label("Football Fun",15,text,true),new LinearLayout.LayoutParams(0,-2,1));vr.addView(label("v"+APP_VERSION+" • "+APP_BUILD_CODE,13,RED,true));version.addView(vr);version.addView(label(t2("Built for fans, not for clutter.","Napravljeno za navijače, bez nepotrebnog nereda.","Für Fans gebaut, ohne Ballast.","Hecha para aficionados, sin ruido.","Conçue pour les fans, sans surcharge."),12,subText,false));
    }

    void showTermsOfUse(){
        clear(t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),"Football Fun","More");
        LinearLayout c=card();
        c.addView(label("📄 "+t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),24,text,true));
        c.addView(label(t2(
            "Football Fun provides football information for personal use. Match data may be delayed or corrected. The app does not provide betting advice. By using the app, you agree to use its content responsibly.",
            "Football Fun pruža nogometne informacije za osobnu upotrebu. Podaci o utakmicama mogu kasniti ili biti naknadno ispravljeni. Aplikacija ne daje savjete za klađenje. Korištenjem aplikacije prihvaćaš odgovorno koristiti njezin sadržaj.",
            "Football Fun stellt Fußballinformationen zur persönlichen Nutzung bereit. Spieldaten können verzögert oder korrigiert werden. Die App bietet keine Wettberatung.",
            "Football Fun ofrece información futbolística para uso personal. Los datos pueden retrasarse o corregirse. La app no ofrece consejos de apuestas.",
            "Football Fun fournit des informations footballistiques à usage personnel. Les données peuvent être retardées ou corrigées. L’application ne fournit aucun conseil de pari."),16,subText,false));
    }

    void openSupportEmail(String subject){
        try{
            Intent email=new Intent(Intent.ACTION_SENDTO);
            email.setData(Uri.parse("mailto:"));
            email.putExtra(Intent.EXTRA_SUBJECT,subject+" • v"+APP_VERSION);
            startActivity(Intent.createChooser(email,t2("Send email","Pošalji e-mail","E-Mail senden","Enviar correo","Envoyer un e-mail")));
        }catch(Exception e){
            toast(t2("No email app is available.","Nije pronađena aplikacija za e-mail.","Keine E-Mail-App verfügbar.","No hay una app de correo disponible.","Aucune application e-mail disponible."));
        }
    }

    String safeTeam(String value){
        if(value==null||value.trim().isEmpty()||value.equalsIgnoreCase("null")) return t2("To be decided","Još nije poznato","Noch offen","Por definir","À déterminer");
        return value.trim();
    }

    void addCompactResultRow(LinearLayout parent,Match m){
        LinearLayout row=hrow(); row.setPadding(dp(10),dp(8),dp(10),dp(8)); row.setBackground(round(chipBg,dp(14),0));
        TextView teams=label(flag(m.home)+" "+safeTeam(m.home)+"  "+m.homeGoals+" : "+m.awayGoals+"  "+flag(m.away)+" "+safeTeam(m.away),14,text,true);
        row.addView(teams,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatchDetails(m));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(4),0,dp(4)); parent.addView(row,lp);
    }

    void showGlobalSearch(){
        clear(t2("Global search","Globalna pretraga","Globale Suche","Búsqueda global","Recherche globale"),t2("Teams • players • competitions • cities","Klubovi • igrači • natjecanja • gradovi","Teams • Spieler • Wettbewerbe • Städte","Equipos • jugadores • competiciones • ciudades","Équipes • joueurs • compétitions • villes"),"More");
        LinearLayout c=card();
        EditText q=new EditText(this); q.setHint(t2("Type a name","Upiši naziv","Namen eingeben","Escribe un nombre","Saisir un nom")); q.setSingleLine(true); q.setTextColor(text); q.setHintTextColor(subText); q.setBackground(round(chipBg,dp(16),0)); q.setPadding(dp(14),0,dp(14),0); c.addView(q,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout results=card(); results.addView(label("🔎 "+t2("Search results","Rezultati pretrage","Suchergebnisse","Resultados","Résultats"),22,text,true));
        Button run=btn(t2("Search everything","Pretraži sve","Alles durchsuchen","Buscar todo","Tout rechercher"));
        run.setOnClickListener(v->{
            results.removeAllViews(); results.addView(label("🔎 "+t2("Search results","Rezultati pretrage","Suchergebnisse","Resultados","Résultats"),22,text,true));
            String term=q.getText().toString().trim().toLowerCase(Locale.US); int count=0;
            for(String team:data.teams) if(term.length()==0||team.toLowerCase(Locale.US).contains(term)){ Button b=outline(flag(team)+" "+team); final String selected=team; b.setOnClickListener(x->{myTeam=selected;userPreferences.saveNationalTeam(myTeam);syncMatchReminders();showMyTeam();}); results.addView(b); if(++count>=8)break; }
            String[][] comps={{"World Cup 2026","International"},{"UEFA European Championship","International"},{"UEFA Champions League","Europe"},{"Premier League","England"},{"Championship","England"},{"La Liga","Spain"},{"Bundesliga","Germany"},{"Serie A","Italy"},{"Ligue 1","France"},{"Eredivisie","Netherlands"},{"Primeira Liga","Portugal"},{"Brasileirão Série A","Brazil"},{"HNL","Croatia"}};
            for(String[] comp:comps) if(term.length()>0&&comp[0].toLowerCase(Locale.US).contains(term)){ Button b=outline("🏆 "+comp[0]); final String n=comp[0],r=comp[1]; b.setOnClickListener(x->showCompetitionHub(n,r)); results.addView(b); }
            if(count==0&&term.length()>0) results.addView(label(t2("No team found. Try a league or country.","Nema pronađene momčadi. Pokušaj ligu ili državu.","Kein Team gefunden.","No se encontró equipo.","Aucune équipe trouvée."),15,subText,false));
        }); c.addView(run);
    }

    void showProfile(){
        clear(t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil"),t2("Your football identity","Tvoj nogometni identitet","Deine Fußballidentität","Tu identidad futbolística","Ton identité football"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("👤 "+profileName,27,Color.WHITE,true)); hero.addView(label(flag(profileCountry)+" "+profileCountry,17,Color.WHITE,false));
        hero.addView(kpiRow(t2("Viewed","Pogledano","Angesehen","Vistos","Vus"),String.valueOf(displayPlayedCount()),t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),String.valueOf(favoriteClubs.size()),t2("Following","Pratiš","Gefolgt","Siguiendo","Suivis"),String.valueOf(followedCompetitions.size()),true));
        LinearLayout form=card();
        EditText name=new EditText(this); name.setText(profileName); name.setHint(t2("Display name","Ime profila","Anzeigename","Nombre visible","Nom affiché")); name.setTextColor(text); name.setBackground(round(chipBg,dp(16),0)); name.setPadding(dp(14),0,dp(14),0); form.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        Spinner country=spinner(data.teams,profileCountry); form.addView(country);
        Button save=btn(t2("Save profile","Spremi profil","Profil speichern","Guardar perfil","Enregistrer le profil")); save.setOnClickListener(v->{profileName=name.getText().toString().trim(); if(profileName.isEmpty())profileName="Football Fan"; profileCountry=country.getSelectedItem().toString(); userPreferences.saveProfile(profileName,profileCountry); toast(t2("Profile saved","Profil spremljen","Profil gespeichert","Perfil guardado","Profil enregistré")); showProfile();}); form.addView(save);
        LinearLayout achievements=card(); achievements.addView(label("🏅 "+t2("Your progress","Tvoj napredak","Dein Fortschritt","Tu progreso","Ta progression"),22,text,true)); achievements.addView(label("✓ "+t2("Profile created","Profil kreiran","Profil erstellt","Perfil creado","Profil créé")+"\n✓ "+t2("Favorite selected","Favorit odabran","Favorit gewählt","Favorito elegido","Favori choisi")+"\n✓ "+t2("Competition followed","Natjecanje praćeno","Wettbewerb verfolgt","Competición seguida","Compétition suivie"),16,subText,false));
    }

    void showOfflineCenter(){
        clear(t2("Offline & sync","Offline i sinkronizacija","Offline & Sync","Offline y sincronización","Hors ligne et synchro"),t2("Always keep your football available","Tvoj nogomet uvijek dostupan","Dein Fußball immer verfügbar","Tu fútbol siempre disponible","Ton football toujours disponible"),"More");
        LinearLayout status=card(); status.addView(label("📡 "+t2("Connection status","Status veze","Verbindungsstatus","Estado de conexión","État de connexion"),22,text,true)); status.addView(label(onlineStatus+"\n"+t2("Last cached update","Zadnje spremljeno ažuriranje","Letztes Cache-Update","Última actualización guardada","Dernière mise à jour en cache")+": "+prefs.getString("onlineLastUpdate","—"),15,subText,false));
        Button sync=btn("↻ "+t2("Sync now","Sinkroniziraj sada","Jetzt synchronisieren","Sincronizar ahora","Synchroniser maintenant")); sync.setOnClickListener(v->refreshOnlineSafe(true)); status.addView(sync);
        LinearLayout offline=card(); offline.addView(label("📦 "+t2("Offline mode","Offline način","Offline-Modus","Modo sin conexión","Mode hors ligne"),22,text,true)); offline.addView(label(t2("The latest matches, favorites and settings stay available without internet.","Zadnje utakmice, favoriti i postavke ostaju dostupni bez interneta.","Letzte Spiele, Favoriten und Einstellungen bleiben offline verfügbar.","Los últimos partidos, favoritos y ajustes quedan disponibles sin internet.","Les derniers matchs, favoris et réglages restent disponibles hors ligne."),15,subText,false));
        Button backup=outline(t2("Export local backup","Izvezi lokalnu kopiju","Lokales Backup exportieren","Exportar copia local","Exporter la sauvegarde locale")); backup.setOnClickListener(v->showBackupExport()); offline.addView(backup);
    }

    void showPremium(){
        clear(tr("Premium"),tr("Free vs Pro"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("💎 Football Fun Pro",27,Color.WHITE,true));
        hero.addView(label(t2("Built for fans who follow football every day.","Za navijače koji nogomet prate svaki dan.","Für Fans, die Fußball jeden Tag verfolgen.","Para aficionados que siguen el fútbol cada día.","Pour les fans qui suivent le football chaque jour."),16,Color.WHITE,false));
        hero.addView(label("€1.99 / "+t2("month","mjesec","Monat","mes","mois"),22,GOLD,true));
        LinearLayout benefits=card(); benefits.addView(label("✓ "+t2("No advertising","Bez oglasa","Keine Werbung","Sin publicidad","Sans publicité"),18,text,true)); benefits.addView(label("✓ "+t2("Unlimited clubs and competitions","Neograničeni klubovi i natjecanja","Unbegrenzte Klubs und Wettbewerbe","Clubes y competiciones ilimitados","Clubs et compétitions illimités"),18,text,true)); benefits.addView(label("✓ "+t2("Advanced match alerts","Napredne obavijesti za utakmice","Erweiterte Spielhinweise","Alertas avanzadas","Alertes avancées"),18,text,true)); benefits.addView(label("✓ "+t2("Deeper statistics and trends","Detaljnija statistika i trendovi","Tiefere Statistiken und Trends","Estadísticas y tendencias detalladas","Statistiques et tendances détaillées"),18,text,true)); benefits.addView(label("✓ "+t2("Premium themes and widgets","Premium teme i widgeti","Premium-Themes und Widgets","Temas y widgets Premium","Thèmes et widgets Premium"),18,text,true));
        Button coming=btn(t2("Pro launch coming soon","Pro uskoro dolazi","Pro startet bald","Pro llegará pronto","Pro arrive bientôt")); coming.setOnClickListener(v->toast(t2("You will keep your favorites when Pro launches.","Favoriti će ostati spremljeni kada Pro bude pokrenut.","Deine Favoriten bleiben beim Pro-Start erhalten.","Tus favoritos se conservarán al lanzar Pro.","Tes favoris seront conservés au lancement de Pro."))); benefits.addView(coming);
    }
    void showStats(){clear(tr("Statistics"),"Advanced insights","More");LinearLayout c=card();c.addView(label("📊 "+tr("Statistics"),25,text,true));c.addView(kpiRow("Played",""+displayPlayedCount(),"Goals",""+displayTotalGoals(),"Progress",displayProgressPercent()+"%",false));c.addView(label("Average goals: "+data.avgGoals(),18,subText,false));c.addView(label("Best attack: "+data.bestAttack(),18,RED,true));c.addView(label("Highest scoring group: "+data.bestGroup(),18,GREEN,true));}
    void sharePrediction(){shareText("⚽ Football Fun\n\n"+tr("My Team")+": "+flag(myTeam)+" "+myTeam+"\nChampion pick: "+topInline(1)+"\nTop 4: "+topInline(4)+"\nProgress: "+displayProgressPercent()+"%\n\nFootball Fun");}
    void shareText(String msg){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(send,"Share"));hideSystemBars();}
    
    void showPlayStoreChecklist() {
        clear("Play Store", tr("Launch readiness checklist"), "More");
        LinearLayout c = card();
        c.addView(label("🚀 Play Store Launch Checklist", 24, text, true));
        c.addView(label("Status: almost ready for private/internal testing.", 15, subText, false));
        c.addView(label("✅ Offline tournament simulator\n✅ All 48 teams loaded\n✅ Group tables\n✅ My Team hub\n✅ Croatia Road to Final\n✅ Multi-language menu\n✅ Dark/Light mode\n✅ Share Prediction\n✅ Premium positioning", 15, subText, false));
        LinearLayout todo = card();
        todo.addView(label("Before public release", 22, RED, true));
        todo.addView(label("1. Verify every official fixture date and venue.\n2. Do not use FIFA logo or official crests.\n3. Add real app icon and screenshots.\n4. Prepare privacy policy.\n5. Test on at least 3 phones.\n6. Build release AAB for Play Console.", 15, subText, false));
    }

    void showCroatiaRoad() {
        clear(myTeam + " Road", "Group "+groupOfTeam(myTeam)+" and path to final", "More");
        LinearLayout hero = card();
        hero.setBackground(gradient(RED_DARK, RED, dp(24)));
        hero.addView(label(flag(myTeam) + " " + myTeam + " Road to Final", 25, Color.WHITE, true));
        hero.addView(label(groupLineFor(myTeam), 16, Color.WHITE, false));
        LinearLayout g = card();
        g.addView(label("Group "+groupOfTeam(myTeam)+" matches", 22, text, true));
        for (Match m : data.matches) {
            if (m.group.equals(groupOfTeam(myTeam)) || m.home.equals(myTeam) || m.away.equals(myTeam)) {
                g.addView(label(displayLocalDateTime(m.date) + " • " + flag(m.home) + " " + m.home + " vs " + flag(m.away) + " " + m.away, 14, subText, false));
            }
        }
        LinearLayout road = card();
        road.addView(label("Projected path", 22, text, true));
        road.addView(label("Group "+groupOfTeam(myTeam)+" → Round of 32 → Round of 16 → Quarter-final → Semi-final → Final", 16, GREEN, true));
        road.addView(label("This is the emotional hook for Croatian users, while the app stays global for every fan.", 14, subText, false));
    }

    void showWorldCupFacts() {
        clear("Facts", "Tournament quick facts", "More");
        String[] facts = {
            "48 teams • 12 groups • 104 matches",
            "Top 2 from each group qualify",
            "Best 8 third-placed teams qualify",
            "Knockout starts with Round of 32",
            "Host countries: USA, Mexico and Canada",
            "App works offline after installation"
        };
        for (String f : facts) {
            LinearLayout c = card();
            c.addView(label("⚽ " + f, 19, text, true));
        }
    }

    void showPrivacyInfo() {
        clear(tr("Privacy"), tr("Legal safety"), "More");
        LinearLayout c = card();
        c.addView(label("🔒 " + tr("Privacy"), 24, text, true));
        c.addView(label(tr("Privacy info text"), 15, subText, false));
        LinearLayout l = card();
        l.addView(label(tr("Legal safety"), 22, RED, true));
        l.addView(label(tr("Legal safety text"), 15, subText, false));
    }

void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    String flag(String t){
        if(t==null)return "🏳";
        String clean=t.trim();
        String n=clean.toLowerCase()
                .replace("&","and")
                .replace("-"," ")
                .replace(".","")
                .replace(",","")
                .replace("  "," ");

        // Exact/variant fixes for countries whose API names differ from local names.
        // Do not shorten display names; this only decides which flag to show.
        if(n.equals("bih") || n.contains("bosnia")) return "🇧🇦";
        if(n.equals("sco") || n.contains("scotland")) return "🏴󠁧󠁢󠁳󠁣󠁴󠁿";
        if(n.equals("cod") || n.equals("drc") || n.contains("dr congo") || n.contains("congo dr") || n.contains("democratic republic of congo") || n.contains("democratic republic of the congo")) return "🇨🇩";

        String[][] f={
            {"Croatia","🇭🇷"},{"Brazil","🇧🇷"},{"Germany","🇩🇪"},{"Argentina","🇦🇷"},{"France","🇫🇷"},{"Spain","🇪🇸"},{"Portugal","🇵🇹"},{"England","🇬🇧"},{"Netherlands","🇳🇱"},{"Belgium","🇧🇪"},
            {"Mexico","🇲🇽"},{"USA","🇺🇸"},{"United States","🇺🇸"},{"Canada","🇨🇦"},{"Japan","🇯🇵"},{"Korea Republic","🇰🇷"},{"South Korea","🇰🇷"},{"South Africa","🇿🇦"},{"Czechia","🇨🇿"},{"Bosnia and Herzegovina","🇧🇦"},
            {"Qatar","🇶🇦"},{"Switzerland","🇨🇭"},{"Morocco","🇲🇦"},{"Haiti","🇭🇹"},{"Scotland","🏴󠁧󠁢󠁳󠁣󠁴󠁿"},{"Paraguay","🇵🇾"},{"Australia","🇦🇺"},{"Turkey","🇹🇷"},{"Curacao","🇨🇼"},{"Curaçao","🇨🇼"},
            {"Ivory Coast","🇨🇮"},{"Cote d'Ivoire","🇨🇮"},{"Ecuador","🇪🇨"},{"Sweden","🇸🇪"},{"Tunisia","🇹🇳"},{"Egypt","🇪🇬"},{"Iran","🇮🇷"},{"New Zealand","🇳🇿"},{"Cape Verde","🇨🇻"},{"Cape Verde Islands","🇨🇻"},{"Saudi Arabia","🇸🇦"},
            {"Uruguay","🇺🇾"},{"Senegal","🇸🇳"},{"Iraq","🇮🇶"},{"Norway","🇳🇴"},{"Algeria","🇩🇿"},{"Austria","🇦🇹"},{"Jordan","🇯🇴"},{"DR Congo","🇨🇩"},{"Uzbekistan","🇺🇿"},{"Colombia","🇨🇴"},{"Ghana","🇬🇭"},{"Panama","🇵🇦"}
        };
        for(String[] x:f)if(clean.equals(x[0]))return x[1];
        return "🏳";
    }
    Drawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(radius);return g;}
    Drawable round(int color,int radius,int sw){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(sw>0)g.setStroke(sw,stroke);return g;}
    int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}


    String liveLabelFromJson(String status, String minute){
        if(status==null) status="";
        if(minute==null) minute="";
        String s=status.trim().toUpperCase(Locale.US);
        String m=minute.trim().replace("'", "");
        boolean live=s.equals("LIVE") || s.equals("1H") || s.equals("2H") ||
                s.equals("IN_PROGRESS") || s.equals("IN PROGRESS") ||
                s.equals("INPLAY") || s.equals("IN PLAY");
        if(live){
            if(m.length()>0) return "🔴 LIVE "+m+"'";
            return "🔴 LIVE";
        }
        if(s.equals("HT")) return "🟠 HT";
        if(s.equals("FT") || s.equals("FINISHED") || s.equals("FULLTIME") || s.equals("FULL TIME")) return "✅ "+t2("FT","KRAJ","ENDE","FINAL","FIN");
        if(s.equals("UPCOMING") || s.equals("SCHEDULED") || s.equals("TIMED") || s.equals("NOT_STARTED") || s.equals("NOT STARTED")) return "📅";
        return "";
    }


    boolean onlineMatchIsFinished(String status){ return MatchStatus.isFinished(status); }


    String tournamentInfoLine(){
        return "🌍 Teams: 48  •  Groups: 12  •  Matches: 104";
    }

}
