package com.asappfactory.footballfun;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;

import com.asappfactory.footballfun.core.AppConfig;
import com.asappfactory.footballfun.core.ProEntitlementManager;
import com.asappfactory.footballfun.billing.GooglePlayBillingManager;
import com.asappfactory.footballfun.data.CompetitionCatalog;
import com.asappfactory.footballfun.data.ClubCatalog;
import com.asappfactory.footballfun.data.ClubIdentityRegistry;
import com.asappfactory.footballfun.data.ClubCrestCache;
import com.asappfactory.footballfun.data.LiveDataClient;
import com.asappfactory.footballfun.data.StaticClubProfileRegistry;
import com.asappfactory.footballfun.data.UserPreferences;
import com.asappfactory.footballfun.data.WorldCupData;
import com.asappfactory.footballfun.domain.MatchStatus;
import com.asappfactory.footballfun.domain.MatchConsistency;
import com.asappfactory.footballfun.model.ClubProfile;
import com.asappfactory.footballfun.model.DetailEvent;
import com.asappfactory.footballfun.model.Match;
import com.asappfactory.footballfun.model.TeamRow;
import com.asappfactory.footballfun.presentation.MatchCenterFormatter;
import com.asappfactory.footballfun.presentation.TeamLocalizer;
import com.asappfactory.footballfun.notifications.MatchReminderScheduler;
import com.asappfactory.footballfun.timeline.TimelineEnvironment;
import com.asappfactory.footballfun.timeline.TimelineProviderManager;
import com.google.android.gms.ads.AdRequest; import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

public class MainActivity extends Activity {
    static final boolean ENABLE_PLAYER_DATA_MODULES = AppConfig.ENABLE_PLAYER_DATA_MODULES;
    static final boolean ENABLE_CARDS_LINEUPS_MODULES = AppConfig.ENABLE_CARDS_LINEUPS_MODULES;
    static final String APP_VERSION = BuildConfig.VERSION_NAME;
    static final int APP_BUILD_CODE = BuildConfig.VERSION_CODE;
    static final int TOURNAMENT_TOTAL_MATCHES = AppConfig.TOURNAMENT_TOTAL_MATCHES;
    static final int REQUEST_NOTIFICATION_PERMISSION = 5240;
    final int RED=Color.rgb(255,48,94), RED_DARK=Color.rgb(139,23,77), GOLD=Color.rgb(247,199,75), GREEN=Color.rgb(35,207,145), BLUE=Color.rgb(92,118,255);
    final int PURPLE=Color.rgb(115,67,255), PURPLE_DARK=Color.rgb(53,28,108), SURFACE=Color.rgb(18,21,31);
    int bg, cardBg, text, subText, navBg, chipBg, stroke;
    int lastSystemInsetLeft=-1,lastSystemInsetTop=-1,lastSystemInsetRight=-1,lastSystemInsetBottom=-1;
    LinearLayout root, content, bottom, header;
    AdView bannerAdView;
    LinearLayout bannerAdHolder;
    InterstitialAd interstitialAd;
    volatile boolean mobileAdsInitialized=false;
    volatile boolean adInitializationRequested=false;
    ConsentInformation consentInformation;
    volatile boolean consentUpdateFinished=false;
    volatile boolean interstitialLoading=false;
    boolean interstitialShownThisSession=false;
    int interstitialMoreRequestGeneration=0;
    static final int INTERSTITIAL_WAIT_STEP_MS=250;
    static final int INTERSTITIAL_WAIT_MAX_STEPS=8;
    static final String ADMOB_TEST_BANNER_ID="ca-app-pub-3940256099942544/6300978111";
    static final String ADMOB_PRODUCTION_BANNER_ID="ca-app-pub-3506216404125900/1296974608";
    static final String ADMOB_TEST_INTERSTITIAL_ID="ca-app-pub-3940256099942544/1033173712";
    static final String ADMOB_PRODUCTION_INTERSTITIAL_ID="ca-app-pub-3506216404125900/5966797028";

    String currentBannerAdUnitId(){ return AppConfig.USE_TEST_ADS?ADMOB_TEST_BANNER_ID:ADMOB_PRODUCTION_BANNER_ID; }
    String currentInterstitialAdUnitId(){ return AppConfig.USE_TEST_ADS?ADMOB_TEST_INTERSTITIAL_ID:ADMOB_PRODUCTION_INTERSTITIAL_ID; }
    boolean shouldSuppressAdsForPro(){ return !AppConfig.QA_UNLOCK_ALL_PRO && hasProAccess(); }
    boolean canServeAdsToCurrentUser(){
        try{
            return !shouldSuppressAdsForPro()
                    && consentInformation!=null
                    && consentInformation.canRequestAds();
        }catch(Exception ignored){return false;}
    }

    ScrollView contentScroll;
    TextView title, subtitle;
    final Map<String,TextView> bottomNavButtons=new LinkedHashMap<String,TextView>();
    SharedPreferences prefs;
    UserPreferences userPreferences;
    WorldCupData data;
    final LiveDataClient liveDataClient=new LiveDataClient();
    final TimelineProviderManager timelineProviderManager=TimelineProviderManager.createDefault();
    ClubCrestCache clubCrestCache;
    volatile Map<String,String> clubCrestUrls=Collections.emptyMap();
    volatile List<Match> competitionSourceSnapshot=Collections.emptyList();
    volatile List<ClubProfile> clubProfilesCache=null;
    volatile Map<String,ClubProfile> clubProfileIndex=Collections.emptyMap();
    volatile JSONObject onlineRootCache=null;
    volatile String onlineRootCacheRaw="";
    Handler handler=new Handler();
    final ExecutorService appSerialExecutor=Executors.newSingleThreadExecutor(new ThreadFactory(){
        public Thread newThread(final Runnable task){
            Thread t=new Thread(new Runnable(){public void run(){
                try{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);}catch(Exception ignored){}
                task.run();
            }},"FootballFun-app-worker");
            t.setDaemon(true);
            return t;
        }
    });
    final ExecutorService homeExecutor=Executors.newSingleThreadExecutor(new ThreadFactory(){
        public Thread newThread(final Runnable task){
            Thread t=new Thread(new Runnable(){public void run(){
                try{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);}catch(Exception ignored){}
                task.run();
            }},"FootballFun-home-worker");
            t.setDaemon(true);
            return t;
        }
    });
    final ExecutorService matchCenterExecutor=Executors.newSingleThreadExecutor(new ThreadFactory(){
        public Thread newThread(final Runnable task){
            Thread t=new Thread(new Runnable(){public void run(){
                try{android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);}catch(Exception ignored){}
                task.run();
            }},"FootballFun-match-worker");
            t.setDaemon(true);
            return t;
        }
    });
    volatile boolean reminderSyncInProgress=false;
    volatile boolean reminderSyncRequested=false;
    volatile boolean clubProfileWarmInProgress=false;
    final Map<String,Long> localMatchMillisCache=Collections.synchronizedMap(new LinkedHashMap<String,Long>(512,0.75f,true){
        protected boolean removeEldestEntry(Map.Entry<String,Long> eldest){return size()>4096;}
    });
    final Map<String,String> localDisplayDateCache=Collections.synchronizedMap(new LinkedHashMap<String,String>(512,0.75f,true){
        protected boolean removeEldestEntry(Map.Entry<String,String> eldest){return size()>4096;}
    });
    volatile String cachedTodayKey="",cachedTomorrowKey="";
    volatile long cachedDayKeysAt=0L;
    volatile Map<String,List<Match>> teamMatchIndex=Collections.emptyMap();
    volatile long teamMatchIndexGeneration=0L;
    int screenGeneration=0;
    static final int MATCH_CENTER_PAGE_SIZE=48;
    int matchCenterPage=0;
    String lastMatchCenterFilterSignature="";
    boolean darkMode;
    boolean proUnlocked=false;
    ProEntitlementManager proEntitlement;
    GooglePlayBillingManager billingManager;
    String lang="EN", currentScreen="Home", myTeam="", favoriteClub="", profileName="Football Fan", profileCountry="Croatia", matchFilter="", groupFilter="All", matchStatusFilter="All", competitionFilter="All", matchDateFilter="TODAY";
    boolean matchFavoritesOnly=false;
    String favoriteClubSearch="", favoriteClubCompetitionFilter="ALL";
    int favoriteClubPickerLimit=18;
    Set<String> followedCompetitions=new LinkedHashSet<String>();
    Set<String> favoriteClubs=new LinkedHashSet<String>();
    Set<String> favoriteNationalTeams=new LinkedHashSet<String>();
    boolean favoriteNotifications=true;
    int matchReminderMinutes=60;
    boolean competitionReminders=false;
    TextView onlineStatusView;
    TextView onlineLastUpdateView;
    TextView matchCenterLastUpdateView;
    String onlineStatus="🟢 Ready for live data";
    volatile boolean onlineRefreshInProgress=false;
    volatile long onlineRateLimitUntilMs=0L;
    static final long ONLINE_RATE_LIMIT_BACKOFF_MS=15L*60L*1000L;
    final Object dataApplyLock=new Object();
    final Object bundledRepairLock=new Object();
    final Object competitionCacheLock=new Object();
    final Map<String,CompetitionSnapshot> competitionSnapshotCache=new LinkedHashMap<String,CompetitionSnapshot>();
    final Map<String,ArrayList<String>> competitionParticipantCache=new LinkedHashMap<String,ArrayList<String>>();
    volatile long competitionCacheGeneration=1L;
    volatile boolean competitionCacheWarmInProgress=false;
    volatile boolean bundledRepairInProgress=false;
    volatile boolean bundledBaselineLoading=false;
    Runnable autoOnlineRefreshRunnable;
    Runnable liveMatchDetailsRefreshRunnable;
    String openMatchHome="", openMatchAway="", openMatchDate="";
    int openMatchApiId=-1;
    final Map<String,PlayerRecord> playerIndex=new LinkedHashMap<String,PlayerRecord>();
    final Map<String,TeamProfileRecord> teamProfileIndex=new LinkedHashMap<String,TeamProfileRecord>();
    final Set<String> favoritePlayers=new LinkedHashSet<String>();
    final Set<String> followedMatches=new LinkedHashSet<String>();
    String openPlayerKey="";
    String currentPlayerTab="overview";
    String playerHubFilter="all";
    String playerHubQuery="";
    int playerHubResultLimit=40;
    Runnable playerHubSearchRunnable;
    String favoritesSection="overview";
    String playerCenterOriginScreen="Players";
    String homeHeroMatchKey="";
    String currentCompetitionName="";
    String currentClubOriginCompetition="";
    String currentClubOriginScreen="";
    String currentCompetitionOriginScreen="";
    String matchDetailsOriginScreen="Matches";
    String globalSearchOriginScreen="Home";
    String globalSearchQuery="";
    String currentClubName="";
    String currentClubTab="overview";
    String premiumOriginNav="More";
    String premiumReturnScreen="Home";
    String premiumRequestedFeature="";

    static final class PlayerRecord {
        int id=-1,shirtNumber=-1,age=-1,appearances=-1,minutes=-1,goals=-1,assists=-1,yellowCards=-1,redCards=-1;
        String name="",position="",club="",nationality="",photoUrl="",height="",weight="",rating="",history="",dateOfBirth="",role="";
        final ArrayList<String> recentForm=new ArrayList<String>();
        String key(){return id>0?"id:"+id:(name.trim().toLowerCase(Locale.ROOT)+"|"+club.trim().toLowerCase(Locale.ROOT));}
    }

    static final class TeamProfileRecord {
        int id=-1,founded=-1;
        String name="",shortName="",tla="",area="",crest="",address="",website="",clubColors="",venue="",coachName="",coachNationality="",lastUpdated="";
        String displayName(){return shortName.length()>0?shortName:(name.length()>0?name:tla);}
    }

    static final class CompetitionSnapshot {
        final ArrayList<Match> matches=new ArrayList<Match>();
        final ArrayList<Match> live=new ArrayList<Match>();
        final ArrayList<Match> upcoming=new ArrayList<Match>();
        final ArrayList<Match> finished=new ArrayList<Match>();
        LinkedHashMap<String,ArrayList<Match>> rounds=new LinkedHashMap<String,ArrayList<Match>>();
        int todayCount=0;
        int totalMatches=0;
        int playedMatches=0;
        int detailedResultCount=0;
        boolean playedCountFromStandings=false;
        int currentMatchday=0;
        int progressPercent=0;
        String cacheDayKey="";
    }

    static final class HomeQuickSnapshot {
        int liveCount=0,todayCount=0,tomorrowCount=0;
        int personalLive=0,personalToday=0,personalUpcoming7=0;
        final ArrayList<Match> tracked=new ArrayList<Match>();
        final ArrayList<Match> today=new ArrayList<Match>();
        final ArrayList<Match> favoriteUpcoming=new ArrayList<Match>();
        final ArrayList<String> followed=new ArrayList<String>();
        Match briefNext=null;
    }

    public void onCreate(Bundle b){
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        userPreferences=new UserPreferences(this);
        proEntitlement=new ProEntitlementManager(userPreferences);
        billingManager=new GooglePlayBillingManager(this,new GooglePlayBillingManager.Listener(){
            @Override public void onBillingStateChanged(){
                runOnUiThread(()->{
                    if(proEntitlement!=null&&billingManager!=null)proEntitlement.setGooglePlayEntitled(billingManager.hasPlayProEntitlement());
                    refreshAdsForEntitlement();
                    if("Premium".equals(currentScreen))showPremium(premiumRequestedFeature,premiumOriginNav);
                });
            }
            @Override public void onBillingMessage(String message){
                runOnUiThread(()->toast(message));
            }
        });
        billingManager.start();
        clubCrestCache=new ClubCrestCache(this);
        prefs=userPreferences.raw();
        darkMode=userPreferences.darkMode();
        lang=userPreferences.language();
        proUnlocked=userPreferences.proUnlocked();
        myTeam=userPreferences.nationalTeam();
        favoriteClub=userPreferences.favoriteClub();
        profileName=userPreferences.profileName();
        profileCountry=userPreferences.profileCountry();
        favoriteClubs=userPreferences.favoriteClubs(favoriteClub);
        favoriteNationalTeams.addAll(userPreferences.favoriteNationalTeams(myTeam));
        if(!favoriteClubs.isEmpty() && (favoriteClub==null||favoriteClub.trim().isEmpty())) favoriteClub=favoriteClubs.iterator().next();
        if(!favoriteNationalTeams.isEmpty() && (myTeam==null||myTeam.trim().isEmpty())) myTeam=favoriteNationalTeams.iterator().next();
        followedCompetitions=userPreferences.followedCompetitions();
        favoriteNotifications=userPreferences.favoriteNotifications();
        matchReminderMinutes=userPreferences.matchReminderMinutes();
        competitionReminders=userPreferences.competitionReminders();
        registerBundledStaticClubProfiles();
        normalizeFavoriteClubSelections();
        favoritePlayers.addAll(prefs.getStringSet("favorite_players",new LinkedHashSet<String>()));
        restoreFavoritePlayerProfiles();
        followedMatches.addAll(prefs.getStringSet("followed_matches",new LinkedHashSet<String>()));
        data=new WorldCupData(this,new WorldCupData.MatchRules(){
            public boolean isFinished(Match match){ return matchIsFinished(match); }
            public Match nextForTeam(String team){ return nextMatchForTeam(team); }
        });
        // Keep the main looper free for the first frame. Central-model cleanup,
        // deduplication and snapshot building are serialized on appSerialExecutor.
        applyTheme();
        build();
        initializePrivacyAndAds();
        // Start central-cache restoration before Home requests any secondary work.
        // The worker is background-only; Home immediately paints a lightweight shell.
        warmStartDataAsync();
        showHome();
        handleNotificationIntent(getIntent());
        // Competition caches are warmed only after cached/bundled data has been
        // merged into the central model. Warming them here can cache an empty
        // league snapshot during startup and make the first league open show 0.
        startAutoOnlineRefresh();
    }

    @Override
    public void onBackPressed(){
        // v5.62.1: never let a deep single-activity screen accidentally close the app.
        // Every internal destination returns exactly one logical step.
        if("ClubCenter".equals(currentScreen)){
            if("GlobalSearch".equals(currentClubOriginScreen)){
                currentClubOriginScreen="";
                showGlobalSearch();
            }else if(currentClubOriginCompetition!=null&&!currentClubOriginCompetition.isEmpty()){
                String origin=currentClubOriginCompetition;
                showCompetitionParticipants(origin);
            }else{
                showFavorites();
            }
            return;
        }
        if(("CompetitionRounds".equals(currentScreen)||"CompetitionResults".equals(currentScreen)||"CompetitionStandings".equals(currentScreen)||"CompetitionParticipants".equals(currentScreen))&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){
            showCompetitionHub(currentCompetitionName,competitionRegion(currentCompetitionName));
            return;
        }
        if("CompetitionHub".equals(currentScreen)){
            if("GlobalSearch".equals(currentCompetitionOriginScreen)){
                currentCompetitionOriginScreen="";
                showGlobalSearch();
                return;
            }
            currentCompetitionName="";
            currentClubOriginCompetition="";
            currentClubName="";
            currentClubTab="overview";
            showLeagues();
            return;
        }
        if("PlayerCenter".equals(currentScreen)){
            PlayerRecord player=playerIndex.get(openPlayerKey);
            if("ClubCenter".equals(playerCenterOriginScreen)&&player!=null&&player.club!=null&&!player.club.trim().isEmpty())showClubCenterTab(player.club,"players");
            else if("Favorites".equals(playerCenterOriginScreen))showFavorites();
            else if("More".equals(playerCenterOriginScreen)||"GlobalSearch".equals(playerCenterOriginScreen))showGlobalSearch();
            else showPlayersHub();
            return;
        }
        if("Premium".equals(currentScreen)){
            returnFromPremium();
            return;
        }
        if("MatchDetails".equals(currentScreen)){
            String origin=matchDetailsOriginScreen==null?"Matches":matchDetailsOriginScreen;
            matchDetailsOriginScreen="Matches";
            if("Home".equals(origin)){showHome();return;}
            if("DailyBrief".equals(origin)){showDailyBrief();return;}
            if("Notifications".equals(origin)){showNotificationCenter();return;}
            if("Favorites".equals(origin)){showFavorites();return;}
            if("ClubCenter".equals(origin)&&currentClubName!=null&&!currentClubName.isEmpty()){showClubCenterTab(currentClubName,currentClubTab);return;}
            if("CompetitionHub".equals(origin)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionHub(currentCompetitionName,competitionRegion(currentCompetitionName));return;}
            if("CompetitionRounds".equals(origin)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionRounds(currentCompetitionName);return;}
            if("CompetitionResults".equals(origin)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionResults(currentCompetitionName);return;}
            showMatches();return;
        }
        if("Players".equals(currentScreen)){showMore();return;}
        if("DailyBrief".equals(currentScreen)||"Notifications".equals(currentScreen)){showHome();return;}
        if("GlobalSearch".equals(currentScreen)){
            if("More".equals(globalSearchOriginScreen))showMore();else showHome();
            return;
        }
        if("Leagues".equals(currentScreen)||"Matches".equals(currentScreen)||"Favorites".equals(currentScreen)||"More".equals(currentScreen)){showHome();return;}
        if(!"Home".equals(currentScreen)){showHome();return;}
        super.onBackPressed();
    }

    void returnFromPremium(){
        String target=premiumReturnScreen==null?"Home":premiumReturnScreen;
        if("More".equals(target)){showMore();return;}
        if("Matches".equals(target)){showMatches();return;}
        if("MatchDetails".equals(target)){Match open=findOpenMatchDetails();if(open!=null){showMatchDetails(open);return;}showMatches();return;}
        if("Leagues".equals(target)){showLeagues();return;}
        if("CompetitionHub".equals(target)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionHub(currentCompetitionName,competitionRegion(currentCompetitionName));return;}
        if("CompetitionRounds".equals(target)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionRounds(currentCompetitionName);return;}
        if("CompetitionResults".equals(target)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionResults(currentCompetitionName);return;}
        if("CompetitionStandings".equals(target)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showLeagueStandings(currentCompetitionName);return;}
        if("CompetitionParticipants".equals(target)&&currentCompetitionName!=null&&!currentCompetitionName.isEmpty()){showCompetitionParticipants(currentCompetitionName);return;}
        if("ClubCenter".equals(target)&&currentClubName!=null&&!currentClubName.isEmpty()){showClubCenterTab(currentClubName,currentClubTab);return;}
        if("Players".equals(target)){showPlayersHub();return;}
        if("Notifications".equals(target)){showNotificationCenter();return;}
        if("DailyBrief".equals(target)){showDailyBrief();return;}
        showHome();
    }

    @Override
    protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        handleNotificationIntent(intent);
    }

    void handleNotificationIntent(Intent intent){
        if(intent==null)return;
        if(intent.getBooleanExtra("open_match_reminder",false)){
            String home=intent.getStringExtra("reminder_home");
            String away=intent.getStringExtra("reminder_away");
            long kickoff=intent.getLongExtra("reminder_kickoff",0L);
            intent.removeExtra("open_match_reminder");
            intent.removeExtra("reminder_home");
            intent.removeExtra("reminder_away");
            intent.removeExtra("reminder_kickoff");
            Match match=findReminderMatch(home,away,kickoff);
            if(match!=null){showMatchDetails(match);return;}
            showNotificationCenter();
            return;
        }
        if(!intent.getBooleanExtra("open_notifications",false))return;
        intent.removeExtra("open_notifications");
        showNotificationCenter();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode!=REQUEST_NOTIFICATION_PERMISSION)return;
        if(notificationPermissionGranted()){
            syncMatchRemindersAsync();
            toast(t2("Notifications enabled","Obavijesti su uključene","Benachrichtigungen aktiviert","Notificaciones activadas","Notifications activées"));
        }else{
            toast(t2("Notification permission was not granted","Dozvola za obavijesti nije odobrena","Benachrichtigungsberechtigung wurde nicht erteilt","No se concedió el permiso de notificaciones","L’autorisation de notification n’a pas été accordée"));
        }
        if(currentScreen.equals("Notifications"))showNotificationCenter();
    }

    public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) hideSystemBars();
    }

    @Override
    protected void onResume(){
        super.onResume();
        try{if(bannerAdView!=null)bannerAdView.resume();}catch(Exception ignored){}
        if(billingManager!=null)billingManager.refresh();
    }

    @Override
    protected void onPause(){
        try{if(bannerAdView!=null)bannerAdView.pause();}catch(Exception ignored){}
        super.onPause();
    }

    @Override
    protected void onDestroy(){
        try{if(bannerAdView!=null){bannerAdView.destroy();bannerAdView=null;}bannerAdHolder=null;}catch(Exception ignored){}
        try{if(billingManager!=null)billingManager.close();}catch(Exception ignored){}
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            if(liveMatchDetailsRefreshRunnable!=null) handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        try{appSerialExecutor.shutdownNow();}catch(Exception ignored){}
        try{homeExecutor.shutdownNow();}catch(Exception ignored){}
        try{matchCenterExecutor.shutdownNow();}catch(Exception ignored){}
        super.onDestroy();
    }

    long nextOnlineRefreshDelay(){
        try{
            if(data!=null && data.matches!=null){
                long now=System.currentTimeMillis();
                for(Match match:data.matches){
                    if(match==null)continue;
                    if(matchIsLive(match))return AppConfig.ACTIVE_FOOTBALL_REFRESH_MS;
                    if(matchIsUpcoming(match) && !hnlMatchNeedsResultConfirmation(match)){
                        Date kickoff=localMatchDate(match);
                        if(kickoff==null)continue;
                        long until=kickoff.getTime()-now;
                        if(until>=-AppConfig.MATCH_START_GRACE_MS
                                && until<=AppConfig.ACTIVE_FOOTBALL_WINDOW_MS){
                            return AppConfig.ACTIVE_FOOTBALL_REFRESH_MS;
                        }
                    }
                }
            }
        }catch(Exception ignored){}
        return AppConfig.AUTO_REFRESH_MS;
    }

    void startAutoOnlineRefresh(){
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            autoOnlineRefreshRunnable=new Runnable(){ public void run(){
                try{
                    refreshOnlineSafe(false);
                }catch(Exception ignored){}
                handler.postDelayed(this,nextOnlineRefreshDelay());
            }};
            handler.postDelayed(autoOnlineRefreshRunnable,nextOnlineRefreshDelay());
        }catch(Exception ignored){}
    }

    // v5.67.2: Android 15/16 enforce edge-to-edge for targetSdk 35.
    // System bars stay visible, while the header and bottom navigation consume
    // their own insets. The historical method name remains for existing callers.
    void hideSystemBars(){
        try{
            Window window=getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            if(Build.VERSION.SDK_INT>=30){
                window.setDecorFitsSystemWindows(false);
            }
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            if(Build.VERSION.SDK_INT>=29){
                window.setNavigationBarDividerColor(Color.TRANSPARENT);
                window.setNavigationBarContrastEnforced(false);
                window.setStatusBarContrastEnforced(false);
            }
            int flags=View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
            if(Build.VERSION.SDK_INT<30){
                flags|=View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
            }
            if(!darkMode&&Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            window.getDecorView().setSystemUiVisibility(flags);
            if(root!=null&&Build.VERSION.SDK_INT>=21){
                root.post(()->{try{root.requestApplyInsets();}catch(Exception ignored){}});
            }
        }catch(Exception ignored){}
    }

    void installSystemInsets(){
        if(root==null||header==null||bottom==null||content==null||Build.VERSION.SDK_INT<21)return;
        root.setOnApplyWindowInsetsListener((view,insets)->{
            int left=0,top=0,right=0,bottomInset=0;
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets bars=insets.getInsets(
                        WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars()|WindowInsets.Type.displayCutout());
                android.graphics.Insets status=insets.getInsets(
                        WindowInsets.Type.statusBars()|WindowInsets.Type.displayCutout());
                android.graphics.Insets navigation=insets.getInsets(WindowInsets.Type.navigationBars());
                left=Math.max(0,bars.left);
                top=Math.max(0,status.top);
                right=Math.max(0,bars.right);
                bottomInset=Math.max(0,navigation.bottom);
            }else{
                left=Math.max(0,insets.getSystemWindowInsetLeft());
                top=Math.max(0,insets.getSystemWindowInsetTop());
                right=Math.max(0,insets.getSystemWindowInsetRight());
                bottomInset=Math.max(0,insets.getSystemWindowInsetBottom());
                if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){
                    android.view.DisplayCutout cutout=insets.getDisplayCutout();
                    left=Math.max(left,cutout.getSafeInsetLeft());
                    top=Math.max(top,cutout.getSafeInsetTop());
                    right=Math.max(right,cutout.getSafeInsetRight());
                    bottomInset=Math.max(bottomInset,cutout.getSafeInsetBottom());
                }
            }
            if(left!=lastSystemInsetLeft||top!=lastSystemInsetTop||right!=lastSystemInsetRight||bottomInset!=lastSystemInsetBottom){
                lastSystemInsetLeft=left;lastSystemInsetTop=top;lastSystemInsetRight=right;lastSystemInsetBottom=bottomInset;
                applySystemInsets(left,top,right,bottomInset);
            }
            return insets;
        });
        root.post(()->{
            try{root.requestApplyInsets();}catch(Exception ignored){}
        });
    }

    void applySystemInsets(int left,int top,int right,int bottomInset){
        if(header!=null){
            header.setPadding(dp(18)+left,dp(8)+top,dp(18)+right,dp(6));
            ViewGroup.LayoutParams params=header.getLayoutParams();
            if(params!=null){params.height=dp(82)+top;header.setLayoutParams(params);}
        }
        if(content!=null){
            content.setPadding(dp(12)+left,dp(12),dp(12)+right,dp(28));
        }
        if(bottom!=null){
            bottom.setPadding(dp(7)+left,dp(6),dp(7)+right,dp(6)+bottomInset);
            ViewGroup.LayoutParams params=bottom.getLayoutParams();
            if(params!=null){params.height=dp(72)+bottomInset;bottom.setLayoutParams(params);}
        }
    }

    void applyTheme(){
        bg=darkMode?Color.rgb(7,9,15):Color.rgb(246,247,250);
        cardBg=darkMode?Color.rgb(18,22,33):Color.WHITE;
        text=darkMode?Color.rgb(248,249,252):Color.rgb(20,24,32);
        subText=darkMode?Color.rgb(160,169,187):Color.rgb(92,99,112);
        navBg=darkMode?Color.rgb(11,13,21):Color.WHITE;
        chipBg=darkMode?Color.rgb(28,33,46):Color.rgb(238,241,246);
        stroke=darkMode?Color.rgb(43,50,68):Color.rgb(220,225,233);
    }

    String tr(String key){
        String en=key, hr=key, de=key, es=key, fr=key;
        if(key.equals("Home")){hr="Početna";de="Start";es="Inicio";fr="Accueil";}
        else if(key.equals("Matches")){hr="Utakmice";de="Spiele";es="Partidos";fr="Matchs";}
        else if(key.equals("Groups")){hr="Skupine";de="Gruppen";es="Grupos";fr="Groupes";}
        else if(key.equals("Predict")){hr="Prognoza";de="Tipp";es="Predicción";fr="Prono";}
        else if(key.equals("More")){hr="Više";de="Mehr";es="Más";fr="Plus";}
        else if(key.equals("Leagues")){hr="Natjecanja";de="Wettbewerbe";es="Competiciones";fr="Compétitions";}
        else if(key.equals("Favorites")){hr="Favoriti";de="Favoriten";es="Favoritos";fr="Favoris";}
        else if(key.equals("My Team")){hr="Moja reprezentacija";de="Mein Team";es="Mi equipo";fr="Mon équipe";}
        else if(key.equals("Start Simulator")){hr="Pokreni simulator";de="Simulator starten";es="Iniciar simulador";fr="Démarrer";}
        else if(key.equals("Team Hub")){hr="Centar reprezentacije";de="Team-Zentrale";es="Centro equipo";fr="Hub équipe";}
        else if(key.equals("Share Poster")){hr="Podijeli poster";de="Poster teilen";es="Compartir póster";fr="Partager poster";}
        else if(key.equals("Smart Match Center")){hr="Pametni centar utakmica";de="Match-Zentrale";es="Centro de partidos";fr="Centre matchs";}
        else if(key.equals("Search team, group or host city")){hr="Traži reprezentaciju, skupinu ili grad";de="Team, Gruppe oder Stadt suchen";es="Buscar equipo, grupo o ciudad";fr="Chercher équipe, groupe ou ville";}
        else if(key.equals("Apply Search")){hr="Primijeni pretragu";de="Suchen";es="Buscar";fr="Rechercher";}
        else if(key.equals("Save Result")){hr="Spremi rezultat";de="Ergebnis speichern";es="Guardar resultado";fr="Enregistrer";}
        else if(key.equals("Prediction Studio")){hr="Studio prognoze";de="Prognose-Studio";es="Estudio de predicción";fr="Studio prédiction";}
        else if(key.equals("Enter Scores")){hr="Upiši rezultate";de="Ergebnisse eingeben";es="Introducir marcadores";fr="Saisir scores";}
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Dream Final")){hr="Finale snova";de="Traumfinale";es="Final soñado";fr="Finale rêvée";}
        else if(key.equals("Reset Scores")){hr="Resetiraj rezultate";de="Zurücksetzen";es="Reiniciar";fr="Réinitialiser";}
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Austragungsorte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Statistics")){hr="Statistika";de="Statistiken";es="Estadísticas";fr="Statistiques";}
        else if(key.equals("Premium")){hr="Premium";de="Premium";es="Premium";fr="Premium";}
        else if(key.equals("Switch to Light Mode")){hr="Prebaci na svijetli način";de="Hellmodus";es="Modo claro";fr="Mode clair";}
        else if(key.equals("Switch to Dark Mode")){hr="Prebaci na tamni način";de="Dunkelmodus";es="Modo oscuro";fr="Mode sombre";}
        else if(key.equals("Language")){hr="Jezik";de="Sprache";es="Idioma";fr="Langue";}
        else if(key.equals(myTeam + " Road to Final")){hr="Hrvatska put do finala";de="Kroatien Weg ins Finale";es="Croacia camino a la final";fr="Croatie route finale";}
        else if(key.equals("Free vs Pro")){hr="Besplatno vs Pro";de="Gratis vs Pro";es="Gratis vs Pro";fr="Gratuit vs Pro";}
        else if(key.equals("Open")){hr="Otvori";de="Öffnen";es="Abrir";fr="Ouvrir";}
        
        else if(key.equals("Visual Bracket")){hr="Vizualni kostur";de="Turnierbaum";es="Cuadro visual";fr="Tableau visuel";}
        else if(key.equals("Golden Boot")){hr="Zlatna kopačka";de="Goldener Schuh";es="Bota de Oro";fr="Soulier d'Or";}
        else if(key.equals("MVP Prediction")){hr="MVP prognoza";de="MVP Prognose";es="Predicción MVP";fr="Prédiction MVP";}
        else if(key.equals("Compare Teams")){hr="Usporedi timove";de="Teams vergleichen";es="Comparar equipos";fr="Comparer équipes";}
        else if(key.equals("Export Backup")){hr="Izvoz kopije";de="Backup exportieren";es="Exportar copia";fr="Exporter sauvegarde";}
        else if(key.equals("PDF Poster Info")){hr="PDF poster info";de="PDF Poster Info";es="Info póster PDF";fr="Info poster PDF";}
        else if(key.equals("World Cup Quiz")){hr="SP kviz";de="WM Quiz";es="Quiz Mundial";fr="Quiz Coupe du Monde";}
        else if(key.equals("Stadium Guide")){hr="Vodič stadiona";de="Stadionführer";es="Guía de estadios";fr="Guide des stades";}
        else if(key.equals("City Guide Pro")){hr="Vodič gradova Pro";de="Städteführer Pro";es="Guía de ciudades Pro";fr="Guide des villes Pro";}
        else if(key.equals("Achievements")){hr="Postignuća";de="Erfolge";es="Logros";fr="Succès";}
        else if(key.equals("Tournament tree preview")){hr="Pregled turnirskog stabla";de="Vorschau Turnierbaum";es="Vista del cuadro";fr="Aperçu du tableau";}
        else if(key.equals("Golden Boot simulation")){hr="Simulacija zlatne kopačke";de="Goldener Schuh Simulation";es="Simulación Bota de Oro";fr="Simulation Soulier d'Or";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Team vs Team")){hr="Tim protiv tima";de="Team gegen Team";es="Equipo contra equipo";fr="Équipe contre équipe";}
        else if(key.equals("Export / Import prediction")){hr="Izvoz / uvoz prognoze";de="Prognose export/import";es="Exportar / importar predicción";fr="Exporter / importer pronostic";}
        else if(key.equals("Printable prediction poster")){hr="Poster prognoze za print";de="Druckbares Prognoseposter";es="Póster imprimible";fr="Poster imprimable";}
        else if(key.equals("Fan challenge")){hr="Navijački izazov";de="Fan Herausforderung";es="Reto de fans";fr="Défi des fans";}
        else if(key.equals("Host stadium notes")){hr="Bilješke o stadionima";de="Stadion Notizen";es="Notas de estadios";fr="Notes stades";}
        else if(key.equals("Fan travel notes")){hr="Navijačke putne bilješke";de="Fan Reisehinweise";es="Notas de viaje";fr="Notes voyage fans";}
        else if(key.equals("Badges and milestones")){hr="Značke i postignuća";de="Abzeichen und Meilensteine";es="Insignias e hitos";fr="Badges et étapes";}
        else if(key.equals("Launch readiness checklist")){hr="Popis spremnosti za objavu";de="Checkliste Veröffentlichung";es="Lista de lanzamiento";fr="Liste de lancement";}
        else if(key.equals("Privacy")){hr="Privatnost";de="Datenschutz";es="Privacidad";fr="Confidentialité";}
        else if(key.equals("Legal safety")){hr="Pravna sigurnost";de="Rechtliche Sicherheit";es="Seguridad legal";fr="Sécurité juridique";}

        
        else if(key.equals("Host Cities Pro")){hr="Gradovi domaćini Pro";de="Gastgeberstädte Pro";es="Ciudades sede Pro";fr="Villes hôtes Pro";}
        else if(key.equals("Team Hub Pro")){hr="Centar reprezentacije Pro";de="Team-Zentrale Pro";es="Centro equipo Pro";fr="Hub équipe Pro";}
        else if(key.equals("Onboarding Preview")){hr="Uvodni ekran";de="Einführung";es="Introducción";fr="Introduction";}
        else if(key.equals("Poster Export Plan")){hr="Plan izvoza postera";de="Poster-Export Plan";es="Plan exportar póster";fr="Plan export poster";}
        else if(key.equals("Tournament Rules")){hr="Pravila turnira";de="Turnierregeln";es="Reglas torneo";fr="Règles tournoi";}
        else if(key.equals("Monetization Plan")){hr="Plan zarade";de="Monetarisierung";es="Monetización";fr="Monétisation";}

        
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Players")){hr="Igrači";de="Spieler";es="Jugadores";fr="Joueurs";}
        else if(key.equals("Top scorers prediction")){hr="Prognoza najboljih strijelaca";de="Torschützen-Prognose";es="Predicción de goleadores";fr="Pronostic buteurs";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Star watch")){hr="Zvijezde turnira";de="Stars im Blick";es="Estrellas a seguir";fr="Stars à suivre";}
        else if(key.equals("Shortlist")){hr="🏆 MVP Power Ranking";de="Auswahlliste";es="Lista corta";fr="Liste courte";}
        else if(key.equals("goals")){hr="golova";de="Tore";es="goles";fr="buts";}
        else if(key.equals("Privacy / Legal")){hr="Privatnost / Pravno";de="Datenschutz / Rechtliches";es="Privacidad / Legal";fr="Confidentialité / Légal";}

        
        else if(key.equals("About App")){hr="O aplikaciji";de="Über die App";es="Acerca de la app";fr="À propos";}
        else if(key.equals("Privacy Policy")){hr="Pravila privatnosti";de="Datenschutzerklärung";es="Política de privacidad";fr="Politique de confidentialité";}
        else if(key.equals("App version")){hr="Verzija aplikacije";de="App-Version";es="Versión de la app";fr="Version de l'app";}
        else if(key.equals("Independent fan-made app")){hr="Nezavisna navijačka aplikacija";de="Unabhängige Fan-App";es="Aplicación independiente de fans";fr="Application indépendante de fans";}
        else if(key.equals("No login. No account. No personal profile.")){en="No registration. No user account. Personalization stays on this device.";hr="Bez registracije i korisničkog računa. Personalizacija ostaje na ovom uređaju.";de="Keine Registrierung und kein Benutzerkonto. Personalisierung bleibt auf diesem Gerät.";es="Sin registro ni cuenta de usuario. La personalización permanece en este dispositivo.";fr="Sans inscription ni compte utilisateur. La personnalisation reste sur cet appareil.";}
        else if(key.equals("Data is stored only on this device.")){hr="Podaci se spremaju samo na ovom uređaju.";de="Daten werden nur auf diesem Gerät gespeichert.";es="Los datos se guardan solo en este dispositivo.";fr="Les données sont stockées uniquement sur cet appareil.";}
        else if(key.equals("Scores, language, theme and selected team are saved locally.")){en="Language, theme, selected competition, favorites, followed players and notification settings are stored locally.";hr="Jezik, tema, odabrano natjecanje, favoriti, praćeni igrači i postavke obavijesti spremaju se lokalno.";de="Sprache, Design, ausgewählter Wettbewerb, Favoriten, gefolgte Spieler und Benachrichtigungseinstellungen werden lokal gespeichert.";es="El idioma, tema, competición elegida, favoritos, jugadores seguidos y ajustes de notificaciones se guardan localmente.";fr="La langue, le thème, la compétition choisie, les favoris, les joueurs suivis et les réglages de notification sont stockés localement.";}
        else if(key.equals("This app is not affiliated with FIFA.")){en="Football Fun is independent and is not affiliated with or endorsed by FIFA, UEFA, national leagues, clubs or players.";hr="Football Fun je neovisan i nije povezan s FIFA-om, UEFA-om, nacionalnim ligama, klubovima ni igračima niti ga oni podržavaju.";de="Football Fun ist unabhängig und weder mit FIFA, UEFA, nationalen Ligen, Klubs oder Spielern verbunden noch von ihnen unterstützt.";es="Football Fun es independiente y no está afiliada ni respaldada por FIFA, UEFA, ligas nacionales, clubes o jugadores.";fr="Football Fun est indépendante et n’est ni affiliée ni approuvée par la FIFA, l’UEFA, les ligues nationales, les clubs ou les joueurs.";}
        else if(key.equals("Independent fan app subtitle")){en="Independent football app for matches, competitions, clubs and players.";hr="Neovisna nogometna aplikacija za utakmice, natjecanja, klubove i igrače.";de="Unabhängige Fußball-App für Spiele, Wettbewerbe, Klubs und Spieler.";es="Aplicación de fútbol independiente para partidos, competiciones, clubes y jugadores.";fr="Application de football indépendante pour les matchs, compétitions, clubs et joueurs.";}
        else if(key.equals("About feature line")){en="Live status • Fixtures • Results • Competitions • Clubs • Players";hr="Status uživo • Raspored • Rezultati • Natjecanja • Klubovi • Igrači";de="Live-Status • Spielplan • Ergebnisse • Wettbewerbe • Klubs • Spieler";es="Estado en vivo • Calendario • Resultados • Competiciones • Clubes • Jugadores";fr="Statut en direct • Calendrier • Résultats • Compétitions • Clubs • Joueurs";}
        else if(key.equals("Legal")){hr="Pravno";de="Rechtliches";es="Legal";fr="Mentions légales";}
        else if(key.equals("Legal notice detail")){en="Football Fun is independent and is not affiliated with or endorsed by FIFA, UEFA, national leagues, clubs or players. Club names, badges and trademarks belong to their respective owners and are displayed for identification where supplied by connected sources.";hr="Football Fun je neovisan i nije povezan s FIFA-om, UEFA-om, nacionalnim ligama, klubovima ni igračima niti ga oni podržavaju. Nazivi klubova, grbovi i žigovi pripadaju njihovim vlasnicima i prikazuju se radi identifikacije kada ih dostavi povezani izvor.";de="Football Fun ist unabhängig und weder mit FIFA, UEFA, nationalen Ligen, Klubs oder Spielern verbunden noch von ihnen unterstützt. Klubnamen, Wappen und Marken gehören ihren jeweiligen Eigentümern und dienen der Identifikation, wenn sie von verbundenen Quellen bereitgestellt werden.";es="Football Fun es independiente y no está afiliada ni respaldada por FIFA, UEFA, ligas nacionales, clubes o jugadores. Los nombres, escudos y marcas pertenecen a sus propietarios y se muestran para identificación cuando los proporcionan fuentes conectadas.";fr="Football Fun est indépendante et n’est ni affiliée ni approuvée par la FIFA, l’UEFA, les ligues nationales, les clubs ou les joueurs. Les noms, écussons et marques appartiennent à leurs propriétaires et sont affichés à titre d’identification lorsqu’ils sont fournis par des sources connectées.";}
        else if(key.equals("Privacy info text")){en="Football Fun does not require registration or a user account. Language, theme, selected competitions, favorites, followed clubs, players and matches, local profile fields and notification settings are stored on this device. Online connections are used to load football data and club images. Removing the app removes locally stored preferences.";hr="Football Fun ne zahtijeva registraciju ni korisnički račun. Jezik, tema, odabrana natjecanja, favoriti, praćeni klubovi, igrači i utakmice, lokalna polja profila i postavke obavijesti spremaju se na ovom uređaju. Internetska veza koristi se za dohvat nogometnih podataka i slika klubova. Uklanjanjem aplikacije uklanjaju se lokalne postavke.";de="Football Fun erfordert keine Registrierung und kein Benutzerkonto. Sprache, Design, Wettbewerbe, Favoriten, gefolgte Klubs, Spieler und Spiele, lokale Profilfelder sowie Benachrichtigungseinstellungen werden auf diesem Gerät gespeichert. Online-Verbindungen laden Fußballdaten und Klubgrafiken. Beim Entfernen der App werden lokale Einstellungen gelöscht.";es="Football Fun no requiere registro ni cuenta. El idioma, tema, competiciones, favoritos, clubes, jugadores y partidos seguidos, campos de perfil local y ajustes de notificación se guardan en este dispositivo. La conexión se usa para cargar datos de fútbol e imágenes de clubes. Al desinstalar se eliminan los ajustes locales.";fr="Football Fun ne nécessite ni inscription ni compte. La langue, le thème, les compétitions, favoris, clubs, joueurs et matchs suivis, les champs de profil local et les réglages de notification sont stockés sur cet appareil. La connexion sert à charger les données football et les images de clubs. La désinstallation supprime les réglages locaux.";}
        else if(key.equals("Legal safety text")){en="Football Fun provides football information for personal use. It does not offer betting, gambling, live video or official broadcast content. Match data can be delayed or corrected by the source.";hr="Football Fun pruža nogometne informacije za osobnu uporabu. Ne nudi klađenje, igre na sreću, video prijenos uživo ni službeni televizijski sadržaj. Podaci o utakmicama mogu kasniti ili ih izvor može naknadno ispraviti.";de="Football Fun bietet Fußballinformationen zur persönlichen Nutzung. Keine Wetten, Glücksspiele, Live-Videos oder offiziellen Übertragungen. Spieldaten können verspätet oder nachträglich korrigiert werden.";es="Football Fun ofrece información de fútbol para uso personal. No ofrece apuestas, juegos de azar, vídeo en directo ni retransmisiones oficiales. Los datos pueden retrasarse o corregirse.";fr="Football Fun fournit des informations football pour un usage personnel. Aucun pari, jeu d’argent, vidéo en direct ni diffusion officielle. Les données peuvent être retardées ou corrigées.";}
        else if(key.equals("No betting streaming media")){hr="Aplikacija ne nudi klađenje, prijenos uživo ni službeni turnirski medijski sadržaj.";de="Die App bietet keine Wetten, kein Live-Streaming und keine offiziellen Turniermedien.";es="La aplicación no ofrece apuestas, transmisión en vivo ni contenido multimedia oficial del torneo.";fr="L'application ne propose aucun pari, aucun streaming en direct et aucun contenu média officiel du tournoi.";}

        
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Round of 32")){hr="Šesnaestina finala";de="Runde der 32";es="Dieciseisavos";fr="Seizièmes de finale";}
        else if(key.equals("Round of 16")){hr="Osmina finala";de="Achtelfinale";es="Octavos de final";fr="Huitièmes de finale";}
        else if(key.equals("Quarter-finals")){hr="Četvrtfinale";de="Viertelfinale";es="Cuartos de final";fr="Quarts de finale";}
        else if(key.equals("Semi-finals")){hr="Polufinale";de="Halbfinale";es="Semifinales";fr="Demi-finales";}
        else if(key.equals("Final")){hr="Finale";de="Finale";es="Final";fr="Finale";}
        else if(key.equals("Projected path from your group results.")){hr="Kostur prema upisanim rezultatima skupina.";de="Turnierweg nach deinen Gruppenergebnissen.";es="Camino según tus resultados de grupo.";fr="Parcours selon tes résultats de groupe.";}
        
        else if(key.equals("Tournament is live")){hr="Prvenstvo je u tijeku";de="Das Turnier läuft";es="El torneo está en marcha";fr="Le tournoi est en cours";}
        else if(key.equals("Day 1 of the World Cup")){hr="Dan 1 Svjetskog prvenstva";de="Tag 1 der Weltmeisterschaft";es="Día 1 del Mundial";fr="Jour 1 de la Coupe du Monde";}
        else if(key.equals("Global Edition")){hr="Globalno izdanje";de="Globale Ausgabe";es="Edición global";fr="Édition mondiale";}
        else if(key.equals("Progress")){hr="Napredak";de="Fortschritt";es="Progreso";fr="Progression";}
        else if(key.equals("Played")){hr="Odigrano";de="Gespielt";es="Jugados";fr="Joués";}
        else if(key.equals("Goals")){hr="Golovi";de="Tore";es="Goles";fr="Buts";}
        else if(key.equals("Road to Final")){hr="Put do finala";de="Weg ins Finale";es="Camino a la final";fr="Route vers la finale";}
        else if(key.equals("Scores to tables")){hr="Upiši rezultate, provjeri skupine i podijeli poster.";de="Tippe Ergebnisse ein, prüfe Gruppen und teile dein Poster.";es="Introduce resultados, revisa grupos y comparte tu póster.";fr="Entre les scores, vérifie les groupes et partage ton poster.";}
        else if(key.equals("Winner")){hr="Pobjednik";de="Sieger";es="Ganador";fr="Vainqueur";}
        else if(key.equals("Not selected")){hr="nije odabran";de="nicht gewählt";es="no seleccionado";fr="non choisi";}
        else if(key.equals("Question")){hr="Pitanje";de="Frage";es="Pregunta";fr="Question";}
        else if(key.equals("Score")){hr="Bodovi";de="Punkte";es="Puntuación";fr="Score";}
        else if(key.equals("Correct")){hr="Točno";de="Richtig";es="Correcto";fr="Correct";}
        else if(key.equals("Wrong")){hr="Netočno";de="Falsch";es="Incorrecto";fr="Incorrect";}
        else if(key.equals("Try again")){hr="Pokušaj ponovno";de="Erneut versuchen";es="Intentar de nuevo";fr="Réessayer";}

        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("16 host cities")){hr="16 gradova domaćina";de="16 Gastgeberstädte";es="16 ciudades sede";fr="16 villes hôtes";}
        else if(key.equals("Country")){hr="Država";de="Land";es="País";fr="Pays";}
        else if(key.equals("Capacity")){hr="Kapacitet";de="Kapazität";es="Capacidad";fr="Capacité";}
        else if(key.equals("Matches count")){hr="Broj utakmica";de="Anzahl Spiele";es="Número de partidos";fr="Nombre de matchs";}

        if(lang.equals("HR")) return hr; if(lang.equals("DE")) return de; if(lang.equals("ES")) return es; if(lang.equals("FR")) return fr; return en;
    }

    String ui(String value){
        if(value==null||value.length()==0||"EN".equals(lang))return value;
        String[][] rows={
            {"Best third-placed teams","Najbolje trećeplasirane reprezentacije","Beste Gruppendritte","Mejores terceros","Meilleurs troisièmes"},
            {"Online update","Online ažuriranje","Online-Aktualisierung","Actualización en línea","Mise à jour en ligne"},
            {"Online match center","Online centar utakmica","Online-Spielzentrum","Centro de partidos en línea","Centre de matchs en ligne"},
            {"Live matches","Utakmice uživo","Live-Spiele","Partidos en vivo","Matchs en direct"},
            {"Finished matches","Završene utakmice","Beendete Spiele","Partidos finalizados","Matchs terminés"},
            {"No finished matches yet.","Još nema završenih utakmica.","Noch keine beendeten Spiele.","Aún no hay partidos finalizados.","Aucun match terminé pour le moment."},
            {"Upcoming matches","Nadolazeće utakmice","Kommende Spiele","Próximos partidos","Matchs à venir"},
            {"No upcoming matches.","Nema nadolazećih utakmica.","Keine kommenden Spiele.","No hay próximos partidos.","Aucun match à venir."},
            {"Online dashboard","Online pregled","Online-Übersicht","Panel en línea","Tableau de bord en ligne"},
            {"Online rankings","Online poredak","Online-Rangliste","Clasificación en línea","Classement en ligne"},
            {"Scores → tables → best thirds → bracket → champion → share poster.","Rezultati → tablice → najbolje trećeplasirane → kostur → prvak → podijeli poster.","Ergebnisse → Tabellen → beste Dritte → Turnierbaum → Sieger → Poster teilen.","Resultados → tablas → mejores terceros → cuadro → campeón → compartir póster.","Scores → classements → meilleurs troisièmes → tableau → champion → partager le poster."},
            {"Qualified teams preview","Pregled kvalificiranih reprezentacija","Vorschau qualifizierter Teams","Vista de equipos clasificados","Aperçu des équipes qualifiées"},
            {"MY TOURNAMENT PREDICTION","MOJA PROGNOZA TURNIRA","MEINE TURNIERPROGNOSE","MI PREDICCIÓN DEL TORNEO","MON PRONOSTIC DU TOURNOI"},
            {"Champion:","Prvak:","Sieger:","Campeón:","Champion :"},
            {"Made with Football Fun","Napravljeno u Football Fun","Erstellt mit Football Fun","Creado con Football Fun","Créé avec Football Fun"},
            {"Finalist 1","Finalist 1","Finalist 1","Finalista 1","Finaliste 1"},
            {"Finalist 2","Finalist 2","Finalist 2","Finalista 2","Finaliste 2"},
            {"No matches found for","Nema pronađenih utakmica za","Keine Spiele gefunden für","No se encontraron partidos para","Aucun match trouvé pour"},
            {"Top Scorers 2026","Najbolji strijelci 2026","Top-Torschützen 2026","Máximos goleadores 2026","Meilleurs buteurs 2026"},
            {"Projected winner:","Predviđeni pobjednik:","Prognostizierter Sieger:","Ganador previsto:","Vainqueur prévu :"},
            {"Export code lets fans save or send their prediction. Import can be added later when we move the app from MVP to full account-free backup.","Kod za izvoz omogućuje spremanje ili slanje prognoze. Uvoz se može dodati kada aplikacija dobije potpunu lokalnu sigurnosnu kopiju bez korisničkog računa.","Mit dem Exportcode können Fans ihre Prognose speichern oder senden. Der Import kann später mit einer vollständigen kontofreien Sicherung ergänzt werden.","El código de exportación permite guardar o enviar el pronóstico. La importación podrá añadirse con una copia completa sin cuenta.","Le code d’export permet d’enregistrer ou d’envoyer le pronostic. L’import pourra être ajouté avec une sauvegarde complète sans compte."},
            {"The app already has the poster layout. Next technical step is Android PDF export. For now, Share Poster creates a clean shareable prediction text/card.","Aplikacija već ima izgled postera. Sljedeći tehnički korak je Android PDF izvoz. Za sada Podijeli poster stvara uredan tekst ili karticu prognoze za dijeljenje.","Das Posterlayout ist bereits vorhanden. Der nächste Schritt ist der Android-PDF-Export. Bis dahin erstellt Poster teilen einen sauberen teilbaren Prognosetext.","La aplicación ya tiene el diseño del póster. El siguiente paso es exportar a PDF en Android. Por ahora crea una predicción limpia para compartir.","La mise en page du poster existe déjà. La prochaine étape est l’export PDF Android. Pour l’instant, le partage crée un pronostic propre à partager."},
            {"First-team forward","Napadač prve momčadi","Stürmer der ersten Mannschaft","Delantero del primer equipo","Attaquant de l’équipe première"},
            {"Central midfielder","Središnji vezni","Zentraler Mittelfeldspieler","Centrocampista central","Milieu central"},
            {"New signing added to the followed-club watchlist.","Novo pojačanje dodano je na popis praćenog kluba.","Neuzugang zur Beobachtungsliste des gefolgten Klubs hinzugefügt.","Nuevo fichaje añadido a la lista del club seguido.","Nouvelle recrue ajoutée à la liste du club suivi."},
            {"Midfielder linked with a summer move.","Veznjak se povezuje s ljetnim transferom.","Mittelfeldspieler wird mit einem Sommertransfer in Verbindung gebracht.","Centrocampista relacionado con un traspaso de verano.","Milieu annoncé pour un transfert estival."},
            {"Loan option being monitored.","Prati se mogućnost posudbe.","Eine Leihoption wird beobachtet.","Se sigue una posible cesión.","Une option de prêt est suivie."},
            {"Three targets match the club profile.","Tri igrača odgovaraju profilu kluba.","Drei Kandidaten passen zum Klubprofil.","Tres objetivos encajan con el perfil del club.","Trois cibles correspondent au profil du club."},
            {"Advanced insights","Napredni uvidi","Erweiterte Einblicke","Análisis avanzados","Analyses avancées"},
            {"Average goals:","Prosjek golova:","Tore im Schnitt:","Promedio de goles:","Moyenne de buts :"},
            {"Best attack:","Najbolji napad:","Bester Angriff:","Mejor ataque:","Meilleure attaque :"},
            {"Highest scoring group:","Skupina s najviše golova:","Torreichste Gruppe:","Grupo con más goles:","Groupe le plus prolifique :"},
            {"Champion pick:","Odabir prvaka:","Meistertipp:","Campeón elegido:","Champion choisi :"},
            {"Top 4:","Najbolja 4:","Top 4:","Top 4:","Top 4 :"},
            {"Share","Podijeli","Teilen","Compartir","Partager"},
            {"Play Store Launch Checklist","Kontrolni popis za Play Store","Play-Store-Checkliste","Lista de Play Store","Liste de contrôle Play Store"},
            {"Status: almost ready for private/internal testing.","Status: gotovo spremno za privatno/interno testiranje.","Status: fast bereit für private/interne Tests.","Estado: casi listo para pruebas privadas/internas.","Statut : presque prêt pour les tests privés/internes."},
            {"Before public release","Prije javne objave","Vor der öffentlichen Veröffentlichung","Antes del lanzamiento público","Avant la publication"},
            {"Projected path","Predviđeni put","Prognostizierter Weg","Ruta prevista","Parcours prévu"},
            {"Tournament quick facts","Brze činjenice o natjecanju","Turnierfakten","Datos rápidos del torneo","Faits rapides du tournoi"},
            {"Top 2 from each group qualify","Prve dvije reprezentacije iz svake skupine prolaze","Die besten zwei jeder Gruppe qualifizieren sich","Los dos primeros de cada grupo se clasifican","Les deux premiers de chaque groupe se qualifient"},
            {"Best 8 third-placed teams qualify","Najboljih 8 trećeplasiranih prolazi","Die besten 8 Gruppendritten qualifizieren sich","Los 8 mejores terceros se clasifican","Les 8 meilleurs troisièmes se qualifient"},
            {"Knockout starts with Round of 32","Nokaut faza počinje šesnaestinom finala","Die K.-o.-Phase beginnt mit der Runde der 32","La fase eliminatoria empieza en dieciseisavos","La phase à élimination commence en seizièmes"},
            {"Host countries: USA, Mexico and Canada","Domaćini: SAD, Meksiko i Kanada","Gastgeber: USA, Mexiko und Kanada","Países anfitriones: EE. UU., México y Canadá","Pays hôtes : États-Unis, Mexique et Canada"},
            {"App works offline after installation","Aplikacija nakon instalacije radi i bez interneta","Die App funktioniert nach der Installation offline","La aplicación funciona sin conexión tras instalarla","L’application fonctionne hors ligne après installation"},
            {"Group stage","Faza skupina","Gruppenphase","Fase de grupos","Phase de groupes"},
            {"Referee","Sudac","Schiedsrichter","Árbitro","Arbitre"},
            {"Stadium","Stadion","Stadion","Estadio","Stade"},
            {"Attendance","Gledatelji","Zuschauer","Asistencia","Affluence"},
            {"Lineups","Sastavi","Aufstellungen","Alineaciones","Compositions"},
            {"Substitutes","Klupa","Ersatzspieler","Suplentes","Remplaçants"},
            {"Match events","Događaji utakmice","Spielereignisse","Eventos del partido","Événements du match"},
            {"No events available.","Događaji nisu dostupni.","Keine Ereignisse verfügbar.","No hay eventos disponibles.","Aucun événement disponible."},
            {"No statistics available.","Statistika nije dostupna.","Keine Statistiken verfügbar.","No hay estadísticas disponibles.","Aucune statistique disponible."},
            {"No lineup available.","Sastav nije dostupan.","Keine Aufstellung verfügbar.","No hay alineación disponible.","Aucune composition disponible."},
            {"Possession","Posjed","Ballbesitz","Posesión","Possession"},
            {"Shots","Udarci","Schüsse","Tiros","Tirs"},
            {"Shots on target","Udarci u okvir","Schüsse aufs Tor","Tiros a puerta","Tirs cadrés"},
            {"Corners","Korneri","Ecken","Córners","Corners"},
            {"Yellow cards","Žuti kartoni","Gelbe Karten","Tarjetas amarillas","Cartons jaunes"},
            {"Red cards","Crveni kartoni","Rote Karten","Tarjetas rojas","Cartons rouges"},
            {"Fouls","Prekršaji","Fouls","Faltas","Fautes"},
            {"Offsides","Zaleđa","Abseits","Fueras de juego","Hors-jeu"},
            {"Matchday","Kolo","Spieltag","Jornada","Journée"},
            {"First half","Prvo poluvrijeme","Erste Halbzeit","Primera parte","Première mi-temps"},
            {"Second half","Drugo poluvrijeme","Zweite Halbzeit","Segunda parte","Deuxième mi-temps"},
            {"Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps"},
            {"Full-time","Kraj","Abpfiff","Final","Terminé"},
            {"Scheduled","Zakazano","Geplant","Programado","Programmé"},
            {"Postponed","Odgođeno","Verschoben","Aplazado","Reporté"},
            {"Cancelled","Otkazano","Abgesagt","Cancelado","Annulé"}
        };
        int column="HR".equals(lang)?1:"DE".equals(lang)?2:"ES".equals(lang)?3:4;
        String out=value;
        for(String[] row:rows)if(out.contains(row[0]))out=out.replace(row[0],row[column]);
        return out;
    }

    void build(){
        lastSystemInsetLeft=-1;lastSystemInsetTop=-1;lastSystemInsetRight=-1;lastSystemInsetBottom=-1;
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        setContentView(root);
        hideSystemBars();

        header=new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(18),dp(8),dp(18),dp(6));
        header.setBackground(gradient(Color.rgb(20,22,38),PURPLE_DARK,0));
        header.setElevation(dp(6));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(82)));
        title=label("Football Fun",24,Color.WHITE,true);
        title.setLetterSpacing(0.01f);
        title.setGravity(Gravity.CENTER);
        subtitle=label("",12,Color.rgb(210,216,230),false);
        subtitle.setGravity(Gravity.CENTER);
        header.addView(title);
        header.addView(subtitle);

        contentScroll=new ScrollView(this);
        contentScroll.setFillViewport(true);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12),dp(12),dp(12),dp(28));
        contentScroll.addView(content);
        root.addView(contentScroll,new LinearLayout.LayoutParams(-1,0,1));

        addAdMobTestBanner();

        bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(dp(7),dp(6),dp(7),dp(6));
        bottom.setBackgroundColor(navBg);
        bottom.setElevation(dp(14));
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(72)));
        bottomNavButtons.clear();
        nav("🏠","Home"); nav("⚽","Matches"); nav("🏆","Leagues"); nav("⭐","Favorites"); nav("☰","More");
        refreshBottomNavigation();
        installSystemInsets();
    }


    void initializePrivacyAndAds(){
        try{
            consentInformation=UserMessagingPlatform.getConsentInformation(this);
            ConsentRequestParameters params=new ConsentRequestParameters.Builder().build();
            consentInformation.requestConsentInfoUpdate(
                    this,
                    params,
                    ()->{
                        consentUpdateFinished=true;
                        startAdsIfPrivacyAllows();
                        UserMessagingPlatform.loadAndShowConsentFormIfRequired(this,formError->{
                            consentUpdateFinished=true;
                            startAdsIfPrivacyAllows();
                            refreshPrivacyOptionsUiIfNeeded();
                        });
                    },
                    requestConsentError->{
                        consentUpdateFinished=true;
                        // UMP can still return a usable status from the previous session.
                        startAdsIfPrivacyAllows();
                        refreshPrivacyOptionsUiIfNeeded();
                    });
            // A previous valid consent decision may already allow ad requests immediately
            // after requestConsentInfoUpdate() has been invoked.
            startAdsIfPrivacyAllows();
        }catch(Exception ignored){
            consentUpdateFinished=true;
        }
    }

    void startAdsIfPrivacyAllows(){
        try{
            if(!canServeAdsToCurrentUser()||adInitializationRequested)return;
            adInitializationRequested=true;
            initializeMobileAds();
        }catch(Exception ignored){}
    }

    void refreshAdsForEntitlement(){
        try{
            if(shouldSuppressAdsForPro()){
                interstitialAd=null;
                interstitialLoading=false;
                interstitialMoreRequestGeneration++;
                if(bannerAdHolder!=null){
                    bannerAdHolder.setVisibility(View.GONE);
                    ViewGroup.LayoutParams raw=bannerAdHolder.getLayoutParams();
                    if(raw instanceof LinearLayout.LayoutParams){
                        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)raw;
                        lp.height=0;
                        bannerAdHolder.setLayoutParams(lp);
                    }
                }
                return;
            }
            if(canServeAdsToCurrentUser()){
                if(!adInitializationRequested)startAdsIfPrivacyAllows();
                else if(mobileAdsInitialized){
                    loadCurrentTestBanner();
                    loadTestInterstitial();
                }
            }
        }catch(Exception ignored){}
    }

    boolean isPrivacyOptionsRequired(){
        try{
            return consentInformation!=null
                    &&consentInformation.getPrivacyOptionsRequirementStatus()==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
        }catch(Exception ignored){return false;}
    }

    void showAdPrivacyOptions(){
        try{
            UserMessagingPlatform.showPrivacyOptionsForm(this,formError->{
                startAdsIfPrivacyAllows();
                refreshPrivacyOptionsUiIfNeeded();
            });
        }catch(Exception ignored){
            toast(t2("Privacy options are not available right now.","Postavke privatnosti trenutačno nisu dostupne.","Datenschutzoptionen sind derzeit nicht verfügbar.","Las opciones de privacidad no están disponibles ahora.","Les options de confidentialité ne sont pas disponibles actuellement."));
        }
    }

    void refreshPrivacyOptionsUiIfNeeded(){
        try{
            runOnUiThread(()->{if("More".equals(currentScreen))showMore();});
        }catch(Exception ignored){}
    }

    void initializeMobileAds(){
        new Thread(()->{
            try{MobileAds.initialize(this,status->{
                mobileAdsInitialized=true;
                runOnUiThread(()->{
                    loadCurrentTestBanner();
                    loadTestInterstitial();
                });
            });}catch(Exception ignored){}
        },"FootballFun-admob-init").start();
    }

    void loadCurrentTestBanner(){
        try{
            if(shouldSuppressAdsForPro()||!canServeAdsToCurrentUser())return;
            if(bannerAdView!=null)bannerAdView.loadAd(new AdRequest.Builder().build());
        }catch(Exception ignored){}
    }

    void addAdMobTestBanner(){
        try{
            if(bannerAdView!=null){bannerAdView.destroy();bannerAdView=null;}
            bannerAdView=new AdView(this);
            bannerAdView.setAdSize(AdSize.BANNER);
            // Debug/QA = Google's demo unit. Release = Football Fun production unit.
            // This prevents invalid production traffic during development.
            bannerAdView.setAdUnitId(currentBannerAdUnitId());
            bannerAdHolder=new LinearLayout(this);
            bannerAdHolder.setGravity(Gravity.CENTER);
            bannerAdHolder.setBackgroundColor(navBg);
            bannerAdHolder.setVisibility(View.GONE);
            bannerAdHolder.addView(bannerAdView,new LinearLayout.LayoutParams(-2,-2));
            root.addView(bannerAdHolder,new LinearLayout.LayoutParams(-1,0));
            bannerAdView.setAdListener(new AdListener(){
                @Override public void onAdLoaded(){
                    try{
                        if(bannerAdHolder==null||shouldSuppressAdsForPro())return;
                        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)bannerAdHolder.getLayoutParams();
                        lp.height=dp(50);
                        bannerAdHolder.setLayoutParams(lp);
                        bannerAdHolder.setVisibility(View.VISIBLE);
                    }catch(Exception ignored){}
                }
                @Override public void onAdFailedToLoad(LoadAdError error){
                    try{
                        if(bannerAdHolder==null)return;
                        bannerAdHolder.setVisibility(View.GONE);
                        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)bannerAdHolder.getLayoutParams();
                        lp.height=0;
                        bannerAdHolder.setLayoutParams(lp);
                    }catch(Exception ignored){}
                }
            });
            if(mobileAdsInitialized)loadCurrentTestBanner();
        }catch(Exception ignored){}
    }

    void loadTestInterstitial(){
        if(shouldSuppressAdsForPro()||!canServeAdsToCurrentUser())return;
        if(!mobileAdsInitialized||interstitialAd!=null||interstitialLoading)return;
        interstitialLoading=true;
        try{
            InterstitialAd.load(this,currentInterstitialAdUnitId(),new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){
                @Override public void onAdLoaded(InterstitialAd ad){
                    interstitialLoading=false;
                    interstitialAd=ad;
                }
                @Override public void onAdFailedToLoad(LoadAdError error){
                    interstitialLoading=false;
                    interstitialAd=null;
                }
            });
        }catch(Exception ignored){
            interstitialLoading=false;
            interstitialAd=null;
        }
    }

    void showMoreWithTestInterstitial(){
        if("More".equals(currentScreen)){showMore();return;}
        if(shouldSuppressAdsForPro()){showMore();return;}
        if(interstitialShownThisSession){showMore();return;}

        // Privacy or entitlement must never block navigation.
        if(!canServeAdsToCurrentUser()){
            showMore();
            return;
        }

        if(interstitialAd!=null){
            showLoadedTestInterstitialThenMore();
            return;
        }

        // The first tap can happen before Google has finished preloading the ad.
        // Start/restart the preload and wait at most ~2 seconds. This makes the
        // controlled QA test deterministic without creating a long UX delay.
        loadTestInterstitial();
        final int request=++interstitialMoreRequestGeneration;
        waitForTestInterstitialThenMore(request,0);
    }

    void waitForTestInterstitialThenMore(final int request,final int step){
        if(request!=interstitialMoreRequestGeneration)return;
        if(interstitialShownThisSession){showMore();return;}
        if(interstitialAd!=null){
            showLoadedTestInterstitialThenMore();
            return;
        }
        if(step>=INTERSTITIAL_WAIT_MAX_STEPS){
            showMore();
            return;
        }
        handler.postDelayed(()->waitForTestInterstitialThenMore(request,step+1),INTERSTITIAL_WAIT_STEP_MS);
    }

    void showLoadedTestInterstitialThenMore(){
        final InterstitialAd ad=interstitialAd;
        if(ad==null){showMore();return;}
        interstitialMoreRequestGeneration++;
        interstitialShownThisSession=true;
        interstitialAd=null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback(){
            @Override public void onAdDismissedFullScreenContent(){
                showMore();
                // Preload again for lifecycle resilience, but the once-per-session
                // guard prevents another full-screen ad during the same session.
                loadTestInterstitial();
            }
            @Override public void onAdFailedToShowFullScreenContent(AdError adError){
                showMore();
                loadTestInterstitial();
            }
        });
        try{ad.show(this);}catch(Exception ignored){showMore();loadTestInterstitial();}
    }

    String playerBottomNavTarget(){
        if("ClubCenter".equals(playerCenterOriginScreen))return currentClubOriginCompetition.isEmpty()?"Favorites":"Leagues";
        if("GlobalSearch".equals(playerCenterOriginScreen))return "More".equals(globalSearchOriginScreen)?"More":"Home";
        return "Favorites".equals(playerCenterOriginScreen)?"Favorites":"More";
    }

    boolean isBottomNavSelected(String name){
        if(currentScreen.equals(name))return true;
        if("Premium".equals(currentScreen))return name.equals(premiumOriginNav);
        if("MatchDetails".equals(currentScreen))return "Matches".equals(name);
        if("PlayerCenter".equals(currentScreen))return name.equals(playerBottomNavTarget());
        if(("CompetitionHub".equals(currentScreen)||"CompetitionRounds".equals(currentScreen)||"CompetitionResults".equals(currentScreen)||"CompetitionStandings".equals(currentScreen)||"CompetitionParticipants".equals(currentScreen)))return name.equals("GlobalSearch".equals(currentCompetitionOriginScreen)?("More".equals(globalSearchOriginScreen)?"More":"Home"):"Leagues");
        if("ClubCenter".equals(currentScreen))return name.equals("GlobalSearch".equals(currentClubOriginScreen)?("More".equals(globalSearchOriginScreen)?"More":"Home"):(currentClubOriginCompetition.isEmpty()?"Favorites":"Leagues"));
        if("DailyBrief".equals(currentScreen))return "Home".equals(name);
        if("Notifications".equals(currentScreen)||"Players".equals(currentScreen))return "More".equals(name);
        if("GlobalSearch".equals(currentScreen))return name.equals("More".equals(globalSearchOriginScreen)?"More":"Home");
        return false;
    }

    void applyBottomNavVisual(TextView button,boolean selected){
        if(button==null)return;
        // Every navigation item keeps exactly the same footprint. The active
        // state is communicated by colour, background and elevation only, so
        // no label can stretch or become taller than the remaining items.
        button.setTextSize(10);
        button.setTextColor(selected?Color.WHITE:subText);
        button.setBackground(selected?gradient(PURPLE_DARK,RED,dp(20)):round(Color.TRANSPARENT,dp(20),0));
        button.setElevation(selected?dp(4):0f);
        button.animate().cancel();
        button.setScaleX(1f);
        button.setScaleY(1f);
        button.setSelected(selected);
    }

    void refreshBottomNavigation(){
        for(Map.Entry<String,TextView> entry:bottomNavButtons.entrySet())applyBottomNavVisual(entry.getValue(),isBottomNavSelected(entry.getKey()));
    }

    String bottomNavLabel(String name){
        if("Leagues".equals(name)){
            if("HR".equals(lang))return "Lige";
            if("DE".equals(lang))return "Ligen";
            if("ES".equals(lang))return "Ligas";
            if("FR".equals(lang))return "Ligues";
        }
        if("Favorites".equals(name)){
            if("DE".equals(lang))return "Favoriten";
            if("ES".equals(lang))return "Favoritos";
            if("FR".equals(lang))return "Favoris";
        }
        return tr(name);
    }

    void nav(String icon,String name){
        TextView b=label(icon+"\n"+bottomNavLabel(name),10,subText,true);
        b.setGravity(Gravity.CENTER);
        b.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        b.setIncludeFontPadding(false);
        b.setLines(2);
        b.setMaxLines(2);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        b.setContentDescription(tr(name));
        b.setOnClickListener(v->{
            if(name.equals("Home")){if(!"Home".equals(currentScreen))showHome();return;}
            if(name.equals("Matches")){if(!"Matches".equals(currentScreen))showMatches();return;}
            if(name.equals("Leagues")){if(!"Leagues".equals(currentScreen))showLeagues();return;}
            if(name.equals("Favorites")){if(!"Favorites".equals(currentScreen)){favoritesSection="overview";showFavorites();}return;}
            if(!"More".equals(currentScreen))showMoreWithTestInterstitial();
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.setMargins(dp(2),0,dp(2),0);
        bottom.addView(b,lp);
        bottomNavButtons.put(name,b);
        applyBottomNavVisual(b,isBottomNavSelected(name));
    }

    void redraw(){
        applyTheme();
        build();
        if(currentScreen.equals("Home"))showHome();
        else if(currentScreen.equals("Matches"))showMatches();
        else if(currentScreen.equals("MatchDetails")){
            Match open=findOpenMatchDetails();
            if(open!=null)showMatchDetails(open); else showMatches();
        }
        else if(currentScreen.equals("Leagues"))showLeagues();
        else if(currentScreen.equals("CompetitionHub")&&!currentCompetitionName.isEmpty())showCompetitionHub(currentCompetitionName,competitionRegion(currentCompetitionName));
        else if(currentScreen.equals("CompetitionRounds")&&!currentCompetitionName.isEmpty())showCompetitionRounds(currentCompetitionName);
        else if(currentScreen.equals("CompetitionResults")&&!currentCompetitionName.isEmpty())showCompetitionResults(currentCompetitionName);
        else if(currentScreen.equals("CompetitionStandings")&&!currentCompetitionName.isEmpty())showLeagueStandings(currentCompetitionName);
        else if(currentScreen.equals("CompetitionParticipants")&&!currentCompetitionName.isEmpty())showCompetitionParticipants(currentCompetitionName);
        else if(currentScreen.equals("ClubCenter")&&!currentClubName.isEmpty())showClubCenterTab(currentClubName,currentClubTab);
        else if(currentScreen.equals("Favorites"))showFavorites();
        else if(currentScreen.equals("Players"))showPlayersHub();
        else if(currentScreen.equals("DailyBrief"))showDailyBrief();
        else if(currentScreen.equals("Notifications"))showNotificationCenter();
        else if(currentScreen.equals("Premium"))showPremium(premiumRequestedFeature,premiumOriginNav);
        else if(currentScreen.equals("PlayerCenter")){
            PlayerRecord player=playerIndex.get(openPlayerKey);
            if(player!=null)showPlayerCenterTab(player,currentPlayerTab); else showFavorites();
        }
        else showMore();
    }

    TextView label(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(ui(s));t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(dp(1),1.10f);t.setLetterSpacing(sp>=20?0.01f:0f);t.setPadding(dp(3),dp(5),dp(3),dp(5));if(bold)t.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));return t;}
    Drawable ripple(Drawable content){return new RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(72,255,255,255)),content,null);}
    Button btn(String s){Button b=new Button(this);b.setText(ui(s));b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(18),dp(11),dp(18),dp(11));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(ripple(gradient(PURPLE_DARK,RED,dp(18))));b.setElevation(dp(4));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.98f).scaleY(.98f).setDuration(80).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();}return false;});return b;}
    Button outline(String s){Button b=new Button(this);b.setText(ui(s));b.setTextSize(13);b.setTextColor(text);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(15),dp(10),dp(15),dp(10));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(ripple(round(chipBg,dp(18),1)));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).alpha(.82f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start();}return false;});return b;}
    TextView chip(String s){TextView t=label(s,13,text,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(13),dp(10),dp(13),dp(10));t.setBackground(round(chipBg,dp(18),1));return t;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(19),dp(18),dp(19),dp(18));l.setBackground(round(cardBg,dp(22),1));l.setElevation(dp(3));l.setClipToOutline(true);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(16));content.addView(l,lp);return l;}
    LinearLayout hrow(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    void clear(String h,String s,String key){
        if(!"MatchDetails".equals(key)) stopLiveMatchDetailsRefresh();
        screenGeneration++;
        if(clubCrestCache!=null)clubCrestCache.onScreenChanged();
        currentScreen=key;
        refreshBottomNavigation();
        title.setText(h);
        boolean hasSubtitle=s!=null && s.trim().length()>0;
        subtitle.setText(hasSubtitle?s:"");
        subtitle.setVisibility(hasSubtitle?View.VISIBLE:View.GONE);
        content.removeAllViews();
        content.setAlpha(0f);
        content.setTranslationY(dp(6));
        content.animate().alpha(1f).translationY(0f).setDuration(160).start();
        hideSystemBars();
    }

    String t2(String en,String hr,String de,String es,String fr){if(lang.equals("HR"))return hr;if(lang.equals("DE"))return de;if(lang.equals("ES"))return es;if(lang.equals("FR"))return fr;return en;}
    String lastUpdateLabel(String last){
        if(last!=null && last.trim().length()>0){
            String local=displayLocalDateTime(last);
            return t2("🕒 Last update: "+local,"🕒 Zadnje ažuriranje: "+local,"🕒 Letzte Aktualisierung: "+local,"🕒 Última actualización: "+local,"🕒 Dernière mise à jour : "+local);
        }
        return t2("🕒 Last update: not yet refreshed","🕒 Još nije ažurirano","🕒 Noch nicht aktualisiert","🕒 Aún no actualizado","🕒 Pas encore actualisé");
    }


    String displayUiTimestamp(String raw){
        if(raw==null||raw.trim().isEmpty())return "";
        String value=raw.trim();
        Date parsed=null;
        String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","yyyy-MM-dd'T'HH:mm:ss","yyyy-MM-dd'T'HH:mm"};
        for(String pattern:patterns){
            try{
                SimpleDateFormat parser=new SimpleDateFormat(pattern,Locale.US);
                parser.setLenient(false);
                parsed=parser.parse(value);
                if(parsed!=null)break;
            }catch(Exception ignored){}
        }
        if(parsed==null)return value;
        if("HR".equals(lang))return new SimpleDateFormat("dd.MM.yyyy. HH:mm",new Locale("hr","HR")).format(parsed);
        if("DE".equals(lang))return new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.GERMANY).format(parsed);
        if("ES".equals(lang))return new SimpleDateFormat("dd/MM/yyyy HH:mm",new Locale("es","ES")).format(parsed);
        if("FR".equals(lang))return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.FRANCE).format(parsed);
        return new SimpleDateFormat("dd MMM yyyy, HH:mm",Locale.ENGLISH).format(parsed);
    }

    String dataFreshnessLabel(){
        String checked=prefs==null?"":prefs.getString("online_lastChecked","");
        String changed=prefs==null?"":prefs.getString("online_lastUpdate","");
        if(checked!=null&&!checked.trim().isEmpty()){
            String local=displayUiTimestamp(checked);
            if(lang.equals("HR"))return "🕒 Zadnja provjera: "+local;
            if(lang.equals("DE"))return "🕒 Letzte Prüfung: "+local;
            if(lang.equals("ES"))return "🕒 Última comprobación: "+local;
            if(lang.equals("FR"))return "🕒 Dernière vérification : "+local;
            return "🕒 Last checked: "+local;
        }
        return lastUpdateLabel(changed);
    }

    String displayTeamName(String team){
        // Always present the canonical Football Fun club identity when a provider
        // sends a legal/alternate suffix (for example Hull City AFC or Ipswich Town FC).
        // National teams and unknown names pass through unchanged.
        String canonical=ClubIdentityRegistry.canonicalName(team);
        return TeamLocalizer.displayName(canonical,lang);
    }

    TextView sectionHeading(String value){
        TextView h=label(value,19,text,true);
        h.setPadding(dp(5),dp(8),dp(5),dp(12));
        content.addView(h);
        return h;
    }

    LinearLayout homeStat(String value,String caption,View.OnClickListener listener){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(5),dp(9),dp(5),dp(9));
        box.setBackground(round(chipBg,dp(18),1));
        TextView v=centerLabel(value,21,value.equals("0")?subText:RED,true);
        TextView c=centerLabel(caption,11,subText,true);
        box.addView(v); box.addView(c);
        if(listener!=null){box.setClickable(true);box.setOnClickListener(listener);}
        return box;
    }

    String friendlyCompetitionName(Match m){
        if(m==null)return "";
        String[] all={"HNL","UEFA Champions League","Premier League","Championship","La Liga","Bundesliga","Serie A","Ligue 1","Eredivisie","Primeira Liga","Brasileirão Série A","World Cup 2026","UEFA European Championship"};
        for(String c:all)if(matchBelongsToCompetition(m,c))return c;
        if(m.competition!=null && m.competition.trim().length()>0)return m.competition.trim();
        return t2("Football","Nogomet","Fußball","Fútbol","Football");
    }

    String competitionIcon(String competition){
        if(competition.equals("HNL"))return "🇭🇷";
        if(competition.equals("Premier League")||competition.equals("Championship"))return "🇬🇧";
        if(competition.equals("La Liga"))return "🇪🇸";
        if(competition.equals("Bundesliga"))return "🇩🇪";
        if(competition.equals("Serie A"))return "🇮🇹";
        if(competition.equals("Ligue 1"))return "🇫🇷";
        if(competition.equals("Eredivisie"))return "🇳🇱";
        if(competition.equals("Primeira Liga"))return "🇵🇹";
        if(competition.equals("Brasileirão Série A"))return "🇧🇷";
        if(competition.equals("World Cup 2026"))return "🌍";
        if(competition.equals("UEFA European Championship"))return "🇪🇺";
        return "🏆";
    }

    boolean hnlDataConnected(){
        JSONObject root=cachedOnlineRoot();
        if(root!=null){
            JSONObject sources=root.optJSONObject("sources");
            JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
            if(hnl!=null&&hnl.optString("status","").equalsIgnoreCase("connected"))return true;
            JSONObject standings=root.optJSONObject("standings");
            if(standings!=null&&standings.optJSONObject("HNL")!=null)return true;
        }
        if(data!=null)for(Match match:data.matches)if(matchBelongsToCompetition(match,"HNL"))return true;
        return false;
    }

    String hnlSourceStatus(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return "";
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        return hnl==null?"":hnl.optString("status","");
    }

    int hnlOfficialMatchCount(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return 0;
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        int sourceCount=hnl==null?0:hnl.optInt("matchCount",0);
        if(sourceCount>0)return sourceCount;
        int count=0;
        JSONArray matches=root.optJSONArray("matches");
        if(matches!=null)for(int i=0;i<matches.length();i++){
            JSONObject match=matches.optJSONObject(i);if(match==null)continue;
            JSONObject competition=match.optJSONObject("competition");
            String code=competition==null?"":competition.optString("code",competition.optString("name",""));
            if("HNL".equalsIgnoreCase(code))count++;
        }
        return count;
    }

    String hnlLastSuccessfulUpdate(){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return "";
        JSONObject sources=root.optJSONObject("sources");
        JSONObject hnl=sources==null?null:sources.optJSONObject("HNL");
        return hnl==null?"":hnl.optString("lastSuccessfulUpdate","");
    }

    boolean competitionHasConnectedSource(String competition){
        return !"HNL".equals(competition)||hnlDataConnected();
    }

    int competitionStatusColor(String competition){
        return competitionHasConnectedSource(competition)?GREEN:Color.rgb(244,184,64);
    }

    int verifiedSourceCompetitionMatchCount(String competition){
        if(competition==null||competition.length()==0)return 0;
        int bundled=expectedBundledFixtureCount(competition);
        JSONObject root=cachedOnlineRoot();
        if(root==null)return bundled;
        JSONObject sources=root.optJSONObject("sources");
        if(sources==null)return bundled;
        String code=competitionApiCode(competition);
        JSONObject source=sources.optJSONObject(code);
        if(source==null&&"HNL".equals(competition))source=sources.optJSONObject("HNL");
        int connected=source==null?0:Math.max(0,source.optInt("matchCount",0));
        // For competitions with a complete bundled 2026/27 fixture baseline, the
        // known season total is authoritative. A connected provider can contain
        // aliases, stale rows or duplicates and must not inflate the UI count.
        if(bundled>0)return bundled;
        return connected;
    }

    String competitionDataStatus(String competition){
        if("HNL".equals(competition)){
            if(hnlDataConnected()){
                int count=hnlOfficialMatchCount();
                String state=hnlSourceStatus();
                if("degraded".equalsIgnoreCase(state))return t2("Official HNL data available from verified cache","Službeni HNL podaci dostupni iz provjerene kopije","Offizielle HNL-Daten aus geprüftem Cache","Datos HNL desde copia verificada","Données HNL depuis une copie vérifiée");
                return count>0
                        ?t2("Official HNL schedule connected • "+count+" matches","Službeni HNL raspored povezan • "+count+" utakmica","Offizieller HNL-Spielplan verbunden • "+count+" Spiele","Calendario HNL conectado • "+count+" partidos","Calendrier HNL connecté • "+count+" matchs")
                        :t2("Official HNL data connected","Službeni HNL podaci povezani","Offizielle HNL-Daten verbunden","Datos oficiales de HNL conectados","Données officielles HNL connectées");
            }
            return t2("Waiting for official HNL data","Čekanje službenih HNL podataka","Warten auf offizielle HNL-Daten","Esperando datos oficiales de HNL","En attente des données officielles HNL");
        }
        ArrayList<Match> competitionMatches=matchesForCompetition(competition);
        int sourceMatchCount=verifiedSourceCompetitionMatchCount(competition);
        if(competitionMatches.isEmpty()&&sourceMatchCount>0){
            return t2("Verified schedule connected • "+sourceMatchCount+" matches","Provjereni raspored povezan • "+sourceMatchCount+" utakmica","Verifizierter Spielplan verbunden • "+sourceMatchCount+" Spiele","Calendario verificado conectado • "+sourceMatchCount+" partidos","Calendrier vérifié connecté • "+sourceMatchCount+" matchs");
        }
        if(competitionMatches.isEmpty()&&!hasVerifiedStandings(competition)){
            return t2("Connected source ready • competition data pending","Povezani izvor spreman • čekanje podataka natjecanja","Quelle bereit • Wettbewerbsdaten ausstehend","Fuente conectada • datos pendientes","Source connectée • données en attente");
        }
        boolean hasLive=false;
        for(Match match:competitionMatches)if(matchIsLive(match)){hasLive=true;break;}
        if(hasLive){
            return t2("Live results available","Rezultati uživo dostupni","Live-Ergebnisse verfügbar","Resultados en vivo disponibles","Résultats en direct disponibles");
        }
        if(!competitionMatches.isEmpty()){
            int count=competitionMatches.size();
            return t2("Verified schedule connected • "+count+" matches","Provjereni raspored povezan • "+count+" utakmica","Verifizierter Spielplan verbunden • "+count+" Spiele","Calendario verificado conectado • "+count+" partidos","Calendrier vérifié connecté • "+count+" matchs");
        }
        return t2("Verified table available","Provjerena tablica dostupna","Verifizierte Tabelle verfügbar","Tabla verificada disponible","Classement vérifié disponible");
    }

    String competitionDataStatusFromMatches(String competition,List<Match> competitionMatches){
        if("HNL".equals(competition))return competitionDataStatus(competition);
        List<Match> safeMatches=competitionMatches==null?Collections.<Match>emptyList():competitionMatches;
        int sourceMatchCount=verifiedSourceCompetitionMatchCount(competition);
        if(safeMatches.isEmpty()&&sourceMatchCount>0){
            return t2("Verified schedule connected • "+sourceMatchCount+" matches","Provjereni raspored povezan • "+sourceMatchCount+" utakmica","Verifizierter Spielplan verbunden • "+sourceMatchCount+" Spiele","Calendario verificado conectado • "+sourceMatchCount+" partidos","Calendrier vérifié connecté • "+sourceMatchCount+" matchs");
        }
        if(safeMatches.isEmpty()&&!hasVerifiedStandings(competition)){
            return t2("Connected source ready • competition data pending","Povezani izvor spreman • čekanje podataka natjecanja","Quelle bereit • Wettbewerbsdaten ausstehend","Fuente conectada • datos pendientes","Source connectée • données en attente");
        }
        for(Match match:safeMatches)if(matchIsLive(match)){
            return t2("Live results available","Rezultati uživo dostupni","Live-Ergebnisse verfügbar","Resultados en vivo disponibles","Résultats en direct disponibles");
        }
        if(!safeMatches.isEmpty()){
            int count=safeMatches.size();
            return t2("Verified schedule connected • "+count+" matches","Provjereni raspored povezan • "+count+" utakmica","Verifizierter Spielplan verbunden • "+count+" Spiele","Calendario verificado conectado • "+count+" partidos","Calendrier vérifié connecté • "+count+" matchs");
        }
        return t2("Verified table available","Provjerena tablica dostupna","Verifizierte Tabelle verfügbar","Tabla verificada disponible","Classement vérifié disponible");
    }

    void addClubChoiceRow(LinearLayout parent,String left,String right){
        LinearLayout row=hrow();
        String[] clubs={left,right};
        for(String club:clubs){
            if(club==null||club.length()==0)continue;
            final String cn=canonicalFavoriteClubName(club);
            boolean selected=isFavoriteClubName(cn);
            Button b=selected?btn("✓ "+displayTeamName(cn)):outline("＋ "+displayTeamName(cn));
            b.setTextSize(12);
            b.setOnClickListener(v->{
                toggleFavoriteClub(cn);
                showFavorites();
            });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));
            row.addView(b,lp);
        }
        parent.addView(row);
    }


    boolean hasPersonalSelection(){
        return (favoriteClubs!=null&&!favoriteClubs.isEmpty())||(favoriteNationalTeams!=null&&!favoriteNationalTeams.isEmpty())||(followedCompetitions!=null&&!followedCompetitions.isEmpty());
    }

    boolean isSelectedClub(String club){
        if(club==null||favoriteClubs==null)return false;
        for(String selected:favoriteClubs)if(sameTeam(club,selected))return true;
        return false;
    }

    boolean isSelectedCompetition(String competition){
        if(competition==null||followedCompetitions==null)return false;
        for(String selected:followedCompetitions)if(selected.equalsIgnoreCase(competition))return true;
        return false;
    }

    boolean isLastDestinationRelevant(){
        String type=prefs.getString("lastDestinationType","");
        String key=prefs.getString("lastDestinationKey","");
        if("club".equals(type))return isSelectedClub(key);
        if("competition".equals(type))return isSelectedCompetition(key);
        if("match".equals(type)){
            for(Match m:data.matches)if(personalMatchKey(m).equals(key))return matchMatchesPersonalSelection(m);
        }
        return false;
    }

    void clearIrrelevantLastDestination(){
        if(!isLastDestinationRelevant())prefs.edit().remove("lastDestinationType").remove("lastDestinationKey").remove("lastDestinationLabel").apply();
    }

    void rememberLastDestination(String type,String key,String label){
        if(type==null||key==null||key.trim().isEmpty())return;
        prefs.edit().putString("lastDestinationType",type).putString("lastDestinationKey",key).putString("lastDestinationLabel",label==null?key:label).apply();
    }

    void openLastDestination(){
        String type=prefs.getString("lastDestinationType","");
        String key=prefs.getString("lastDestinationKey","");
        if("club".equals(type)){showClubCenter(key);return;}
        if("competition".equals(type)){showCompetitionHub(key,competitionRegion(key));return;}
        if("match".equals(type)){
            for(Match m:data.matches)if(personalMatchKey(m).equals(key)){showMatchDetails(m);return;}
        }
        showMatches();
    }

    String competitionFavoriteSummary(String competition){
        int live=competitionLiveCount(competition),today=competitionTodayCount(competition),week=competitionUpcomingCount(competition,7);
        if(live>0)return live+" "+t2("live","uživo","live","en vivo","en direct");
        if(today>0)return today+" "+t2("today","danas","heute","hoy","aujourd’hui");
        if(week>0)return week+" "+localizedCountNoun(week,"match")+" "+t2("in the next 7 days","u sljedećih 7 dana","in den nächsten 7 Tagen","en los próximos 7 días","dans les 7 prochains jours");
        return t2("Following this competition • schedule updates automatically","Pratiš ovo natjecanje • raspored se automatski ažurira","Du folgst diesem Wettbewerb • der Spielplan wird automatisch aktualisiert","Sigues esta competición • el calendario se actualiza automáticamente","Tu suis cette compétition • le calendrier se met à jour automatiquement");
    }

    void addPersonalizationStrip(){
        LinearLayout strip=homeCard();
        strip.addView(label("⭐ "+t2("YOUR FAVORITES","TVOJI FAVORITI","DEINE FAVORITEN","TUS FAVORITOS","TES FAVORIS"),17,text,true));
        if(!hasPersonalSelection()){
            strip.addView(label(t2("Start by choosing the clubs, national teams or competitions you care about. Your Home screen will adapt automatically.","Za početak odaberi klubove, reprezentacije ili natjecanja koja te zanimaju. Početna će se automatski prilagoditi.","Wähle zuerst Clubs, Nationalteams oder Wettbewerbe, die dich interessieren. Deine Startseite passt sich automatisch an.","Empieza eligiendo clubes, selecciones o competiciones que te interesen. La portada se adaptará automáticamente.","Commence par choisir les clubs, sélections ou compétitions qui t’intéressent. L’accueil s’adaptera automatiquement."),13,subText,false));
            LinearLayout actions=hrow();
            Button favorites=btn("⭐ "+t2("Choose favorites","Odaberi favorite","Favoriten wählen","Elegir favoritos","Choisir des favoris"));favorites.setOnClickListener(v->showFavorites());
            Button competitions=outline("🏆 "+t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"));competitions.setOnClickListener(v->showLeagues());
            actions.addView(favorites,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,dp(52),1);gap.setMargins(dp(8),0,0,0);actions.addView(competitions,gap);strip.addView(actions);
            return;
        }
        addFavoritesSummary(strip);
        int visible=0;
        final int maxVisible=4;
        int total=(favoriteClubs==null?0:favoriteClubs.size())+(favoriteNationalTeams==null?0:favoriteNationalTeams.size())+(followedCompetitions==null?0:followedCompetitions.size());
        if(favoriteClubs!=null&&!favoriteClubs.isEmpty()){
            for(String club:favoriteClubs){
                if(visible>=maxVisible)break;visible++;
                final String selected=club;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(round(Color.rgb(30,36,49),dp(17),0));
                card.addView(label("⚽ "+displayTeamName(club),13,Color.WHITE,true));Match next=nextMatchForTeam(club);card.addView(label(nextOpponentSummary(next,club),11,subText,false));
                card.setOnClickListener(v->showClubCenter(selected));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,0);strip.addView(card,lp);
            }
        }
        if(visible<maxVisible&&favoriteNationalTeams!=null&&!favoriteNationalTeams.isEmpty()){
            for(String team:favoriteNationalTeams){
                if(visible>=maxVisible)break;visible++;
                final String selected=team;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(round(Color.rgb(30,36,49),dp(17),0));
                card.addView(label("🌍 "+displayTeamName(team),13,Color.WHITE,true));Match next=nextMatchForTeam(team);card.addView(label(nextOpponentSummary(next,team),11,subText,false));
                card.setOnClickListener(v->{myTeam=selected;userPreferences.saveNationalTeam(selected);showMyTeam();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,0);strip.addView(card,lp);
            }
        }
        if(visible<maxVisible&&followedCompetitions!=null&&!followedCompetitions.isEmpty()){
            for(String competition:followedCompetitions){
                if(visible>=maxVisible)break;visible++;
                final String selected=competition;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(10),dp(14),dp(10));card.setBackground(round(Color.rgb(30,36,49),dp(17),0));
                card.addView(label(competitionIcon(competition)+" "+displayCompetitionName(competition),13,Color.WHITE,true));card.addView(label(competitionFavoriteSummary(competition),11,subText,false));
                card.setOnClickListener(v->showCompetitionHub(selected,competitionRegion(selected)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,0);strip.addView(card,lp);
            }
        }
        if(total>visible){
            TextView more=centerLabel("+"+(total-visible)+" "+t2("more selections  ›","još odabira  ›","weitere Auswahlen  ›","selecciones más  ›","autres sélections  ›"),13,RED,true);
            more.setPadding(dp(8),dp(11),dp(8),dp(5));more.setOnClickListener(v->showFavorites());strip.addView(more);
        }
    }

    String nextOpponentSummary(Match next,String selectedTeam){
        if(next==null&&hnlAwaitingResultConfirmationForTeam(selectedTeam))return t2("Waiting for HNL match confirmation","Čeka se potvrda HNL podataka","Warten auf HNL-Spielbestätigung","Esperando confirmación HNL","En attente de confirmation HNL");
        if(next==null)return t2("No upcoming verified match","Nema nadolazeće provjerene utakmice","Kein kommendes verifiziertes Spiel","No hay próximo partido verificado","Aucun prochain match vérifié");
        String opponent=sameTeam(next.home,selectedTeam)?next.away:next.home;
        if(opponent==null||opponent.trim().isEmpty())opponent=sameTeam(next.home,selectedTeam)?next.home:next.away;
        return t2("Next: ","Sljedeće: ","Nächstes: ","Próximo: ","Prochain : ")+displayTeamName(opponent)+" • "+homeDateLabel(next);
    }

    int smartPriority(Match m){
        int score=0;
        if(matchIsLive(m))score+=1000;
        if(matchMatchesPersonalTeams(m))score+=500;
        if(matchMatchesFollowedCompetition(m))score+=220;
        if(matchIsToday(m))score+=120;
        if(matchIsUpcoming(m))score+=50;
        return score;
    }

    boolean isHomeHeroMatch(Match match){
        if(match==null||homeHeroMatchKey==null||homeHeroMatchKey.isEmpty())return false;
        if(homeHeroMatchKey.equals(personalMatchKey(match)))return true;
        Match hero=null;
        if(data!=null&&data.matches!=null)for(Match candidate:data.matches){
            if(candidate!=null&&homeHeroMatchKey.equals(personalMatchKey(candidate))){hero=candidate;break;}
        }
        return hero!=null&&favoriteMatchIdentityKey(hero).equals(favoriteMatchIdentityKey(match));
    }

    String homeProfessionalFixtureKey(Match match){
        if(match==null)return "";

        ClubProfile homeProfile=ClubIdentityRegistry.resolve(match.home);
        ClubProfile awayProfile=ClubIdentityRegistry.resolve(match.away);
        String homeName=homeProfile!=null?homeProfile.name:match.home;
        String awayName=awayProfile!=null?awayProfile.name:match.away;

        String homeKey=duplicateTeamKey(homeName);
        String awayKey=duplicateTeamKey(awayName);
        if(homeKey.isEmpty()||awayKey.isEmpty())return "";

        String dayKey=duplicateMatchDayKey(match);
        if(!dayKey.isEmpty())return homeKey+"|"+awayKey+"|day:"+dayKey;

        if(match.matchday>0)return homeKey+"|"+awayKey+"|md:"+match.matchday;
        return "";
    }

    ArrayList<Match> dedupeHomeScheduleMatches(Collection<Match> source){
        LinkedHashMap<String,Match> unique=new LinkedHashMap<String,Match>();
        if(source==null)return new ArrayList<Match>();

        for(Match candidate:source){
            if(candidate==null)continue;
            String key=homeProfessionalFixtureKey(candidate);
            if(key.isEmpty()){
                unique.put("raw|"+System.identityHashCode(candidate),candidate);
                continue;
            }

            Match existing=unique.get(key);
            if(existing==null){
                unique.put(key,candidate);
                continue;
            }

            Match preferred=matchDataRichness(candidate)>matchDataRichness(existing)?candidate:existing;
            Match other=preferred==candidate?existing:candidate;
            mergeDuplicateMatchBasics(preferred,other);
            unique.put(key,preferred);
        }
        return new ArrayList<Match>(unique.values());
    }

    ArrayList<Match> smartSchedule(int limit){
        ArrayList<Match> all=new ArrayList<Match>();boolean hasSelection=hasPersonalSelection();
        for(Match m:data.matches){
            if(hnlMatchNeedsResultConfirmation(m))continue;
            if(!(matchIsLive(m)||matchIsUpcoming(m)||matchIsToday(m)))continue;
            if(hasSelection&&!matchMatchesPersonalTeams(m)&&!matchMatchesFollowedCompetition(m))continue;
            // Home hierarchy: the hero owns the primary match and the Today section
            // owns today's remaining fixtures. Smart Schedule therefore starts with
            // the next distinct fixture instead of repeating what is already above.
            if(isHomeHeroMatch(m)||matchIsToday(m))continue;
            all.add(m);
        }
        all=dedupeHomeScheduleMatches(all);
        Collections.sort(all,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db!=null)return 1;
            if(da!=null&&db==null)return -1;
            if(da!=null){int byKickoff=da.compareTo(db);if(byKickoff!=0)return byKickoff;}
            int byCompetition=matchCompetitionLabel(a).compareToIgnoreCase(matchCompetitionLabel(b));if(byCompetition!=0)return byCompetition;
            int byHome=displayTeamName(a.home).compareToIgnoreCase(displayTeamName(b.home));if(byHome!=0)return byHome;
            int byAway=displayTeamName(a.away).compareToIgnoreCase(displayTeamName(b.away));if(byAway!=0)return byAway;
            return personalMatchKey(a).compareToIgnoreCase(personalMatchKey(b));
        });
        if(limit>0&&all.size()>limit)return new ArrayList<Match>(all.subList(0,limit));return all;
    }

    String matchCompetitionLabel(Match m){String c=friendlyCompetitionName(m);return (c==null||c.trim().isEmpty())?t2("Competition","Natjecanje","Wettbewerb","Competición","Compétition"):displayCompetitionName(c);}
    String matchPhaseLabel(Match m){
        if(m==null)return "";
        String competition=friendlyCompetitionName(m);
        if(competition!=null&&!competition.trim().isEmpty()&&!isNationalCompetition(competition)){
            if(m.matchday>0)return t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+m.matchday;
            return t2("League season","Ligaška sezona","Ligasaison","Temporada de liga","Saison de ligue");
        }
        String stage=stageLabel(m);
        if(stage!=null&&!stage.trim().isEmpty())return stage.trim();
        if(m.roundName!=null&&!m.roundName.trim().isEmpty())return m.roundName.trim();
        if(m.group!=null&&!m.group.trim().isEmpty())return t2("Group ","Skupina ","Gruppe ","Grupo ","Groupe ")+m.group.trim();
        return t2("Scheduled match","Zakazana utakmica","Geplantes Spiel","Partido programado","Match programmé");
    }
    String countdownLabel(Match m){
        if(m==null)return "";
        if(matchIsLive(m))return t2("LIVE NOW","UŽIVO SADA","JETZT LIVE","EN VIVO","EN DIRECT");
        if(matchIsFinished(m))return t2("Finished","Završeno","Beendet","Finalizado","Terminé");
        Date d=localMatchDate(m);
        if(d==null)return t2("Kick-off to be confirmed","Termin će biti potvrđen","Termin wird bestätigt","Horario por confirmar","Horaire à confirmer");
        long diff=d.getTime()-System.currentTimeMillis();
        if(diff<=0)return t2("Starting soon","Počinje uskoro","Beginnt bald","Empieza pronto","Commence bientôt");
        long mins=Math.max(1,diff/60000L);
        if(matchIsToday(m))return t2("Today at ","Danas u ","Heute um ","Hoy a las ","Aujourd’hui à ")+new SimpleDateFormat("HH:mm",Locale.US).format(d);
        if(matchIsTomorrow(m))return t2("Tomorrow at ","Sutra u ","Morgen um ","Mañana a las ","Demain à ")+new SimpleDateFormat("HH:mm",Locale.US).format(d);
        long days=mins/1440L;
        if(days>=2)return t2("In ","Za ","In ","En ","Dans ")+days+t2(" days"," dana"," Tagen"," días"," jours");
        long hours=mins/60L;
        if(hours>=1)return t2("In ","Za ","In ","En ","Dans ")+hours+t2(" hours"," sati"," Stunden"," horas"," heures");
        return t2("In ","Za ","In ","En ","Dans ")+mins+t2(" min"," min"," Min."," min"," min");
    }

    int competitionMatchCount(String competition){
        int count=0;for(Match m:data.matches)if(matchBelongsToCompetition(m,competition))count++;return count;
    }

    int competitionFocusMatchday(String competition){
        int liveRound=Integer.MAX_VALUE,upcomingRound=Integer.MAX_VALUE,lastRound=0;
        for(Match m:data.matches){
            if(!matchBelongsToCompetition(m,competition)||m.matchday<=0)continue;
            if(matchIsLive(m))liveRound=Math.min(liveRound,m.matchday);
            else if(matchIsUpcoming(m))upcomingRound=Math.min(upcomingRound,m.matchday);
            else if(matchIsFinished(m))lastRound=Math.max(lastRound,m.matchday);
        }
        if(liveRound!=Integer.MAX_VALUE)return liveRound;
        if(upcomingRound!=Integer.MAX_VALUE)return upcomingRound;
        return lastRound;
    }

    int competitionMatchdayCount(String competition,int matchday){
        if(matchday<=0)return 0;
        int count=0;
        for(Match m:data.matches)if(matchBelongsToCompetition(m,competition)&&m.matchday==matchday)count++;
        return count;
    }

    String competitionRoundFact(String competition){
        return competitionRoundFact(competition,null);
    }

    String competitionRoundFact(String competition,Match focusMatch){
        int round=(focusMatch!=null&&matchBelongsToCompetition(focusMatch,competition)&&focusMatch.matchday>0)?focusMatch.matchday:competitionFocusMatchday(competition);
        int count=competitionMatchdayCount(competition,round);
        if(count>0&&round>0)return "⚽ "+count+" "+t2("matches • MD ","utakmica • Kolo ","Spiele • ST ","partidos • J ","matchs • J ")+round;
        int matches=competitionMatchCount(competition);
        return matches>0?"⚽ "+matches+" "+t2("matches","utakmica","Spiele","partidos","matchs"):"";
    }

    int competitionClubCount(String competition){
        LinkedHashSet<String> clubs=new LinkedHashSet<String>();
        for(Match m:data.matches)if(matchBelongsToCompetition(m,competition)){if(m.home!=null&&!m.home.trim().isEmpty())clubs.add(m.home.trim());if(m.away!=null&&!m.away.trim().isEmpty())clubs.add(m.away.trim());}
        return clubs.size();
    }

    TextView heroInfoChip(String value){
        TextView chip=centerLabel(value,12,Color.WHITE,true);
        chip.setSingleLine(true);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(dp(38));
        chip.setPadding(dp(12),dp(7),dp(12),dp(7));
        chip.setBackground(round(Color.argb(82,255,255,255),dp(19),1));
        chip.setElevation(dp(1));
        return chip;
    }

    TextView favoriteSummaryChip(String value,String caption){
        TextView chip=centerLabel(value+"\n"+caption,11,Color.WHITE,true);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(dp(54));
        chip.setPadding(dp(7),dp(7),dp(7),dp(7));
        chip.setLineSpacing(0,0.92f);
        chip.setBackground(round(Color.rgb(25,31,44),dp(17),1));
        return chip;
    }

    void addFavoritesSummary(LinearLayout parent){
        int clubs=favoriteClubs==null?0:favoriteClubs.size();
        int nationalTeams=favoriteNationalTeams==null?0:favoriteNationalTeams.size();
        int teams=clubs+nationalTeams;
        int competitions=followedCompetitions==null?0:followedCompetitions.size();
        int today=personalTodayCount();
        LinearLayout row=hrow();
        row.setGravity(Gravity.CENTER);
        row.addView(favoriteSummaryChip("⚽ "+teams,localizedCountNoun(teams,"team")),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        row.addView(favoriteSummaryChip("🏆 "+competitions,localizedCountNoun(competitions,"competition")),middle);
        row.addView(favoriteSummaryChip("📅 "+today,t2("today","danas","heute","hoy","aujourd’hui")),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(11),0,dp(4));parent.addView(row,lp);
    }

    void addCompetitionHeroFacts(LinearLayout parent,String competition){
        addCompetitionHeroFacts(parent,competition,null);
    }

    void addCompetitionHeroFacts(LinearLayout parent,String competition,Match focusMatch){
        int clubs=competitionClubCount(competition);
        String roundFact=competitionRoundFact(competition,focusMatch);
        LinearLayout facts=hrow();facts.setGravity(Gravity.CENTER_VERTICAL);
        if(clubs>0)facts.addView(heroInfoChip("👥 "+clubs+" "+localizedCountNoun(clubs,"club")),new LinearLayout.LayoutParams(0,-2,1));
        if(!roundFact.isEmpty()){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(6),0,0,0);facts.addView(heroInfoChip(roundFact),lp);}
        if(facts.getChildCount()>0){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(9),0,dp(2));parent.addView(facts,lp);}
    }

    void addCompetitionMatchGroup(LinearLayout parent,String competition,ArrayList<Match> matches){
        parent.addView(label(competitionIcon(competition)+" "+displayCompetitionName(competition),13,Color.rgb(236,220,113),true));
        for(Match m:matches)addDynamicHomeMatch(parent,m);
    }

    void addContinueAndSmartSchedule(){
        addContinueAndSmartSchedule(smartSchedule(8));
    }


    void addHomeSecondarySectionsDeferred(){
        if(bundledBaselineLoading)return;
        final int generation=screenGeneration;
        // First paint and touch handling have priority. Secondary Home work uses a
        // dedicated worker so it can never delay central-cache restore or live sync.
        handler.postDelayed(()->{
            if(generation!=screenGeneration||!"Home".equals(currentScreen)||isFinishing()||isDestroyed())return;
            addPersonalizationStrip();
        },90L);
        homeExecutor.execute(()->{
            final ArrayList<Match> schedule=smartSchedule(8);
            runOnUiThread(()->{
                if(generation!=screenGeneration||!"Home".equals(currentScreen)||isFinishing()||isDestroyed())return;
                addContinueAndSmartSchedule(schedule);
            });
        });
    }

    void addContinueAndSmartSchedule(ArrayList<Match> schedule){
        clearIrrelevantLastDestination();String lastLabel=prefs.getString("lastDestinationLabel","");
        if(!lastLabel.isEmpty()&&isLastDestinationRelevant()){LinearLayout resume=homeCard();resume.setBackground(gradient(Color.rgb(26,31,54),Color.rgb(62,38,105),dp(22)));resume.addView(label("↩ "+t2("CONTINUE WHERE YOU LEFT OFF","NASTAVI GDJE SI STAO","WEITERMACHEN","CONTINUAR","REPRENDRE"),15,Color.WHITE,true));Button open=outline(lastLabel+"  ›");open.setOnClickListener(v->openLastDestination());resume.addView(open);}
        LinearLayout smart=homeCard();smart.addView(briefSectionHeader("🧠",t2("Smart schedule","Pametni raspored","Intelligenter Spielplan","Calendario inteligente","Programme intelligent"),t2("All matches","Sve utakmice","Alle Spiele","Todos","Tous"),v->{matchDateFilter="ALL";matchStatusFilter="All";matchCenterPage=0;showMatches();}));
        smart.addView(label(hasPersonalSelection()?t2("Your selected teams and competitions, strictly ordered by actual kickoff time.","Tvoji odabrani klubovi, reprezentacije i natjecanja, strogo poredani prema stvarnom vremenu početka.","Deine Teams und Wettbewerbe, strikt nach der tatsächlichen Anstoßzeit sortiert.","Tus equipos y competiciones, ordenados estrictamente por la hora real de inicio.","Tes équipes et compétitions, strictement classées selon l’heure réelle du coup d’envoi."):t2("Upcoming verified matches, ordered by actual kickoff time. Choose favorites to personalize this schedule.","Nadolazeće provjerene utakmice, poredane prema stvarnom vremenu početka. Odaberi favorite za personalizirani raspored.","Kommende verifizierte Spiele nach tatsächlicher Anstoßzeit. Wähle Favoriten für einen persönlichen Spielplan.","Próximos partidos verificados, ordenados por la hora real de inicio. Elige favoritos para personalizar el calendario.","Matchs vérifiés à venir, classés selon l’heure réelle du coup d’envoi. Choisis des favoris pour personnaliser ce programme."),12,subText,false));
        if(schedule==null||schedule.isEmpty()){addBriefEmpty(smart,t2("No verified matches are available.","Nema dostupnih provjerenih utakmica.","Keine verifizierten Spiele verfügbar.","No hay partidos verificados.","Aucun match vérifié disponible."));return;}
        String previousCompetition="";
        for(Match m:schedule){
            String competition=friendlyCompetitionName(m);if(competition==null||competition.trim().isEmpty())competition=t2("Other","Ostalo","Andere","Otros","Autres");
            if(!competition.equalsIgnoreCase(previousCompetition))smart.addView(label(competitionIcon(competition)+" "+displayCompetitionName(competition),13,Color.rgb(236,220,113),true));
            addDynamicHomeMatch(smart,m); previousCompetition=competition;
        }
    }


    boolean hasProAccess(){
        return proEntitlement!=null ? proEntitlement.isPro() : (AppConfig.QA_UNLOCK_ALL_PRO || proUnlocked || (userPreferences!=null&&userPreferences.proUnlocked()));
    }

    boolean requirePro(String feature){
        if(hasProAccess())return true;
        showPremium(feature);
        return false;
    }

    Button lockedProButton(String caption,String feature){
        Button button=outline("🔒 "+caption);
        button.setOnClickListener(v->showPremium(feature));
        return button;
    }

    void addProLockedCard(String titleText,String description,String feature){
        LinearLayout locked=card();
        locked.setBackground(gradient(Color.rgb(35,25,65),Color.rgb(92,34,116),dp(22)));
        locked.addView(label("🔒 "+titleText,21,Color.WHITE,true));
        locked.addView(label(description,13,Color.rgb(224,224,236),false));
        Button open=outline(t2("View Football Fun Pro","Pogledaj Football Fun Pro","Football Fun Pro ansehen","Ver Football Fun Pro","Voir Football Fun Pro"));
        open.setOnClickListener(v->showPremium(feature));
        locked.addView(open);
    }

    ArrayList<Match> freeFeaturedMatches(){
        ArrayList<Match> matches=new ArrayList<Match>();
        if(data==null)return matches;
        for(Match match:data.matches)if(matchIsLive(match)||matchIsUpcoming(match))matches.add(match);
        Collections.sort(matches,(a,b)->{
            if(matchIsLive(a)!=matchIsLive(b))return matchIsLive(a)?-1:1;
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return matches;
    }

    void showFreeHome(){
        homeHeroMatchKey="";
        clear("Football Fun",t2("Fixtures, results, competitions and players","Rasporedi, rezultati, natjecanja i igrači","Spielpläne, Ergebnisse, Wettbewerbe und Spieler","Calendarios, resultados, competiciones y jugadores","Calendriers, résultats, compétitions et joueurs"),"Home");
        addHomeSearchShortcut();
        LinearLayout hero=card();
        hero.setBackground(gradient(Color.rgb(45,22,94),Color.rgb(232,31,91),dp(24)));
        hero.addView(label("⚽ Football Fun",27,Color.WHITE,true));
        hero.addView(label(t2("Everything needed to follow fixtures and results. Advanced personalization is available with Pro.","Sve potrebno za praćenje rasporeda i rezultata. Napredna personalizacija dostupna je uz Pro.","Alles für Spielpläne und Ergebnisse. Erweiterte Personalisierung gibt es mit Pro.","Todo para seguir calendarios y resultados. La personalización avanzada está disponible con Pro.","Tout pour suivre calendriers et résultats. La personnalisation avancée est disponible avec Pro."),15,Color.WHITE,false));
        LinearLayout stats=hrow();
        stats.addView(homeStat(String.valueOf(homeTodayCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),v->{matchDateFilter=dateKeyOffset(0);matchStatusFilter="All";showMatches();}),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(8),0,dp(8),0);
        stats.addView(homeStat("13",t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"),v->showLeagues()),middle);
        stats.addView(homeStat(String.valueOf(playerIndex.size()),t2("Players","Igrači","Spieler","Jugadores","Joueurs"),v->showPlayersHub()),new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(stats);

        LinearLayout access=card();
        access.addView(label("⚡ "+t2("Free access","Besplatan pristup","Kostenloser Zugang","Acceso gratuito","Accès gratuit"),21,text,true));
        LinearLayout first=hrow();
        Button matches=btn("⚽ "+t2("Matches","Utakmice","Spiele","Partidos","Matchs"));matches.setOnClickListener(v->showMatches());
        Button leagues=outline("🏆 "+t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"));leagues.setOnClickListener(v->showLeagues());
        first.addView(matches,new LinearLayout.LayoutParams(0,dp(56),1));LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,dp(56),1);gap.setMargins(dp(8),0,0,0);first.addView(leagues,gap);access.addView(first);
        Button players=outline("👥 "+t2("Player directory","Imenik igrača","Spielerverzeichnis","Directorio de jugadores","Annuaire des joueurs"));players.setOnClickListener(v->showPlayersHub());access.addView(players);

        ArrayList<Match> featured=freeFeaturedMatches();
        LinearLayout next=card();next.addView(label("📅 "+t2("Next verified matches","Sljedeće provjerene utakmice","Nächste verifizierte Spiele","Próximos partidos verificados","Prochains matchs vérifiés"),21,text,true));
        if(featured.isEmpty())addBriefEmpty(next,t2("No published upcoming matches are available yet.","Još nema dostupnih objavljenih nadolazećih utakmica.","Noch keine kommenden Spiele veröffentlicht.","Aún no hay próximos partidos publicados.","Aucun prochain match publié."));
        else for(int i=0;i<Math.min(3,featured.size());i++)addDynamicHomeMatch(next,featured.get(i));
        Button all=outline(t2("Open all matches","Otvori sve utakmice","Alle Spiele öffnen","Abrir todos los partidos","Ouvrir tous les matchs"));all.setOnClickListener(v->{matchDateFilter="ALL";matchStatusFilter="All";matchCenterPage=0;showMatches();});next.addView(all);

        addProLockedCard(t2("Personal football center","Osobni nogometni centar","Persönliches Fußballzentrum","Centro de fútbol personal","Centre football personnel"),t2("Pro unlocks favorites, club centers, standings, reminders, following and the personalized home feed.","Pro otključava favorite, centre klubova, tablice, podsjetnike, praćenje i personaliziranu početnu stranicu.","Pro schaltet Favoriten, Klubzentren, Tabellen, Erinnerungen, Folgen und die personalisierte Startseite frei.","Pro desbloquea favoritos, centros de clubes, tablas, recordatorios, seguimiento y la portada personalizada.","Pro débloque favoris, centres de clubs, classements, rappels, suivi et accueil personnalisé."),t2("Personalization","Personalizacija","Personalisierung","Personalización","Personnalisation"));
    }

void showHome(){
        if(!hasProAccess()){showFreeHome();return;}
        homeHeroMatchKey="";
        clear("Football Fun","","Home");
        addHomeSearchShortcut();
        if(bundledBaselineLoading){
            renderFastHomeLoadingShell();
            return;
        }

        boolean hasClubSelection=favoriteClubs!=null&&!favoriteClubs.isEmpty();
        boolean hasNationalSelection=favoriteNationalTeams!=null&&!favoriteNationalTeams.isEmpty();
        if(!hasClubSelection&&!hasNationalSelection&&followedCompetitions!=null&&!followedCompetitions.isEmpty()){
            String competition=followedCompetitions.iterator().next();
            LinearLayout hero=homeCard();
            hero.setPadding(dp(17),dp(17),dp(17),dp(18));
            hero.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(224,18,75),dp(25)));
            hero.setElevation(dp(8));
            LinearLayout top=hrow();
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
            copy.addView(label(t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),12,Color.rgb(231,218,228),true));
            copy.addView(label(displayCompetitionName(competition),28,Color.WHITE,true));
            copy.addView(label(competitionRegion(competition)+"  •  "+competitionRound(competition),14,Color.WHITE,true));
            top.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            top.addView(competitionVisual(competition,dp(124)),new LinearLayout.LayoutParams(dp(124),dp(124)));
            hero.addView(top);
            Match nextCompetition=null;Date bestDate=null;
            for(Match m:data.matches){if(!matchBelongsToCompetition(m,competition)||(!matchIsUpcoming(m)&&!matchIsLive(m)))continue;Date d=localMatchDate(m);if(matchIsLive(m)){nextCompetition=m;break;}if(d!=null&&(bestDate==null||d.before(bestDate))){bestDate=d;nextCompetition=m;}}
            addCompetitionHeroFacts(hero,competition,nextCompetition);
            if(nextCompetition!=null){
                homeHeroMatchKey=personalMatchKey(nextCompetition);
                LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(14),dp(13),dp(14),dp(14));panel.setBackground(round(Color.rgb(8,12,22),dp(21),1));
                panel.addView(label(matchIsLive(nextCompetition)?t2("LIVE MATCH","UTAKMICA UŽIVO","LIVE-SPIEL","PARTIDO EN VIVO","MATCH EN DIRECT"):t2("NEXT MATCH","SLJEDEĆA UTAKMICA","NÄCHSTES SPIEL","PRÓXIMO PARTIDO","PROCHAIN MATCH"),12,Color.rgb(174,183,201),true));
                addDynamicHomeMatch(panel,nextCompetition,false);
                String phase=matchPhaseLabel(nextCompetition);
                if(phase.length()>0)panel.addView(label("🏆 "+phase,12,Color.rgb(205,211,224),true));
                if(!matchIsLive(nextCompetition)&&!matchIsFinished(nextCompetition))panel.addView(label("⏳ "+countdownLabel(nextCompetition),12,Color.rgb(205,211,224),true));
                hero.addView(panel);
            }
            hero.setOnClickListener(v->showCompetitionHub(competition,competitionRegion(competition)));
            addHomeSecondarySectionsDeferred();
            addHomeLowerSectionsDeferred();
            return;
        }

        if(!hasClubSelection&&!hasNationalSelection&&(followedCompetitions==null||followedCompetitions.isEmpty())){
            LinearLayout empty=homeCard();empty.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(115,28,108),dp(24)));
            empty.addView(label("⚽ "+t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),13,Color.WHITE,true));
            empty.addView(label(t2("Choose clubs, national teams or competitions","Odaberi klubove, reprezentacije ili natjecanja","Wähle Clubs, Nationalteams oder Wettbewerbe","Elige clubes, selecciones o competiciones","Choisis des clubs, sélections ou compétitions"),25,Color.WHITE,true));
            Button choose=outline(t2("Open favorites","Otvori favorite","Favoriten öffnen","Abrir favoritos","Ouvrir les favoris"));choose.setOnClickListener(v->showFavorites());empty.addView(choose);
            addHomeSecondarySectionsDeferred();
            addHomeLowerSectionsDeferred();
            return;
        }

        String club=primaryFavoriteClub();
        if(club.isEmpty()&&hasNationalSelection){
            String selectedTeam=favoriteNationalTeams.iterator().next();
            LinearLayout hero=homeCard();hero.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(224,18,75),dp(24)));
            hero.addView(label(t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),12,Color.WHITE,true));
            hero.addView(label(flag(selectedTeam)+" "+displayTeamName(selectedTeam),29,Color.WHITE,true));
            Match next=nextMatchForTeam(selectedTeam);if(next!=null){homeHeroMatchKey=personalMatchKey(next);addDynamicHomeMatch(hero,next);}
            final String nt=selectedTeam;hero.setOnClickListener(v->{myTeam=nt;showMyTeam();});
            addHomeSecondarySectionsDeferred();
            addHomeLowerSectionsDeferred();
            return;
        }
        String league=clubLeague(club);
        String country=clubCountry(club);
        String countryFlag=clubCountryFlag(club);

        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(17),dp(15),dp(17),dp(16));
        hero.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(224,18,75),dp(24)));
        hero.setElevation(dp(8));
        LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,-2);heroLp.setMargins(0,0,0,dp(14));content.addView(hero,heroLp);

        LinearLayout top=hrow();
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label(t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),12,Color.rgb(231,218,228),true));
        TextView clubName=label(twoLineClubName(club),29,Color.WHITE,true);clubName.setMaxLines(2);clubName.setLineSpacing(0,.95f);copy.addView(clubName);
        copy.addView(label(countryFlag+" "+country+"  •  "+displayCompetitionName(league),14,Color.WHITE,true));
        top.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        View crest=homeTeamVisual(club,dp(116),true);crest.setElevation(dp(6));top.addView(crest,new LinearLayout.LayoutParams(dp(116),dp(116)));
        hero.addView(top);

        if(hasCompletedMatchForTeam(club)){
            LinearLayout form=hrow();
            form.addView(label(t2("FORM","FORMA","FORM","FORMA","FORME"),12,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
            for(String letter:recentForm(club,5)){
                int color=letter.equals("W")?Color.rgb(18,190,83):letter.equals("L")?Color.rgb(238,41,75):letter.equals("D")?Color.rgb(80,88,105):Color.rgb(55,60,74);
                TextView f=centerLabel(letter,12,Color.WHITE,true);f.setBackground(round(color,dp(18),0));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(34),dp(34));lp.setMargins(dp(4),dp(5),0,dp(7));form.addView(f,lp);
            }
            hero.addView(form);
        }else if(!dataContainsTeam(club)){
            TextView pending=label("● "+competitionDataStatus(league),13,Color.rgb(255,214,115),true);
            pending.setPadding(dp(12),dp(8),dp(12),dp(8));pending.setBackground(round(Color.argb(50,255,255,255),dp(16),0));
            LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-2,-2);pp.setMargins(0,dp(7),0,dp(9));hero.addView(pending,pp);
        }

        boolean hnlNextPending=hnlAwaitingResultConfirmationForTeam(club);
        Match next=nextMatchForTeam(club);
        String nextOwner=club;
        if(next==null&&!hnlNextPending){next=nextMatchForTeam(myTeam);nextOwner=myTeam;}
        LinearLayout nextPanel=new LinearLayout(this);nextPanel.setOrientation(LinearLayout.VERTICAL);nextPanel.setPadding(dp(13),dp(11),dp(13),dp(12));nextPanel.setBackground(round(Color.rgb(8,12,22),dp(19),1));
        String nextTitle=t2("NEXT MATCH","SLJEDEĆA UTAKMICA","NÄCHSTES SPIEL","PRÓXIMO PARTIDO","PROCHAIN MATCH");
        if(next!=null&&!sameTeam(nextOwner,club))nextTitle+=" • "+displayTeamName(nextOwner);
        nextPanel.addView(label(nextTitle,12,Color.rgb(174,183,201),true));
        if(next!=null){
            final Match selected=next;
            LinearLayout matchup=hrow();matchup.setGravity(Gravity.CENTER);
            matchup.addView(dynamicTeamBlock(next.home,74),new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);
            center.addView(centerLabel(homeDateLabel(next),11,subText,false));
            boolean timeTba=isMatchTimeTba(next);
            TextView centerValue=centerLabel(homeCenterValue(next),timeTba?14:(matchIsLive(next)||matchIsFinished(next)?25:29),Color.WHITE,true);
            centerValue.setSingleLine(true);
            centerValue.setEllipsize(android.text.TextUtils.TruncateAt.END);
            center.addView(centerValue);
            center.addView(centerLabel(homeCenterStatus(next),13,matchIsLive(next)?RED:subText,true));
            matchup.addView(center,new LinearLayout.LayoutParams(dp(88),-2));
            matchup.addView(dynamicTeamBlock(next.away,74),new LinearLayout.LayoutParams(0,-2,1));
            matchup.setOnClickListener(v->showMatchDetails(selected));applyPressFeedback(matchup);nextPanel.addView(matchup);
        }else{
            String emptyNext=hnlNextPending
                    ?t2("Waiting for verified HNL match status before showing the next fixture.","Čeka se potvrda HNL podataka prije prikaza sljedeće utakmice.","Vor der Anzeige des nächsten Spiels wird auf bestätigte HNL-Daten gewartet.","Se espera la confirmación HNL antes de mostrar el próximo partido.","En attente de données HNL confirmées avant d’afficher le prochain match.")
                    :t2("No upcoming match is available yet.","Još nema dostupne sljedeće utakmice.","Noch kein nächstes Spiel verfügbar.","Aún no hay próximo partido disponible.","Aucun prochain match disponible.");
            nextPanel.addView(label(emptyNext,14,subText,false));
            Button open=outline(t2("Open all matches","Otvori sve utakmice","Alle Spiele öffnen","Abrir todos los partidos","Ouvrir tous les matchs"));open.setOnClickListener(v->{matchStatusFilter="All";matchDateFilter="ALL";showMatches();});nextPanel.addView(open);
        }
        hero.addView(nextPanel);
        if(next!=null)homeHeroMatchKey=personalMatchKey(next);

        addHomeSecondarySectionsDeferred();

        addHomeLowerSectionsDeferred();
    }

    void renderFastHomeLoadingShell(){
        LinearLayout hero=homeCard();
        hero.setBackground(gradient(Color.rgb(38,4,27),Color.rgb(224,18,75),dp(24)));
        hero.addView(label(t2("YOUR FOOTBALL","TVOJ NOGOMET","DEIN FUSSBALL","TU FÚTBOL","TON FOOTBALL"),12,Color.rgb(231,218,228),true));
        String club=primaryFavoriteClub();
        if(club!=null&&!club.trim().isEmpty()){
            LinearLayout top=hrow();
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
            TextView name=label(twoLineClubName(club),28,Color.WHITE,true);name.setMaxLines(2);copy.addView(name);
            copy.addView(label(clubCountryFlag(club)+" "+clubCountry(club)+"  •  "+displayCompetitionName(clubLeague(club)),13,Color.WHITE,true));
            top.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            top.addView(homeTeamVisual(club,dp(96),true),new LinearLayout.LayoutParams(dp(96),dp(96)));
            hero.addView(top);
        }else{
            hero.addView(label("⚽ Football Fun",28,Color.WHITE,true));
        }
        LinearLayout loading=hrow();loading.setGravity(Gravity.CENTER_VERTICAL);loading.setPadding(0,dp(12),0,dp(2));
        ProgressBar progress=new ProgressBar(this);loading.addView(progress,new LinearLayout.LayoutParams(dp(30),dp(30)));
        TextView status=label(t2("Loading saved football data…","Učitavam spremljene nogometne podatke…","Gespeicherte Fußballdaten werden geladen…","Cargando datos de fútbol guardados…","Chargement des données football enregistrées…"),13,Color.WHITE,true);
        LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(0,-2,1);slp.setMargins(dp(10),0,0,0);loading.addView(status,slp);hero.addView(loading);
    }

    HomeQuickSnapshot buildHomeQuickSnapshot(){
        HomeQuickSnapshot snapshot=new HomeQuickSnapshot();
        if(followedCompetitions!=null)snapshot.followed.addAll(new LinkedHashSet<String>(followedCompetitions));
        if(data==null||data.matches==null)return snapshot;
        ArrayList<Match> source=new ArrayList<Match>(data.matches);
        long now=System.currentTimeMillis();
        long end7=now+7L*24L*60L*60L*1000L;
        Date bestDate=null;
        for(Match match:source){
            if(match==null)continue;
            boolean live=matchIsLive(match);
            boolean today=matchIsToday(match);
            if(live)snapshot.liveCount++;
            if(today){snapshot.todayCount++;snapshot.today.add(match);}
            if(matchIsTomorrow(match))snapshot.tomorrowCount++;
            if(isFollowedMatch(match))snapshot.tracked.add(match);
            if(matchMatchesPersonalSelection(match)){
                if(matchMatchesPersonalTeams(match)&&(live||matchIsUpcoming(match)))snapshot.favoriteUpcoming.add(match);
                if(live){snapshot.personalLive++;if(snapshot.briefNext==null&&!isHomeHeroMatch(match))snapshot.briefNext=match;}
                if(today)snapshot.personalToday++;
                if(matchIsUpcoming(match)){
                    Date date=localMatchDate(match);
                    if(date!=null){
                        long millis=date.getTime();
                        if(millis>=now-AppConfig.MATCH_START_GRACE_MS&&millis<=end7)snapshot.personalUpcoming7++;
                        if(!isHomeHeroMatch(match)&&(snapshot.briefNext==null||!matchIsLive(snapshot.briefNext))){
                            boolean dateOnly=match.date==null||displayLocalDateTime(match.date).length()<16;
                            long effective=millis+(dateOnly?24L*60L*60L*1000L-1L:0L);
                            if(effective>=now-AppConfig.MATCH_START_GRACE_MS&&(bestDate==null||date.before(bestDate))){snapshot.briefNext=match;bestDate=date;}
                        }
                    }
                }
            }
        }
        Collections.sort(snapshot.today,(a,b)->{
            boolean aPersonal=matchMatchesPersonalSelection(a),bPersonal=matchMatchesPersonalSelection(b);
            if(aPersonal!=bPersonal)return aPersonal?-1:1;
            if(matchIsLive(a)!=matchIsLive(b))return matchIsLive(a)?-1:1;
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        Collections.sort(snapshot.tracked,(a,b)->{
            if(matchIsLive(a)!=matchIsLive(b))return matchIsLive(a)?-1:1;
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        ArrayList<Match> favoriteDeduped=dedupeHomeScheduleMatches(snapshot.favoriteUpcoming);
        snapshot.favoriteUpcoming.clear();
        snapshot.favoriteUpcoming.addAll(favoriteDeduped);
        Collections.sort(snapshot.favoriteUpcoming,(a,b)->{
            if(matchIsLive(a)!=matchIsLive(b))return matchIsLive(a)?-1:1;
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return snapshot;
    }

    void addHomeLowerSectionsDeferred(){
        if(bundledBaselineLoading)return;
        final int generation=screenGeneration;
        homeExecutor.execute(()->{
            final HomeQuickSnapshot snapshot=buildHomeQuickSnapshot();
            runOnUiThread(()->{
                if(generation!=screenGeneration||!"Home".equals(currentScreen)||isFinishing()||isDestroyed())return;
                renderHomeLowerSections(snapshot);
            });
        });
    }

    void renderHomeLowerSections(HomeQuickSnapshot home){
        if(home==null)return;
        LinearLayout snapshot=homeCard();
        LinearLayout snapshotHead=hrow();snapshotHead.addView(label(t2("MATCHDAY","DAN UTAKMICA","SPIELTAG","DÍA DE PARTIDO","JOUR DE MATCH"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=label("↻ "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"),13,RED,true);refresh.setOnClickListener(v->refreshOnlineSafe(true));snapshotHead.addView(refresh);snapshot.addView(snapshotHead);
        LinearLayout stats=hrow();
        stats.addView(homeStat(String.valueOf(home.liveCount),t2("Live","Uživo","Live","En vivo","Direct"),v->{matchStatusFilter="Live";matchDateFilter=dateKeyOffset(0);showMatches();}),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(7),0,dp(7),0);
        stats.addView(homeStat(String.valueOf(home.todayCount),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),v->{matchStatusFilter="Today";matchDateFilter=dateKeyOffset(0);showMatches();}),mid);
        stats.addView(homeStat(String.valueOf(home.tomorrowCount),t2("Tomorrow","Sutra","Morgen","Mañana","Demain"),v->{matchStatusFilter="Tomorrow";matchDateFilter=dateKeyOffset(1);showMatches();}),new LinearLayout.LayoutParams(0,-2,1));
        snapshot.addView(stats);

        if(!home.tracked.isEmpty()){
            LinearLayout trackedHome=homeCard();
            LinearLayout trackedHead=hrow();
            trackedHead.addView(label("📌 "+t2("TRACKED MATCHES","PRAĆENE UTAKMICE","VERFOLGTE SPIELE","PARTIDOS SEGUIDOS","MATCHS SUIVIS"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
            TextView trackedManage=label(t2("Manage  ›","Uredi  ›","Verwalten  ›","Gestionar  ›","Gérer  ›"),13,RED,true);
            trackedManage.setOnClickListener(v->{favoritesSection="matches";showFavorites();});trackedHead.addView(trackedManage);trackedHome.addView(trackedHead);
            int trackedLimit=Math.min(3,home.tracked.size());
            for(int i=0;i<trackedLimit;i++)addDynamicHomeMatch(trackedHome,home.tracked.get(i));
            if(home.tracked.size()>trackedLimit){
                TextView moreTracked=centerLabel("+"+(home.tracked.size()-trackedLimit)+" "+t2("more tracked matches","još praćenih utakmica","weitere verfolgte Spiele","partidos seguidos más","autres matchs suivis"),13,RED,true);
                moreTracked.setPadding(dp(8),dp(10),dp(8),dp(6));moreTracked.setOnClickListener(v->{favoritesSection="matches";showFavorites();});trackedHome.addView(moreTracked);
            }
        }

        LinearLayout dailyBrief=homeCard();
        dailyBrief.setBackground(gradient(Color.rgb(45,22,91),Color.rgb(145,22,91),dp(23)));
        if(!hasPersonalSelection()){
            dailyBrief.addView(label("✨ "+t2("MAKE HOME YOURS","PRILAGODI POČETNU","MACH HOME ZU DEINER","HAZ TUYA LA PORTADA","PERSONNALISE TON ACCUEIL"),16,Color.WHITE,true));
            dailyBrief.addView(label(t2("Choose at least one club, national team or competition. This space will then show only the football that matters to you.","Odaberi barem jedan klub, reprezentaciju ili natjecanje. Ovdje će se zatim prikazivati samo nogomet koji ti je važan.","Wähle mindestens einen Club, ein Nationalteam oder einen Wettbewerb. Danach siehst du hier nur noch den Fußball, der dir wichtig ist.","Elige al menos un club, una selección o una competición. Aquí verás después solo el fútbol que te importa.","Choisis au moins un club, une sélection ou une compétition. Cet espace affichera ensuite uniquement le football qui compte pour toi."),13,Color.rgb(245,232,246),false));
            Button personalize=outline("⭐ "+t2("Choose favorites","Odaberi favorite","Favoriten wählen","Elegir favoritos","Choisir des favoris"));personalize.setOnClickListener(v->showFavorites());dailyBrief.addView(personalize);
        }else{
        LinearLayout briefHead=hrow();
        briefHead.addView(label("✨ "+t2("FOR YOUR FAVORITES","ZA TVOJE FAVORITE","FÜR DEINE FAVORITEN","PARA TUS FAVORITOS","POUR TES FAVORIS"),16,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView briefOpen=label(t2("Open  ›","Otvori  ›","Öffnen  ›","Abrir  ›","Ouvrir  ›"),13,Color.WHITE,true);briefHead.addView(briefOpen);dailyBrief.addView(briefHead);
        dailyBrief.addView(kpiRow(t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(home.personalLive),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(home.personalToday),t2("Next 7 days","Sljedećih 7 dana","Nächste 7 Tage","Próximos 7 días","7 prochains jours"),String.valueOf(home.personalUpcoming7),true));
        Match briefNext=home.briefNext;
        String personalSummary;
        if(home.personalLive>0){
            personalSummary="🔴 "+home.personalLive+" "+t2(home.personalLive==1?"favorite match is live now":"favorite matches are live now",home.personalLive==1?"utakmica tvojih favorita je sada uživo":"utakmice tvojih favorita su sada uživo",home.personalLive==1?"Favoritenspiel läuft jetzt live":"Favoritenspiele laufen jetzt live",home.personalLive==1?"partido de tus favoritos está en vivo":"partidos de tus favoritos están en vivo",home.personalLive==1?"match de tes favoris est en direct":"matchs de tes favoris sont en direct");
        }else if(home.personalToday>0){
            personalSummary="📅 "+home.personalToday+" "+t2(home.personalToday==1?"match from your football is on today":"matches from your football are on today",home.personalToday==1?"utakmica iz tvog nogometa igra se danas":"utakmice iz tvog nogometa igraju se danas",home.personalToday==1?"Spiel aus deinem Fußball ist heute":"Spiele aus deinem Fußball sind heute",home.personalToday==1?"partido de tu fútbol es hoy":"partidos de tu fútbol son hoy",home.personalToday==1?"match de ton football a lieu aujourd’hui":"matchs de ton football ont lieu aujourd’hui");
        }else if(home.personalUpcoming7>0){
            personalSummary="📌 "+home.personalUpcoming7+" "+t2(home.personalUpcoming7==1?"relevant match in the next 7 days":"relevant matches in the next 7 days",home.personalUpcoming7==1?"relevantna utakmica u sljedećih 7 dana":"relevantne utakmice u sljedećih 7 dana",home.personalUpcoming7==1?"relevantes Spiel in den nächsten 7 Tagen":"relevante Spiele in den nächsten 7 Tagen",home.personalUpcoming7==1?"partido relevante en los próximos 7 días":"partidos relevantes en los próximos 7 días",home.personalUpcoming7==1?"match pertinent dans les 7 prochains jours":"matchs pertinents dans les 7 prochains jours");
        }else{
            personalSummary="✓ "+t2("No urgent favorite activity right now.","Trenutačno nema važnih događaja tvojih favorita.","Aktuell gibt es keine wichtigen Favoriten-Ereignisse.","Ahora no hay actividad urgente de tus favoritos.","Aucune activité importante de tes favoris pour le moment.");
        }
        TextView personalStatus=label(personalSummary,13,Color.WHITE,true);
        personalStatus.setPadding(dp(10),dp(9),dp(10),dp(9));personalStatus.setBackground(round(Color.argb(35,255,255,255),dp(15),0));dailyBrief.addView(personalStatus);
        if(briefNext!=null){
            String nextPrefix=matchMatchesFollowedCompetition(briefNext)&&!matchMatchesPersonalTeams(briefNext)?"🏆 ":"⚽ ";
            String nextLine=nextPrefix+t2("Next: ","Sljedeće: ","Nächstes: ","Próximo: ","Prochain : ")+displayTeamName(briefNext.home)+" – "+displayTeamName(briefNext.away)+"  •  "+homeDateLabel(briefNext);
            TextView nextHint=label(nextLine,12,Color.rgb(245,232,246),false);
            nextHint.setPadding(dp(10),dp(7),dp(10),0);dailyBrief.addView(nextHint);
        }
        dailyBrief.setOnClickListener(v->showDailyBrief());
        }

        if(hasPersonalSelection()&&!home.favoriteUpcoming.isEmpty()){
            LinearLayout favoritesHome=homeCard();
            LinearLayout favoriteHead=hrow();
            favoriteHead.addView(label("⭐ "+t2("FAVORITE MATCHES","UTAKMICE FAVORITA","FAVORITENSPIELE","PARTIDOS FAVORITOS","MATCHS FAVORIS"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
            TextView favoriteOpen=label(t2("All  ›","Sve  ›","Alle  ›","Todos  ›","Tous  ›"),13,RED,true);
            favoriteOpen.setOnClickListener(v->{matchFavoritesOnly=true;matchDateFilter="ALL";matchStatusFilter="All";matchCenterPage=0;showMatches();});
            favoriteHead.addView(favoriteOpen);
            favoritesHome.addView(favoriteHead);
            int shownFavorites=0;
            for(Match favoriteMatch:home.favoriteUpcoming){
                if(isHomeHeroMatch(favoriteMatch)&&home.favoriteUpcoming.size()>1)continue;
                addDynamicHomeMatch(favoritesHome,favoriteMatch);
                if(++shownFavorites>=3)break;
            }
            if(shownFavorites==0)addDynamicHomeMatch(favoritesHome,home.favoriteUpcoming.get(0));
        }

        LinearLayout matches=homeCard();
        LinearLayout head=hrow();head.addView(label(t2("TODAY","DANAS","HEUTE","HOY","AUJOURD’HUI"),17,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView all=label(t2("All matches  ›","Sve utakmice  ›","Alle Spiele  ›","Todos  ›","Tous les matchs  ›"),13,RED,true);all.setOnClickListener(v->{matchStatusFilter="Today";matchDateFilter=dateKeyOffset(0);showMatches();});head.addView(all);matches.addView(head);
        if(home.today.isEmpty()){
            matches.addView(label(t2("No matches are scheduled today.","Danas nema zakazanih utakmica.","Heute sind keine Spiele angesetzt.","No hay partidos hoy.","Aucun match aujourd’hui."),15,subText,false));
            LinearLayout actions=hrow();
            Button tomorrow=outline(t2("Tomorrow","Sutra","Morgen","Mañana","Demain"));tomorrow.setOnClickListener(v->{matchStatusFilter="Tomorrow";matchDateFilter=dateKeyOffset(1);showMatches();});
            Button browse=outline(t2("Browse all","Pregledaj sve","Alle ansehen","Ver todos","Tout voir"));browse.setOnClickListener(v->{matchStatusFilter="All";matchDateFilter="ALL";showMatches();});
            actions.addView(tomorrow,new LinearLayout.LayoutParams(0,dp(50),1));actions.addView(browse,new LinearLayout.LayoutParams(0,dp(50),1));matches.addView(actions);
        }else{
            int shownToday=0;
            for(Match todayMatch:home.today){
                if(isHomeHeroMatch(todayMatch))continue;
                addDynamicHomeMatch(matches,todayMatch);
                if(++shownToday>=3)break;
            }
            if(shownToday==0){
                TextView heroNote=label(t2("Your priority match is already highlighted above.","Tvoja prioritetna utakmica već je istaknuta iznad.","Dein wichtigstes Spiel ist bereits oben hervorgehoben.","Tu partido prioritario ya está destacado arriba.","Ton match prioritaire est déjà mis en avant ci-dessus."),13,subText,false);
                heroNote.setPadding(dp(9),dp(9),dp(9),dp(9));matches.addView(heroNote);
            }
        }

        LinearLayout following=homeCard();
        LinearLayout followHead=hrow();followHead.addView(label(t2("FOLLOWING","PRATIM","GEFOLGT","SIGUIENDO","SUIVI"),16,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView manage=label(t2("Manage  ›","Uredi  ›","Verwalten  ›","Gestionar  ›","Gérer  ›"),13,RED,true);manage.setOnClickListener(v->showLeagues());followHead.addView(manage);following.addView(followHead);
        int shown=0;
        for(String comp:home.followed){
            if(shown>=3)break;final String cn=comp;
            LinearLayout row=hrow();row.setPadding(dp(9),dp(8),dp(9),dp(8));row.setBackground(round(chipBg,dp(16),0));
            row.addView(label(competitionIcon(comp),20,text,true));
            LinearLayout rc=new LinearLayout(this);rc.setOrientation(LinearLayout.VERTICAL);rc.addView(label(comp,15,text,true));rc.addView(label(competitionDataStatus(comp),11,competitionStatusColor(comp),true));row.addView(rc,new LinearLayout.LayoutParams(0,-2,1));
            row.addView(label("›",24,subText,true));row.setOnClickListener(v->showCompetitionHub(cn,competitionRegion(cn)));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(5),0,0);following.addView(row,rp);shown++;
        }
        if(shown==0)following.addView(label(t2("Follow competitions to build your personal feed.","Zaprati natjecanja kako bi složio osobni sadržaj.","Folge Wettbewerben für deinen Feed.","Sigue competiciones para crear tu contenido.","Suis des compétitions pour créer ton fil."),14,subText,false));
    }

    void showFavoriteLeagueStatus(String league,String country,String club){
        clear(league,country,"Leagues");
        LinearLayout hero=card();
        hero.setBackground(gradient(RED_DARK,RED,dp(24)));
        hero.addView(label("🏆 "+league,26,Color.WHITE,true));
        hero.addView(label(clubCountryFlag(club)+" "+club,19,Color.WHITE,true));
        hero.addView(label(t2("Favourite club competition","Natjecanje omiljenog kluba","Wettbewerb des Lieblingsklubs","Competición del club favorito","Compétition du club favori"),14,Color.WHITE,false));

        LinearLayout status=card();
        status.addView(label("🌐 "+t2("Verified data source","Provjereni izvor podataka","Verifizierte Datenquelle","Fuente de datos verificada","Source de données vérifiée"),22,text,true));
        if(competitionHasConnectedSource(league)){
            status.addView(label(t2(
                    "Matches, results, live statuses and standings use a verified connected source. Football Fun displays only published data.",
                    "Utakmice, rezultati, statusi uživo i tablica koriste provjereni povezani izvor. Football Fun prikazuje samo objavljene podatke.",
                    "Spiele, Ergebnisse, Live-Status und Tabelle nutzen eine verifizierte verbundene Quelle. Football Fun zeigt nur veröffentlichte Daten.",
                    "Los partidos, resultados, estados en vivo y la clasificación usan una fuente conectada y verificada. Football Fun muestra solo datos publicados.",
                    "Les matchs, résultats, statuts en direct et le classement utilisent une source connectée vérifiée. Football Fun n’affiche que les données publiées."),15,subText,false));
            Button matches=btn("⚽ "+t2("Open competition matches","Otvori utakmice natjecanja","Wettbewerbsspiele öffnen","Abrir partidos de la competición","Ouvrir les matchs de la compétition"));
            matches.setOnClickListener(v->{competitionFilter=league;matchStatusFilter="All";matchDateFilter="ALL";showMatches();});
            status.addView(matches);
            Button standings=outline("📊 "+t2("Open verified standings","Otvori provjerenu tablicu","Verifizierte Tabelle öffnen","Abrir clasificación verificada","Ouvrir le classement vérifié"));
            standings.setOnClickListener(v->showLeagueStandings(league));
            status.addView(standings);
        }else{
            status.addView(label(t2(
                    "Official HNL data has not reached this device yet. Refresh after the updater completes; no placeholder data is shown.",
                    "Službeni HNL podaci još nisu stigli na ovaj uređaj. Osvježi nakon završetka updatera; ne prikazujemo demonstracijske podatke.",
                    "Offizielle HNL-Daten sind noch nicht auf diesem Gerät angekommen. Nach dem Updater erneut laden; keine Demo-Daten.",
                    "Los datos oficiales de HNL aún no han llegado al dispositivo. Actualiza después del updater; no se muestran datos de demostración.",
                    "Les données officielles HNL ne sont pas encore arrivées sur cet appareil. Actualise après l’updater; aucune donnée fictive."),15,subText,false));
            Button pending=outline("🇭🇷 "+t2("Waiting for official HNL data","Čekanje službenih HNL podataka","Warten auf offizielle HNL-Daten","Esperando datos oficiales HNL","En attente des données officielles HNL"));
            pending.setEnabled(false);
            status.addView(pending);
        }
        Button competitions=outline(t2("View all competitions","Pogledaj sva natjecanja","Alle Wettbewerbe anzeigen","Ver todas las competiciones","Voir toutes les compétitions"));
        competitions.setOnClickListener(v->showLeagues());
        status.addView(competitions);
    }


    String primaryFavoriteClub(){
        if(favoriteClub!=null && favoriteClub.trim().length()>0 && favoriteClubs!=null && favoriteClubs.contains(favoriteClub.trim())) return favoriteClub.trim();
        if(favoriteClubs!=null && !favoriteClubs.isEmpty()) return favoriteClubs.iterator().next();
        return "";
    }

    String twoLineClubName(String name){
        if(name==null) return "Football Club";
        String n=displayTeamName(name).trim();
        String key=teamKey(n);
        if(key.equals("wolverhamptonwanderers"))return "Wolverhampton\nWanderers";
        if(key.equals("birminghamcity"))return "Birmingham\nCity";
        if(key.equals("queensparkrangers"))return "Queens Park\nRangers";
        if(key.equals("borussiamonchengladbach"))return "Borussia\nM'gladbach";
        if(key.equals("hamburgersv"))return "Hamburger\nSV";
        if(key.equals("fcschalke04")||key.equals("schalke04"))return "FC Schalke\n04";
        if(key.equals("sportclubfreiburg")||key.equals("scfreiburg"))return "SC Freiburg";
        if(key.equals("werderbremen")||key.equals("svwerderbremen"))return "Werder Bremen";
        if(n.length()<=12) return n;
        int split=n.lastIndexOf(' ');
        if(split>3) return n.substring(0,split)+"\n"+n.substring(split+1);
        return n;
    }

    String clubLogoResource(String club,boolean hero){
        String k=teamKey(club);
        if(k.equals("dinamozagreb")||k.equals("dinamo")) return hero?"logo_dinamo":"logo_dinamo_match";
        if(k.equals("hajduksplit")||k.equals("hajduk")) return hero?"logo_hajduk_hero":"logo_hajduk_match";
        if(k.equals("gorica")) return "logo_gorica";
        if(k.equals("istra1961")) return "logo_istra_1961";
        if(k.equals("lokomotivazagreb")) return "logo_lokomotiva";
        if(k.equals("osijek")) return "logo_osijek";
        if(k.equals("rijeka")) return "logo_rijeka";
        if(k.equals("rudes")) return "logo_rudes";
        if(k.equals("slavenbelupo")) return "logo_slaven_belupo";
        if(k.equals("varazdin")) return "logo_varazdin";
        if(k.equals("realmadrid")) return hero?"logo_real_madrid_hero":"logo_real_madrid";
        if(k.equals("bayernmunich")||k.equals("bayernmunchen")||k.equals("bayern")) return hero?"logo_bayern_hero":"logo_bayern";
        if(k.equals("liverpool")) return hero?"logo_liverpool_hero":"logo_liverpool";
        if(k.equals("arsenal")) return hero?"logo_arsenal_hero":"logo_arsenal";
        if(k.equals("barcelona")||k.equals("fcbarcelona")) return hero?"logo_barcelona_hero":"logo_barcelona";
        if(k.equals("atleticomadrid")||k.equals("atletico")) return hero?"logo_atletico_hero":"logo_atletico";
        // UEFA Champions League 2026/27: these four provider badges were visibly
        // missing on real devices, so bundle verified PNGs locally. Local assets
        // take precedence over remote URLs and remain available offline.
        if(k.equals("floriana")||k.equals("florianafc")) return "logo_ucl_floriana";
        if(k.equals("gyorieto")||k.equals("gyorietofc")||k.equals("gyorieto")||k.equals("etofcgyor")) return "logo_ucl_gyori_eto";
        if(k.equals("interdescaldes")||k.equals("interclubdescaldes")||k.equals("interescaldes")) return "logo_ucl_inter_escaldes";
        if(k.equals("sabah")||k.equals("sabahfk")||k.equals("sabahfc")||k.equals("sabahbaku")) return "logo_ucl_sabah";
        // Eredivisie: keep the nine provider-problem crests inside the app so
        // club lists and match cards never fall back to the generic shield.
        if(k.equals("fcgroningen")||k.equals("groningen")) return "logo_ered_fc_groningen";
        if(k.equals("fctwente")||k.equals("twente")) return "logo_ered_fc_twente";
        if(k.equals("fcutrecht")||k.equals("utrecht")) return "logo_ered_fc_utrecht";
        if(k.equals("feyenoord")||k.equals("feyenoordrotterdam")) return "logo_ered_feyenoord";
        if(k.equals("fortunasittard")) return "logo_ered_fortuna_sittard";
        if(k.equals("peczwolle")||k.equals("zwolle")) return "logo_ered_pec_zwolle";
        if(k.equals("scheerenveen")||k.equals("heerenveen")) return "logo_ered_sc_heerenveen";
        if(k.equals("spartarotterdam")||k.equals("sparta")) return "logo_ered_sparta_rotterdam";
        if(k.equals("telstar")||k.equals("sctelstar")) return "logo_ered_telstar";
        // Primeira Liga: all 18 official crests are bundled locally so the
        // league remains visually complete even when a remote crest host fails.
        if(k.equals("estorilpraia")||k.equals("estoril")) return "logo_primeira_estoril_praia";
        if(k.equals("fcfamalicao")||k.equals("famalicao")) return "logo_primeira_fc_famalicao";
        if(k.equals("maritimo")||k.equals("csmaritimo")) return "logo_primeira_maritimo";
        if(k.equals("casapiaac")||k.equals("casapia")) return "logo_primeira_casa_pia";
        if(k.equals("vitoriasc")||k.equals("vitoriaguimaraes")||k.equals("guimaraes")) return "logo_primeira_vitoria_sc";
        if(k.equals("fcarouca")||k.equals("arouca")) return "logo_primeira_fc_arouca";
        if(k.equals("estrelaamadora")||k.equals("cfestrelaamadora")||k.equals("estrela")) return "logo_primeira_estrela_amadora";
        if(k.equals("sportingcp")||k.equals("sporting")||k.equals("sportinglisbon")) return "logo_primeira_sporting_cp";
        if(k.equals("fcporto")||k.equals("porto")) return "logo_primeira_fc_porto";
        if(k.equals("fcalverca")||k.equals("alverca")) return "logo_primeira_fc_alverca";
        if(k.equals("gilvicentefc")||k.equals("gilvicente")) return "logo_primeira_gil_vicente";
        if(k.equals("rioavefc")||k.equals("rioave")) return "logo_primeira_rio_ave";
        if(k.equals("slbenfica")||k.equals("benfica")) return "logo_primeira_sl_benfica";
        if(k.equals("academico")||k.equals("academicodeviseu")||k.equals("acviseu")) return "logo_primeira_academico";
        if(k.equals("moreirensefc")||k.equals("moreirense")) return "logo_primeira_moreirense";
        if(k.equals("scbraga")||k.equals("braga")) return "logo_primeira_sc_braga";
        if(k.equals("santaclara")||k.equals("cdsantaclara")) return "logo_primeira_santa_clara";
        if(k.equals("cdnacional")||k.equals("nacional")||k.equals("nacionalmadeira")) return "logo_primeira_cd_nacional";
        // Brasileirão Série A 2026: all 20 current club crests are bundled
        // locally so club lists and fixture cards remain complete offline.
        if(k.equals("athleticoparanaense")||k.equals("athleticopr")||k.equals("cap")) return "logo_brasil_athletico_paranaense";
        if(k.equals("atleticomineiro")||k.equals("atleticomg")||k.equals("cam")) return "logo_brasil_atletico_mineiro";
        if(k.equals("bahia")) return "logo_brasil_bahia";
        if(k.equals("botafogo")) return "logo_brasil_botafogo";
        if(k.equals("chapecoense")) return "logo_brasil_chapecoense";
        if(k.equals("corinthians")) return "logo_brasil_corinthians";
        if(k.equals("coritiba")) return "logo_brasil_coritiba";
        if(k.equals("cruzeiro")) return "logo_brasil_cruzeiro";
        if(k.equals("flamengo")) return "logo_brasil_flamengo";
        if(k.equals("fluminense")) return "logo_brasil_fluminense";
        if(k.equals("gremio")) return "logo_brasil_gremio";
        if(k.equals("internacional")) return "logo_brasil_internacional";
        if(k.equals("mirassol")) return "logo_brasil_mirassol";
        if(k.equals("palmeiras")) return "logo_brasil_palmeiras";
        if(k.equals("redbullbragantino")||k.equals("rbbragantino")) return "logo_brasil_rb_bragantino";
        if(k.equals("remo")) return "logo_brasil_remo";
        if(k.equals("santos")) return "logo_brasil_santos";
        if(k.equals("saopaulo")) return "logo_brasil_sao_paulo";
        if(k.equals("vascodagama")) return "logo_brasil_vasco";
        if(k.equals("vitoria")) return "logo_brasil_vitoria";
        return "";
    }

    void rebuildClubCrestIndex(JSONObject root){
        if(root==null){clubCrestUrls=Collections.emptyMap();return;}
        LinkedHashMap<String,String> found=new LinkedHashMap<String,String>();
        // Index crests from every match feed. European qualifiers are supplied
        // through upcoming/live/finished and may not be duplicated in matches.
        // Scanning only matches caused the UI to fall back to initials even when
        // the verified provider had already supplied a real crest URL.
        String[] matchFeeds={"matches","upcoming","live","finished"};
        for(String feedName:matchFeeds){
            JSONArray feed=root.optJSONArray(feedName);
            if(feed==null)continue;
            for(int i=0;i<feed.length();i++){
                JSONObject match=feed.optJSONObject(i);if(match==null)continue;
                indexClubCrest(found,match.optJSONObject("homeTeam"));
                indexClubCrest(found,match.optJSONObject("awayTeam"));
            }
        }
        JSONArray profileTeams=root.optJSONArray("teams");
        if(profileTeams!=null)for(int i=0;i<profileTeams.length();i++)indexClubCrest(found,profileTeams.optJSONObject(i));
        JSONObject allStandings=root.optJSONObject("standings");
        if(allStandings!=null){
            Iterator<String> codes=allStandings.keys();
            while(codes.hasNext()){
                JSONObject entry=allStandings.optJSONObject(codes.next());if(entry==null)continue;
                JSONArray blocks=entry.optJSONArray("standings");if(blocks==null)continue;
                for(int i=0;i<blocks.length();i++){
                    JSONObject block=blocks.optJSONObject(i);JSONArray table=block==null?null:block.optJSONArray("table");if(table==null)continue;
                    for(int j=0;j<table.length();j++){
                        JSONObject row=table.optJSONObject(j);if(row!=null)indexClubCrest(found,row.optJSONObject("team"));
                    }
                }
            }
        }
        clubCrestUrls=Collections.unmodifiableMap(found);
        persistCompactCrestIndex(found);
    }

    void persistCompactCrestIndex(Map<String,String> found){
        if(prefs==null||found==null||found.isEmpty())return;
        try{
            JSONObject root=new JSONObject();
            for(Map.Entry<String,String> entry:found.entrySet()){
                if(entry.getKey()!=null&&entry.getValue()!=null&&entry.getValue().startsWith("https://"))root.put(entry.getKey(),entry.getValue());
            }
            prefs.edit().putString("compact_crest_index_v1",root.toString()).apply();
        }catch(Exception ignored){}
    }

    void restoreCompactCrestIndex(){
        if(prefs==null)return;
        String raw=prefs.getString("compact_crest_index_v1","");
        if(raw==null||raw.trim().isEmpty())return;
        try{
            JSONObject root=new JSONObject(raw);LinkedHashMap<String,String> found=new LinkedHashMap<String,String>();
            Iterator<String> keys=root.keys();while(keys.hasNext()){String key=keys.next();String url=root.optString(key,"");if(!key.isEmpty()&&url.startsWith("https://"))found.put(key,url);}
            if(!found.isEmpty())clubCrestUrls=Collections.unmodifiableMap(found);
        }catch(Exception ignored){}
    }

    void indexClubCrest(Map<String,String> target,JSONObject team){
        if(target==null||team==null)return;
        String url=team.optString("crest",team.optString("emblem",team.optString("logo",""))).trim();
        if(url.length()==0||!url.startsWith("https://"))return;
        String[] names={team.optString("name",""),team.optString("shortName",""),team.optString("tla","")};
        for(String name:names){String key=teamKey(name);if(key.length()>0&&!target.containsKey(key))target.put(key,url);}
    }

    String crestUrlForClub(String club){
        if(club==null)return "";
        // A tiny verified completion map covers clubs whose provider badge is
        // missing or points to an unsupported SVG. Keep this ahead of the live
        // index so a known broken provider URL cannot win over a working PNG.
        String completed=completedCrestUrl(club);
        if(completed.length()>0)return completed;
        String direct=clubCrestUrls.get(teamKey(club));
        if(direct!=null)return direct;
        for(Map.Entry<String,String> entry:clubCrestUrls.entrySet()){
            if(sameTeam(entry.getKey(),club))return entry.getValue();
        }
        return "";
    }

    String completedCrestUrl(String club){
        String key=teamKey(club);
        if(key.equals(teamKey("Ararat-Armenia"))||key.equals(teamKey("FC Ararat-Armenia"))||
                key.equals(teamKey("Ararat Armenia"))||key.equals(teamKey("Ararat Armenia FC")))
            return "https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/FC_Ararat-Armenia_logo.svg/1280px-FC_Ararat-Armenia_logo.svg.png";
        if(key.equals(teamKey("Egnatia"))||key.equals(teamKey("KF Egnatia"))||key.equals(teamKey("Egnatia Rrogozhine")))
            return "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Egnatia_Rrogozhin%C3%AB_club_logo.svg/500px-Egnatia_Rrogozhin%C3%AB_club_logo.svg.png";
        if(key.equals(teamKey("Sabah"))||key.equals(teamKey("Sabah FK"))||key.equals(teamKey("Sabah FC"))||key.equals(teamKey("Sabah Baku")))
            return "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Sabah_FK_logo_black.png/500px-Sabah_FK_logo_black.png";
        if(key.equals(teamKey("Gornik Zabrze"))||key.equals(teamKey("Górnik Zabrze")))
            return "https://upload.wikimedia.org/wikipedia/commons/d/d9/Gornik_Zabrze.png";
        if(key.equals(teamKey("Kauno Zalgiris"))||key.equals(teamKey("Kauno Žalgiris"))||
                key.equals(teamKey("FK Kauno Zalgiris"))||key.equals(teamKey("FK Kauno Žalgiris")))
            return "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/BC_%C5%BDalgiris_2023.png/250px-BC_%C5%BDalgiris_2023.png";
        if(key.equals(teamKey("Atert Bissen"))||key.equals(teamKey("FC Atert Bissen")))
            return "https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/FC_Atert_Bissen_Logo.svg/500px-FC_Atert_Bissen_Logo.svg.png";
        if(key.equals(teamKey("ML Vitebsk"))||key.equals(teamKey("FC ML Vitebsk"))||key.equals(teamKey("Maxline Vitebsk")))
            return "https://upload.wikimedia.org/wikipedia/el/thumb/4/4d/FC_ML_Vitebsk_logo.png/500px-FC_ML_Vitebsk_logo.png";
        if(key.equals(teamKey("Vitebsk"))||key.equals(teamKey("FC Vitebsk")))
            return "https://en.wikipedia.org/wiki/Special:Redirect/file/FC_Vitebsk_Logo.png?width=512";
        if(key.equals(teamKey("Brighton & Hove Albion"))||key.equals(teamKey("Brighton Hove Albion"))||key.equals(teamKey("Brighton")))
            return "https://crests.football-data.org/397.png";
        if(key.equals(teamKey("Nottingham Forest"))||key.equals(teamKey("Nottingham")))
            return "https://crests.football-data.org/351.png";
        if(key.equals(teamKey("Manchester City"))||key.equals(teamKey("Man City")))
            return "https://crests.football-data.org/65.png";
        if(key.equals(teamKey("Manchester United"))||key.equals(teamKey("Man United"))||key.equals(teamKey("Man Utd")))
            return "https://crests.football-data.org/66.png";
        if(key.equals(teamKey("Newcastle United"))||key.equals(teamKey("Newcastle")))
            return "https://crests.football-data.org/67.png";
        if(key.equals(teamKey("Tottenham Hotspur"))||key.equals(teamKey("Tottenham"))||key.equals(teamKey("Spurs")))
            return "https://crests.football-data.org/73.png";

        // Premier League 2026/27: direct football-data crest fallbacks for
        // every bundled participant. This removes cold-start placeholder shields
        // when the provider match payload has not yet supplied team metadata.
        String[][] premierCrests={
                {"Arsenal","57"},{"Aston Villa","58"},{"Chelsea","61"},{"Everton","62"},
                {"Fulham","63"},{"Liverpool","64"},{"Manchester City","65"},{"Manchester United","66"},
                {"Newcastle United","67"},{"Tottenham Hotspur","73"},{"Leeds United","341"},
                {"Nottingham Forest","351"},{"Crystal Palace","354"},{"Brentford","402"},
                {"Brighton & Hove Albion","397"},{"AFC Bournemouth","1044"},{"Sunderland","71"},
                {"Ipswich Town","349"},{"Hull City","322"},{"Coventry City","1076"}
        };
        for(String[] item:premierCrests){
            if(key.equals(teamKey(item[0])))return "https://crests.football-data.org/"+item[1]+".png";
        }

        // La Liga 2026/27: verified football-data.org PNG fallbacks for all
        // 20 clubs. The connected API remains authoritative for fixtures,
        // results and standings; these URLs only guarantee consistent badges.
        String[][] laLigaCrests={
                {"Athletic Club","77"},{"Athletic Bilbao","77"},{"Atlético de Madrid","78"},{"Atletico Madrid","78"},
                {"CA Osasuna","79"},{"Osasuna","79"},{"FC Barcelona","81"},{"Barcelona","81"},
                {"Getafe CF","82"},{"Getafe","82"},{"Málaga CF","84"},{"Malaga CF","84"},{"Real Madrid","86"},
                {"Rayo Vallecano","87"},{"Levante UD","88"},{"Racing Santander","89"},{"Real Betis","90"},
                {"Real Sociedad","92"},{"Villarreal CF","94"},{"Villarreal","94"},{"Valencia CF","95"},
                {"Deportivo Alavés","263"},{"Deportivo Alaves","263"},{"Elche CF","285"},
                {"Celta de Vigo","558"},{"Celta Vigo","558"},{"Sevilla FC","559"},
                {"Deportivo La Coruña","560"},{"Deportivo La Coruna","560"},{"RCD Espanyol","80"},{"Espanyol","80"}
        };
        for(String[] item:laLigaCrests){
            if(key.equals(teamKey(item[0])))return "https://crests.football-data.org/"+item[1]+".png";
        }

        // Bundesliga 2026/27: direct verified crest fallbacks for all 18 clubs.
        String[][] bundesligaCrests={
                {"1. FC Köln","1"},{"TSG Hoffenheim","2"},{"Bayer 04 Leverkusen","3"},
                {"Borussia Dortmund","4"},{"FC Bayern München","5"},{"Bayern Munich","5"},
                {"FC Schalke 04","6"},{"Schalke 04","6"},{"Hamburger SV","7"},
                {"VfB Stuttgart","10"},{"SV Werder Bremen","12"},{"Werder Bremen","12"},
                {"1. FSV Mainz 05","15"},{"Mainz 05","15"},{"FC Augsburg","16"},
                {"Sport-Club Freiburg","17"},{"SC Freiburg","17"},
                {"Borussia Mönchengladbach","18"},{"Borussia Monchengladbach","18"},
                {"Eintracht Frankfurt","19"},{"1. FC Union Berlin","28"},{"Union Berlin","28"},
                {"SC Paderborn 07","29"},{"RB Leipzig","721"},{"SV Elversberg","932"}
        };
        for(String[] item:bundesligaCrests){
            if(key.equals(teamKey(item[0])))return "https://crests.football-data.org/"+item[1]+".png";
        }

        // Serie A 2026/27: direct verified PNG fallbacks for all 20 clubs.
        String[][] serieACrests={
                {"Atalanta","102"},{"Atalanta BC","102"},{"Bologna","103"},{"Bologna FC 1909","103"},
                {"Cagliari","104"},{"Cagliari Calcio","104"},{"Como","7397"},{"Como 1907","7397"},
                {"Fiorentina","99"},{"ACF Fiorentina","99"},{"Frosinone","470"},{"Frosinone Calcio","470"},
                {"Genoa","107"},{"Genoa CFC","107"},{"Inter","108"},{"Inter Milan","108"},
                {"FC Internazionale Milano","108"},{"Juventus","109"},{"Juventus FC","109"},
                {"Lazio","110"},{"SS Lazio","110"},{"Lecce","5890"},{"US Lecce","5890"},
                {"Milan","98"},{"AC Milan","98"},{"Monza","5911"},{"AC Monza","5911"},
                {"Napoli","113"},{"SSC Napoli","113"},{"Parma","112"},{"Parma Calcio 1913","112"},
                {"Roma","100"},{"AS Roma","100"},{"Sassuolo","471"},{"US Sassuolo Calcio","471"},
                {"Torino","586"},{"Torino FC","586"},{"Udinese","115"},{"Udinese Calcio","115"},
                {"Venezia","454"},{"Venezia FC","454"}
        };
        for(String[] item:serieACrests){
            if(key.equals(teamKey(item[0])))return "https://crests.football-data.org/"+item[1]+".png";
        }

        // Ligue 1 2026/27: current men's club IDs from ESPN. These raster
        // fallbacks prevent stale or mismatched football-data crest IDs from
        // surviving an app upgrade cache.
        String[][] ligue1Crests={
                {"Angers","7868"},{"Angers SCO","7868"},{"Auxerre","172"},{"AJ Auxerre","172"},
                {"Brest","6997"},{"Stade Brestois 29","6997"},{"Le Havre","3236"},{"Le Havre AC","3236"},
                {"Le Mans","2697"},{"Le Mans FC","2697"},{"Lens","175"},{"RC Lens","175"},
                {"Lille","166"},{"LOSC","166"},{"Lorient","273"},{"FC Lorient","273"},
                {"Lyon","167"},{"Olympique Lyonnais","167"},{"Marseille","176"},{"Olympique de Marseille","176"},
                {"Monaco","174"},{"AS Monaco","174"},{"Nice","2502"},{"OGC Nice","2502"},
                {"Paris FC","6851"},{"Paris Saint-Germain","160"},{"PSG","160"},
                {"Rennes","169"},{"Stade Rennais FC","169"},{"Strasbourg","180"},{"RC Strasbourg Alsace","180"},
                {"Toulouse","179"},{"Toulouse FC","179"},{"Troyes","170"},{"ESTAC Troyes","170"}
        };
        for(String[] item:ligue1Crests){
            if(key.equals(teamKey(item[0])))return "https://a.espncdn.com/i/teamlogos/soccer/500/"+item[1]+".png";
        }

        // Championship 2026/27: keep a direct verified PNG fallback for every
        // participant. Match cards must not depend on the crest index being
        // rebuilt first, especially after a cold start or a partial refresh.
        String[][] championshipCrests={
                {"Birmingham City","332"},{"Blackburn Rovers","59"},{"Bolton Wanderers","60"},
                {"Bristol City","387"},{"Burnley","328"},{"Cardiff City","715"},
                {"Charlton Athletic","348"},{"Derby County","342"},{"Lincoln City","1126"},
                {"Middlesbrough","343"},{"Millwall","384"},{"Norwich City","68"},
                {"Portsmouth","325"},{"Preston North End","1081"},{"Queens Park Rangers","69"},
                {"Sheffield United","356"},{"Southampton","340"},{"Stoke City","70"},
                {"Swansea City","72"},{"Watford","346"},{"West Bromwich Albion","74"},
                {"West Ham United","563"},{"Wolverhampton Wanderers","76"},{"Wrexham","404"}
        };
        for(String[] item:championshipCrests){
            if(key.equals(teamKey(item[0])))return "https://crests.football-data.org/"+item[1]+".png";
        }
        return "";
    }

    float clubCrestOpticalScale(String team){
        // Remote crests are normalized from their real transparent-pixel bounds
        // in ClubCrestCache, so every club now uses the same optical scale.
        return 1f;
    }

    View remoteClubVisual(String team,String url,int sizePx,boolean hero){
        FrameLayout frame=new FrameLayout(this);
        ImageView fallback=homeLogo("ic_club_placeholder",sizePx);
        int fallbackInset=dp(hero?5:3);
        fallback.setPadding(fallbackInset,fallbackInset,fallbackInset,fallbackInset);
        frame.addView(fallback,new FrameLayout.LayoutParams(-1,-1));
        String crestKey=teamKey(team);
        if(crestKey.equals(teamKey("Juventus"))||crestKey.equals(teamKey("Juventus FC"))){
            frame.setBackground(round(Color.WHITE,dp(hero?18:15),0));
            int frameInset=dp(hero?5:4);
            frame.setPadding(frameInset,frameInset,frameInset,frameInset);
        }
        ImageView crest=new ImageView(this);
        crest.setVisibility(View.INVISIBLE);
        crest.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        crest.setAdjustViewBounds(true);
        // A small transparent safety inset keeps wide and shield-shaped crests
        // optically equal without forcing every badge into a dark circle.
        int inset=dp(hero?3:2);crest.setPadding(inset,inset,inset,inset);
        float opticalScale=clubCrestOpticalScale(team);
        crest.setScaleX(opticalScale);
        crest.setScaleY(opticalScale);
        frame.setClipChildren(true);
        frame.setClipToPadding(true);
        frame.addView(crest,new FrameLayout.LayoutParams(-1,-1));
        if(clubCrestCache!=null)clubCrestCache.load(crest,teamKey(team),url);
        return frame;
    }

    void invalidateClubProfileCache(){
        clubProfilesCache=null;
        clubProfileIndex=Collections.emptyMap();
        warmClubProfileCacheAsync();
    }

    ArrayList<ClubProfile> buildClubProfilesSnapshot(){
        ArrayList<ClubProfile> base=new ArrayList<ClubProfile>(ClubCatalog.build(data==null?null:data.matches,favoriteClubs));
        LinkedHashMap<String,ClubProfile> merged=new LinkedHashMap<String,ClubProfile>();
        for(ClubProfile club:base){
            ClubProfile verified=ClubIdentityRegistry.resolve(club.name);
            ClubProfile value=verified!=null?verified:club;
            merged.put(teamKey(value.name),value);
        }
        // Standings may contribute clubs not present in the shipped registry, but this
        // enrichment is intentionally background-only. It previously ran lazily from
        // Favorites/Home and could block the main looper for several seconds.
        for(String competitionName:CompetitionCatalog.all().keySet()){
            CompetitionCatalog.Competition meta=CompetitionCatalog.get(competitionName);
            if(meta.nationalTeams)continue;
            JSONArray table=verifiedTotalStandingTable(competitionName);
            if(table==null)continue;
            for(int i=0;i<table.length();i++){
                JSONObject row=table.optJSONObject(i);if(row==null)continue;
                JSONObject team=row.optJSONObject("team");if(team==null)continue;
                String name=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();
                if(name.length()==0)continue;
                ClubProfile verified=ClubIdentityRegistry.resolve(name);
                ClubProfile candidate=verified!=null?verified:new ClubProfile(name,competitionName,meta.regionKey);
                String key=teamKey(candidate.name);
                ClubProfile existing=merged.get(key);
                if(existing==null || (ClubIdentityRegistry.resolve(existing.name)==null && verified!=null))merged.put(key,candidate);
            }
        }
        ArrayList<ClubProfile> result=new ArrayList<ClubProfile>(merged.values());
        Collections.sort(result,(a,b)->{int c=a.competition.compareToIgnoreCase(b.competition);return c!=0?c:a.name.compareToIgnoreCase(b.name);});
        return result;
    }

    void warmClubProfileCacheAsync(){
        synchronized(this){if(clubProfileWarmInProgress)return;clubProfileWarmInProgress=true;}
        try{
            appSerialExecutor.execute(new Runnable(){public void run(){
                try{
                    ArrayList<ClubProfile> result=buildClubProfilesSnapshot();
                    LinkedHashMap<String,ClubProfile> index=new LinkedHashMap<String,ClubProfile>();
                    for(ClubProfile profile:result)index.put(teamKey(profile.name),profile);
                    clubProfilesCache=Collections.unmodifiableList(new ArrayList<ClubProfile>(result));
                    clubProfileIndex=Collections.unmodifiableMap(index);
                }catch(Exception ignored){}
                finally{synchronized(MainActivity.this){clubProfileWarmInProgress=false;}}
            }});
        }catch(Exception ignored){synchronized(this){clubProfileWarmInProgress=false;}}
    }

    ArrayList<ClubProfile> availableClubProfiles(){
        List<ClubProfile> cached=clubProfilesCache;
        if(cached!=null)return new ArrayList<ClubProfile>(cached);
        // Never perform standings/JSON enrichment on the UI thread. The verified
        // static registry already contains every supported club and is enough for
        // immediate rendering while the richer snapshot warms in the background.
        warmClubProfileCacheAsync();
        ArrayList<ClubProfile> fast=new ArrayList<ClubProfile>(ClubIdentityRegistry.all());
        Collections.sort(fast,(a,b)->{int c=a.competition.compareToIgnoreCase(b.competition);return c!=0?c:a.name.compareToIgnoreCase(b.name);});
        return fast;
    }

    ClubProfile availableClubProfile(String club){
        if(club==null||club.trim().length()==0)return null;
        // Known clubs resolve in O(1) from the static identity registry. This avoids
        // triggering a full catalog/standings rebuild from clubCountry/clubLeague.
        ClubProfile verified=ClubIdentityRegistry.resolve(club);
        if(verified!=null)return verified;
        String canonical=ClubIdentityRegistry.canonicalName(club);
        ClubProfile direct=clubProfileIndex.get(teamKey(canonical));
        if(direct!=null)return direct;
        warmClubProfileCacheAsync();
        return null;
    }

    String clubLeague(String club){
        String k=teamKey(club);
        if(k.equals("dinamozagreb")||k.equals("hajduksplit")||k.equals("rijeka")||k.equals("osijek")||k.equals("gorica")||k.equals("istra1961")||k.equals("lokomotivazagreb")||k.equals("rudes")||k.equals("slavenbelupo")||k.equals("varazdin")) return "HNL";
        if(k.equals("realmadrid")||k.contains("barcelona")||k.contains("atletico")) return "La Liga";
        if(k.contains("manchestercity")||k.equals("liverpool")||k.equals("arsenal")) return "Premier League";
        if(k.contains("bayern")||k.contains("borussiadortmund")) return "Bundesliga";
        if(k.equals("atalanta")||k.equals("bologna")||k.equals("cagliari")||k.equals("como")||
                k.equals("fiorentina")||k.equals("frosinone")||k.equals("genoa")||k.equals("inter")||
                k.equals("juventus")||k.equals("lazio")||k.equals("lecce")||k.equals("milan")||
                k.equals("monza")||k.equals("napoli")||k.equals("parma")||k.equals("roma")||
                k.equals("sassuolo")||k.equals("torino")||k.equals("udinese")||k.equals("venezia")) return "Serie A";
        if(k.equals("angers")||k.equals("angerssco")||k.equals("auxerre")||k.equals("ajauxerre")||
                k.equals("brest")||k.equals("stadebrestois29")||k.equals("lehavre")||k.equals("lehavreac")||
                k.equals("lemans")||k.equals("lemansfc")||k.equals("lens")||k.equals("rclens")||
                k.equals("lille")||k.equals("losc")||k.equals("lorient")||k.equals("fclorient")||
                k.equals("lyon")||k.equals("olympiquelyonnais")||k.equals("marseille")||k.equals("olympiquedemarseille")||
                k.equals("monaco")||k.equals("asmonaco")||k.equals("nice")||k.equals("ogcnice")||
                k.equals("parisfc")||k.contains("parissaintgermain")||k.equals("psg")||k.equals("rennes")||
                k.equals("staderennaisfc")||k.equals("strasbourg")||k.equals("rcstrasbourgaslace")||
                k.equals("toulouse")||k.equals("toulousefc")||k.equals("troyes")||k.equals("estactroyes")) return "Ligue 1";
        if(k.equals("adodenhaag")||k.equals("ajax")||k.equals("ajaxamsterdam")||k.equals("az")||k.equals("azalkmaar")||
                k.equals("excelsior")||k.equals("excelsiorrotterdam")||k.equals("fcgroningen")||k.equals("groningen")||
                k.equals("fctwente")||k.equals("twente")||k.equals("fcutrecht")||k.equals("utrecht")||
                k.equals("feyenoord")||k.equals("fortunasittard")||k.equals("goaheadeagles")||
                k.equals("nec")||k.equals("necnijmegen")||k.equals("peczwolle")||k.equals("psv")||k.equals("psveindhoven")||
                k.equals("sccambuur")||k.equals("cambuur")||k.equals("scheerenveen")||k.equals("heerenveen")||
                k.equals("spartarotterdam")||k.equals("telstar")||k.equals("willemii")||k.equals("willem2")) return "Eredivisie";
        if(k.equals("estorilpraia")||k.equals("estoril")||k.equals("fcfamalicao")||k.equals("famalicao")||
                k.equals("maritimo")||k.equals("csmaritimo")||k.equals("casapiaac")||k.equals("casapia")||
                k.equals("vitoriasc")||k.equals("vitoriaguimaraes")||k.equals("fcarouca")||k.equals("arouca")||
                k.equals("estrelaamadora")||k.equals("cfestrelaamadora")||k.equals("sportingcp")||k.equals("sporting")||
                k.equals("fcporto")||k.equals("porto")||k.equals("fcalverca")||k.equals("alverca")||
                k.equals("gilvicentefc")||k.equals("gilvicente")||k.equals("rioavefc")||k.equals("rioave")||
                k.equals("slbenfica")||k.equals("benfica")||k.equals("academico")||k.equals("academicodeviseu")||
                k.equals("moreirensefc")||k.equals("moreirense")||k.equals("scbraga")||k.equals("braga")||
                k.equals("santaclara")||k.equals("cdnacional")||k.equals("nacional")) return "Primeira Liga";
        if(k.equals("athleticoparanaense")||k.equals("atleticomineiro")||k.equals("bahia")||k.equals("botafogo")||
                k.equals("chapecoense")||k.equals("corinthians")||k.equals("coritiba")||k.equals("cruzeiro")||
                k.equals("flamengo")||k.equals("fluminense")||k.equals("gremio")||k.equals("internacional")||
                k.equals("mirassol")||k.equals("palmeiras")||k.equals("redbullbragantino")||k.equals("remo")||
                k.equals("santos")||k.equals("saopaulo")||k.equals("vascodagama")||k.equals("vitoria")) return "Brasileirão Série A";
        ClubProfile profile=availableClubProfile(club);
        if(profile!=null&&profile.competition.length()>0)return profile.competition;
        if(data!=null)for(Match match:data.matches){
            if(sameTeam(match.home,club)||sameTeam(match.away,club)){
                String competition=friendlyCompetitionName(match);
                if(!isNationalCompetition(competition))return competition;
            }
        }
        return t2("Club competition","Klupsko natjecanje","Klubwettbewerb","Competición de clubes","Compétition de clubs");
    }

    String clubCountry(String club){
        ClubProfile profile=availableClubProfile(club);
        if(profile!=null&&profile.country.length()>0)return localizedClubCountry(profile.country);
        String league=clubLeague(club);
        if(league.equals("HNL")) return localizedClubCountry("Croatia");
        if(league.equals("La Liga")) return localizedClubCountry("Spain");
        if(league.equals("Premier League")||league.equals("Championship")) return localizedClubCountry("England");
        if(league.equals("Bundesliga")) return localizedClubCountry("Germany");
        if(league.equals("Serie A")) return localizedClubCountry("Italy");
        if(league.equals("Ligue 1")) return localizedClubCountry("France");
        if(league.equals("Eredivisie")) return localizedClubCountry("Netherlands");
        if(league.equals("Primeira Liga")) return localizedClubCountry("Portugal");
        if(league.equals("Brasileirão Série A")) return localizedClubCountry("Brazil");
        return competitionRegion(league);
    }

    String localizedClubCountry(String country){
        if(country==null)return "";String key=country.trim().toLowerCase(Locale.ROOT);
        if(key.equals("croatia"))return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(key.equals("spain"))return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(key.equals("england"))return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(key.equals("scotland"))return t2("Scotland","Škotska","Schottland","Escocia","Écosse");
        if(key.equals("wales"))return t2("Wales","Wales","Wales","Gales","Pays de Galles");
        if(key.equals("germany"))return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(key.equals("italy"))return t2("Italy","Italija","Italien","Italia","Italie");
        if(key.equals("france"))return t2("France","Francuska","Frankreich","Francia","France");
        if(key.equals("netherlands"))return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(key.equals("portugal"))return "Portugal";if(key.equals("brazil"))return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        if(key.equals("belgium"))return t2("Belgium","Belgija","Belgien","Bélgica","Belgique");
        if(key.equals("turkey"))return t2("Turkey","Turska","Türkei","Turquía","Turquie");
        if(key.equals("austria"))return t2("Austria","Austrija","Österreich","Austria","Autriche");
        if(key.equals("norway"))return t2("Norway","Norveška","Norwegen","Noruega","Norvège");
        if(key.equals("greece"))return t2("Greece","Grčka","Griechenland","Grecia","Grèce");
        return country;
    }

    String clubCountryFlag(String club){
        ClubProfile profile=availableClubProfile(club);String country=profile==null?"":profile.country;
        if(country.length()==0){String league=clubLeague(club);if(league.equals("HNL"))country="Croatia";else if(league.equals("La Liga"))country="Spain";else if(league.equals("Premier League")||league.equals("Championship"))country="England";else if(league.equals("Bundesliga"))country="Germany";else if(league.equals("Serie A"))country="Italy";else if(league.equals("Ligue 1"))country="France";else if(league.equals("Eredivisie"))country="Netherlands";else if(league.equals("Primeira Liga"))country="Portugal";else if(league.equals("Brasileirão Série A"))country="Brazil";}
        String k=country.trim().toLowerCase(Locale.ROOT);
        if(k.equals("croatia"))return "🇭🇷";if(k.equals("spain"))return "🇪🇸";if(k.equals("england"))return "🏴";if(k.equals("scotland"))return "🏴";if(k.equals("wales"))return "🏴";
        if(k.equals("germany"))return "🇩🇪";if(k.equals("italy"))return "🇮🇹";if(k.equals("france"))return "🇫🇷";if(k.equals("netherlands"))return "🇳🇱";if(k.equals("portugal"))return "🇵🇹";if(k.equals("brazil"))return "🇧🇷";
        if(k.equals("belgium"))return "🇧🇪";if(k.equals("turkey"))return "🇹🇷";if(k.equals("ukraine"))return "🇺🇦";if(k.equals("czechia"))return "🇨🇿";if(k.equals("greece"))return "🇬🇷";if(k.equals("norway"))return "🇳🇴";if(k.equals("slovenia"))return "🇸🇮";if(k.equals("israel"))return "🇮🇱";if(k.equals("austria"))return "🇦🇹";if(k.equals("bulgaria"))return "🇧🇬";if(k.equals("slovakia"))return "🇸🇰";if(k.equals("azerbaijan"))return "🇦🇿";
        if(k.equals("denmark"))return "🇩🇰";if(k.equals("armenia"))return "🇦🇲";if(k.equals("serbia"))return "🇷🇸";if(k.equals("kazakhstan"))return "🇰🇿";if(k.equals("lithuania"))return "🇱🇹";if(k.equals("sweden"))return "🇸🇪";if(k.equals("albania"))return "🇦🇱";if(k.equals("poland"))return "🇵🇱";if(k.equals("georgia"))return "🇬🇪";if(k.equals("finland"))return "🇫🇮";if(k.equals("ireland"))return "🇮🇪";if(k.equals("switzerland"))return "🇨🇭";if(k.equals("romania"))return "🇷🇴";if(k.equals("iceland"))return "🇮🇸";if(k.equals("latvia"))return "🇱🇻";if(k.equals("kosovo"))return "🇽🇰";if(k.equals("north macedonia"))return "🇲🇰";if(k.equals("malta"))return "🇲🇹";if(k.equals("san marino"))return "🇸🇲";if(k.equals("hungary"))return "🇭🇺";if(k.equals("montenegro"))return "🇲🇪";if(k.equals("estonia"))return "🇪🇪";if(k.equals("belarus"))return "🇧🇾";if(k.equals("moldova"))return "🇲🇩";
        return "⚽";
    }

    View leagueVisual(String league,String fallbackFlag,int size){
        if("Premier League".equals(league)) return homeLogo("logo_premier_league",dp(size));
        TextView badge=centerLabel(fallbackFlag,44,Color.WHITE,true);
        badge.setBackground(round(Color.rgb(28,33,46),dp(24),1));
        return badge;
    }

    String clubInitials(String team){
        if(team==null||team.trim().length()==0)return "FC";
        String[] parts=team.trim().split("\\s+");
        StringBuilder out=new StringBuilder();
        for(String part:parts){
            if(part.length()==0||part.equalsIgnoreCase("FC")||part.equalsIgnoreCase("CF"))continue;
            out.append(Character.toUpperCase(part.charAt(0)));
            if(out.length()>=2)break;
        }
        if(out.length()==0)out.append("FC");
        return out.toString();
    }

    View localClubVisual(String team,String logo,int sizePx,boolean hero){
        FrameLayout frame=new FrameLayout(this);
        ImageView crest=homeLogo(logo,sizePx);
        crest.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        // Keep bundled PNGs on the same optical canvas as downloaded crests.
        // This prevents round/full-canvas badges (Bayern, Dortmund-style badges)
        // from visually overpowering narrow shield crests in fixture lists.
        int inset=Math.max(dp(hero?3:4),Math.round(sizePx*0.065f));
        crest.setPadding(inset,inset,inset,inset);
        frame.addView(crest,new FrameLayout.LayoutParams(-1,-1));
        return frame;
    }

    View homeTeamVisual(String team,int sizePx,boolean hero){
        String logo=clubLogoResource(team,hero);
        if(logo.length()>0) return localClubVisual(team,logo,sizePx,hero);
        String symbol=flag(team);
        boolean national=!symbol.equals("🏳");
        if(!national){
            String remote=crestUrlForClub(team);
            if(remote.length()>0)return remoteClubVisual(team,remote,sizePx,hero);
        }
        if(!national){
            ImageView placeholder=homeLogo("ic_club_placeholder",sizePx);
            int inset=dp(hero?5:3);
            placeholder.setPadding(inset,inset,inset,inset);
            return placeholder;
        }
        TextView badge=centerLabel(symbol,hero?58:38,Color.WHITE,true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(Color.TRANSPARENT,dp(hero?34:24),1));
        return badge;
    }

    LinearLayout dynamicTeamBlock(String team,int sizeDp){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(sizeDp),false);
        visual.setElevation(dp(5));
        box.addView(visual,new LinearLayout.LayoutParams(dp(sizeDp),dp(sizeDp)));
        TextView n=centerLabel(shortName(team),14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    String compactTeamCardName(String team){
        String name=displayTeamName(team);
        if(name==null)return "";
        name=name.trim().replaceAll("\\s+"," ");
        String key=teamKey(name);
        if(key.equals("heartofmidlothian")||key.equals("heartofmidlothia")){
            return "Heart of\nMidlothian";
        }
        if(key.equals("wolverhamptonwanderers"))return "Wolverhampton\nWanderers";
        if(key.equals("birminghamcity"))return "Birmingham\nCity";
        if(key.equals("queensparkrangers"))return "Queens Park\nRangers";
        if(key.equals("borussiamonchengladbach"))return "Borussia M'gladbach";
        if(key.equals("hamburgersv"))return "Hamburger SV";
        if(key.equals("sportclubfreiburg")||key.equals("scfreiburg"))return "SC Freiburg";
        if(key.equals("werderbremen")||key.equals("svwerderbremen"))return "Werder Bremen";
        if(key.equals("parissaintgermain")||key.equals("psg"))return "Paris Saint-\nGermain";
        if(key.equals("rcstrasbourgaslace"))return "Strasbourg";
        int hyphen=name.indexOf('-');
        if(name.length()>12&&hyphen>=4&&hyphen<name.length()-3){
            return name.substring(0,hyphen+1)+"\n"+name.substring(hyphen+1);
        }
        if(name.length()>12&&name.contains(" ")){
            int best=-1;
            int target=name.length()/2;
            for(int i=0;i<name.length();i++){
                if(name.charAt(i)!=' ')continue;
                if(best<0||Math.abs(i-target)<Math.abs(best-target))best=i;
            }
            if(best>0&&best<name.length()-1)return name.substring(0,best)+"\n"+name.substring(best+1);
        }
        return name;
    }

    int compactTeamCardTextSize(String visibleName){
        if(visibleName==null||visibleName.length()==0)return 13;
        String[] lines=visibleName.split("\\n");
        int longest=0;
        for(String line:lines){
            String[] words=line.trim().split("\\s+");
            for(String word:words)longest=Math.max(longest,word.length());
        }
        // "Bournemouth" is a single 11-letter word. At 11sp Android can still
        // wrap it inside the word on compact match cards, even with hyphenation
        // disabled. Use 9sp only for this exact compact two-line label.
        if("AFC\nBournemouth".equals(visibleName))return 9;
        if("Wolverhampton\nWanderers".equals(visibleName))return 8;
        if("Birmingham\nCity".equals(visibleName))return 10;
        if("Queens Park\nRangers".equals(visibleName))return 11;
        if("Borussia M'gladbach".equals(visibleName))return 10;
        if("Hamburger SV".equals(visibleName))return 11;
        if("SC Freiburg".equals(visibleName))return 11;
        if("Paris\nSaint-Germain".equals(visibleName))return 10;
        if("Chapecoense".equals(visibleName))return 10;
        if(longest>=10)return 11;
        if(longest>=8)return 12;
        return 13;
    }

    @android.annotation.SuppressLint("WrongConstant")
    LinearLayout dynamicCompactTeamBlock(String team){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(64),false);
        visual.setElevation(dp(4));
        box.addView(visual,new LinearLayout.LayoutParams(dp(64),dp(64)));
        String visibleName=compactTeamCardName(team);
        TextView teamName=centerLabel(visibleName,compactTeamCardTextSize(visibleName),text,true);
        boolean oneLongWord=visibleName.indexOf('\n')<0&&visibleName.indexOf(' ')<0;
        teamName.setMaxLines(oneLongWord?1:2);
        teamName.setMinLines(oneLongWord?1:2);
        teamName.setSingleLine(oneLongWord);
        teamName.setEllipsize(null);
        if(Build.VERSION.SDK_INT>=23){
            teamName.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
            teamName.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);
        }
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(3),dp(5),dp(3),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(43)));
        return box;
    }

    int smartBadgeColor(Match m){
        if(matchIsLive(m))return Color.rgb(240,18,75);
        if(matchIsToday(m))return Color.rgb(22,145,88);
        if(matchIsTomorrow(m))return Color.rgb(179,132,28);
        return Color.rgb(66,74,92);
    }

    boolean isIncompleteVenueFragment(String value){
        if(value==null)return false;
        String folded=Normalizer.normalize(value.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","").trim();
        String compact=folded.replaceAll("[^a-z0-9]+","");
        return compact.equals("arena")||compact.equals("georgi")||compact.equals("merkur")||compact.equals("stockhorn")||
                compact.equals("stadium")||compact.equals("stadion")||compact.equals("park")||compact.equals("ground")||
                compact.equals("hall")||compact.equals("ulker")||compact.equals("vazgen")||compact.equals("vagen")||compact.equals("mikheil")||
                compact.equals("vareareenatn");
    }

    String cleanCompactPhase(String value){
        String phase=value==null?"":normalizeStage(value).trim();
        if(phase.length()==0)return "";
        String[] parts=phase.split("\\s*[•·|]\\s*");
        if(parts.length<=1)return isIncompleteVenueFragment(phase)?"":phase;
        ArrayList<String> kept=new ArrayList<String>();
        for(String part:parts){
            String clean=part==null?"":part.trim();
            if(clean.length()>0&&!isIncompleteVenueFragment(clean))kept.add(clean);
        }
        return android.text.TextUtils.join(" • ",kept);
    }

    @android.annotation.SuppressLint("WrongConstant")
    boolean compactMatchContextFits(String value){
        if(value==null||value.trim().length()==0)return true;
        try{
            android.text.TextPaint paint=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG);
            paint.setTextSize(9f*getResources().getDisplayMetrics().scaledDensity);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
            int width=Math.max(1,dp(108));
            android.text.StaticLayout layout=android.text.StaticLayout.Builder
                    .obtain(value,0,value.length(),paint,width)
                    .setAlignment(android.text.Layout.Alignment.ALIGN_CENTER)
                    .setIncludePad(false)
                    .setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE)
                    .setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE)
                    .build();
            return layout.getLineCount()<=2;
        }catch(Exception ignored){
            return value.length()<=38;
        }
    }

    String compactContextWithVenue(String primary,String venue){
        String main=primary==null?"":primary.trim();
        String stadium=venue==null?"":venue.trim();
        if(stadium.length()==0)return main;
        if(main.length()==0)return compactMatchContextFits(stadium)?stadium:"";
        String combined=main+"  •  "+stadium;
        // A full stadium name is useful only when the compact card can show it in
        // full. If it would be clipped to a fragment such as "Arena", "Georgi",
        // "Merkur", "Stockhorn", "Vazgen" or "Mikheil", keep only the phase/date.
        return compactMatchContextFits(combined)?combined:main;
    }

    String compactMatchContext(Match m,boolean dateAlreadyShown){
        if(m==null)return "";
        String phase=m.matchday>0
                ?t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+m.matchday
                :cleanCompactPhase(m.roundName);
        if(phase.length()==0 && m.group!=null && m.group.trim().length()>0){
            String group=m.group.trim();
            phase=group.toLowerCase(homeLocale()).contains("pretkolo")?group:("Group "+group);
        }
        String venue=m.actualVenue==null?"":confirmedStadiumName(m.actualVenue);
        if(venue.length()==0 && m.venue!=null){
            String raw=m.venue.trim();
            String normalized=normalizeStage(raw);
            if(!raw.equalsIgnoreCase(normalized))venue=confirmedStadiumName(raw);
        }

        // When the upper badge already shows the matchday (for example "Kolo 9"),
        // do not repeat the same information below the VS label. Prefer a known
        // calendar date plus a stadium only when the complete name fits the card.
        if(isMatchTimeTba(m)&&m.matchday>0){
            if(dateAlreadyShown)return compactContextWithVenue(phase,venue);
            String date=compactPublishedDateLabel(m);
            if(date.length()>0)return compactContextWithVenue(date,venue);
            return compactContextWithVenue(phase,venue);
        }
        return compactContextWithVenue(phase,venue);
    }

    String compactPublishedDateLabel(Match m){
        if(m==null||m.date==null)return "";
        String local=displayLocalDateTime(m.date).trim();
        if(local.length()<10)return "";
        try{
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(local.substring(0,10));
            return new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(d);
        }catch(Exception ignored){return "";}
    }

    String fullPublishedKickoffLabel(Match m,boolean showMatchdayWhenTba){
        if(m==null)return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        Date d=localMatchDate(m);
        if(d==null)return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        String date=new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(d);
        if(!hasConfirmedKickoffTime(m))return date+" • "+t2("TBA","Naknadno","Offen","Pendiente","À confirmer");
        return date+" • "+new SimpleDateFormat("HH:mm",Locale.US).format(d);
    }

    void addDynamicHomeMatch(LinearLayout parent,Match m){ addDynamicHomeMatch(parent,m,true,false,false); }

    void addDynamicHomeMatch(LinearLayout parent,Match m,boolean showMatchdayWhenTba){ addDynamicHomeMatch(parent,m,showMatchdayWhenTba,false,false); }

    void addDynamicHomeMatch(LinearLayout parent,Match m,boolean showMatchdayWhenTba,boolean showDate){ addDynamicHomeMatch(parent,m,showMatchdayWhenTba,showDate,false); }

    void addDynamicHomeMatch(LinearLayout parent,Match m,boolean showMatchdayWhenTba,boolean showDate,boolean fullDateTimeBadge){
        final Match selected=m;
        LinearLayout row=hrow();
        row.setPadding(dp(12),dp(15),dp(12),dp(15));
        row.setBackground(round(Color.rgb(16,21,33),dp(21),1));
        row.setElevation(dp(2));
        row.addView(dynamicCompactTeamBlock(m.home),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        String rawStatus=m==null||m.status==null?"":m.status.trim().toUpperCase(Locale.US);
        boolean resultUnavailable=matchHasResultUnavailable(m);
        boolean postponed=rawStatus.startsWith("POSTPON");
        String badgeText=matchIsLive(m)?t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT"):matchIsFinished(m)?t2("FT","KRAJ","ENDE","FINAL","FIN"):
                resultUnavailable?homeCenterStatus(m):
                postponed?t2("POSTPONED","ODGOĐENO","VERSCHOBEN","APLAZADO","REPORTÉ"):
                (fullDateTimeBadge?fullPublishedKickoffLabel(m,showMatchdayWhenTba):compactHomeTimeLabel(m,showMatchdayWhenTba));
        TextView b=centerLabel(badgeText,badgeText.length()>18?8:badgeText.length()>12?9:10,Color.WHITE,true);
        b.setSingleLine(true);
        b.setMaxLines(1);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10),dp(2),dp(10),dp(2));
        b.setBackground(round(smartBadgeColor(m),dp(13),0));
        int centerWidth=fullDateTimeBadge?dp(138):dp(112);
        mid.addView(b,new LinearLayout.LayoutParams(centerWidth,dp(26)));
        String center=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" - "+m.awayGoals:(resultUnavailable||postponed?"—":"VS");
        TextView scoreView=centerLabel(center,center.equals("VS")?24:31,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        LinearLayout.LayoutParams scoreLp=new LinearLayout.LayoutParams(-2,-2);scoreLp.setMargins(0,dp(7),0,0);mid.addView(scoreView,scoreLp);
        if(matchIsLive(m) && m.minute!=null && m.minute.trim().length()>0) mid.addView(centerLabel(m.minute.replace("'","")+"′",12,RED,true));
        if(showDate){
            String dateLabel=compactPublishedDateLabel(m);
            if(dateLabel.length()>0){
                TextView dateView=centerLabel(dateLabel,10,subText,true);
                dateView.setSingleLine(true);
                LinearLayout.LayoutParams dateLp=new LinearLayout.LayoutParams(centerWidth,-2);dateLp.setMargins(0,dp(4),0,0);mid.addView(dateView,dateLp);
            }
        }
        String context=compactMatchContext(m,showDate||fullDateTimeBadge);
        if(context.length()>0){
            TextView contextView=centerLabel(context,9,subText,true);
            contextView.setMaxLines(2);
            contextView.setGravity(Gravity.CENTER);
            contextView.setPadding(dp(2),dp(5),dp(2),0);
            mid.addView(contextView,new LinearLayout.LayoutParams(centerWidth,-2));
        }
        row.addView(mid,new LinearLayout.LayoutParams(centerWidth,-2));
        row.addView(dynamicCompactTeamBlock(m.away),new LinearLayout.LayoutParams(0,-2,1));
        if(resultUnavailable||postponed){
            // Incomplete historical/postponed rows deliberately contain no invented
            // score or replacement kickoff, so do not open an incomplete details page.
            row.setClickable(false);
        }else{
            row.setOnClickListener(v->showMatchDetails(selected));
            row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        }
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(14),0,0);
        parent.addView(row,lp);
        row.setAlpha(0f);
        row.setTranslationY(dp(8));
        row.animate().alpha(1f).translationY(0f).setDuration(190).start();
    }

    boolean dataContainsTeam(String team){
        if(team==null) return false;
        for(Match m:data.matches) if(sameTeam(m.home,team)||sameTeam(m.away,team)) return true;
        return false;
    }

    Date localMatchDate(Match m){
        if(m==null||m.date==null)return null;
        String raw=m.date.trim();
        if(raw.isEmpty())return null;
        Long cached=localMatchMillisCache.get(raw);
        if(cached!=null)return cached<0L?null:new Date(cached);
        String d=displayLocalDateTime(raw).trim();
        long millis=-1L;
        try{
            Date parsed=null;
            if(d.length()>=16)parsed=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(d.substring(0,16));
            else if(d.length()>=10)parsed=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d.substring(0,10));
            if(parsed!=null)millis=parsed.getTime();
        }catch(Exception ignored){}
        localMatchMillisCache.put(raw,millis);
        return millis<0L?null:new Date(millis);
    }

    String localDateKey(Match m){
        Date d=localMatchDate(m);
        return d==null?"":new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);
    }

    boolean matchIsLive(Match m){ return m!=null && isLiveStatus(m.status); }
    boolean matchHasResultUnavailable(Match m){ return m!=null && MatchStatus.isResultUnavailable(m.status); }
    boolean matchIsFinished(Match m){
        return MatchConsistency.isVerifiedFinished(m);
    }
    boolean matchIsUpcoming(Match m){
        if(m==null||matchIsLive(m)||matchIsFinished(m)||matchHasResultUnavailable(m))return false;
        return isUpcomingStatus(m.status);
    }

    void refreshDayKeysIfNeeded(){
        long now=System.currentTimeMillis();
        if(!cachedTodayKey.isEmpty()&&now-cachedDayKeysAt<30000L)return;
        Date current=new Date(now);
        cachedTodayKey=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(current);
        Calendar c=Calendar.getInstance();c.setTime(current);c.add(Calendar.DAY_OF_YEAR,1);
        cachedTomorrowKey=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
        cachedDayKeysAt=now;
    }

    boolean matchIsToday(Match m){refreshDayKeysIfNeeded();return cachedTodayKey.equals(localDateKey(m));}

    boolean matchIsTomorrow(Match m){refreshDayKeysIfNeeded();return cachedTomorrowKey.equals(localDateKey(m));}

    ArrayList<Match> todaysMatches(){
        ArrayList<Match> out=new ArrayList<>();
        for(Match m:data.matches) if(matchIsToday(m)&&!hnlMatchNeedsResultConfirmation(m)) out.add(m);
        Collections.sort(out,(a,b)->{
            Date da=localMatchDate(a), db=localMatchDate(b);
            if(da==null&&db==null)return 0; if(da==null)return 1; if(db==null)return -1; return da.compareTo(db);
        });
        return out;
    }

    List<Match> matchesForTeamSnapshot(String team){
        if(team==null||team.trim().isEmpty())return Collections.emptyList();
        Map<String,List<Match>> index=teamMatchIndex;
        List<Match> hit=index.get(teamKey(team));
        if(hit!=null)return hit;
        // Index is warmed off the UI thread. Until then return a cheap empty snapshot
        // rather than scanning thousands of fixtures during navigation.
        if(Looper.myLooper()==Looper.getMainLooper())return Collections.emptyList();
        ArrayList<Match> fallback=new ArrayList<>();
        if(data!=null&&data.matches!=null)for(Match m:data.matches)if(sameTeam(m.home,team)||sameTeam(m.away,team))fallback.add(m);
        return fallback;
    }

    void rebuildTeamMatchIndex(){
        if(data==null||data.matches==null){teamMatchIndex=Collections.emptyMap();return;}
        LinkedHashMap<String,ArrayList<Match>> building=new LinkedHashMap<>();
        for(Match m:data.matches){
            if(m==null)continue;
            String hk=teamKey(m.home),ak=teamKey(m.away);
            if(!hk.isEmpty())building.computeIfAbsent(hk,k->new ArrayList<Match>()).add(m);
            if(!ak.isEmpty()&&!ak.equals(hk))building.computeIfAbsent(ak,k->new ArrayList<Match>()).add(m);
        }
        LinkedHashMap<String,List<Match>> ready=new LinkedHashMap<>();
        for(Map.Entry<String,ArrayList<Match>> e:building.entrySet())ready.put(e.getKey(),Collections.unmodifiableList(e.getValue()));
        teamMatchIndex=Collections.unmodifiableMap(ready);
        teamMatchIndexGeneration++;
    }

    boolean hnlMatchNeedsResultConfirmation(Match m){
        if(m==null||!matchBelongsToCompetition(m,"HNL")||!matchIsUpcoming(m))return false;
        String matchDay=localDateKey(m);
        if(matchDay.isEmpty())return false;
        refreshDayKeysIfNeeded();
        // HNL currently has a verified fixture baseline, but no live/result provider.
        // Once a scheduled HNL fixture reaches match day, do not keep presenting it as
        // a confirmed "next match" if our HNL source has not refreshed on/after that day.
        // This prevents stale schedule-only rows from surviving as future fixtures after
        // the real match has already been played. Other paid competitions are untouched.
        if(matchDay.compareTo(cachedTodayKey)>0)return false;
        String lastUpdate=hnlLastSuccessfulUpdate();
        return lastUpdate==null||lastUpdate.trim().isEmpty()||lastUpdate.trim().compareTo(matchDay)<0;
    }

    boolean hnlAwaitingResultConfirmationForTeam(String team){
        if(team==null||team.trim().isEmpty())return false;
        for(Match m:matchesForTeamSnapshot(team)){
            if((sameTeam(m.home,team)||sameTeam(m.away,team))&&hnlMatchNeedsResultConfirmation(m))return true;
        }
        return false;
    }

    Match nextMatchForTeam(String team){
        if(team==null || team.trim().length()==0) return null;
        // Do not jump over an unresolved HNL match to a later round. Until a reliable
        // HNL result/status source confirms the played fixture, the honest state is
        // "waiting for confirmation", not a fabricated next match.
        if(hnlAwaitingResultConfirmationForTeam(team))return null;
        Match best=null; Date bestDate=null; long now=System.currentTimeMillis();
        for(Match m:matchesForTeamSnapshot(team)){
            if(matchIsLive(m)) return m;
            if(!matchIsUpcoming(m)) continue;
            Date d=localMatchDate(m); if(d==null)continue;
            boolean dateOnly=displayLocalDateTime(m.date).length()<16;
            long effectiveTime=d.getTime()+(dateOnly?24L*60L*60L*1000L-1L:0L);
            if(effectiveTime<now-AppConfig.MATCH_START_GRACE_MS)continue;
            if(best==null||bestDate==null||d.before(bestDate)){best=m;bestDate=d;}
        }
        return best;
    }

    String[] recentForm(String team,int count){
        ArrayList<Match> finished=new ArrayList<>();
        for(Match m:matchesForTeamSnapshot(team)) if(matchIsFinished(m)) finished.add(m);
        Collections.sort(finished,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
        String[] out=new String[count];
        Arrays.fill(out,"–");
        for(int i=0;i<Math.min(count,finished.size());i++){
            Match m=finished.get(i);
            int own=sameTeam(m.home,team)?m.homeGoals:m.awayGoals;
            int opp=sameTeam(m.home,team)?m.awayGoals:m.homeGoals;
            out[count-1-i]=own>opp?"W":own<opp?"L":"D";
        }
        return out;
    }


    String recentFormDisplay(String team){
        String[] f=recentForm(team,5);
        return f[0]+" • "+f[1]+" • "+f[2]+" • "+f[3]+" • "+f[4];
    }

    String homeDateLabel(Match m){
        Date d=localMatchDate(m);
        if(d==null) return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        return new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(d);
    }

    boolean hasConfirmedKickoffTime(Match m){
        if(m==null)return false;
        if(matchIsLive(m)||matchIsFinished(m))return true;
        String status=m.status==null?"":m.status.trim().toUpperCase(Locale.US);
        if(status.equals("TBD")||status.equals("TBA")||status.equals("POSTPONED")||status.equals("CANCELLED"))return false;
        String local=m.date==null?"":displayLocalDateTime(m.date).trim();
        if(local.length()<16)return false;
        String time=local.substring(11,16);
        return !time.equals("00:00") || status.equals("TIMED") || status.equals("CONFIRMED");
    }

    boolean isMatchTimeTba(Match m){
        return m==null || localMatchDate(m)==null || m.date==null || displayLocalDateTime(m.date).length()<16 || !hasConfirmedKickoffTime(m);
    }

    String homeTimeLabel(Match m){
        Date d=localMatchDate(m);
        if(d==null || m==null || m.date==null || displayLocalDateTime(m.date).length()<16 || !hasConfirmedKickoffTime(m))
            return t2("Kick-off soon","Uskoro","Termin folgt","Horario pronto","Horaire bientôt");
        return new SimpleDateFormat("HH:mm",Locale.US).format(d);
    }

    String compactHomeTimeLabel(Match m){ return compactHomeTimeLabel(m,true); }

    String compactHomeTimeLabel(Match m,boolean showMatchdayWhenTba){
        if(m==null)return t2("Soon","Uskoro","Bald","Pronto","Bientôt");
        Date d=localMatchDate(m);
        if(d==null || m.date==null || displayLocalDateTime(m.date).length()<16 || !hasConfirmedKickoffTime(m)){
            if(showMatchdayWhenTba && m.matchday>0)return t2("MD ","Kolo ","ST ","J ","J ")+m.matchday;
            return t2("Soon","Uskoro","Bald","Pronto","Bientôt");
        }
        String time=new SimpleDateFormat("HH:mm",Locale.US).format(d);
        if(matchIsToday(m))return t2("Today ","Danas ","Heute ","Hoy ","Auj. ")+time;
        if(matchIsTomorrow(m))return t2("Tomorrow ","Sutra ","Morgen ","Mañana ","Demain ")+time;
        long diff=d.getTime()-System.currentTimeMillis();
        if(diff>0&&diff<7L*24L*60L*60L*1000L)return new SimpleDateFormat("EEE HH:mm",homeLocale()).format(d);
        return new SimpleDateFormat("dd.MM. HH:mm",homeLocale()).format(d);
    }

    boolean hasCompletedMatchForTeam(String team){
        if(team==null || team.trim().length()==0) return false;
        for(Match m:matchesForTeamSnapshot(team)){
            if(matchIsFinished(m)) return true;
        }
        return false;
    }

    Locale homeLocale(){
        return TeamLocalizer.localeFor(lang);
    }

    String homeCenterValue(Match m){
        if(m.homeGoals>=0&&m.awayGoals>=0) return m.homeGoals+" - "+m.awayGoals;
        return homeTimeLabel(m);
    }

    String homeCenterStatus(Match m){
        if(m==null) return "VS";
        String value=MatchCenterFormatter.status(m.status,m.minute,matchIsLive(m),matchIsFinished(m),lang);
        return value.length()>0?value:"VS";
    }

    LinearLayout homeCard(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(15),dp(16),dp(15));
        l.setBackground(round(Color.rgb(12,16,26),dp(23),1)); l.setElevation(dp(5));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(16)); content.addView(l,lp); return l;
    }

    ImageView homeLogo(String name,int size){
        ImageView iv=new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); iv.setAdjustViewBounds(true);
        int id=getResources().getIdentifier(name,"drawable",getPackageName()); if(id!=0) iv.setImageResource(id);
        iv.setPadding(dp(2),dp(2),dp(2),dp(2)); return iv;
    }

    TextView centerLabel(String s,int sp,int color,boolean bold){ TextView t=label(s,sp,color,bold); t.setGravity(Gravity.CENTER); return t; }

    void applyPressFeedback(View view){
        if(view==null)return;
        Drawable base=view.getBackground();
        if(base!=null && !(base instanceof RippleDrawable))view.setBackground(ripple(base));
        view.setClickable(true);
        view.setOnTouchListener((v,e)->{
            if(e.getAction()==android.view.MotionEvent.ACTION_DOWN){v.animate().scaleX(.985f).scaleY(.985f).alpha(.92f).setDuration(70).start();}
            else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL){v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(110).start();}
            return false;
        });
    }

    void animateSelection(View view,Runnable action){
        if(view==null){action.run();return;}
        view.animate().scaleX(.94f).scaleY(.94f).alpha(.78f).setDuration(75).withEndAction(()->{
            action.run();
            if(content!=null){content.setAlpha(.72f);content.animate().alpha(1f).setDuration(180).start();}
            view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(105).start();
        }).start();
    }

    String competitionBadgeText(String competition){
        if("UEFA Champions League".equals(competition))return "UCL";
        if("Premier League".equals(competition))return "PL";
        if("Championship".equals(competition))return "EFL";
        if("La Liga".equals(competition))return "LL";
        if("Bundesliga".equals(competition))return "BL";
        if("Serie A".equals(competition))return "SA";
        if("Ligue 1".equals(competition))return "L1";
        if("Eredivisie".equals(competition))return "ED";
        if("Primeira Liga".equals(competition))return "LP";
        if("Brasileirão Série A".equals(competition))return "BR";
        if("HNL".equals(competition))return "HNL";
        if("World Cup 2026".equals(competition))return "WC";
        if("UEFA European Championship".equals(competition))return "EURO";
        return "🏆";
    }

    int competitionBadgeColor(String competition){
        if("UEFA Champions League".equals(competition))return Color.rgb(28,39,112);
        if("Premier League".equals(competition))return Color.rgb(62,13,86);
        if("Championship".equals(competition))return Color.rgb(20,64,126);
        if("La Liga".equals(competition))return Color.rgb(225,37,43);
        if("Bundesliga".equals(competition))return Color.rgb(211,25,33);
        if("Serie A".equals(competition))return Color.rgb(16,65,145);
        if("Ligue 1".equals(competition))return Color.rgb(17,28,58);
        if("Eredivisie".equals(competition))return Color.rgb(236,93,36);
        if("Primeira Liga".equals(competition))return Color.rgb(20,132,79);
        if("Brasileirão Série A".equals(competition))return Color.rgb(25,110,63);
        if("HNL".equals(competition))return Color.rgb(196,29,46);
        if("World Cup 2026".equals(competition))return Color.rgb(123,34,74);
        return Color.rgb(64,72,92);
    }

    String competitionLogoResource(String competition){
        if("UEFA Champions League".equals(competition))return "logo_comp_ucl";
        if("UEFA Europa League".equals(competition)||"Europa League".equals(competition))return "logo_comp_uel";
        if("Premier League".equals(competition))return "logo_comp_premier";
        if("Championship".equals(competition))return "logo_comp_championship";
        if("La Liga".equals(competition))return "logo_comp_laliga";
        if("Bundesliga".equals(competition))return "logo_comp_bundesliga";
        if("Serie A".equals(competition))return "logo_comp_seriea";
        if("Ligue 1".equals(competition))return "logo_comp_ligue1";
        if("Eredivisie".equals(competition))return "logo_comp_eredivisie";
        if("Primeira Liga".equals(competition))return "logo_comp_primeiraliga";
        if("Brasileirão Série A".equals(competition))return "logo_comp_brasileirao";
        if("HNL".equals(competition))return "logo_comp_hnl";
        if("World Cup 2026".equals(competition))return "logo_comp_worldcup";
        if("UEFA European Championship".equals(competition))return "logo_comp_euro";
        return "";
    }

    View competitionVisual(String competition,int size){
        String resource=competitionLogoResource(competition);
        if(resource.length()>0){
            ImageView logo=homeLogo(resource,size);
            logo.setBackground(round(chipBg,dp(18),1));
            int logoPadding=dp(5);
            if("HNL".equals(competition))logoPadding=dp(2);
            else if("UEFA Champions League".equals(competition))logoPadding=dp(6);
            else if("World Cup 2026".equals(competition)||"UEFA European Championship".equals(competition))logoPadding=dp(4);
            logo.setPadding(logoPadding,logoPadding,logoPadding,logoPadding);
            logo.setContentDescription(competition);
            return logo;
        }
        TextView badge=centerLabel(competitionBadgeText(competition),competitionBadgeText(competition).length()>3?10:13,Color.WHITE,true);
        badge.setBackground(gradient(competitionBadgeColor(competition),Color.rgb(38,42,58),dp(18)));
        badge.setLetterSpacing(.04f);
        return badge;
    }

    LinearLayout teamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(76));
        crest.setElevation(dp(5));
        box.addView(crest,new LinearLayout.LayoutParams(dp(76),dp(76)));
        TextView n=centerLabel(name,14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    void addPremiumMatch(LinearLayout parent,String leftLogo,String leftName,String score,String rightName,String rightLogo,String badge,String minute){
        LinearLayout row=hrow();
        row.setPadding(dp(12),dp(15),dp(12),dp(15));
        row.setBackground(round(Color.rgb(16,21,33),dp(21),1));
        row.setElevation(dp(2));

        LinearLayout leftTeam=compactTeamBlock(leftLogo,leftName);
        row.addView(leftTeam,new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        if(badge!=null&&!badge.isEmpty()){
            TextView b=centerLabel(badge,11,Color.WHITE,true);
            b.setPadding(dp(12),dp(3),dp(12),dp(3));
            b.setBackground(round(badge.equals("LIVE")?Color.rgb(240,18,75):Color.rgb(66,74,92),dp(9),0));
            b.setElevation(dp(3));
            mid.addView(b,new LinearLayout.LayoutParams(dp(86),dp(26)));
        }
        TextView scoreView=centerLabel(score,30,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        mid.addView(scoreView);
        if(minute!=null&&!minute.isEmpty())mid.addView(centerLabel(minute,12,subText,false));
        row.addView(mid,new LinearLayout.LayoutParams(dp(94),-2));

        LinearLayout rightTeam=compactTeamBlock(rightLogo,rightName);
        row.addView(rightTeam,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatches());
        row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(14),0,0);
        parent.addView(row,lp);
    }

    LinearLayout compactTeamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(52));
        crest.setElevation(dp(4));
        box.addView(crest,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView teamName=centerLabel(name,12,text,true);
        teamName.setMaxLines(2);
        teamName.setMinLines(2);
        teamName.setEllipsize(null);
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(2),dp(3),dp(2),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(40)));
        return box;
    }


    int realLiveCount(){ int c=0; for(Match m:data.matches) if(matchIsLive(m)) c++; return c; }
    Match firstLiveMatch(){ for(Match m:data.matches) if(matchIsLive(m)) return m; return null; }
    String primaryFollowedCompetition(){ if(followedCompetitions!=null&&!followedCompetitions.isEmpty())return followedCompetitions.iterator().next(); return "HNL"; }
    String competitionTeams(String c){ return String.valueOf(competitionParticipantCount(c)); }
    String competitionApiCode(String c){ return CompetitionCatalog.get(c).apiCode; }
    boolean competitionUsesFootballData(String c){ return CompetitionCatalog.get(c).footballDataSource; }
    boolean isNationalCompetition(String c){ return CompetitionCatalog.get(c).nationalTeams; }
    boolean competitionUsesRounds(String c){ return CompetitionCatalog.get(c).roundBased; }
    String competitionRound(String c){ if(isNationalCompetition(c))return t2("Tournament","Turnir","Turnier","Torneo","Tournoi"); return t2("League season","Ligaška sezona","Ligasaison","Temporada de liga","Saison de ligue"); }
    String competitionRegion(String c){
        String region=CompetitionCatalog.get(c).regionKey;
        if(region.equals("Croatia"))return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(region.equals("England"))return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(region.equals("Spain"))return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(region.equals("Italy"))return t2("Italy","Italija","Italien","Italia","Italie");
        if(region.equals("Germany"))return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(region.equals("France"))return t2("France","Francuska","Frankreich","Francia","France");
        if(region.equals("Netherlands"))return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(region.equals("Portugal"))return "Portugal";
        if(region.equals("Brazil"))return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        if(region.equals("International"))return t2("International","Međunarodno","International","Internacional","International");
        return t2("Europe","Europa","Europa","Europa","Europe");
    }
    String competitionMeta(String c){
        String sourceLabel;
        if("HNL".equals(c)) sourceLabel=hnlDataConnected()?t2("Official HNL source","Službeni HNL izvor","Offizielle HNL-Quelle","Fuente oficial de HNL","Source officielle HNL"):t2("HNL source is connecting","HNL izvor se povezuje","HNL-Quelle wird verbunden","Conectando fuente HNL","Connexion de la source HNL");
        else sourceLabel=t2("Live data","Podaci uživo","Live-Daten","Datos en vivo","Données en direct");
        return competitionRegion(c)+"  •  "+competitionTeams(c)+" "+t2(isNationalCompetition(c)?"teams":"clubs",isNationalCompetition(c)?"reprezentacija":"klubova",isNationalCompetition(c)?"Teams":"Klubs",isNationalCompetition(c)?"selecciones":"clubes",isNationalCompetition(c)?"équipes":"clubs")+"  •  "+sourceLabel;
    }
    boolean competitionIdentityMatches(String rawCompetition,String selected){
        if(selected==null||selected.equals("All"))return true;
        String raw=rawCompetition==null?"":rawCompetition.toLowerCase(Locale.US);
        String name=selected.toLowerCase(Locale.US);
        String code=competitionApiCode(selected).toLowerCase(Locale.US);
        if(raw.equals(code)||raw.contains(name))return true;
        if(selected.equals("World Cup 2026"))return raw.contains("world cup")||raw.equals("wc");
        if(selected.equals("UEFA European Championship"))return raw.contains("european championship")||raw.contains("euro")||raw.equals("ec");
        if(selected.equals("La Liga"))return raw.contains("primera division")||raw.contains("primera división")||raw.equals("pd");
        if(selected.equals("Brasileirão Série A"))return raw.contains("brasileiro")||raw.contains("brazil")||raw.equals("bsa");
        return false;
    }

    boolean matchBelongsToCompetition(Match m,String selected){
        return m!=null&&competitionIdentityMatches(m.competition,selected);
    }

    boolean jsonMatchBelongsToCompetition(JSONObject row,String selected){
        if(row==null)return false;
        String identity=competitionNameFromJson(row);
        if(competitionIdentityMatches(identity,selected))return true;
        String code=row.optString("competitionCode","");
        if(code.length()>0&&competitionIdentityMatches(code,selected))return true;
        JSONObject competition=row.optJSONObject("competition");
        if(competition!=null){
            if(competitionIdentityMatches(competition.optString("code",""),selected))return true;
            if(competitionIdentityMatches(competition.optString("name",""),selected))return true;
        }
        return false;
    }
    Match lastFavoriteResult(){
        String preferred=dataContainsTeam(primaryFavoriteClub())?primaryFavoriteClub():myTeam;
        ArrayList<Match> found=new ArrayList<>();
        for(Match m:data.matches) if(matchIsFinished(m)&&(sameTeam(m.home,preferred)||sameTeam(m.away,preferred))) found.add(m);
        Collections.sort(found,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);});
        return found.isEmpty()?null:found.get(0);
    }
    void addResultRow(LinearLayout parent,Match m){ LinearLayout row=hrow(); row.setPadding(dp(10),dp(10),dp(10),dp(10)); row.setBackground(round(chipBg,dp(16),0)); TextView left=label(flag(m.home)+" "+safeTeam(m.home),15,text,true); TextView score=label(m.homeGoals+" : "+m.awayGoals,18,RED,true); TextView right=label(flag(m.away)+" "+safeTeam(m.away),15,text,true); right.setGravity(Gravity.RIGHT); row.addView(left,new LinearLayout.LayoutParams(0,-2,1)); row.addView(score); row.addView(right,new LinearLayout.LayoutParams(0,-2,1)); parent.addView(row); }

    void addHomeMatchRow(LinearLayout parent,Match m,boolean highlight){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(12),dp(10),dp(12),dp(10));
        row.setBackground(round(highlight?Color.argb(46,255,48,94):chipBg,dp(18),highlight?1:0));
        String displayedVenue=m.venue!=null&&m.venue.length()>0?confirmedStadiumName(m.venue):"";
        TextView meta=label(displayLocalDateTime(m.date)+(displayedVenue.length()>0?" • "+displayedVenue:""),12,subText,true); row.addView(meta);
        LinearLayout teams=hrow();
        String homeName=safeTeam(m.home), awayName=safeTeam(m.away);
        TextView left=label(flag(homeName)+" "+homeName,15,text,true); TextView right=label(flag(awayName)+" "+awayName,15,text,true); right.setGravity(Gravity.RIGHT);
        teams.addView(left,new LinearLayout.LayoutParams(0,-2,1)); TextView versus=label("VS",11,Color.WHITE,true); versus.setGravity(Gravity.CENTER); versus.setPadding(dp(7),dp(3),dp(7),dp(3)); versus.setBackground(gradient(PURPLE_DARK,RED,dp(11))); teams.addView(versus); teams.addView(right,new LinearLayout.LayoutParams(0,-2,1)); row.addView(teams);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); parent.addView(row,lp);
    }

    int favoriteCoverageScore(){
        int score=20;
        if(myTeam!=null&&!myTeam.trim().isEmpty())score+=25;
        if(favoriteClubs!=null&&!favoriteClubs.isEmpty())score+=30;
        if(followedCompetitions!=null&&!followedCompetitions.isEmpty())score+=25;
        return Math.min(100,score);
    }


    int homeLiveCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsLive(m)) c++;
        return c;
    }

    boolean isFinalStageLabel(String s){
        if(s==null)return false;
        String x=s.toLowerCase(Locale.US);
        return x.contains("final") || x.contains("round") || x.contains("group") || x.contains("stadium") || x.contains("arena");
    }

    int homeTodayCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsToday(m)) c++;
        return c;
    }

    Match nextFavoriteMatch(){
        Match clubMatch=nextMatchForTeam(primaryFavoriteClub());
        return clubMatch!=null?clubMatch:nextMatchForTeam(myTeam);
    }

    LinearLayout pathPreview(String team){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(0,dp(6),0,dp(8));
        String[] rounds={"Round of 32","Round of 16","Quarter-final","Semi-final","Final"};
        String[] steps={
            "✅ Group "+groupOfTeam(team),
            (hasWonStage(team,"Round of 32")?"✅ ":"⬜ ")+"Round of 32",
            (hasWonStage(team,"Round of 16")?"✅ ":"⬜ ")+"Round of 16",
            (hasWonStage(team,"Quarter-final")?"✅ ":"⬜ ")+"Quarter-final",
            (hasWonStage(team,"Semi-final")?"✅ ":"⬜ ")+"Semi-final",
            (hasWonStage(team,"Final")?"🏆 ":"🏆 ")+"Final"
        };
        for(String s:steps)p.addView(label("   "+s,15,subText,false));
        return p;
    }

    LinearLayout kpiRow(String a,String av,String b,String bv,String c,String cv,boolean light){
        LinearLayout r=hrow();r.setPadding(0,dp(10),0,0);
        r.addView(kpi(a,av,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(b,bv,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(c,cv,light),new LinearLayout.LayoutParams(0,dp(72),1));return r;
    }
    LinearLayout kpi(String n,String v,boolean light){LinearLayout k=new LinearLayout(this);k.setOrientation(LinearLayout.VERTICAL);k.setGravity(Gravity.CENTER);k.setPadding(dp(4),dp(4),dp(4),dp(4));k.setBackground(round(light?Color.argb(45,255,255,255):chipBg,dp(18),0));TextView val=label(v,22,light?Color.WHITE:RED,true);val.setGravity(Gravity.CENTER);TextView name=label(n,11,light?Color.WHITE:subText,false);name.setGravity(Gravity.CENTER);k.addView(val);k.addView(name);return k;}
    String daysTo(String date){try{Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(date);long diff=d.getTime()-System.currentTimeMillis();return String.valueOf(Math.max(0,diff/86400000));}catch(Exception e){return "0";}}


    void showFreeLeagues(){
        clear(t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"),t2("Choose a competition for fixtures and results","Odaberi natjecanje za raspored i rezultate","Wähle einen Wettbewerb für Spielplan und Ergebnisse","Elige una competición para calendario y resultados","Choisis une compétition pour le calendrier et les résultats"),"Leagues");
        LinearLayout summary=card();summary.setBackground(gradient(Color.rgb(46,24,92),Color.rgb(139,23,77),dp(22)));
        summary.addView(label("🏆 "+t2("Choose your competition","Odaberi svoje natjecanje","Wähle deinen Wettbewerb","Elige tu competición","Choisis ta compétition"),22,Color.WHITE,true));
        LinearLayout numbers=hrow();
        numbers.addView(homeStat("13",t2("Available","Dostupno","Verfügbar","Disponibles","Disponibles"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        numbers.addView(homeStat(String.valueOf(realLiveCount()),t2("Live","Uživo","Live","En vivo","Direct"),null),middle);
        numbers.addView(homeStat(String.valueOf(homeTodayCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),null),new LinearLayout.LayoutParams(0,-2,1));summary.addView(numbers);
        summary.addView(label(t2("Fixtures and results are free. Following, tables and club centers are Pro features.","Rasporedi i rezultati su besplatni. Praćenje, tablice i centri klubova Pro su funkcije.","Spielpläne und Ergebnisse sind kostenlos. Folgen, Tabellen und Klubzentren gehören zu Pro.","Calendarios y resultados son gratuitos. Seguimiento, tablas y centros de clubes son Pro.","Calendriers et résultats sont gratuits. Suivi, classements et centres de clubs sont Pro."),13,Color.WHITE,false));
        sectionHeading(t2("Club competitions","Klupska natjecanja","Klubwettbewerbe","Competiciones de clubes","Compétitions de clubs"));
        String[][] clubs={{"🏆","UEFA Champions League"},{"🏴","Premier League"},{"🏴","Championship"},{"🇪🇸","La Liga"},{"🇩🇪","Bundesliga"},{"🇮🇹","Serie A"},{"🇫🇷","Ligue 1"},{"🇳🇱","Eredivisie"},{"🇵🇹","Primeira Liga"},{"🇧🇷","Brasileirão Série A"},{"🇭🇷","HNL"}};
        for(String[] x:clubs)addCompetitionCard(x[0],x[1]);
        sectionHeading(t2("National teams","Reprezentacije","Nationalteams","Selecciones","Équipes nationales"));
        String[][] national={{"🌍","World Cup 2026"},{"🇪🇺","UEFA European Championship"}};
        for(String[] x:national)addCompetitionCard(x[0],x[1]);
    }

    void showLeagues(){
        currentCompetitionOriginScreen="";
        if(!hasProAccess()){showFreeLeagues();return;}
        clear(t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"),t2("Follow the football that matters to you","Prati nogomet koji ti je važan","Folge deinem Fußball","Sigue el fútbol que te importa","Suis le football qui compte"),"Leagues");

        LinearLayout summary=card();
        summary.setBackground(gradient(Color.rgb(46,24,92),Color.rgb(139,23,77),dp(22)));
        summary.addView(label("🏆 "+t2("Your competition hub","Tvoj centar natjecanja","Deine Wettbewerbszentrale","Tu centro de competiciones","Ton centre de compétitions"),22,Color.WHITE,true));
        LinearLayout numbers=hrow();
        numbers.addView(homeStat(String.valueOf(followedCompetitions.size()),t2("Following","Pratim","Gefolgt","Siguiendo","Suivi"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(0,-2,1);mlp.setMargins(dp(7),0,dp(7),0);
        numbers.addView(homeStat(String.valueOf(realLiveCount()),t2("Live now","Uživo","Jetzt live","En vivo","Direct"),null),mlp);
        numbers.addView(homeStat("13",t2("Available","Dostupno","Verfügbar","Disponibles","Disponibles"),null),new LinearLayout.LayoutParams(0,-2,1));
        summary.addView(numbers);
        summary.addView(label(t2("Pin competitions for faster access and personalized alerts.","Prati natjecanja za brži pristup i personalizirane obavijesti.","Hefte Wettbewerbe für schnellen Zugriff an.","Fija competiciones para acceso rápido.","Épingle des compétitions pour un accès rapide."),13,Color.WHITE,false));

        if(followedCompetitions!=null&&!followedCompetitions.isEmpty()){
            sectionHeading(t2("Following","Pratim","Gefolgt","Siguiendo","Suivi"));
            for(String c:new ArrayList<String>(followedCompetitions))addCompetitionCard(competitionIcon(c),c);
        }
        sectionHeading(t2("Club competitions","Klupska natjecanja","Klubwettbewerbe","Competiciones de clubes","Compétitions de clubs"));
        String[][] clubs={{"🏆","UEFA Champions League"},{"🏴","Premier League"},{"🏴","Championship"},{"🇪🇸","La Liga"},{"🇩🇪","Bundesliga"},{"🇮🇹","Serie A"},{"🇫🇷","Ligue 1"},{"🇳🇱","Eredivisie"},{"🇵🇹","Primeira Liga"},{"🇧🇷","Brasileirão Série A"},{"🇭🇷","HNL"}};
        for(String[] x:clubs)if(!followedCompetitions.contains(x[1]))addCompetitionCard(x[0],x[1]);
        sectionHeading(t2("National teams","Reprezentacije","Nationalteams","Selecciones","Équipes nationales"));
        String[][] national={{"🌍","World Cup 2026"},{"🇪🇺","UEFA European Championship"}};
        for(String[] x:national)if(!followedCompetitions.contains(x[1]))addCompetitionCard(x[0],x[1]);
    }

    void addCompetitionSection(String sectionTitle,String[][] comps){
        sectionHeading(sectionTitle);
        for(String[] x:comps)addCompetitionCard(x[0],x[1]);
    }



    String competitionParticipantLabelFast(String competitionName){
        int count=CompetitionCatalog.get(competitionName).teamCount;
        synchronized(competitionCacheLock){
            ArrayList<String> cached=competitionParticipantCache.get(competitionName);
            if(cached!=null&&!cached.isEmpty())count=cached.size();
        }
        if(competitionUsesStrictCurrentRoster(competitionName)){
            int verified=strictCompetitionRoster(competitionName).size();
            if(verified>0)count=verified;
        }
        String label=participantCountLabel(count,isNationalCompetition(competitionName));
        if("UEFA Champions League".equals(competitionName)){
            return t2(label+" in the published schedule",label+" u objavljenom rasporedu",label+" im veröffentlichten Spielplan",label+" en el calendario publicado",label+" dans le calendrier publié");
        }
        return label;
    }

    String competitionDataStatusFast(String competition){
        if("HNL".equals(competition))return competitionDataStatus(competition);

        CompetitionSnapshot cached=cachedCompetitionSnapshot(competition);
        if(cached!=null){
            if(cached.live!=null&&!cached.live.isEmpty()){
                return t2("Live results available","Rezultati uživo dostupni","Live-Ergebnisse verfügbar","Resultados en vivo disponibles","Résultats en direct disponibles");
            }
            if(cached.matches!=null&&!cached.matches.isEmpty()){
                int count=isBundledLeagueCompetition(competition)
                        ?verifiedSourceCompetitionMatchCount(competition)
                        :cached.matches.size();
                return t2("Verified schedule connected • "+count+" matches","Provjereni raspored povezan • "+count+" utakmica","Verifizierter Spielplan verbunden • "+count+" Spiele","Calendario verificado conectado • "+count+" partidos","Calendrier vérifié connecté • "+count+" matchs");
            }
        }

        int sourceMatchCount=verifiedSourceCompetitionMatchCount(competition);
        if(sourceMatchCount>0){
            return t2("Verified schedule connected • "+sourceMatchCount+" matches","Provjereni raspored povezan • "+sourceMatchCount+" utakmica","Verifizierter Spielplan verbunden • "+sourceMatchCount+" Spiele","Calendario verificado conectado • "+sourceMatchCount+" partidos","Calendrier vérifié connecté • "+sourceMatchCount+" matchs");
        }
        if(hasVerifiedStandings(competition)){
            return t2("Verified table available","Provjerena tablica dostupna","Verifizierte Tabelle verfügbar","Tabla verificada disponible","Classement vérifié disponible");
        }
        return t2("Connected source ready • competition data pending","Povezani izvor spreman • čekanje podataka natjecanja","Quelle bereit • Wettbewerbsdaten ausstehend","Fuente conectada • datos pendientes","Source connectée • données en attente");
    }

    void addCompetitionCard(String icon,String competitionName){
        final String cn=competitionName;
        final String rg=competitionRegion(competitionName);
        boolean followed=followedCompetitions.contains(cn);
        LinearLayout c=card();c.setPadding(dp(15),dp(13),dp(13),dp(13));
        LinearLayout row=hrow();
        View badge=competitionVisual(competitionName,dp(54));badge.setElevation(dp(3));row.addView(badge,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(5),0);
        copy.addView(label(displayCompetitionName(competitionName),19,text,true));
        copy.addView(label(rg+"  •  "+competitionParticipantLabelFast(competitionName),13,subText,false));
        copy.addView(label("● "+competitionDataStatusFast(competitionName),12,competitionStatusColor(competitionName),true));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        String followSymbol=hasProAccess()?(followed?"★":"☆"):"›";
        TextView follow=centerLabel(followSymbol,hasProAccess()?25:28,hasProAccess()&&followed?GOLD:subText,true);follow.setBackground(round(chipBg,dp(18),1));
        follow.setContentDescription(hasProAccess()?t2("Follow competition","Prati natjecanje","Wettbewerb folgen","Seguir competición","Suivre la compétition"):t2("Open competition","Otvori natjecanje","Wettbewerb öffnen","Abrir competición","Ouvrir la compétition"));
        follow.setOnClickListener(v->{
            if(!hasProAccess()){showCompetitionHub(cn,rg);return;}
            if(followedCompetitions.contains(cn))followedCompetitions.remove(cn);else followedCompetitions.add(cn);
            userPreferences.saveFollowedCompetitions(followedCompetitions);syncMatchRemindersAsync();showLeagues();
        });
        row.addView(follow,new LinearLayout.LayoutParams(dp(50),dp(50)));c.addView(row);
        TextView open=label(t2("Open competition  ›","Otvori natjecanje  ›","Wettbewerb öffnen  ›","Abrir competición  ›","Ouvrir la compétition  ›"),13,RED,true);open.setGravity(Gravity.RIGHT);c.addView(open);
        c.setClickable(true);c.setOnClickListener(v->showCompetitionHub(cn,rg));applyPressFeedback(c);
    }


    @android.annotation.SuppressLint("WrongConstant")
    void showFreeCompetitionHub(final String competitionName,final String region){
        currentCompetitionName=competitionName;currentClubOriginCompetition="";
        rememberLastDestination("competition",competitionName,displayCompetitionName(competitionName));
        ensureCompetitionDataReady(competitionName);
        clear(displayCompetitionName(competitionName),competitionIcon(competitionName)+" "+region,"CompetitionHub");
        boolean connected=competitionHasConnectedSource(competitionName);
        CompetitionSnapshot snapshot=competitionSnapshot(competitionName);
        ArrayList<Match> competitionMatches=snapshot.matches,live=snapshot.live,upcoming=snapshot.upcoming,finished=snapshot.finished;
        ArrayList<String> participantNames=competitionParticipantNames(competitionName,competitionMatches);
        String hubDataStatus=competitionDataStatusFromMatches(competitionName,competitionMatches);
        int todayCount=snapshot.todayCount;
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(58,18,91),Color.rgb(241,31,87),dp(24)));
        LinearLayout heroTop=hrow();View badge=competitionVisual(competitionName,dp(68));heroTop.addView(badge,new LinearLayout.LayoutParams(dp(68),dp(68)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(13),0,dp(8),0);copy.addView(label(t2("COMPETITION CENTER","CENTAR NATJECANJA","WETTBEWERBSZENTRALE","CENTRO DE COMPETICIÓN","CENTRE DE COMPÉTITION"),11,Color.WHITE,true));TextView freeCompetitionTitle=label(displayCompetitionName(competitionName),"Championship".equals(competitionName)?20:24,Color.WHITE,true);
        if("Championship".equals(competitionName)){freeCompetitionTitle.setMaxLines(2);freeCompetitionTitle.setEllipsize(null);if(Build.VERSION.SDK_INT>=23){freeCompetitionTitle.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);freeCompetitionTitle.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);}}
        copy.addView(freeCompetitionTitle);copy.addView(label(region+"  •  "+competitionParticipantLabel(competitionName,participantNames),13,Color.WHITE,false));heroTop.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView lock=centerLabel("🔒",18,Color.WHITE,true);lock.setBackground(round(Color.argb(45,255,255,255),dp(20),1));lock.setOnClickListener(v->showPremium(t2("Following competitions","Praćenje natjecanja","Wettbewerbe folgen","Seguimiento de competiciones","Suivi des compétitions")));heroTop.addView(lock,new LinearLayout.LayoutParams(dp(56),dp(56)));hero.addView(heroTop);
        TextView source=label("● "+hubDataStatus,12,connected?Color.rgb(166,255,220):Color.rgb(255,221,135),true);source.setPadding(dp(12),dp(7),dp(12),dp(7));source.setBackground(round(Color.argb(35,255,255,255),dp(15),0));hero.addView(source);
        hero.addView(kpiRow(t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(live.size()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(todayCount),t2("Matches","Utakmica","Spiele","Partidos","Matchs"),String.valueOf(competitionMatches.size()),true));

        LinearLayout navigation=card();navigation.addView(label("⚡ "+t2("Free access","Besplatan pristup","Kostenloser Zugang","Acceso gratuito","Accès gratuit"),20,text,true));
        LinearLayout free=hrow();Button rounds=btn("📅 "+t2("Schedule","Raspored","Spielplan","Calendario","Calendrier"));rounds.setOnClickListener(v->showCompetitionRounds(competitionName));Button results=outline("✅ "+t2("Results","Rezultati","Ergebnisse","Resultados","Résultats"));results.setOnClickListener(v->showCompetitionResults(competitionName));free.addView(rounds,new LinearLayout.LayoutParams(0,dp(56),1));LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,dp(56),1);gap.setMargins(dp(8),0,0,0);free.addView(results,gap);navigation.addView(free);
        LinearLayout pro=hrow();Button table=lockedProButton(t2("Table","Tablica","Tabelle","Tabla","Classement"),t2("League tables","Tablice liga","Ligatabellen","Tablas de liga","Classements"));Button clubs=lockedProButton(t2(isNationalCompetition(competitionName)?"Teams":"Clubs",isNationalCompetition(competitionName)?"Reprezentacije":"Klubovi",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"Selecciones":"Clubes",isNationalCompetition(competitionName)?"Équipes":"Clubs"),t2("Club and team centers","Centri klubova i reprezentacija","Klub- und Teamzentren","Centros de clubes y selecciones","Centres de clubs et équipes"));pro.addView(table,new LinearLayout.LayoutParams(0,dp(56),1));LinearLayout.LayoutParams pg=new LinearLayout.LayoutParams(0,dp(56),1);pg.setMargins(dp(8),0,0,0);pro.addView(clubs,pg);LinearLayout.LayoutParams plp=new LinearLayout.LayoutParams(-1,-2);plp.setMargins(0,dp(8),0,0);navigation.addView(pro,plp);
        if(!connected){LinearLayout unavailable=card();unavailable.addView(label("🟠 "+t2("Waiting for the verified source","Čekanje provjerenog izvora","Warten auf verifizierte Quelle","Esperando la fuente verificada","En attente de la source vérifiée"),21,text,true));unavailable.addView(label(t2("Official data has not reached this device yet. Refresh after the updater completes.","Službeni podaci još nisu stigli na ovaj uređaj. Osvježi nakon završetka updatera.","Offizielle Daten sind noch nicht angekommen. Nach dem Updater aktualisieren.","Los datos oficiales aún no han llegado. Actualiza tras completar el updater.","Les données officielles ne sont pas encore arrivées. Actualise après l’updater."),15,subText,false));return;}
        if(!live.isEmpty())addCompetitionMatchPreview(competitionName,t2("Live now","Uživo sada","Jetzt live","En vivo ahora","En direct"),"🔴",live,3);
        if(!upcoming.isEmpty())addCompetitionMatchPreview(competitionName,t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),"📅",upcoming,5);
        if(!finished.isEmpty())addCompetitionMatchPreview(competitionName,t2("Latest results","Zadnji rezultati","Letzte Ergebnisse","Últimos resultados","Derniers résultats"),"✅",finished,3);
        if(competitionMatches.isEmpty()){LinearLayout empty=card();empty.addView(label("⚽ "+t2("No published matches yet","Još nema objavljenih utakmica","Noch keine veröffentlichten Spiele","Aún no hay partidos publicados","Aucun match publié"),21,text,true));}
        addCompetitionRoundPreview(competitionName,competitionMatches);
        addProLockedCard(t2("Competition insights","Detalji natjecanja","Wettbewerbsdetails","Detalles de competición","Détails de la compétition"),t2("Pro adds verified tables, participant clubs, season overview and following.","Pro dodaje provjerene tablice, klubove sudionike, pregled sezone i praćenje.","Pro ergänzt verifizierte Tabellen, Teilnehmer, Saisonübersicht und Folgen.","Pro añade tablas verificadas, participantes, resumen de temporada y seguimiento.","Pro ajoute classements vérifiés, participants, aperçu de saison et suivi."),t2("Competition insights","Detalji natjecanja","Wettbewerbsdetails","Detalles de competición","Détails de la compétition"));
        LinearLayout trust=card();trust.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),20,text,true));trust.addView(label(lastUpdateLabel(prefs.getString("online_lastUpdate","")),13,subText,true));trust.addView(label("Football data provided by the Football-Data.org API",12,subText,true));
    }

    @android.annotation.SuppressLint("WrongConstant")
    void showCompetitionHub(final String competitionName,final String region){
        if(!hasProAccess()){showFreeCompetitionHub(competitionName,region);return;}
        ensureCompetitionDataReady(competitionName);
        currentCompetitionName=competitionName;
        currentClubOriginCompetition="";
        rememberLastDestination("competition",competitionName,displayCompetitionName(competitionName));
        clear(displayCompetitionName(competitionName),competitionIcon(competitionName)+" "+region,"CompetitionHub");
        boolean connected=competitionHasConnectedSource(competitionName);
        CompetitionSnapshot snapshot=competitionSnapshot(competitionName);
        ArrayList<Match> competitionMatches=snapshot.matches;
        ArrayList<Match> live=snapshot.live;
        ArrayList<Match> upcoming=snapshot.upcoming;
        ArrayList<Match> finished=snapshot.finished;
        ArrayList<String> participantNames=competitionParticipantNames(competitionName,competitionMatches);
        String hubDataStatus=competitionDataStatusFromMatches(competitionName,competitionMatches);
        int todayCount=snapshot.todayCount;

        LinearLayout hero=card();
        hero.setBackground(gradient(Color.rgb(58,18,91),Color.rgb(241,31,87),dp(24)));
        LinearLayout heroTop=hrow();heroTop.setGravity(Gravity.CENTER_VERTICAL);
        View badge=competitionVisual(competitionName,dp(68));
        heroTop.addView(badge,new LinearLayout.LayoutParams(dp(68),dp(68)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(13),0,dp(8),0);
        heroCopy.addView(label(t2("COMPETITION CENTER","CENTAR NATJECANJA","WETTBEWERBSZENTRALE","CENTRO DE COMPETICIÓN","CENTRE DE COMPÉTITION"),11,Color.WHITE,true));
        TextView proCompetitionTitle=label(displayCompetitionName(competitionName),"Championship".equals(competitionName)?20:24,Color.WHITE,true);
        if("Championship".equals(competitionName)){proCompetitionTitle.setMaxLines(2);proCompetitionTitle.setEllipsize(null);if(Build.VERSION.SDK_INT>=23){proCompetitionTitle.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);proCompetitionTitle.setHyphenationFrequency(android.text.Layout.HYPHENATION_FREQUENCY_NONE);}}
        heroCopy.addView(proCompetitionTitle);
        heroCopy.addView(label(region+"  •  "+competitionParticipantLabel(competitionName,participantNames),13,Color.WHITE,false));
        heroTop.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));
        boolean followed=followedCompetitions.contains(competitionName);
        TextView follow=centerLabel(followed?"★":"☆",28,followed?GOLD:Color.WHITE,true);
        follow.setContentDescription(followed?t2("Stop following","Prestani pratiti","Nicht mehr folgen","Dejar de seguir","Ne plus suivre"):t2("Follow competition","Prati natjecanje","Wettbewerb folgen","Seguir competición","Suivre la compétition"));
        follow.setBackground(round(Color.argb(45,255,255,255),dp(20),1));
        follow.setOnClickListener(v->{
            if(followedCompetitions.contains(competitionName))followedCompetitions.remove(competitionName);else followedCompetitions.add(competitionName);
            userPreferences.saveFollowedCompetitions(followedCompetitions);
            syncMatchRemindersAsync();
            showCompetitionHub(competitionName,region);
        });
        heroTop.addView(follow,new LinearLayout.LayoutParams(dp(56),dp(56)));
        hero.addView(heroTop);
        TextView sourcePill=label("● "+hubDataStatus,12,connected?Color.rgb(166,255,220):Color.rgb(255,221,135),true);
        sourcePill.setPadding(dp(12),dp(7),dp(12),dp(7));sourcePill.setBackground(round(Color.argb(35,255,255,255),dp(15),0));
        LinearLayout.LayoutParams sourceLp=new LinearLayout.LayoutParams(-2,-2);sourceLp.setMargins(0,dp(11),0,0);hero.addView(sourcePill,sourceLp);
        hero.addView(kpiRow(
                t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(live.size()),
                t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(todayCount),
                t2("Matches","Utakmica","Spiele","Partidos","Matchs"),String.valueOf(competitionMatches.size()),true));

        LinearLayout navigation=card();
        navigation.addView(label("⚡ "+t2("Quick access","Brzi pristup","Schnellzugriff","Acceso rápido","Accès rapide"),20,text,true));
        LinearLayout navRow=hrow();
        Button standings=btn("📊 "+t2("Table","Tablica","Tabelle","Tabla","Classement"));
        standings.setOnClickListener(v->showLeagueStandings(competitionName));
        Button rounds=outline("📅 "+(competitionUsesRounds(competitionName)
                ?t2("Rounds","Kola","Spieltage","Jornadas","Journées")
                :t2("Phases","Faze","Phasen","Fases","Phases")));
        rounds.setOnClickListener(v->showCompetitionRounds(competitionName));
        navRow.addView(standings,new LinearLayout.LayoutParams(0,dp(56),1));
        LinearLayout.LayoutParams navGap=new LinearLayout.LayoutParams(0,dp(56),1);navGap.setMargins(dp(8),0,0,0);navRow.addView(rounds,navGap);
        navigation.addView(navRow);
        LinearLayout navRow2=hrow();
        Button results=outline("✅ "+t2("Results","Rezultati","Ergebnisse","Resultados","Résultats"));
        results.setOnClickListener(v->showCompetitionResults(competitionName));
        Button clubs=outline((isNationalCompetition(competitionName)?"🌍 ":"🛡️ ")+t2(isNationalCompetition(competitionName)?"Teams":"Clubs",isNationalCompetition(competitionName)?"Reprezentacije":"Klubovi",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"Selecciones":"Clubes",isNationalCompetition(competitionName)?"Équipes":"Clubs"));
        clubs.setOnClickListener(v->showCompetitionParticipants(competitionName));
        navRow2.addView(results,new LinearLayout.LayoutParams(0,dp(56),1));
        LinearLayout.LayoutParams navGap2=new LinearLayout.LayoutParams(0,dp(56),1);navGap2.setMargins(dp(8),0,0,0);navRow2.addView(clubs,navGap2);
        LinearLayout.LayoutParams row2lp=new LinearLayout.LayoutParams(-1,-2);row2lp.setMargins(0,dp(8),0,0);navigation.addView(navRow2,row2lp);
        if(competitionName.equals("World Cup 2026")){
            Button groups=outline("🌍 "+t2("World Cup groups","Skupine Svjetskog prvenstva","WM-Gruppen","Grupos del Mundial","Groupes de la Coupe du monde"));
            groups.setOnClickListener(v->showGroups());navigation.addView(groups);
        }

        if(!connected){
            LinearLayout unavailable=card();
            unavailable.addView(label("🟠 "+t2("Waiting for the verified source","Čekanje provjerenog izvora","Warten auf verifizierte Quelle","Esperando la fuente verificada","En attente de la source vérifiée"),21,text,true));
            unavailable.addView(label(t2(
                    "Official data has not reached this device yet. Run the updater and refresh the app; Football Fun will not invent fixtures or standings.",
                    "Službeni podaci još nisu stigli na ovaj uređaj. Pokreni updater i osvježi aplikaciju; Football Fun neće izmišljati utakmice ni tablicu.",
                    "Offizielle Daten sind noch nicht auf diesem Gerät angekommen. Updater ausführen und App aktualisieren; Football Fun erfindet keine Spiele oder Tabellen.",
                    "Los datos oficiales aún no han llegado al dispositivo. Ejecuta el updater y actualiza la app; Football Fun no inventará partidos ni clasificaciones.",
                    "Les données officielles ne sont pas encore arrivées sur cet appareil. Lance l’updater puis actualise l’application; Football Fun n’inventera aucun match ni classement."),15,subText,false));
            return;
        }

        addCompetitionSeasonOverview(competitionName,snapshot);
        if(!live.isEmpty())addCompetitionMatchPreview(competitionName,t2("Live now","Uživo sada","Jetzt live","En vivo ahora","En direct"),"🔴",live,3);
        if(!upcoming.isEmpty())addCompetitionMatchPreview(competitionName,t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),"📅",upcoming,5);
        if(!finished.isEmpty())addCompetitionMatchPreview(competitionName,t2("Latest results","Zadnji rezultati","Letzte Ergebnisse","Últimos resultados","Derniers résultats"),"✅",finished,3);

        if(competitionMatches.isEmpty()){
            LinearLayout empty=card();
            empty.addView(label("⚽ "+t2("No published matches yet","Još nema objavljenih utakmica","Noch keine veröffentlichten Spiele","Aún no hay partidos publicados","Aucun match publié"),21,text,true));
            empty.addView(label(t2("The center will populate automatically after the connected source publishes fixtures.","Centar će se automatski popuniti kada povezani izvor objavi raspored.","Das Zentrum füllt sich automatisch, sobald die Quelle Spielpläne veröffentlicht.","El centro se completará automáticamente cuando la fuente publique el calendario.","Le centre se remplira automatiquement lorsque la source publiera le calendrier."),15,subText,false));
        }

        addCompetitionStandingsPreview(competitionName,snapshot,participantNames);
        addCompetitionRoundPreview(competitionName,competitionMatches);
        addCompetitionParticipantsPreview(competitionName,participantNames);

        LinearLayout trust=card();
        trust.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),20,text,true));
        trust.addView(label(lastUpdateLabel(prefs.getString("online_lastUpdate","")),13,subText,true));
        if("Brasileirão Série A".equals(competitionName)){
            trust.addView(label(t2(
                    "Schedule and standings come from verified competition data. A match is shown as Final only when its exact score is verified; otherwise historical fixtures stay marked No result. Unconfirmed kick-off times are marked Time TBA.",
                    "Raspored i tablica dolaze iz provjerenih podataka natjecanja. Utakmica se prikazuje kao Kraj samo kada je točan rezultat potvrđen; povijesne utakmice bez potvrđenog rezultata ostaju označene Bez rezultata. Nepotvrđene satnice označene su kao Naknadno.",
                    "Spielplan und Tabelle stammen aus verifizierten Wettbewerbsdaten. Ein Spiel wird nur bei verifiziertem exaktem Ergebnis als Ende angezeigt; historische Spiele ohne bestätigtes Ergebnis bleiben als Ohne Ergebnis markiert. Unbestätigte Anstoßzeiten werden als Offen markiert.",
                    "El calendario y la clasificación proceden de datos verificados de la competición. Un partido solo se muestra como Final cuando el marcador exacto está verificado; los partidos históricos sin marcador confirmado quedan como Sin resultado. Las horas no confirmadas se marcan como Pendiente.",
                    "Le calendrier et le classement proviennent de données vérifiées de la compétition. Un match n’est affiché comme Terminé que lorsque son score exact est vérifié ; les anciens matchs sans score confirmé restent indiqués Sans résultat. Les horaires non confirmés sont indiqués À confirmer."),13,subText,false));
        }else{
            trust.addView(label(t2("Fixtures, results and standings are shown exactly as published by the connected source. Unconfirmed kick-off times are marked as Time TBA.","Raspored, rezultati i tablica prikazuju se točno kako ih objavi povezani izvor. Nepotvrđene satnice označene su kao Naknadno.","Spielpläne, Ergebnisse und Tabellen werden wie von der Quelle veröffentlicht angezeigt. Unbestätigte Anstoßzeiten werden als Offen markiert.","Calendario, resultados y clasificación se muestran tal como los publica la fuente. Las horas no confirmadas se marcan como Pendiente.","Calendrier, résultats et classement sont affichés tels que publiés par la source. Les horaires non confirmés sont indiqués À confirmer."),13,subText,false));
        }
    }

    int competitionParticipantCount(String competitionName){
        return competitionParticipantCount(competitionName,competitionParticipantNames(competitionName));
    }

    int competitionParticipantCount(String competitionName,List<String> publishedNames){
        int published=publishedNames==null?0:publishedNames.size();
        return published>0?published:CompetitionCatalog.get(competitionName).teamCount;
    }

    String participantCountLabel(int count,boolean national){
        if(!"HR".equals(lang)){
            return count+" "+t2(national?"teams":"clubs",national?"reprezentacija":"klubova",national?"Teams":"Klubs",national?"selecciones":"clubes",national?"équipes":"clubs");
        }
        int lastTwo=count%100,last=count%10;
        String noun;
        if(national){
            noun=(lastTwo>=11&&lastTwo<=14)?"reprezentacija":(last==1?"reprezentacija":((last>=2&&last<=4)?"reprezentacije":"reprezentacija"));
        }else{
            noun=(lastTwo>=11&&lastTwo<=14)?"klubova":(last==1?"klub":((last>=2&&last<=4)?"kluba":"klubova"));
        }
        return count+" "+noun;
    }

    String competitionParticipantShortLabel(String competitionName){
        return participantCountLabel(competitionParticipantCount(competitionName),isNationalCompetition(competitionName));
    }

    String competitionParticipantLabel(String competitionName){
        String count=competitionParticipantShortLabel(competitionName);
        if("UEFA Champions League".equals(competitionName)){
            return t2(count+" in the published schedule",count+" u objavljenom rasporedu",count+" im veröffentlichten Spielplan",count+" en el calendario publicado",count+" dans le calendrier publié");
        }
        return count;
    }

    String competitionParticipantLabel(String competitionName,List<String> publishedNames){
        String count=participantCountLabel(competitionParticipantCount(competitionName,publishedNames),isNationalCompetition(competitionName));
        if("UEFA Champions League".equals(competitionName)){
            return t2(count+" in the published schedule",count+" u objavljenom rasporedu",count+" im veröffentlichten Spielplan",count+" en el calendario publicado",count+" dans le calendrier publié");
        }
        return count;
    }

    int competitionCurrentMatchday(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry!=null){
            JSONObject season=entry.optJSONObject("season");
            int current=season==null?0:season.optInt("currentMatchday",0);
            if(current>0)return current;
        }
        if(!competitionUsesRounds(competitionName))return 0;
        ArrayList<Match> matches=matchesForCompetition(competitionName);
        int lastFinished=0;
        for(Match match:matches){
            if(match==null||match.matchday<=0)continue;
            if(matchIsUpcoming(match)||matchIsLive(match))return match.matchday;
            if(matchIsFinished(match))lastFinished=Math.max(lastFinished,match.matchday);
        }
        return lastFinished;
    }

    String competitionSeasonLabel(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry!=null){
            JSONObject season=entry.optJSONObject("season");
            if(season!=null){
                String start=season.optString("startDate","");String end=season.optString("endDate","");
                if(start.length()>=4&&end.length()>=4){
                    String a=start.substring(0,4),b=end.substring(0,4);
                    return a.equals(b)?a:a+"/"+b.substring(2);
                }
            }
        }
        int firstYear=Integer.MAX_VALUE,lastYear=0;
        for(Match match:matchesForCompetition(competitionName)){
            if(match==null||match.date==null||match.date.length()<4)continue;
            try{int year=Integer.parseInt(match.date.substring(0,4));firstYear=Math.min(firstYear,year);lastYear=Math.max(lastYear,year);}catch(Exception ignored){}
        }
        if(lastYear>0&&firstYear<Integer.MAX_VALUE){
            return firstYear==lastYear?String.valueOf(firstYear):firstYear+"/"+String.valueOf(lastYear).substring(2);
        }
        if("Brasileirão Série A".equals(competitionName))return "2026";
        if("La Liga".equals(competitionName)||"Bundesliga".equals(competitionName)||"Serie A".equals(competitionName)||"Ligue 1".equals(competitionName)||"Eredivisie".equals(competitionName)||"Primeira Liga".equals(competitionName))return "2026/27";
        return t2("Current season","Aktualna sezona","Aktuelle Saison","Temporada actual","Saison actuelle");
    }

    String competitionSeasonLabel(String competitionName,List<Match> knownMatches){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry!=null){
            JSONObject season=entry.optJSONObject("season");
            if(season!=null){
                String start=season.optString("startDate","");String end=season.optString("endDate","");
                if(start.length()>=4&&end.length()>=4){
                    String a=start.substring(0,4),b=end.substring(0,4);
                    return a.equals(b)?a:a+"/"+b.substring(2);
                }
            }
        }
        int firstYear=Integer.MAX_VALUE,lastYear=0;
        List<Match> source=knownMatches==null?matchesForCompetition(competitionName):knownMatches;
        for(Match match:source){
            if(match==null||match.date==null||match.date.length()<4)continue;
            try{int year=Integer.parseInt(match.date.substring(0,4));firstYear=Math.min(firstYear,year);lastYear=Math.max(lastYear,year);}catch(Exception ignored){}
        }
        if(lastYear>0&&firstYear<Integer.MAX_VALUE){
            return firstYear==lastYear?String.valueOf(firstYear):firstYear+"/"+String.valueOf(lastYear).substring(2);
        }
        if("Brasileirão Série A".equals(competitionName))return "2026";
        if("La Liga".equals(competitionName)||"Bundesliga".equals(competitionName)||"Serie A".equals(competitionName)||"Ligue 1".equals(competitionName)||"Eredivisie".equals(competitionName)||"Primeira Liga".equals(competitionName))return "2026/27";
        return t2("Current season","Aktualna sezona","Aktuelle Saison","Temporada actual","Saison actuelle");
    }

    void addCompetitionSeasonOverview(String competitionName,CompetitionSnapshot snapshot){
        LinearLayout season=card();
        LinearLayout head=hrow();
        head.addView(label("📈 "+t2("Season overview","Pregled sezone","Saisonübersicht","Resumen de temporada","Aperçu de la saison"),21,text,true),new LinearLayout.LayoutParams(0,-2,1));
        head.addView(label(competitionSeasonLabel(competitionName,snapshot==null?null:snapshot.matches),13,RED,true));season.addView(head);
        int total=snapshot==null?0:snapshot.totalMatches;
        int displayedFinished=snapshot==null?0:snapshot.playedMatches;
        int progress=snapshot==null?0:snapshot.progressPercent;
        LinearLayout numbers=hrow();
        numbers.addView(homeStat(String.valueOf(displayedFinished),t2("Played","Odigrano","Gespielt","Jugados","Joués"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        int matchday=snapshot==null?0:snapshot.currentMatchday;
        boolean phaseBased=!competitionUsesRounds(competitionName);
        String periodCaption=phaseBased
                ?t2("Phase","Faza","Phase","Fase","Phase")
                :t2("Matchday","Kolo","Spieltag","Jornada","Journée");
        numbers.addView(homeStat(matchday>0?String.valueOf(matchday):"—",periodCaption,null),middle);
        numbers.addView(homeStat(String.valueOf(total),t2("Matches","Utakmica","Spiele","Partidos","Matchs"),null),new LinearLayout.LayoutParams(0,-2,1));
        season.addView(numbers);
        LinearLayout progressTrack=new LinearLayout(this);progressTrack.setOrientation(LinearLayout.HORIZONTAL);progressTrack.setBackground(round(chipBg,dp(7),0));
        View fill=new View(this);fill.setBackground(gradient(PURPLE_DARK,RED,dp(7)));progressTrack.addView(fill,new LinearLayout.LayoutParams(0,dp(10),progress));
        View rest=new View(this);progressTrack.addView(rest,new LinearLayout.LayoutParams(0,dp(10),Math.max(1,100-progress)));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(10));pp.setMargins(0,dp(12),0,dp(7));season.addView(progressTrack,pp);
        season.addView(label(progress+"%  "+t2("of published fixtures completed","objavljenog rasporeda završeno","der veröffentlichten Spiele abgeschlossen","del calendario publicado completado","du calendrier publié terminé"),12,subText,true));
        if(snapshot!=null&&snapshot.playedCountFromStandings&&snapshot.playedMatches>snapshot.detailedResultCount){
            String coverage=t2(
                    "Played count confirmed by verified standings • detailed scores: ",
                    "Broj odigranih potvrđen provjerenom tablicom • detaljni rezultati: ",
                    "Gespielte Spiele durch verifizierte Tabelle bestätigt • Detailergebnisse: ",
                    "Partidos jugados confirmados por la tabla verificada • resultados detallados: ",
                    "Matchs joués confirmés par le classement vérifié • résultats détaillés : ")
                    +snapshot.detailedResultCount;
            TextView coverageView=label("🛡️ "+coverage,11,GREEN,true);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(8),0,0);season.addView(coverageView,cp);
        }
    }

    String competitionRoundKey(Match match){
        if(match==null)return "";
        if(match.matchday>0)return t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+match.matchday;
        if(match.roundName!=null&&match.roundName.trim().length()>0)return match.roundName.trim();
        String stage=stageLabel(match);
        if(stage!=null&&stage.trim().length()>0)return stage.trim();
        if(match.group!=null&&match.group.trim().length()>0)return t2("Group ","Skupina ","Gruppe ","Grupo ","Groupe ")+match.group.trim();
        return t2("Published fixtures","Objavljeni raspored","Veröffentlichte Spiele","Calendario publicado","Calendrier publié");
    }

    String qualifierRoundBase(String value){
        if(value==null)return "";
        String folded=Normalizer.normalize(value.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","");
        if(folded.contains("play-off")||folded.contains("playoff")||folded.contains("play off"))return "Play-off";
        if(folded.contains("3. pretkolo")||folded.contains("third qualifying")||folded.contains("3rd qualifying")||folded.contains("qualifying round 3"))return "3. pretkolo";
        if(folded.contains("2. pretkolo")||folded.contains("second qualifying")||folded.contains("2nd qualifying")||folded.contains("qualifying round 2"))return "2. pretkolo";
        if(folded.contains("1. pretkolo")||folded.contains("first qualifying")||folded.contains("1st qualifying")||folded.contains("qualifying round 1"))return "1. pretkolo";
        return "";
    }

    String qualifierLegLabel(String value){
        if(value==null)return "";
        String folded=Normalizer.normalize(value.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","");
        if(folded.contains("uzvrat")||folded.contains("second leg")||folded.contains("2nd leg")||folded.contains("leg 2")||folded.contains("ruckspiel")||folded.contains("vuelta")||folded.contains("retour"))return "Uzvrat";
        if(folded.contains("prva utakmica")||folded.contains("first leg")||folded.contains("1st leg")||folded.contains("leg 1")||folded.contains("hinspiel")||folded.contains("ida")||folded.contains("aller"))return "Prva utakmica";
        return "";
    }

    String qualifierTieKey(Match match){
        if(match==null)return "";
        String homeKey=duplicateTeamKey(match.home),awayKey=duplicateTeamKey(match.away);
        if(homeKey.length()==0||awayKey.length()==0)return "";
        return homeKey.compareTo(awayKey)<=0?homeKey+"|"+awayKey:awayKey+"|"+homeKey;
    }

    void normalizeCompetitionQualifierLegs(String competitionName,ArrayList<Match> matches){
        if(!"UEFA Champions League".equals(competitionName)||matches==null||matches.size()<2)return;
        LinkedHashMap<String,ArrayList<Match>> ties=new LinkedHashMap<String,ArrayList<Match>>();
        for(Match match:matches){
            String raw=match.roundName==null?"":match.roundName.trim();
            if(raw.length()==0)raw=stageLabel(match);
            String base=qualifierRoundBase(raw);
            String tie=qualifierTieKey(match);
            if(base.length()==0||tie.length()==0)continue;
            String key=base+"|"+tie;
            ArrayList<Match> list=ties.get(key);
            if(list==null){list=new ArrayList<Match>();ties.put(key,list);}
            list.add(match);
        }
        for(Map.Entry<String,ArrayList<Match>> entry:ties.entrySet()){
            ArrayList<Match> list=entry.getValue();
            if(list.size()<2)continue;
            Collections.sort(list,(a,b)->{
                Date da=localMatchDate(a),db=localMatchDate(b);
                if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
            });
            Match first=list.get(0),last=list.get(list.size()-1);
            Date firstDate=localMatchDate(first),lastDate=localMatchDate(last);
            if(firstDate==null||lastDate==null||localDateKey(first).equals(localDateKey(last)))continue;
            String base=entry.getKey().substring(0,entry.getKey().indexOf('|'));
            first.roundName=base+" • Prva utakmica";
            last.roundName=base+" • Uzvrat";
            for(int i=1;i<list.size()-1;i++){
                Match middle=list.get(i);
                String existing=qualifierLegLabel(middle.roundName);
                middle.roundName=base+(existing.length()>0?" • "+existing:"");
            }
        }
    }

    LinkedHashMap<String,ArrayList<Match>> competitionMatchesByRound(String competitionName,boolean finishedOnly){
        ArrayList<Match> source=matchesForCompetition(competitionName);
        return competitionMatchesByRound(competitionName,source,finishedOnly);
    }

    LinkedHashMap<String,ArrayList<Match>> competitionMatchesByRound(String competitionName,List<Match> source,boolean finishedOnly){
        LinkedHashMap<String,ArrayList<Match>> grouped=new LinkedHashMap<String,ArrayList<Match>>();
        if(source==null)return grouped;
        for(Match match:source){
            if(finishedOnly&&!matchIsFinished(match))continue;
            String key=competitionRoundKey(match);
            ArrayList<Match> list=grouped.get(key);
            if(list==null){list=new ArrayList<Match>();grouped.put(key,list);}
            list.add(match);
        }
        return grouped;
    }

    String publishedPeriodCountLabel(String competitionName,int count){
        boolean rounds=competitionUsesRounds(competitionName);
        if("HR".equals(lang)){
            int lastTwo=count%100,last=count%10;
            String noun;
            if(rounds) noun=(lastTwo>=11&&lastTwo<=14)?"objavljenih kola":(last==1?"objavljeno kolo":((last>=2&&last<=4)?"objavljena kola":"objavljenih kola"));
            else noun=(lastTwo>=11&&lastTwo<=14)?"objavljenih faza":(last==1?"objavljena faza":((last>=2&&last<=4)?"objavljene faze":"objavljenih faza"));
            return count+" "+noun;
        }
        return count+" "+(rounds
                ?t2("published rounds","objavljena kola","veröffentlichte Spieltage","jornadas publicadas","journées publiées")
                :t2("published phases","objavljene faze","veröffentlichte Phasen","fases publicadas","phases publiées"));
    }

    String competitionScheduleTitle(String competitionName){
        return competitionUsesRounds(competitionName)
                ?t2("Schedule by round","Raspored po kolima","Spielplan nach Spieltagen","Calendario por jornadas","Calendrier par journées")
                :t2("Schedule by phase","Raspored po fazama","Spielplan nach Phasen","Calendario por fases","Calendrier par phases");
    }

    String competitionScheduleEmptyText(String competitionName){
        return competitionUsesRounds(competitionName)
                ?t2("No verified round schedule is available yet.","Još nema dostupnog provjerenog rasporeda po kolima.","Noch kein verifizierter Spielplan nach Spieltagen verfügbar.","Aún no hay un calendario verificado por jornadas.","Aucun calendrier vérifié par journées n’est encore disponible.")
                :t2("No verified phase schedule is available yet.","Još nema dostupnog provjerenog rasporeda po fazama.","Noch kein verifizierter Phasen-Spielplan verfügbar.","Aún no hay un calendario por fases verificado.","Aucun calendrier vérifié par phases n’est encore disponible.");
    }

    void addCompetitionRoundPreview(final String competitionName,ArrayList<Match> matches){
        LinearLayout preview=card();
        preview.addView(label("📅 "+competitionScheduleTitle(competitionName),22,text,true));
        LinkedHashMap<String,ArrayList<Match>> rounds=competitionMatchesByRound(competitionName,matches,false);
        if(rounds.isEmpty())preview.addView(label(competitionScheduleEmptyText(competitionName),14,subText,false));
        else{
            int shown=0;
            for(Map.Entry<String,ArrayList<Match>> entry:rounds.entrySet()){
                TextView row=label(entry.getKey()+"  •  "+entry.getValue().size()+" "+t2("matches","utakmica","Spiele","partidos","matchs")+"   ›",15,text,true);
                row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(round(chipBg,dp(15),1));
                row.setOnClickListener(v->showCompetitionRounds(competitionName));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));preview.addView(row,lp);
                if(++shown>=3)break;
            }
        }
        String allText=competitionUsesRounds(competitionName)
                ?t2("Open full schedule by rounds","Otvori cijeli raspored po kolima","Vollständigen Spielplan nach Spieltagen öffnen","Abrir calendario completo por jornadas","Ouvrir le calendrier complet par journées")
                :t2("Open full schedule by phases","Otvori cijeli raspored po fazama","Vollständigen Phasen-Spielplan öffnen","Abrir calendario completo por fases","Ouvrir le calendrier complet par phases");
        Button all=outline(allText);
        all.setOnClickListener(v->showCompetitionRounds(competitionName));preview.addView(all);
    }

    void showCompetitionRounds(final String competitionName){
        currentCompetitionName=competitionName;
        ensureCompetitionDataReady(competitionName);
        CompetitionSnapshot snapshot=competitionSnapshot(competitionName);
        clear(displayCompetitionName(competitionName),competitionScheduleTitle(competitionName),"CompetitionRounds");
        LinkedHashMap<String,ArrayList<Match>> rounds=snapshot.rounds;
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));
        hero.addView(label("📅 "+displayCompetitionName(competitionName),24,Color.WHITE,true));
        hero.addView(label(publishedPeriodCountLabel(competitionName,rounds.size()),14,Color.WHITE,false));
        if(rounds.isEmpty()){
            LinearLayout empty=card();
            String emptyText=competitionUsesRounds(competitionName)
                    ?t2("The verified source has not published round information yet.","Provjereni izvor još nije objavio podatke o kolima.","Die verifizierte Quelle hat noch keine Spieltagsdaten veröffentlicht.","La fuente verificada aún no ha publicado las jornadas.","La source vérifiée n’a pas encore publié les journées.")
                    :t2("The verified source has not published phase information yet.","Provjereni izvor još nije objavio podatke o fazama.","Die verifizierte Quelle hat noch keine Phasendaten veröffentlicht.","La fuente verificada aún no ha publicado las fases.","La source vérifiée n’a pas encore publié les phases.");
            empty.addView(label(emptyText,15,subText,false));return;
        }
        for(Map.Entry<String,ArrayList<Match>> entry:rounds.entrySet()){
            LinearLayout section=card();
            LinearLayout head=hrow();head.addView(label(entry.getKey(),20,text,true),new LinearLayout.LayoutParams(0,-2,1));head.addView(label(String.valueOf(entry.getValue().size()),13,RED,true));section.addView(head);
            for(Match match:entry.getValue()){
                if(matchIsUpcoming(match))addDynamicHomeMatch(section,match,true,false,true);
                else addDynamicHomeMatch(section,match,true,true,false);
            }
        }
    }

    void showCompetitionResults(final String competitionName){
        currentCompetitionName=competitionName;
        ensureCompetitionDataReady(competitionName);
        CompetitionSnapshot snapshot=competitionSnapshot(competitionName);
        clear(displayCompetitionName(competitionName),t2("Results","Rezultati","Ergebnisse","Resultados","Résultats"),"CompetitionResults");
        ArrayList<Match> finished=new ArrayList<Match>(snapshot.finished);
        ArrayList<Match> chronologicalFinished=new ArrayList<Match>(finished);
        Collections.reverse(chronologicalFinished);
        LinkedHashMap<String,ArrayList<Match>> rounds=competitionMatchesByRound(competitionName,chronologicalFinished,false);
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));
        int count=finished.size();
        boolean seasonNotStarted=count==0&&!snapshot.rounds.isEmpty();
        hero.addView(label("✅ "+displayCompetitionName(competitionName),24,Color.WHITE,true));
        hero.addView(label(seasonNotStarted
                ?t2("Season ","Sezona ","Saison ","Temporada ","Saison ")+competitionSeasonLabel(competitionName)+t2(" has not started yet"," još nije započela"," hat noch nicht begonnen"," aún no ha comenzado"," n’a pas encore commencé")
                :count+" "+t2(
                        snapshot.playedCountFromStandings&&snapshot.playedMatches>count?"detailed verified results":"verified results",
                        snapshot.playedCountFromStandings&&snapshot.playedMatches>count?"detaljnih provjerenih rezultata":"provjerenih rezultata",
                        snapshot.playedCountFromStandings&&snapshot.playedMatches>count?"detaillierte verifizierte Ergebnisse":"verifizierte Ergebnisse",
                        snapshot.playedCountFromStandings&&snapshot.playedMatches>count?"resultados verificados detallados":"resultados verificados",
                        snapshot.playedCountFromStandings&&snapshot.playedMatches>count?"résultats vérifiés détaillés":"résultats vérifiés"),14,Color.WHITE,false));
        if(!seasonNotStarted&&snapshot.playedCountFromStandings&&snapshot.playedMatches>count){
            hero.addView(label(t2(
                    "Verified standings confirm ",
                    "Provjerena tablica potvrđuje ",
                    "Die verifizierte Tabelle bestätigt ",
                    "La tabla verificada confirma ",
                    "Le classement vérifié confirme ")
                    +snapshot.playedMatches+t2(
                    " played matches; exact scores are shown only where a verified score is available.",
                    " odigranih utakmica; točan rezultat prikazuje se samo ondje gdje je provjeren.",
                    " gespielte Spiele; exakte Ergebnisse werden nur angezeigt, wenn sie verifiziert vorliegen.",
                    " partidos jugados; el marcador exacto se muestra solo cuando está verificado.",
                    " matchs joués ; le score exact n’est affiché que lorsqu’il est vérifié."),12,Color.WHITE,false));
        }
        if(rounds.isEmpty()){
            LinearLayout empty=card();
            if(seasonNotStarted){
                empty.addView(label("⏳ "+t2("The season has not started yet","Sezona još nije započela","Die Saison hat noch nicht begonnen","La temporada aún no ha comenzado","La saison n’a pas encore commencé"),22,text,true));
                empty.addView(label(t2(
                        "The first results will appear automatically after the first official matches are completed.",
                        "Prvi rezultati prikazat će se automatski nakon završetka prvih službenih utakmica.",
                        "Die ersten Ergebnisse erscheinen automatisch nach Abschluss der ersten offiziellen Spiele.",
                        "Los primeros resultados aparecerán automáticamente al finalizar los primeros partidos oficiales.",
                        "Les premiers résultats apparaîtront automatiquement après les premiers matchs officiels."),15,subText,false));
                empty.addView(label("🛡️ "+t2(
                        "Football Fun shows only verified results.",
                        "Football Fun prikazuje isključivo provjerene rezultate.",
                        "Football Fun zeigt ausschließlich verifizierte Ergebnisse.",
                        "Football Fun muestra únicamente resultados verificados.",
                        "Football Fun affiche uniquement des résultats vérifiés."),13,GREEN,true));
            }else{
                empty.addView(label(t2("No verified results are available yet.","Još nema dostupnih provjerenih rezultata.","Noch keine verifizierten Ergebnisse verfügbar.","Aún no hay resultados verificados.","Aucun résultat vérifié n’est disponible."),15,subText,false));
            }
            return;
        }
        ArrayList<Map.Entry<String,ArrayList<Match>>> entries=new ArrayList<Map.Entry<String,ArrayList<Match>>>(rounds.entrySet());
        Collections.reverse(entries);
        for(Map.Entry<String,ArrayList<Match>> entry:entries){
            LinearLayout section=card();section.addView(label(entry.getKey(),20,text,true));
            ArrayList<Match> list=new ArrayList<Match>(entry.getValue());Collections.reverse(list);
            for(Match match:list)addDynamicHomeMatch(section,match,true,true);
        }
    }

    void addCompetitionTopClubsPreview(final String competitionName){
        LinearLayout preview=card();
        preview.addView(label("🏆 "+t2(isNationalCompetition(competitionName)?"Best teams":"Best clubs",isNationalCompetition(competitionName)?"Najbolje reprezentacije":"Najbolji klubovi",isNationalCompetition(competitionName)?"Beste Teams":"Beste Klubs",isNationalCompetition(competitionName)?"Mejores selecciones":"Mejores clubes",isNationalCompetition(competitionName)?"Meilleures équipes":"Meilleurs clubs"),22,text,true));
        JSONArray table=verifiedTotalStandingTable(competitionName);
        if(table==null||table.length()==0)preview.addView(label(t2("Top clubs will appear when the verified table is available.","Najbolji klubovi prikazat će se kada bude dostupna provjerena tablica.","Die besten Klubs erscheinen, sobald die verifizierte Tabelle verfügbar ist.","Los mejores clubes aparecerán cuando esté disponible la tabla verificada.","Les meilleurs clubs apparaîtront lorsque le classement vérifié sera disponible."),14,subText,false));
        else for(int i=0;i<Math.min(3,table.length());i++){JSONObject row=table.optJSONObject(i);if(row!=null)preview.addView(verifiedStandingRow(row));}
        Button all=outline(t2("Open best clubs","Otvori najbolje klubove","Beste Klubs öffnen","Abrir mejores clubes","Ouvrir les meilleurs clubs"));all.setOnClickListener(v->showCompetitionTopClubs(competitionName));preview.addView(all);
    }

    void showCompetitionTopClubs(final String competitionName){
        clear(displayCompetitionName(competitionName),t2(isNationalCompetition(competitionName)?"Best teams":"Best clubs",isNationalCompetition(competitionName)?"Najbolje reprezentacije":"Najbolji klubovi",isNationalCompetition(competitionName)?"Beste Teams":"Beste Klubs",isNationalCompetition(competitionName)?"Mejores selecciones":"Mejores clubes",isNationalCompetition(competitionName)?"Meilleures équipes":"Meilleurs clubs"),"Leagues");
        JSONArray table=verifiedTotalStandingTable(competitionName);
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,20,91),Color.rgb(225,29,88),dp(24)));hero.addView(label("🏆 "+displayCompetitionName(competitionName),24,Color.WHITE,true));hero.addView(label(t2("Ranking based only on the verified competition table.","Poredak se temelji isključivo na provjerenoj tablici natjecanja.","Rangliste nur auf Basis der verifizierten Tabelle.","Clasificación basada solo en la tabla verificada.","Classement fondé uniquement sur le tableau vérifié."),14,Color.WHITE,false));
        if(table==null||table.length()==0){LinearLayout empty=card();empty.addView(label(t2("The verified table is not available yet.","Provjerena tablica još nije dostupna.","Die verifizierte Tabelle ist noch nicht verfügbar.","La tabla verificada aún no está disponible.","Le classement vérifié n’est pas encore disponible."),15,subText,false));return;}
        LinearLayout podium=card();podium.addView(verifiedStandingHeader());for(int i=0;i<table.length();i++){JSONObject row=table.optJSONObject(i);if(row!=null)podium.addView(verifiedStandingRow(row));}
    }

    boolean competitionUsesStrictCurrentRoster(String competitionName){
        return "HNL".equals(competitionName)
                ||"Premier League".equals(competitionName)
                ||"Championship".equals(competitionName)
                ||"La Liga".equals(competitionName)
                ||"Bundesliga".equals(competitionName)
                ||"Serie A".equals(competitionName)
                ||"Ligue 1".equals(competitionName)
                ||"Eredivisie".equals(competitionName)
                ||"Primeira Liga".equals(competitionName)
                ||"Brasileirão Série A".equals(competitionName);
    }

    boolean competitionHasUniqueHomeAwayPairPerSeason(String competitionName){
        return competitionUsesStrictCurrentRoster(competitionName)&&!"HNL".equals(competitionName);
    }

    ArrayList<String> strictCompetitionRoster(String competitionName){
        ArrayList<String> names=new ArrayList<String>();
        if(!competitionUsesStrictCurrentRoster(competitionName))return names;
        for(ClubProfile profile:ClubIdentityRegistry.all()){
            if(profile!=null&&competitionName.equals(profile.competition)
                    &&profile.name!=null&&!profile.name.trim().isEmpty()){
                names.add(profile.name.trim());
            }
        }
        Collections.sort(names,(a,b)->displayTeamName(a).compareToIgnoreCase(displayTeamName(b)));
        return names;
    }

    boolean teamBelongsToStrictCompetitionRoster(String competitionName,String team){
        if(!competitionUsesStrictCurrentRoster(competitionName))return true;
        if(team==null||team.trim().isEmpty())return false;
        ClubProfile resolved=ClubIdentityRegistry.resolve(team);
        if(resolved!=null&&competitionName.equals(resolved.competition))return true;
        for(String club:strictCompetitionRoster(competitionName)){
            if(sameTeam(club,team))return true;
        }
        return false;
    }

    void canonicalizeStrictCompetitionMatchTeams(String competitionName,Match match){
        if(match==null||!competitionUsesStrictCurrentRoster(competitionName))return;
        ClubProfile home=ClubIdentityRegistry.resolve(match.home);
        ClubProfile away=ClubIdentityRegistry.resolve(match.away);
        if(home!=null&&competitionName.equals(home.competition))match.home=home.name;
        if(away!=null&&competitionName.equals(away.competition))match.away=away.name;
    }

    String competitionNameForCanonicalKey(String canonical){
        if(canonical==null||canonical.trim().isEmpty())return "";
        String key=canonical.trim();
        for(String competitionName:CompetitionCatalog.all().keySet()){
            String code=competitionApiCode(competitionName);
            if(code!=null&&!code.trim().isEmpty()&&key.equalsIgnoreCase(code.trim()))return competitionName;
            if(key.equalsIgnoreCase(competitionName))return competitionName;
            String normalized=Normalizer.normalize(competitionName.toLowerCase(Locale.US),Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]+","");
            if(key.equalsIgnoreCase(normalized))return competitionName;
        }
        return "";
    }

    boolean sourceDateIsInActiveCompetitionSeason(JSONObject source,String competitionName){
        if(source==null||competitionName==null||competitionName.isEmpty())return false;
        String day=sourceDateKey(source);
        if(day.length()<10)return false;
        try{
            int year=Integer.parseInt(day.substring(0,4));
            int month=Integer.parseInt(day.substring(5,7));
            int startYear=activeCompetitionSeasonStartYear(competitionName);
            if("Brasileirão Série A".equals(competitionName))return year==startYear;
            if(year==startYear)return month>=7;
            if(year==startYear+1)return month<=6;
            return false;
        }catch(Exception ignored){return false;}
    }

    ArrayList<Match> dedupeStrictDomesticFixtures(String competitionName,List<Match> source){
        if(!competitionHasUniqueHomeAwayPairPerSeason(competitionName))return dedupeCompetitionMatchList(source);
        ArrayList<Match> unique=new ArrayList<Match>();
        LinkedHashMap<String,Integer> positions=new LinkedHashMap<String,Integer>();
        if(source==null)return unique;
        for(Match candidate:source){
            if(candidate==null)continue;
            String homeKey=teamKey(candidate.home),awayKey=teamKey(candidate.away);
            if(homeKey.isEmpty()||awayKey.isEmpty())continue;
            String key=homeKey+">"+awayKey+"|"+duplicateCompetitionKey(candidate);
            Integer position=positions.get(key);
            if(position==null){
                positions.put(key,unique.size());
                unique.add(candidate);
                continue;
            }
            Match current=unique.get(position);
            Match preferred=matchDataRichness(candidate)>matchDataRichness(current)?candidate:current;
            Match other=preferred==current?candidate:current;
            mergeDuplicateMatchBasics(preferred,other);
            unique.set(position,preferred);
        }
        return unique;
    }

    ArrayList<String> competitionParticipantNames(String competitionName){
        return competitionParticipantNames(competitionName,null);
    }

    ArrayList<String> competitionParticipantNames(String competitionName,List<Match> knownMatches){
        // Domestic 2026/27 leagues use the verified central roster as the source
        // of truth. Never let a stale participant cache re-introduce provider
        // aliases or relegated/promoted clubs from another season.
        if(competitionUsesStrictCurrentRoster(competitionName)){
            ArrayList<String> roster=strictCompetitionRoster(competitionName);
            synchronized(competitionCacheLock){
                competitionParticipantCache.put(competitionName,new ArrayList<String>(roster));
            }
            return roster;
        }
        synchronized(competitionCacheLock){
            ArrayList<String> cached=competitionParticipantCache.get(competitionName);
            if(cached!=null)return new ArrayList<String>(cached);
        }
        long generation;
        synchronized(competitionCacheLock){generation=competitionCacheGeneration;}
        LinkedHashSet<String> names=new LinkedHashSet<String>();
        JSONArray table=verifiedTotalStandingTable(competitionName);
        if(table!=null)for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);JSONObject team=row==null?null:row.optJSONObject("team");
            if(team==null)continue;String name=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();if(name.length()>0)names.add(name);
        }
        ArrayList<String> extras=new ArrayList<String>();
        List<Match> participantSource=knownMatches==null?competitionSnapshot(competitionName).matches:knownMatches;
        for(Match match:participantSource){
            if(match.home!=null&&match.home.trim().length()>0&&!containsSameTeam(names,match.home))extras.add(match.home.trim());
            if(match.away!=null&&match.away.trim().length()>0&&!containsSameTeam(names,match.away))extras.add(match.away.trim());
        }
        Collections.sort(extras,(a,b)->displayTeamName(a).compareToIgnoreCase(displayTeamName(b)));
        for(String name:extras)if(!containsSameTeam(names,name))names.add(name);
        // The club directory may be shown before the connected API publishes
        // the first fixture. Keep verified 2026/27 participant sets available;
        // live status, scores, results and table positions still come centrally.
        if("La Liga".equals(competitionName)||"Bundesliga".equals(competitionName)||"Serie A".equals(competitionName)||"Eredivisie".equals(competitionName)||"Primeira Liga".equals(competitionName)||"Brasileirão Série A".equals(competitionName)){
            String[] official;
            if("Bundesliga".equals(competitionName)){
                official=new String[]{"1. FC Köln","1. FC Union Berlin","1. FSV Mainz 05","Bayer 04 Leverkusen",
                        "Borussia Dortmund","Borussia Mönchengladbach","Eintracht Frankfurt","FC Augsburg",
                        "FC Bayern München","FC Schalke 04","Hamburger SV","RB Leipzig","SC Paderborn 07",
                        "Sport-Club Freiburg","SV Elversberg","SV Werder Bremen","TSG Hoffenheim","VfB Stuttgart"};
            }else if("Serie A".equals(competitionName)){
                official=new String[]{"Atalanta","Bologna","Cagliari","Como","Fiorentina","Frosinone",
                        "Genoa","Inter","Juventus","Lazio","Lecce","Milan","Monza","Napoli","Parma",
                        "Roma","Sassuolo","Torino","Udinese","Venezia"};
            }else if("Eredivisie".equals(competitionName)){
                official=new String[]{"ADO Den Haag","Ajax","AZ","Excelsior Rotterdam","FC Groningen","FC Twente",
                        "FC Utrecht","Feyenoord","Fortuna Sittard","Go Ahead Eagles","N.E.C.","PEC Zwolle",
                        "PSV","SC Cambuur","SC Heerenveen","Sparta Rotterdam","Telstar","Willem II"};
            }else if("Primeira Liga".equals(competitionName)){
                official=new String[]{"Académico","Casa Pia AC","CD Nacional","Estoril Praia","Estrela Amadora","FC Alverca",
                        "FC Arouca","FC Famalicão","FC Porto","Gil Vicente FC","Marítimo","Moreirense FC",
                        "Rio Ave FC","Santa Clara","SC Braga","SL Benfica","Sporting CP","Vitória SC"};
            }else if("Brasileirão Série A".equals(competitionName)){
                official=new String[]{"Athletico Paranaense","Atlético Mineiro","Bahia","Botafogo","Chapecoense",
                        "Corinthians","Coritiba","Cruzeiro","Flamengo","Fluminense","Grêmio","Internacional",
                        "Mirassol","Palmeiras","Red Bull Bragantino","Remo","Santos","São Paulo","Vasco da Gama","Vitória"};
            }else{
                official=new String[]{"Athletic Club","Atlético de Madrid","CA Osasuna","Celta de Vigo",
                        "Deportivo Alavés","Elche CF","FC Barcelona","Getafe CF","Levante UD",
                        "Rayo Vallecano","RCD Espanyol","Real Betis","Real Madrid","Real Sociedad",
                        "Racing Santander","Deportivo La Coruña","Málaga CF","Sevilla FC","Valencia CF","Villarreal CF"};
            }
            for(String club:official)if(!containsSameTeam(names,club))names.add(club);
            ArrayList<String> ordered=new ArrayList<String>(names);
            Collections.sort(ordered,(a,b)->displayTeamName(a).compareToIgnoreCase(displayTeamName(b)));
            synchronized(competitionCacheLock){if(generation==competitionCacheGeneration)competitionParticipantCache.put(competitionName,new ArrayList<String>(ordered));}
            return ordered;
        }
        ArrayList<String> result=new ArrayList<String>(names);
        synchronized(competitionCacheLock){if(generation==competitionCacheGeneration)competitionParticipantCache.put(competitionName,new ArrayList<String>(result));}
        return result;
    }

    boolean containsSameTeam(Collection<String> names,String candidate){
        if(names==null||candidate==null)return false;for(String name:names)if(sameTeam(name,candidate))return true;return false;
    }

    int competitionStandingPosition(String competitionName,String teamName){
        JSONArray table=verifiedTotalStandingTable(competitionName);if(table==null)return 0;
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);JSONObject team=row==null?null:row.optJSONObject("team");if(team==null)continue;
            String name=team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(name,teamName))return row.optInt("position",i+1);
        }
        return 0;
    }

    void addCompetitionParticipantsPreview(final String competitionName){
        addCompetitionParticipantsPreview(competitionName,competitionParticipantNames(competitionName));
    }

    void addCompetitionParticipantsPreview(final String competitionName,List<String> publishedNames){
        ArrayList<String> names=publishedNames==null?new ArrayList<String>():new ArrayList<String>(publishedNames);
        LinearLayout preview=card();
        String title=t2(isNationalCompetition(competitionName)?"Teams":"Clubs",isNationalCompetition(competitionName)?"Reprezentacije":"Klubovi",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"Selecciones":"Clubes",isNationalCompetition(competitionName)?"Équipes":"Clubs");
        int participantCount=competitionParticipantCount(competitionName,names);
        LinearLayout head=hrow();head.addView(label((isNationalCompetition(competitionName)?"🌍 ":"🛡️ ")+title,21,text,true),new LinearLayout.LayoutParams(0,-2,1));head.addView(label(String.valueOf(participantCount),13,RED,true));preview.addView(head);
        if(names.isEmpty())preview.addView(label(t2("The verified participant list is still synchronizing.","Popis provjerenih sudionika još se sinkronizira.","Die verifizierte Teilnehmerliste wird noch synchronisiert.","La lista verificada de participantes aún se sincroniza.","La liste vérifiée des participants est encore en cours de synchronisation."),14,subText,false));
        else{
            int limit=Math.min(6,names.size());
            for(int i=0;i<limit;i++)addCompetitionParticipantRow(preview,competitionName,names.get(i),false);
        }
        Button all=outline(t2(isNationalCompetition(competitionName)?"View all teams":"View all clubs",isNationalCompetition(competitionName)?"Pogledaj sve reprezentacije":"Pogledaj sve klubove",isNationalCompetition(competitionName)?"Alle Teams anzeigen":"Alle Klubs anzeigen",isNationalCompetition(competitionName)?"Ver todas las selecciones":"Ver todos los clubes",isNationalCompetition(competitionName)?"Voir toutes les équipes":"Voir tous les clubs"));
        all.setOnClickListener(v->showCompetitionParticipants(competitionName));preview.addView(all);
    }

    String competitionParticipantMeta(String competitionName,String participant){
        int position=competitionStandingPosition(competitionName,participant);
        if(isNationalCompetition(competitionName)){
            return position>0?"#"+position+"  •  "+displayCompetitionName(competitionName):displayCompetitionName(competitionName);
        }
        ArrayList<String> parts=new ArrayList<String>();
        if(position>0)parts.add("#"+position+" "+t2("in table","na tablici","in der Tabelle","en la tabla","au classement"));
        TeamProfileRecord profile=teamProfileForClub(participant);
        if(profile!=null&&profile.area!=null&&profile.area.trim().length()>0)parts.add(localizedCountryName(profile.area.trim()));
        else{
            String regionKey=CompetitionCatalog.get(competitionName).regionKey;
            if(!regionKey.equals("Europe")&&!regionKey.equals("International"))parts.add(competitionRegion(competitionName));
        }
        if(parts.isEmpty())parts.add(t2("Open club profile","Otvori profil kluba","Klubprofil öffnen","Abrir perfil del club","Ouvrir le profil du club"));
        return joinParts(parts,"  •  ");
    }

    void addCompetitionParticipantRow(LinearLayout parent,final String competitionName,final String participant,boolean full){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(full?9:7),dp(8),dp(full?9:7));row.setBackground(ripple(round(chipBg,dp(19),1)));
        int crestSize=full?50:40;
        FrameLayout crestHolder=new FrameLayout(this);crestHolder.setPadding(dp(2),dp(2),dp(2),dp(2));crestHolder.setBackground(round(Color.rgb(27,32,45),dp(17),1));
        View crest=homeTeamVisual(participant,dp(crestSize-4),false);FrameLayout.LayoutParams crestParams=new FrameLayout.LayoutParams(-1,-1);crestParams.gravity=Gravity.CENTER;crestHolder.addView(crest,crestParams);
        row.addView(crestHolder,new LinearLayout.LayoutParams(dp(crestSize),dp(crestSize)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(4),0);
        String participantDisplayName=displayTeamName(participant);
        int participantTextSize=participantDisplayName.length()>24?(full?13:12):(participantDisplayName.length()>18?(full?14:13):(full?16:14));
        TextView clubName=label(participantDisplayName,participantTextSize,text,true);
        clubName.setMaxLines(2);clubName.setEllipsize(null);clubName.setLineSpacing(0,0.94f);copy.addView(clubName);
        TextView meta=label(competitionParticipantMeta(competitionName,participant),11,subText,false);meta.setMaxLines(1);meta.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(meta);
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        if(!isNationalCompetition(competitionName)&&full){
            boolean favorite=isFavoriteClubName(participant);TextView star=centerLabel(favorite?"★":"☆",21,favorite?GOLD:Color.rgb(178,188,207),true);star.setContentDescription(favorite?t2("Stop following club","Prestani pratiti klub","Klub nicht mehr folgen","Dejar de seguir club","Ne plus suivre le club"):t2("Follow club","Prati klub","Klub folgen","Seguir club","Suivre le club"));star.setBackground(round(Color.rgb(29,34,48),dp(15),1));
            star.setOnClickListener(v->{toggleFavoriteClub(participant);showCompetitionParticipants(competitionName);});row.addView(star,new LinearLayout.LayoutParams(dp(42),dp(42)));
        }
        TextView arrow=centerLabel("›",22,RED,true);row.addView(arrow,new LinearLayout.LayoutParams(dp(28),dp(42)));
        row.setOnClickListener(v->{
            if(isNationalCompetition(competitionName)){competitionFilter=competitionName;matchFilter=participant;matchDateFilter="ALL";matchStatusFilter="All";matchFavoritesOnly=false;showMatches();}
            else showClubCenterFromCompetition(participant,competitionName);
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    void showCompetitionParticipants(final String competitionName){
        if(!requirePro(t2("Competition clubs and teams","Klubovi i reprezentacije natjecanja","Wettbewerbsteilnehmer","Clubes y selecciones","Clubs et équipes")))return;
        currentCompetitionName=competitionName;
        ensureCompetitionDataReady(competitionName);
        boolean national=isNationalCompetition(competitionName);
        String title=t2(national?"Teams":"Clubs",national?"Reprezentacije":"Klubovi",national?"Teams":"Klubs",national?"Selecciones":"Clubes",national?"Équipes":"Clubs");
        ArrayList<String> names=competitionParticipantNames(competitionName);
        clear(title,displayCompetitionName(competitionName)+"  •  "+competitionParticipantShortLabel(competitionName),"CompetitionParticipants");

        LinearLayout hero=card();hero.setPadding(dp(16),dp(15),dp(16),dp(14));hero.setBackground(gradient(Color.rgb(53,19,88),Color.rgb(221,28,87),dp(24)));
        LinearLayout heroTop=hrow();
        View competitionLogo=competitionVisual(competitionName,dp(54));heroTop.addView(competitionLogo,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(12),0,0,0);
        TextView competitionTitle=label(displayCompetitionName(competitionName),22,Color.WHITE,true);competitionTitle.setMaxLines(2);competitionTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);heroCopy.addView(competitionTitle);
        TextView heroMeta=label(competitionParticipantLabel(competitionName)+"  •  "+competitionDataStatus(competitionName),13,Color.rgb(239,232,247),false);heroMeta.setMaxLines(2);heroMeta.setEllipsize(android.text.TextUtils.TruncateAt.END);heroCopy.addView(heroMeta);
        heroTop.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(heroTop);
        TextView instruction=label(national?t2("Open a team to view all verified matches.","Otvori reprezentaciju za sve provjerene utakmice.","Öffne ein Team für alle verifizierten Spiele.","Abre una selección para ver todos los partidos verificados.","Ouvre une équipe pour voir tous les matchs vérifiés."):t2("☆ Follow club   •   Tap row to open profile","☆ Prati klub   •   Dodirni redak za profil","☆ Klub folgen   •   Zeile für Profil öffnen","☆ Seguir club   •   Toca la fila para abrir el perfil","☆ Suivre le club   •   Touche la ligne pour le profil"),12,Color.WHITE,true);
        instruction.setPadding(dp(12),dp(8),dp(12),dp(8));instruction.setBackground(round(Color.argb(38,255,255,255),dp(14),0));LinearLayout.LayoutParams instructionParams=new LinearLayout.LayoutParams(-1,-2);instructionParams.setMargins(0,dp(11),0,0);hero.addView(instruction,instructionParams);

        LinearLayout list=card();list.setPadding(dp(14),dp(14),dp(14),dp(14));
        LinearLayout listHead=hrow();listHead.addView(label(title,22,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView count=label(String.valueOf(competitionParticipantCount(competitionName)),13,RED,true);count.setGravity(Gravity.CENTER);count.setPadding(dp(11),dp(7),dp(11),dp(7));count.setBackground(round(chipBg,dp(14),1));listHead.addView(count);list.addView(listHead);
        if(names.isEmpty())list.addView(label(t2("The verified participant list is still synchronizing.","Popis provjerenih sudionika još se sinkronizira.","Die verifizierte Teilnehmerliste wird noch synchronisiert.","La lista verificada de participantes aún se sincroniza.","La liste vérifiée des participants est encore en cours de synchronisation."),14,subText,false));
        else for(String name:names)addCompetitionParticipantRow(list,competitionName,name,true);
    }

    int expectedBundledFixtureCount(String competitionName){
        if("Premier League".equals(competitionName))return 380;
        if("Championship".equals(competitionName))return 552;
        if("La Liga".equals(competitionName))return 380;
        if("Bundesliga".equals(competitionName))return 306;
        if("Serie A".equals(competitionName))return 380;
        if("Ligue 1".equals(competitionName))return 306;
        if("Eredivisie".equals(competitionName))return 306;
        if("Primeira Liga".equals(competitionName))return 306;
        if("Brasileirão Série A".equals(competitionName))return 380;
        return 0;
    }

    boolean isBundledLeagueCompetition(String competitionName){
        return expectedBundledFixtureCount(competitionName)>0;
    }

    int inMemoryCompetitionMatchCount(String competitionName){
        CompetitionSnapshot cached=cachedCompetitionSnapshot(competitionName);
        if(cached!=null){
            if(isBundledLeagueCompetition(competitionName)){
                // A cached snapshot created before roster/dedup sanitisation can be
                // inflated by provider aliases. Re-evaluate strict domestic leagues.
                return matchesForCompetition(competitionName).size();
            }
            return cached.totalMatches;
        }
        if(isBundledLeagueCompetition(competitionName))return matchesForCompetition(competitionName).size();
        List<Match> source=competitionSourceSnapshot;
        if(source==null||source.isEmpty())return 0;
        int count=0;
        for(Match match:source)if(matchBelongsToCompetition(match,competitionName))count++;
        return count;
    }

    void ensureCompetitionDataReady(String competitionName){
        int expected=expectedBundledFixtureCount(competitionName);
        if(expected<=0||inMemoryCompetitionMatchCount(competitionName)>=expected)return;
        // Warm start is already building the same verified baseline. Do not start
        // a second full repair merely because the user opened a league quickly.
        if(bundledBaselineLoading)return;
        scheduleBundledLeagueRepair();
    }

    void scheduleBundledLeagueRepair(){
        synchronized(bundledRepairLock){
            if(bundledRepairInProgress)return;
            bundledRepairInProgress=true;
        }
        try{appSerialExecutor.execute(new Runnable(){ public void run(){
            boolean repaired=false;
            try{
                synchronized(dataApplyLock){
                    String seed=onlineRootCacheRaw;
                    if(seed==null||seed.trim().length()==0)seed=prefs.getString("online_rawJson","");
                    if(seed==null||seed.trim().length()==0)seed="{}";
                    String merged=liveDataClient.mergeBundledFixtures(seed);
                    JSONObject root=new JSONObject(merged);
                    JSONArray all=root.optJSONArray("matches");
                    JSONArray bundledRows=new JSONArray();
                    if(all!=null)for(int i=0;i<all.length();i++){
                        JSONObject row=all.optJSONObject(i);
                        if(row==null)continue;
                        boolean bundled=false;
                        for(String candidate:CompetitionCatalog.all().keySet()){
                            if(!isBundledLeagueCompetition(candidate))continue;
                            if(jsonMatchBelongsToCompetition(row,candidate)){bundled=true;break;}
                        }
                        if(bundled)bundledRows.put(new JSONObject(row.toString()));
                    }
                    if(bundledRows.length()>0){
                        syncMatchesFromArray(bundledRows);
                        MatchConsistency.normalizeAll(data.matches);
                        removeDuplicateMatches();
                        data.save();
                    }
                    onlineRootCache=root;
                    onlineRootCacheRaw=merged;
                    prefs.edit().putString("online_rawJson",merged).apply();
                    rebuildClubCrestIndex(root);
                    invalidateClubProfileCache();
                    refreshCompetitionSourceSnapshot();
                    invalidateCompetitionCaches();
                    repaired=true;
                }
            }catch(Exception ignored){}
            final boolean finished=repaired;
            if(finished){
                String activeCompetition=currentCompetitionName;
                if(activeCompetition!=null&&!activeCompetition.isEmpty())prewarmCompetitionCache(activeCompetition);
            }
            synchronized(bundledRepairLock){bundledRepairInProgress=false;}
            if(finished)prewarmActiveCompetitionAsync();
        }});}catch(Exception ignored){synchronized(bundledRepairLock){bundledRepairInProgress=false;}}
    }

    void refreshCompetitionSourceSnapshot(){
        if(data==null||data.matches==null){
            competitionSourceSnapshot=Collections.emptyList();
            return;
        }
        competitionSourceSnapshot=Collections.unmodifiableList(new ArrayList<Match>(data.matches));
    }

    void invalidateCompetitionCaches(){
        synchronized(competitionCacheLock){
            competitionCacheGeneration++;
            competitionSnapshotCache.clear();
            competitionParticipantCache.clear();
        }
    }

    CompetitionSnapshot cachedCompetitionSnapshot(String competitionName){
        synchronized(competitionCacheLock){
            return competitionSnapshotCache.get(competitionName);
        }
    }

    void prewarmCompetitionCache(String competitionName){
        if(competitionName==null||competitionName.trim().isEmpty())return;
        competitionSnapshot(competitionName);
        competitionParticipantNames(competitionName);
    }

    void prewarmActiveCompetitionAsync(){
        final String active=currentCompetitionName;
        if(active==null||active.trim().isEmpty())return;
        try{appSerialExecutor.execute(new Runnable(){public void run(){
            try{prewarmCompetitionCache(active);}catch(Exception ignored){}
        }});}catch(Exception ignored){}
    }

    void prewarmCompetitionCachesAsync(){
        synchronized(competitionCacheLock){
            if(competitionCacheWarmInProgress)return;
            competitionCacheWarmInProgress=true;
        }
        try{appSerialExecutor.execute(new Runnable(){ public void run(){
            try{
                boolean repeat;
                do{
                    long generation;
                    synchronized(competitionCacheLock){generation=competitionCacheGeneration;}
                    for(String competitionName:CompetitionCatalog.all().keySet()){
                        if(isFinishing()||isDestroyed())break;
                        if(!isBundledLeagueCompetition(competitionName))continue;
                        competitionSnapshot(competitionName);
                        competitionParticipantNames(competitionName);
                    }
                    synchronized(competitionCacheLock){repeat=generation!=competitionCacheGeneration;}
                }while(repeat&&!isFinishing()&&!isDestroyed());
            }catch(Exception ignored){}
            finally{
                synchronized(competitionCacheLock){competitionCacheWarmInProgress=false;}
            }
        }});}catch(Exception ignored){synchronized(competitionCacheLock){competitionCacheWarmInProgress=false;}}
    }

    int verifiedCurrentMatchday(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null)return 0;
        JSONObject season=entry.optJSONObject("season");
        return season==null?0:Math.max(0,season.optInt("currentMatchday",0));
    }

    int verifiedAggregatePlayedMatches(String competitionName,int totalMatches,int detailedFinished){
        // Aggregate season progress and individual match truth are deliberately separate.
        // For Brasileirão the verified standings cover all 20 clubs and therefore give
        // a trustworthy played-match aggregate even when historical score detail is partial.
        // This NEVER promotes an individual fixture to FINISHED: an individual match still
        // requires its own verified home/away score through MatchConsistency.
        if(!"Brasileirão Série A".equals(competitionName))return detailedFinished;
        JSONArray table=verifiedTotalStandingTable(competitionName);
        if(table==null||table.length()!=CompetitionCatalog.get(competitionName).teamCount)return detailedFinished;
        long playedSum=0L;
        int maxPerTeam=table.length()>1&&totalMatches>0?(totalMatches*2)/table.length():Integer.MAX_VALUE;
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);
            if(row==null||!row.has("playedGames")||row.isNull("playedGames"))return detailedFinished;
            int played=row.optInt("playedGames",-1);
            if(played<0||played>maxPerTeam)return detailedFinished;
            playedSum+=played;
        }
        if((playedSum&1L)!=0L)return detailedFinished;
        long aggregate=playedSum/2L;
        if(aggregate<detailedFinished)return detailedFinished;
        if(totalMatches>0&&aggregate>totalMatches)return detailedFinished;
        return (int)aggregate;
    }

    String competitionCacheDayKey(){
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    }

    CompetitionSnapshot competitionSnapshot(String competitionName){
        String dayKey=competitionCacheDayKey();
        long generation;
        synchronized(competitionCacheLock){
            CompetitionSnapshot cached=competitionSnapshotCache.get(competitionName);
            if(cached!=null&&dayKey.equals(cached.cacheDayKey))return cached;
            if(cached!=null){competitionSnapshotCache.remove(competitionName);competitionParticipantCache.remove(competitionName);}
            generation=competitionCacheGeneration;
        }

        CompetitionSnapshot snapshot=new CompetitionSnapshot();
        snapshot.cacheDayKey=dayKey;
        snapshot.matches.addAll(matchesForCompetition(competitionName));
        for(Match match:snapshot.matches){
            if(matchIsLive(match))snapshot.live.add(match);
            else if(matchIsUpcoming(match))snapshot.upcoming.add(match);
            if(matchIsFinished(match))snapshot.finished.add(match);
            if(matchIsToday(match))snapshot.todayCount++;
        }
        final IdentityHashMap<Match,Date> finishedDates=new IdentityHashMap<Match,Date>();
        for(Match match:snapshot.finished)finishedDates.put(match,localMatchDate(match));
        Collections.sort(snapshot.finished,(a,b)->{
            Date da=finishedDates.get(a),db=finishedDates.get(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
        snapshot.totalMatches=snapshot.matches.size();
        snapshot.detailedResultCount=snapshot.finished.size();
        // Match-level truth remains score-backed. Season-level progress may use a complete,
        // internally consistent verified standings table because it represents an aggregate
        // (sum of club appearances / 2), not a claim about any particular scoreless fixture.
        snapshot.playedMatches=verifiedAggregatePlayedMatches(competitionName,snapshot.totalMatches,snapshot.detailedResultCount);
        snapshot.playedCountFromStandings=snapshot.playedMatches>snapshot.detailedResultCount;
        snapshot.currentMatchday=verifiedCurrentMatchday(competitionName);
        if(snapshot.currentMatchday<=0&&competitionUsesRounds(competitionName)){
            int lastFinished=0;
            for(Match match:snapshot.matches){
                if(match==null||match.matchday<=0)continue;
                if(matchIsUpcoming(match)||matchIsLive(match)){snapshot.currentMatchday=match.matchday;break;}
                if(matchIsFinished(match))lastFinished=Math.max(lastFinished,match.matchday);
            }
            if(snapshot.currentMatchday<=0)snapshot.currentMatchday=lastFinished;
        }
        snapshot.progressPercent=snapshot.totalMatches<=0?0:Math.min(100,Math.round((snapshot.playedMatches*100f)/snapshot.totalMatches));
        snapshot.rounds=competitionMatchesByRound(competitionName,snapshot.matches,false);

        synchronized(competitionCacheLock){
            if(generation==competitionCacheGeneration){
                CompetitionSnapshot existing=competitionSnapshotCache.get(competitionName);
                if(existing!=null)return existing;
                if(snapshot.totalMatches>0||!isBundledLeagueCompetition(competitionName)){
                    competitionSnapshotCache.put(competitionName,snapshot);
                }
            }
        }
        return snapshot;
    }


    int activeCompetitionSeasonStartYear(String competitionName){
        Calendar now=Calendar.getInstance();
        int year=now.get(Calendar.YEAR);
        int month=now.get(Calendar.MONTH)+1;
        if("Brasileirão Série A".equals(competitionName))return year;
        if("World Cup 2026".equals(competitionName))return 2026;
        if("UEFA European Championship".equals(competitionName)){
            // The next European Championship after 2024 is 2028.
            return year<=2028?2028:year;
        }
        return month>=7?year:year-1;
    }

    boolean matchIsInActiveCompetitionSeason(Match match,String competitionName){
        if(match==null||match.date==null||match.date.length()<10)return false;
        try{
            int year=Integer.parseInt(match.date.substring(0,4));
            int month=Integer.parseInt(match.date.substring(5,7));
            int startYear=activeCompetitionSeasonStartYear(competitionName);

            if("Brasileirão Série A".equals(competitionName))return year==startYear;
            if("World Cup 2026".equals(competitionName))return year==2026;
            if("UEFA European Championship".equals(competitionName))return year==startYear;

            if(year==startYear)return month>=7;
            if(year==startYear+1)return month<=6;
            return false;
        }catch(Exception ignored){
            return false;
        }
    }

    boolean standingsEntryMatchesActiveSeason(JSONObject entry,String competitionName){
        if(entry==null)return false;
        JSONObject season=entry.optJSONObject("season");
        if(season==null)return false;
        String start=season.optString("startDate","").trim();
        if(start.length()<4)return false;
        try{
            int startYear=Integer.parseInt(start.substring(0,4));
            return startYear==activeCompetitionSeasonStartYear(competitionName);
        }catch(Exception ignored){
            return false;
        }
    }


    ArrayList<Match> dedupeCompetitionMatchList(List<Match> source){
        ArrayList<Match> unique=new ArrayList<Match>();
        if(source==null||source.isEmpty())return unique;

        LinkedHashMap<String,Integer> positions=new LinkedHashMap<String,Integer>();
        for(Match candidate:source){
            if(candidate==null)continue;
            String key=duplicateMatchKey(candidate);
            if(key==null||key.isEmpty()){
                unique.add(candidate);
                continue;
            }

            Integer position=positions.get(key);
            if(position==null){
                positions.put(key,unique.size());
                unique.add(candidate);
                continue;
            }

            Match current=unique.get(position);
            Match preferred=matchDataRichness(candidate)>matchDataRichness(current)?candidate:current;
            Match other=preferred==current?candidate:current;
            mergeDuplicateMatchBasics(preferred,other);
            unique.set(position,preferred);
        }
        return unique;
    }

    ArrayList<Match> matchesForCompetition(String competitionName){
        CompetitionSnapshot cached=cachedCompetitionSnapshot(competitionName);
        if(cached!=null){
            ArrayList<Match> cachedClean=new ArrayList<Match>();
            if(cached.matches!=null)for(Match candidate:cached.matches){
                if(candidate==null||!matchIsInActiveCompetitionSeason(candidate,competitionName))continue;
                canonicalizeStrictCompetitionMatchTeams(competitionName,candidate);
                if(competitionUsesStrictCurrentRoster(competitionName)
                        &&(!teamBelongsToStrictCompetitionRoster(competitionName,candidate.home)
                        ||!teamBelongsToStrictCompetitionRoster(competitionName,candidate.away)))continue;
                cachedClean.add(candidate);
            }
            cachedClean=competitionHasUniqueHomeAwayPairPerSeason(competitionName)
                    ?dedupeStrictDomesticFixtures(competitionName,cachedClean)
                    :dedupeCompetitionMatchList(cachedClean);
            normalizeCompetitionQualifierLegs(competitionName,cachedClean);
            return cachedClean;
        }
        ArrayList<Match> out=new ArrayList<Match>();
        // Keep a stable list snapshot outside the long online-data apply lock.
        // Only the active competition season is allowed into a competition screen.
        // This prevents old 2025/26 rows from being added to the current 2026/27
        // schedule, club list, counters and season label.
        List<Match> source=competitionSourceSnapshot;
        if(source==null||source.isEmpty())return out;
        for(Match candidate:source){
            if(matchBelongsToCompetition(candidate,competitionName)
                    &&matchIsInActiveCompetitionSeason(candidate,competitionName)){
                canonicalizeStrictCompetitionMatchTeams(competitionName,candidate);
                if(competitionUsesStrictCurrentRoster(competitionName)
                        &&(!teamBelongsToStrictCompetitionRoster(competitionName,candidate.home)
                        ||!teamBelongsToStrictCompetitionRoster(competitionName,candidate.away))){
                    continue;
                }
                out.add(candidate);
            }
        }
        out=competitionHasUniqueHomeAwayPairPerSeason(competitionName)
                ?dedupeStrictDomesticFixtures(competitionName,out)
                :dedupeCompetitionMatchList(out);
        normalizeCompetitionQualifierLegs(competitionName,out);
        // Parsing dates inside a sort comparator caused the same timestamp to be
        // parsed dozens of times for 300-550 fixture leagues. Parse once per row.
        final IdentityHashMap<Match,Date> dates=new IdentityHashMap<Match,Date>();
        for(Match match:out)dates.put(match,localMatchDate(match));
        Collections.sort(out,(a,b)->{
            Date da=dates.get(a),db=dates.get(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return out;
    }

    ArrayList<Match> finishedCompetitionMatches(List<Match> matches){
        ArrayList<Match> finished=new ArrayList<Match>();
        if(matches!=null)for(Match match:matches)if(matchIsFinished(match))finished.add(match);
        final IdentityHashMap<Match,Date> dates=new IdentityHashMap<Match,Date>();
        for(Match match:finished)dates.put(match,localMatchDate(match));
        Collections.sort(finished,(a,b)->{
            Date da=dates.get(a),db=dates.get(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
        return finished;
    }

    void addCompetitionMatchPreview(String competitionName,String heading,String icon,ArrayList<Match> matches,int limit){
        LinearLayout section=card();
        section.addView(label(icon+" "+heading,22,text,true));
        int shown=0;
        for(Match m:matches){
            if(matchIsUpcoming(m))addDynamicHomeMatch(section,m,true,false,true);
            else if(matchIsFinished(m))addDynamicHomeMatch(section,m,true,true,false);
            else addDynamicHomeMatch(section,m);
            shown++;
            if(shown>=limit)break;
        }
        if(matches.size()>shown)section.addView(label("+"+(matches.size()-shown)+" "+t2("matches","utakmica","Spiele","partidos","matchs"),13,subText,true));
        Button all=outline(t2("View all competition matches","Pogledaj sve utakmice natjecanja","Alle Wettbewerbsspiele anzeigen","Ver todos los partidos","Voir tous les matchs"));
        all.setOnClickListener(v->{competitionFilter=competitionName;matchStatusFilter="All";matchDateFilter="ALL";matchFilter="";matchCenterPage=0;showMatches();});
        section.addView(all);
    }

    JSONArray verifiedTotalStandingTable(String competitionName){
        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null)return null;
        JSONArray standings=entry.optJSONArray("standings");
        if(standings==null)return null;
        for(int i=0;i<standings.length();i++){
            JSONObject standing=standings.optJSONObject(i);
            if(standing==null)continue;
            String type=standing.optString("type","");
            if(type.length()>0&&!type.equalsIgnoreCase("TOTAL"))continue;
            JSONArray table=standing.optJSONArray("table");
            if(table==null||table.length()==0)continue;
            if(!competitionUsesStrictCurrentRoster(competitionName))return table;

            JSONArray clean=new JSONArray();
            LinkedHashSet<String> seen=new LinkedHashSet<String>();
            for(int j=0;j<table.length();j++){
                JSONObject row=table.optJSONObject(j);
                JSONObject team=row==null?null:row.optJSONObject("team");
                if(team==null)continue;
                String name=team.optString("name",team.optString("shortName",team.optString("tla",""))).trim();
                if(!teamBelongsToStrictCompetitionRoster(competitionName,name))continue;
                String key=teamKey(name);
                if(key.isEmpty()||seen.contains(key))continue;
                seen.add(key);
                clean.put(row);
            }
            int expected=strictCompetitionRoster(competitionName).size();
            return expected>0&&clean.length()==expected?clean:null;
        }
        return null;
    }

    boolean competitionIsInQualificationPhase(String competitionName){
        return competitionIsInQualificationPhase(competitionName,null);
    }

    boolean competitionIsInQualificationPhase(String competitionName,List<Match> knownMatches){
        if(!"UEFA Champions League".equals(competitionName))return false;
        List<Match> source=knownMatches==null?matchesForCompetition(competitionName):knownMatches;
        for(Match match:source){
            String phase=(competitionRoundKey(match)+" "+(match.roundName==null?"":match.roundName)).toLowerCase(homeLocale());
            if(phase.contains("pretkolo")||phase.contains("qualif")||phase.contains("qualification"))return true;
        }
        return false;
    }

    boolean supportsPreseasonZeroTable(String competitionName){
        // Serie A needs the same bundled pre-season snapshot already visible
        // through the complete table screen, without changing other leagues.
        return "Serie A".equals(competitionName)||"Ligue 1".equals(competitionName)||"Eredivisie".equals(competitionName);
    }

    JSONArray preseasonZeroTable(String competitionName){
        return preseasonZeroTable(competitionName,null);
    }

    JSONArray preseasonZeroTable(String competitionName,List<String> publishedNames){
        JSONArray table=new JSONArray();
        ArrayList<String> clubs=publishedNames==null?competitionParticipantNames(competitionName):new ArrayList<String>(publishedNames);
        Collections.sort(clubs,(a,b)->displayTeamName(a).compareToIgnoreCase(displayTeamName(b)));
        for(int i=0;i<clubs.size();i++){
            try{
                JSONObject row=new JSONObject();
                JSONObject team=new JSONObject();
                team.put("name",displayTeamName(clubs.get(i)));
                team.put("shortName",displayTeamName(clubs.get(i)));
                row.put("position",i+1);
                row.put("team",team);
                row.put("playedGames",0);
                row.put("goalDifference",0);
                row.put("points",0);
                table.put(row);
            }catch(Exception ignored){}
        }
        return table;
    }

    void addCompetitionStandingsPreview(String competitionName){
        addCompetitionStandingsPreview(competitionName,null,null);
    }

    void addCompetitionStandingsPreview(String competitionName,CompetitionSnapshot snapshot,List<String> publishedNames){
        JSONArray table=verifiedTotalStandingTable(competitionName);
        List<Match> knownMatches=snapshot==null?null:snapshot.matches;
        boolean noFinished=snapshot==null?finishedCompetitionMatches(matchesForCompetition(competitionName)).isEmpty():snapshot.finished.isEmpty();
        boolean preseason=table==null&&supportsPreseasonZeroTable(competitionName)&&
                competitionUsesRounds(competitionName)&&noFinished;
        if(preseason)table=preseasonZeroTable(competitionName,publishedNames);
        boolean qualificationWithoutTable=table==null&&competitionIsInQualificationPhase(competitionName,knownMatches);
        boolean waitingForFirstLeagueTable=table==null&&competitionUsesRounds(competitionName)&&noFinished;

        LinearLayout preview=card();
        preview.addView(label("📊 "+t2("Table snapshot","Sažetak tablice","Tabellenausschnitt","Resumen de tabla","Aperçu du classement"),22,text,true));
        if(table==null){
            if(qualificationWithoutTable){
                preview.addView(label(t2(
                        "There is no shared table during qualification. It will appear when the league phase begins and the connected source publishes confirmed standings.",
                        "U kvalifikacijskim fazama nema zajedničke tablice. Prikazat će se kada započne ligaška faza i povezani izvor objavi potvrđeni poredak.",
                        "Während der Qualifikation gibt es keine gemeinsame Tabelle. Sie erscheint mit Beginn der Ligaphase, sobald die verbundene Quelle den bestätigten Stand veröffentlicht.",
                        "Durante la clasificación no hay una tabla común. Aparecerá cuando comience la fase de liga y la fuente conectada publique la clasificación confirmada.",
                        "Il n’y a pas de classement commun pendant les qualifications. Il apparaîtra au début de la phase de ligue lorsque la source connectée publiera le classement confirmé."),15,subText,false));
            }else if(waitingForFirstLeagueTable){
                preview.addView(label(t2("The table will be available after the competition starts and the connected source publishes the first confirmed standings.","Tablica će biti dostupna nakon početka natjecanja i objave prvog potvrđenog poretka.","Die Tabelle erscheint nach Wettbewerbsbeginn und Veröffentlichung des ersten bestätigten Tabellenstands.","La tabla estará disponible cuando empiece la competición y la fuente publique la primera clasificación confirmada.","Le classement sera disponible après le début de la compétition et la publication du premier classement confirmé."),15,subText,false));
            }else{
                preview.addView(label(t2("The verified table is still synchronizing. No placeholder positions are shown.","Provjerena tablica još se sinkronizira. Privremene ili izmišljene pozicije ne prikazuju se.","Die verifizierte Tabelle wird noch synchronisiert. Es werden keine Platzhalterpositionen gezeigt.","La tabla verificada aún se está sincronizando. No se muestran posiciones ficticias.","Le classement vérifié est encore en cours de synchronisation. Aucune position fictive n’est affichée."),15,subText,false));
            }
        }else{
            if(preseason)preview.addView(label(t2(
                    "Before the first match, all clubs start with zero points.",
                    "Prije prve utakmice svi klubovi kreću s nula bodova.",
                    "Vor dem ersten Spiel starten alle Klubs mit null Punkten.",
                    "Antes del primer partido, todos los clubes empiezan con cero puntos.",
                    "Avant le premier match, tous les clubs commencent avec zéro point."),13,subText,false));
            preview.addView(verifiedStandingHeader());
            for(int i=0;i<Math.min(5,table.length());i++){
                JSONObject row=table.optJSONObject(i);
                if(row!=null)preview.addView(verifiedStandingRow(row));
            }
        }
        boolean checkAgain=qualificationWithoutTable||waitingForFirstLeagueTable;
        Button full=outline(checkAgain
                ?t2("Check again","Provjeri ponovno","Erneut prüfen","Comprobar de nuevo","Vérifier à nouveau")
                :t2("Open full verified table","Otvori cijelu provjerenu tablicu","Vollständige verifizierte Tabelle öffnen","Abrir tabla verificada completa","Ouvrir le classement vérifié complet"));
        full.setOnClickListener(v->{
            if(checkAgain)refreshOnlineSafe(true);
            else showLeagueStandings(competitionName);
        });
        preview.addView(full);
    }

    JSONObject cachedOnlineRoot(){
        try{
            String raw=prefs.getString("online_rawJson","");
            if(raw==null||raw.trim().length()==0)return null;
            JSONObject cached=onlineRootCache;
            if(cached!=null&&raw.equals(onlineRootCacheRaw))return cached;
            synchronized(this){
                cached=onlineRootCache;
                if(cached==null||!raw.equals(onlineRootCacheRaw)){
                    cached=new JSONObject(raw);
                    onlineRootCache=cached;
                    onlineRootCacheRaw=raw;
                }
            }
            return cached;
        }catch(Exception ignored){return null;}
    }

    JSONObject verifiedStandingsEntry(String competitionName){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return null;
        JSONObject all=root.optJSONObject("standings");
        if(all==null)return null;
        JSONObject entry=all.optJSONObject(competitionApiCode(competitionName));
        if(entry==null||!standingsEntryMatchesActiveSeason(entry,competitionName))return null;
        JSONArray tables=entry.optJSONArray("standings");
        return tables!=null&&tables.length()>0?entry:null;
    }

    boolean hasVerifiedStandings(String competitionName){return verifiedStandingsEntry(competitionName)!=null;}

    void showLeagueStandings(String competitionName){
        if(!requirePro(t2("League tables","Tablice liga","Ligatabellen","Tablas de liga","Classements")))return;
        currentCompetitionName=competitionName;
        ensureCompetitionDataReady(competitionName);
        clear(displayCompetitionName(competitionName),t2("Verified standings","Provjerena tablica","Verifizierte Tabelle","Clasificación verificada","Classement vérifié"),"CompetitionStandings");

        LinearLayout source=card();
        source.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),22,text,true));
        source.addView(label(t2(
                "Football Fun never fills missing positions or statistics with demo values.",
                "Football Fun nikada ne popunjava nedostajuća mjesta ili statistiku demonstracijskim vrijednostima.",
                "Football Fun füllt fehlende Plätze oder Statistiken niemals mit Demo-Werten.",
                "Football Fun nunca rellena posiciones o estadísticas faltantes con valores de demostración.",
                "Football Fun ne remplit jamais les données manquantes avec des valeurs de démonstration."),15,subText,false));

        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null){
            LinearLayout empty=card();
            if(competitionUsesFootballData(competitionName)){
                if(competitionIsInQualificationPhase(competitionName)){
                    empty.addView(label("📊 "+t2("Table is not available yet","Tablica još nije dostupna","Tabelle noch nicht verfügbar","La tabla aún no está disponible","Le classement n’est pas encore disponible"),23,text,true));
                    empty.addView(label(t2(
                            "There is no shared table during qualification. It will appear when the league phase begins and the connected source publishes confirmed standings.",
                            "U kvalifikacijskim fazama nema zajedničke tablice. Prikazat će se kada započne ligaška faza i povezani izvor objavi potvrđeni poredak.",
                            "Während der Qualifikation gibt es keine gemeinsame Tabelle. Sie erscheint mit Beginn der Ligaphase, sobald die verbundene Quelle den bestätigten Stand veröffentlicht.",
                            "Durante la clasificación no hay una tabla común. Aparecerá cuando comience la fase de liga y la fuente conectada publique la clasificación confirmada.",
                            "Il n’y a pas de classement commun pendant les qualifications. Il apparaîtra au début de la phase de ligue lorsque la source connectée publiera le classement confirmé."),15,subText,false));
                    Button refresh=btn("🔄 "+t2("Check again","Provjeri ponovno","Erneut prüfen","Comprobar de nuevo","Vérifier à nouveau"));
                    refresh.setOnClickListener(v->refreshOnlineSafe(true));
                    empty.addView(refresh);
                }else if(competitionUsesRounds(competitionName)&&finishedCompetitionMatches(matchesForCompetition(competitionName)).isEmpty()&&("La Liga".equals(competitionName)||"Bundesliga".equals(competitionName)||"Serie A".equals(competitionName)||"Ligue 1".equals(competitionName)||"Eredivisie".equals(competitionName))){
                    empty.addView(label("📊 "+t2("Pre-season table","Tablica prije početka sezone","Tabelle vor Saisonbeginn","Tabla antes del inicio de temporada","Classement avant le début de saison"),23,text,true));
                    empty.addView(label(t2(
                            "The season has not started yet. All clubs begin with zero points; the table will update automatically after the first completed matches.",
                            "Sezona još nije započela. Svi klubovi kreću s nula bodova, a tablica će se automatski ažurirati nakon prvih odigranih utakmica.",
                            "Die Saison hat noch nicht begonnen. Alle Klubs starten mit null Punkten; die Tabelle wird nach den ersten beendeten Spielen automatisch aktualisiert.",
                            "La temporada aún no ha comenzado. Todos los clubes empiezan con cero puntos y la tabla se actualizará automáticamente tras los primeros partidos finalizados.",
                            "La saison n’a pas encore commencé. Tous les clubs commencent avec zéro point et le classement se mettra à jour automatiquement après les premiers matchs terminés."),15,subText,false));
                    LinearLayout tableCard=card();
                    tableCard.addView(label("🏆 "+t2("Overall table","Ukupna tablica","Gesamttabelle","Tabla general","Classement général"),21,text,true));
                    tableCard.addView(verifiedStandingHeader());
                    JSONArray preseasonTable=preseasonZeroTable(competitionName);
                    for(int i=0;i<preseasonTable.length();i++){
                        JSONObject row=preseasonTable.optJSONObject(i);
                        if(row!=null)tableCard.addView(verifiedStandingRow(row));
                    }
                }else{
                    empty.addView(label("📊 "+t2("Standings are being synchronized","Tablica se sinkronizira","Tabelle wird synchronisiert","La clasificación se está sincronizando","Le classement se synchronise"),23,text,true));
                    empty.addView(label(t2(
                            "Competition tables synchronize gradually. Refresh again later; no invented standings are shown while waiting.",
                            "Tablice natjecanja sinkroniziraju se postupno. Osvježi ponovno kasnije; dok čekamo, ne prikazujemo izmišljene pozicije.",
                            "Wettbewerbstabellen werden schrittweise synchronisiert. Aktualisiere später erneut; es werden keine erfundenen Tabellen angezeigt.",
                            "Las clasificaciones se sincronizan gradualmente. Actualiza más tarde; no se muestran tablas inventadas.",
                            "Les classements se synchronisent progressivement. Actualise plus tard; aucun faux classement n’est affiché."),15,subText,false));
                    Button refresh=btn("🔄 "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"));
                    refresh.setOnClickListener(v->refreshOnlineSafe(true));
                    empty.addView(refresh);
                }
            }else{
                empty.addView(label("🇭🇷 "+t2("Official HNL table is waiting to synchronize","Čekanje sinkronizacije službene HNL tablice","Offizielle HNL-Tabelle wartet auf Synchronisierung","Esperando la tabla oficial de HNL","Classement officiel HNL en attente"),23,text,true));
                empty.addView(label(t2("Run the data updater and refresh the app. Existing verified data is kept if the official page is temporarily unavailable.","Pokreni podatkovni updater i osvježi aplikaciju. Postojeći provjereni podaci ostaju sačuvani ako službena stranica privremeno nije dostupna.","Daten-Updater ausführen und App aktualisieren. Verifizierte Daten bleiben bei vorübergehendem Ausfall erhalten.","Ejecuta el updater y actualiza la app. Los datos verificados se conservan si la página oficial no está disponible.","Lance l’updater puis actualise l’application. Les données vérifiées sont conservées si la page officielle est indisponible."),15,subText,false));
            }
            return;
        }

        if(competitionName.equals("HNL"))source.addView(label("🛡️ "+t2("Official SuperSport HNL / HNS table","Službena tablica SuperSport HNL / HNS","Offizielle SuperSport-HNL-/HNS-Tabelle","Tabla oficial SuperSport HNL / HNS","Classement officiel SuperSport HNL / HNS"),13,GREEN,true));
        String updated=entry.optString("updatedAt",prefs.getString("online_lastUpdate",""));
        JSONObject season=entry.optJSONObject("season");
        int matchday=season==null?0:season.optInt("currentMatchday",0);
        source.addView(label(t2("Verified standings","Provjerena tablica","Verifizierte Tabelle","Clasificación verificada","Classement vérifié")+(matchday>0?"  •  "+t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+matchday:"")+"\n"+lastUpdateLabel(updated),13,subText,false));

        JSONArray standings=entry.optJSONArray("standings");
        boolean rendered=false;
        if(competitionUsesStrictCurrentRoster(competitionName)){
            JSONArray cleanTable=verifiedTotalStandingTable(competitionName);
            if(cleanTable!=null&&cleanTable.length()>0){
                rendered=true;
                LinearLayout tableCard=card();
                tableCard.addView(label("🏆 "+t2("Overall table","Ukupna tablica","Gesamttabelle","Tabla general","Classement général"),21,text,true));
                tableCard.addView(verifiedStandingHeader());
                for(int j=0;j<cleanTable.length();j++){
                    JSONObject row=cleanTable.optJSONObject(j);
                    if(row!=null)tableCard.addView(verifiedStandingRow(row));
                }
            }
        }
        if(!competitionUsesStrictCurrentRoster(competitionName)&&standings!=null)for(int i=0;i<standings.length();i++){
            JSONObject standing=standings.optJSONObject(i);
            if(standing==null)continue;
            String type=standing.optString("type","");
            if(type.length()>0&&!type.equalsIgnoreCase("TOTAL"))continue;
            JSONArray table=standing.optJSONArray("table");
            if(table==null||table.length()==0)continue;
            rendered=true;
            String group=standing.optString("group","");
            if(group==null||group.trim().equalsIgnoreCase("null"))group="";
            String stage=normalizeStage(standing.optString("stage",""));
            if(stage!=null&&stage.trim().equalsIgnoreCase("null"))stage="";
            LinearLayout tableCard=card();
            String heading=(group!=null&&group.trim().length()>0)?group.replace('_',' '):(stage.length()>0?stage:t2("Overall table","Ukupna tablica","Gesamttabelle","Tabla general","Classement général"));
            tableCard.addView(label("🏆 "+heading,21,text,true));
            tableCard.addView(verifiedStandingHeader());
            for(int j=0;j<table.length();j++){
                JSONObject row=table.optJSONObject(j);
                if(row!=null)tableCard.addView(verifiedStandingRow(row));
            }
        }

        if(!rendered){
            LinearLayout empty=card();
            empty.addView(label(t2("The source returned no overall table for this competition.","Izvor nije vratio ukupnu tablicu za ovo natjecanje.","Die Quelle lieferte keine Gesamttabelle für diesen Wettbewerb.","La fuente no devolvió una tabla general para esta competición.","La source n’a fourni aucun classement général pour cette compétition."),15,subText,false));
        }
    }

    LinearLayout verifiedStandingHeader(){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(8),dp(6),dp(8));
        row.setBackground(round(chipBg,dp(12),0));
        row.addView(standingCell("#",11,subText,true,dp(30),0));
        row.addView(standingCell(t2("TEAM","KLUB","TEAM","EQUIPO","ÉQUIPE"),11,subText,true,0,1));
        row.addView(standingCell("P",11,subText,true,dp(34),0));
        row.addView(standingCell("GD",11,subText,true,dp(42),0));
        row.addView(standingCell("PTS",11,subText,true,dp(44),0));
        return row;
    }

    LinearLayout verifiedStandingRow(JSONObject item){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(9),dp(6),dp(9));
        JSONObject team=item.optJSONObject("team");
        String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
        boolean favourite=sameTeam(teamName,primaryFavoriteClub());
        if(favourite)row.setBackground(round(Color.argb(42,255,48,94),dp(12),1));
        row.addView(standingCell(String.valueOf(item.optInt("position",0)),13,favourite?RED:subText,true,dp(30),0));
        row.addView(standingCell(teamName,14,text,favourite,0,1));
        row.addView(standingCell(String.valueOf(item.optInt("playedGames",0)),13,text,false,dp(34),0));
        int gd=item.optInt("goalDifference",0);
        row.addView(standingCell((gd>0?"+":"")+gd,13,gd>0?GREEN:(gd<0?RED:subText),true,dp(42),0));
        row.addView(standingCell(String.valueOf(item.optInt("points",0)),14,text,true,dp(44),0));
        return row;
    }

    TextView standingCell(String value,int sp,int color,boolean bold,int widthDp,int weight){
        TextView view=label(value,sp,color,bold);
        view.setGravity(widthDp>0?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        view.setSingleLine(true);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp=weight>0?new LinearLayout.LayoutParams(0,dp(38),weight):new LinearLayout.LayoutParams(widthDp,dp(38));
        view.setLayoutParams(lp);
        return view;
    }

    void showLeagueStats(String competitionName){
        clear(competitionName,t2("Verified competition statistics","Provjerena statistika natjecanja","Verifizierte Wettbewerbsstatistik","Estadísticas verificadas","Statistiques vérifiées"),"Leagues");
        LinearLayout c=card();
        c.addView(label("🛡️ "+t2("No placeholder statistics","Bez izmišljene statistike","Keine Platzhalter-Statistik","Sin estadísticas inventadas","Aucune statistique fictive"),23,text,true));
        c.addView(label(t2("Top scorers, assists and trends will appear only after the connected source publishes them.","Najbolji strijelci, asistencije i trendovi pojavit će se tek kada ih povezani izvor objavi.","Torschützen, Assists und Trends erscheinen erst, wenn die verbundene Quelle sie veröffentlicht.","Goleadores, asistencias y tendencias aparecerán solo cuando la fuente conectada los publique.","Buteurs, passes décisives et tendances apparaîtront uniquement lorsque la source les publiera."),15,subText,false));
    }

    String followedCompetitionText(){
        if(followedCompetitions==null || followedCompetitions.isEmpty()) return t2("No competitions followed yet","Još ne pratiš nijedno natjecanje","Noch keine Wettbewerbe gefolgt","Aún no sigues competiciones","Aucune compétition suivie");
        StringBuilder b=new StringBuilder();
        for(String c:followedCompetitions){if(b.length()>0)b.append("  •  ");b.append(c);}
        return b.toString();
    }

    String favoriteClubText(){
        if(favoriteClubs==null || favoriteClubs.isEmpty()) return favoriteClub;
        StringBuilder b=new StringBuilder(); int i=0;
        for(String c:favoriteClubs){ if(i>0)b.append(" • "); b.append(displayTeamName(c)); i++; if(i>=3){ if(favoriteClubs.size()>3)b.append(" +").append(favoriteClubs.size()-3); break; } }
        return b.toString();
    }

    String canonicalFavoriteClubName(String club){
        if(club==null)return "";
        String trimmed=club.trim();
        if(trimmed.isEmpty())return "";
        String canonical=ClubIdentityRegistry.canonicalName(trimmed);
        return canonical==null||canonical.trim().isEmpty()?trimmed:canonical.trim();
    }

    void removeFavoriteAliases(String club){
        if(club==null||favoriteClubs==null)return;
        ArrayList<String> remove=new ArrayList<String>();
        for(String selected:favoriteClubs)if(sameTeam(selected,club))remove.add(selected);
        favoriteClubs.removeAll(remove);
    }

    void normalizeFavoriteClubSelections(){
        LinkedHashSet<String> normalized=new LinkedHashSet<String>();
        if(favoriteClubs!=null)for(String selected:favoriteClubs){
            String canonical=canonicalFavoriteClubName(selected);
            if(!canonical.isEmpty()){
                boolean duplicate=false;for(String existing:normalized)if(sameTeam(existing,canonical)){duplicate=true;break;}
                if(!duplicate)normalized.add(canonical);
            }
        }
        String primary=canonicalFavoriteClubName(favoriteClub);
        if(!primary.isEmpty()){
            boolean found=false;for(String existing:normalized)if(sameTeam(existing,primary)){primary=existing;found=true;break;}
            if(!found)normalized.add(primary);
        }
        favoriteClubs=normalized;
        if(primary.isEmpty()&&!favoriteClubs.isEmpty())primary=favoriteClubs.iterator().next();
        favoriteClub=primary;
        userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
    }

    void toggleFavoriteClub(String club){
        String name=canonicalFavoriteClubName(club);
        if(name.isEmpty())return;
        boolean selected=isFavoriteClubName(name);
        if(selected){
            boolean removingPrimary=sameTeam(name,favoriteClub);
            removeFavoriteAliases(name);
            if(removingPrimary)favoriteClub=favoriteClubs.isEmpty()?"":favoriteClubs.iterator().next();
        }else{
            removeFavoriteAliases(name);
            favoriteClubs.add(name);
            if(favoriteClub==null||favoriteClub.trim().isEmpty())favoriteClub=name;
        }
        userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
        invalidateClubProfileCache();
        syncMatchRemindersAsync();
    }

    void makePrimaryClub(String club){
        String name=canonicalFavoriteClubName(club);
        if(name.isEmpty())return;
        removeFavoriteAliases(name);
        favoriteClubs.add(name);
        favoriteClub=name;
        userPreferences.saveFavoriteClubs(favoriteClubs,favoriteClub);
        userPreferences.savePrimaryClub(favoriteClub);
        invalidateClubProfileCache();
        syncMatchRemindersAsync();
    }

    ArrayList<ClubProfile> favoriteClubDirectoryProfiles(){
        // Favorites must use one verified canonical club directory. Runtime standings/matches
        // may contain provider aliases or even non-club teams; they must never create a
        // second visible copy of the same club in the Favorites picker.
        LinkedHashMap<String,ClubProfile> unique=new LinkedHashMap<String,ClubProfile>();
        for(ClubProfile profile:ClubIdentityRegistry.all()){
            if(profile==null||profile.name==null||profile.name.trim().isEmpty())continue;
            String canonical=canonicalFavoriteClubName(profile.name);
            String key=teamKey(canonical);
            if(key.isEmpty())continue;
            ClubProfile verified=ClubIdentityRegistry.resolve(canonical);
            unique.put(key,verified!=null?verified:profile);
        }
        // Preserve already saved favorites only when they resolve to a verified identity.
        if(favoriteClubs!=null)for(String saved:favoriteClubs){
            ClubProfile verified=ClubIdentityRegistry.resolve(saved);
            if(verified==null)continue;
            String key=teamKey(verified.name);
            if(!key.isEmpty())unique.put(key,verified);
        }
        ArrayList<ClubProfile> result=new ArrayList<ClubProfile>(unique.values());
        Collections.sort(result,(a,b)->{int c=a.competition.compareToIgnoreCase(b.competition);return c!=0?c:a.name.compareToIgnoreCase(b.name);});
        return result;
    }

    ArrayList<String> clubCompetitionOptions(ArrayList<ClubProfile> clubs){
        LinkedHashSet<String> values=new LinkedHashSet<String>();
        for(ClubProfile club:clubs)if(club.competition!=null&&club.competition.length()>0)values.add(club.competition);
        return new ArrayList<String>(values);
    }

    boolean clubMatchesPicker(ClubProfile club,String query,String competition){
        if(club==null)return false;
        if(competition!=null&&!competition.equals("ALL")&&!competition.equals(club.competition))return false;
        String q=query==null?"":query.trim().toLowerCase(homeLocale());
        if(q.length()==0)return true;
        String hay=(club.name+" "+displayTeamName(club.name)+" "+club.competition+" "+club.country).toLowerCase(homeLocale());
        return hay.contains(q);
    }

    boolean isFavoriteClubName(String name){
        if(name==null||favoriteClubs==null)return false;
        for(String favorite:favoriteClubs)if(sameTeam(favorite,name))return true;
        return false;
    }

    String compactCompetitionName(String competition){
        if(competition==null||competition.trim().length()==0)return t2("Club","Klub","Klub","Club","Club");
        if(competition.equals("UEFA Champions League"))return t2("Champions League","Liga prvaka","Champions League","Champions League","Ligue des champions");
        if(competition.equals("Brasileirão Série A"))return "Brasileirão A";
        if(competition.equals("UEFA European Championship"))return t2("European Championship","Europsko prvenstvo","Europameisterschaft","Eurocopa","Championnat d’Europe");
        return displayCompetitionName(competition);
    }

    TextView clubPickerSectionLabel(String value){
        TextView heading=label(value,12,subText,true);
        heading.setAllCaps(true);
        heading.setPadding(dp(4),dp(12),dp(4),dp(5));
        return heading;
    }

    void renderClubPicker(LinearLayout target){
        target.removeAllViews();
        ArrayList<ClubProfile> clubs=favoriteClubDirectoryProfiles();
        LinkedHashMap<String,ClubProfile> uniqueFiltered=new LinkedHashMap<String,ClubProfile>();
        for(ClubProfile club:clubs)if(clubMatchesPicker(club,favoriteClubSearch,favoriteClubCompetitionFilter)){
            String key=teamKey(canonicalFavoriteClubName(club.name));
            if(!key.isEmpty()&&!uniqueFiltered.containsKey(key))uniqueFiltered.put(key,club);
        }
        ArrayList<ClubProfile> filtered=new ArrayList<ClubProfile>(uniqueFiltered.values());
        Collections.sort(filtered,(a,b)->{
            boolean ap=sameTeam(a.name,favoriteClub),bp=sameTeam(b.name,favoriteClub);
            if(ap!=bp)return ap?-1:1;
            boolean af=isFavoriteClubName(a.name),bf=isFavoriteClubName(b.name);
            if(af!=bf)return af?-1:1;
            int byCompetition=a.competition.compareToIgnoreCase(b.competition);
            return byCompetition!=0?byCompetition:a.name.compareToIgnoreCase(b.name);
        });
        if(filtered.isEmpty()){
            LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(24),dp(12),dp(18));
            empty.addView(centerLabel("⚽",34,text,true));
            empty.addView(centerLabel(t2("No clubs found","Nema pronađenih klubova","Keine Klubs gefunden","No se encontraron clubes","Aucun club trouvé"),16,text,true));
            empty.addView(centerLabel(t2("Try another name or competition.","Pokušaj drugi naziv ili natjecanje.","Versuche einen anderen Namen oder Wettbewerb.","Prueba otro nombre o competición.","Essaie un autre nom ou une autre compétition."),12,subText,false));
            target.addView(empty);
            return;
        }

        int shown=Math.min(favoriteClubPickerLimit,filtered.size());
        boolean broad=favoriteClubSearch.trim().length()==0&&favoriteClubCompetitionFilter.equals("ALL");
        boolean followingHeadingShown=false,allHeadingShown=false;
        int followedVisible=0;for(int i=0;i<shown;i++)if(isFavoriteClubName(filtered.get(i).name))followedVisible++;
        for(int i=0;i<shown;i++){
            ClubProfile profile=filtered.get(i);
            boolean followed=isFavoriteClubName(profile.name);
            if(broad&&followed&&!followingHeadingShown){
                target.addView(clubPickerSectionLabel(t2("Following","Pratim","Gefolgt","Siguiendo","Suivis")+"  "+followedVisible));
                followingHeadingShown=true;
            }
            if(broad&&!followed&&!allHeadingShown){
                target.addView(clubPickerSectionLabel(t2("All clubs","Svi klubovi","Alle Klubs","Todos los clubes","Tous les clubs")));
                allHeadingShown=true;
            }
            target.addView(favoriteClubPickerRow(profile));
        }
        if(filtered.size()>shown){
            Button more=outline(t2("Show more clubs","Prikaži još klubova","Mehr Klubs anzeigen","Mostrar más clubes","Afficher plus de clubs")+"  +"+(filtered.size()-shown));
            more.setOnClickListener(v->{favoriteClubPickerLimit+=18;renderClubPicker(target);});
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(50));mp.setMargins(0,dp(8),0,0);target.addView(more,mp);
        }
        TextView count=label(shown+" / "+filtered.size()+" "+t2("clubs shown","klubova prikazano","Klubs angezeigt","clubes mostrados","clubs affichés"),11,subText,false);
        count.setPadding(dp(4),dp(9),dp(4),0);target.addView(count);
    }

    LinearLayout favoriteClubPickerRow(ClubProfile profile){
        final String clubName=profile.name;
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(9),dp(9),dp(9));
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(round(chipBg,dp(18),1));
        row.setClickable(true);
        row.setOnClickListener(v->showClubCenter(clubName));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(4),0,dp(4));row.setLayoutParams(rp);

        View visual=homeTeamVisual(clubName,dp(54),false);
        row.addView(visual,new LinearLayout.LayoutParams(dp(54),dp(54)));

        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,dp(5),0);
        String visibleClubName=displayTeamName(clubName);
        TextView name=label(visibleClubName,visibleClubName.length()>24?13:15,text,true);
        name.setSingleLine(false);name.setMaxLines(2);name.setEllipsize(null);name.setLineSpacing(0,0.94f);
        copy.addView(name);
        boolean primary=sameTeam(clubName,favoriteClub);
        String meta=(primary?"★ "+t2("Primary","Glavni","Haupt","Principal","Principal")+"  •  ":clubCountryFlag(clubName)+" ")+compactCompetitionName(profile.competition);
        TextView metaView=label(meta,11,primary?RED:subText,primary);metaView.setSingleLine(true);metaView.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(metaView);
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));

        boolean selected=isFavoriteClubName(clubName);
        Button follow=selected?btn("✓"):outline("＋");follow.setTextSize(17);follow.setPadding(0,0,0,0);
        follow.setContentDescription(selected?t2("Stop following club","Prestani pratiti klub","Klub nicht mehr folgen","Dejar de seguir club","Ne plus suivre le club"):t2("Follow club","Prati klub","Klub folgen","Seguir club","Suivre le club"));
        follow.setOnClickListener(v->{toggleFavoriteClub(clubName);showFavorites();});
        row.addView(follow,new LinearLayout.LayoutParams(dp(50),dp(50)));

        Button primaryButton=outline(primary?"★":"☆");primaryButton.setTextSize(20);primaryButton.setPadding(0,0,0,0);
        primaryButton.setEnabled(!primary);primaryButton.setContentDescription(t2("Set as primary club","Postavi kao glavni klub","Als Hauptklub festlegen","Establecer como club principal","Définir comme club principal"));
        primaryButton.setOnClickListener(v->{makePrimaryClub(clubName);showFavorites();});
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(50),dp(50));pp.setMargins(dp(6),0,0,0);row.addView(primaryButton,pp);
        return row;
    }

    ArrayList<Match> clubMatches(String club){
        ArrayList<Match> matches=new ArrayList<Match>();
        if(data!=null)for(Match match:data.matches)if(sameTeam(match.home,club)||sameTeam(match.away,club))matches.add(match);
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return matches;
    }

    Match lastResultForClub(String club){
        Match result=null;
        for(Match match:clubMatches(club))if(matchIsFinished(match))result=match;
        return result;
    }

    String clubStandingPosition(String club){
        String league=clubLeague(club);
        JSONArray table=verifiedTotalStandingTable(league);
        if(table==null)return "—";
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);if(row==null)continue;
            JSONObject team=row.optJSONObject("team");
            String name=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(name,club))return String.valueOf(row.optInt("position",i+1))+".";
        }
        return "—";
    }

    JSONObject clubStandingRow(String club){
        JSONArray table=verifiedTotalStandingTable(clubLeague(club));
        if(table==null)return null;
        for(int i=0;i<table.length();i++){
            JSONObject row=table.optJSONObject(i);if(row==null)continue;
            JSONObject team=row.optJSONObject("team");
            String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
            if(sameTeam(teamName,club))return row;
        }
        return null;
    }

    String signedNumber(int value){return value>0?"+"+value:String.valueOf(value);}

    String clubResultCode(Match match,String club){
        if(match==null||!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)return "—";
        if(match.homeGoals==match.awayGoals)return "D";
        boolean home=sameTeam(match.home,club);
        boolean won=home?match.homeGoals>match.awayGoals:match.awayGoals>match.homeGoals;
        return won?"W":"L";
    }

    ArrayList<Match> finishedClubMatches(String club){
        ArrayList<Match> finished=new ArrayList<Match>();
        for(Match match:clubMatches(club))if(matchIsFinished(match))finished.add(match);
        return finished;
    }

    void addClubFormStrip(LinearLayout target,String club){
        ArrayList<Match> finished=finishedClubMatches(club);
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);
        int first=Math.max(0,finished.size()-5);
        if(first>=finished.size()){
            row.addView(label(t2("Verified form is not available yet.","Provjerena forma još nije dostupna.","Verifizierte Form ist noch nicht verfügbar.","La forma verificada aún no está disponible.","La forme vérifiée n’est pas encore disponible."),13,subText,false));
        }else{
            for(int i=first;i<finished.size();i++){
                String code=clubResultCode(finished.get(i),club);
                int color=code.equals("W")?GREEN:(code.equals("L")?RED:Color.rgb(113,124,145));
                TextView chip=centerLabel(code,14,Color.WHITE,true);chip.setBackground(round(color,dp(22),1));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(44),dp(44));if(i>first)lp.setMargins(dp(8),0,0,0);row.addView(chip,lp);
            }
        }
        target.addView(row);
    }


    void addClubMatchSection(String titleText,String icon,ArrayList<Match> matches,int limit){
        LinearLayout section=card();section.addView(label(icon+" "+titleText,21,text,true));
        if(matches.isEmpty())section.addView(label(t2("No verified matches are available yet.","Još nema dostupnih provjerenih utakmica.","Noch keine verifizierten Spiele verfügbar.","Aún no hay partidos verificados.","Aucun match vérifié disponible."),14,subText,false));
        else{
            int shown=0;
            for(Match match:matches){addDynamicHomeMatch(section,match);if(++shown>=limit)break;}
        }
    }

    int[] clubVerifiedTotals(String club){
        int played=0,wins=0,draws=0,losses=0,goalsFor=0,goalsAgainst=0;
        for(Match match:clubMatches(club)){
            if(!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)continue;
            boolean home=sameTeam(match.home,club);
            int own=home?match.homeGoals:match.awayGoals;
            int opponent=home?match.awayGoals:match.homeGoals;
            played++;goalsFor+=own;goalsAgainst+=opponent;
            if(own>opponent)wins++;else if(own<opponent)losses++;else draws++;
        }
        return new int[]{played,wins,draws,losses,goalsFor,goalsAgainst};
    }

    void addClubPerformanceCard(String club){
        int[] totals=clubVerifiedTotals(club);
        LinearLayout performance=card();
        performance.addView(label("📊 "+t2("Verified performance","Provjerena statistika","Verifizierte Leistung","Rendimiento verificado","Performance vérifiée"),21,text,true));
        if(totals[0]==0){
            performance.addView(label(t2("No completed verified matches are available for this club yet.","Za ovaj klub još nema dovršenih provjerenih utakmica.","Für diesen Klub sind noch keine abgeschlossenen verifizierten Spiele verfügbar.","Aún no hay partidos verificados finalizados para este club.","Aucun match vérifié terminé n’est encore disponible pour ce club."),14,subText,false));
            return;
        }
        LinearLayout first=hrow();
        first.addView(homeStat(String.valueOf(totals[1]),t2("Wins","Pobjede","Siege","Victorias","Victoires"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        first.addView(homeStat(String.valueOf(totals[2]),t2("Draws","Neriješeno","Remis","Empates","Nuls"),null),middle);
        first.addView(homeStat(String.valueOf(totals[3]),t2("Losses","Porazi","Niederlagen","Derrotas","Défaites"),null),new LinearLayout.LayoutParams(0,-2,1));
        performance.addView(first);
        LinearLayout second=hrow();
        second.addView(homeStat(totals[4]+":"+totals[5],t2("Goals","Golovi","Tore","Goles","Buts"),null),new LinearLayout.LayoutParams(0,-2,1));
        double pointsPerGame=(totals[1]*3.0+totals[2])/totals[0];
        LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1);right.setMargins(dp(7),0,0,0);
        second.addView(homeStat(String.format(Locale.US,"%.2f",pointsPerGame),t2("Points / match","Bodovi / utakmica","Punkte / Spiel","Puntos / partido","Points / match"),null),right);
        performance.addView(second);
        performance.addView(label(t2("Calculated only from completed matches currently delivered by the connected source.","Izračunato samo iz dovršenih utakmica koje je trenutačno dostavio povezani izvor.","Nur aus abgeschlossenen Spielen berechnet, die aktuell von der verbundenen Quelle geliefert werden.","Calculado solo con partidos finalizados entregados actualmente por la fuente conectada.","Calculé uniquement à partir des matchs terminés actuellement fournis par la source connectée."),12,subText,false));
    }

    void addClubSquadCard(){
        LinearLayout squad=card();
        squad.addView(label("👥 "+t2("Players","Igrači","Spieler","Jugadores","Joueurs"),21,text,true));
        squad.addView(label(t2("The connected match source does not currently provide a reliable complete squad for every competition. Football Fun will show players here only after a verified player source is connected.","Povezani izvor utakmica trenutačno ne daje pouzdan kompletan kadar za svako natjecanje. Football Fun će ovdje prikazati igrače tek nakon povezivanja provjerenog izvora igrača.","Die verbundene Spielquelle liefert derzeit nicht für jeden Wettbewerb einen zuverlässigen vollständigen Kader. Football Fun zeigt Spieler hier erst nach Anbindung einer verifizierten Spielerquelle.","La fuente conectada no ofrece actualmente una plantilla completa y fiable para todas las competiciones. Football Fun mostrará jugadores aquí cuando se conecte una fuente verificada.","La source connectée ne fournit pas encore un effectif complet et fiable pour chaque compétition. Football Fun affichera les joueurs ici après connexion d’une source vérifiée."),14,subText,false));
        Button unavailable=outline("🔒 "+t2("Verified squad coming next","Provjereni kadar dolazi uskoro","Verifizierter Kader folgt","Plantilla verificada próximamente","Effectif vérifié à venir"));
        unavailable.setEnabled(false);squad.addView(unavailable);
    }

    void showClubCenter(String club){
        currentClubOriginScreen="";
        if(!requirePro(t2("Club centers","Centri klubova","Klubzentren","Centros de clubes","Centres de clubs")))return;
        currentClubOriginCompetition="";
        showClubCenterTab(club,"overview");
    }

    void showClubCenterFromCompetition(String club,String competitionName){
        currentClubOriginScreen="";
        if(!requirePro(t2("Club centers","Centri klubova","Klubzentren","Centros de clubes","Centres de clubs")))return;
        currentClubOriginCompetition=competitionName==null?"":competitionName;
        showClubCenterTab(club,"overview");
    }

    void showClubCenterTab(String club,String selectedTab){
        if(!requirePro(t2("Club centers","Centri klubova","Klubzentren","Centros de clubes","Centres de clubs")))return;
        String name=club==null?primaryFavoriteClub():club;
        currentClubName=name==null?"":name;
        currentClubTab=(selectedTab==null||selectedTab.trim().isEmpty())?"overview":selectedTab;
        String league=clubLeague(name);
        rememberLastDestination("club",name,displayTeamName(name));
        clear(displayTeamName(name),clubCountryFlag(name)+" "+clubCountry(name)+"  •  "+displayCompetitionName(league),"ClubCenter");
        addClubCenterHero(name,league);
        addClubCenterTabs(name,currentClubTab);
        if("fixtures".equals(currentClubTab))showClubFixturesTab(name);
        else if("results".equals(currentClubTab))showClubResultsTab(name);
        else if("table".equals(currentClubTab))showClubTableTab(name,league);
        else if("statistics".equals(currentClubTab))showClubStatisticsTab(name);
        else if("players".equals(currentClubTab))showClubPlayersTab(name);
        else showClubOverviewTab(name,league);
    }

    void addClubCenterHero(String name,String league){
        TeamProfileRecord profile=teamProfileForClub(name);
        int playerCount=playersForClub(name).size();
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(55,16,82),Color.rgb(235,31,86),dp(24)));hero.setPadding(dp(17),dp(17),dp(17),dp(16));
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);
        View visual=homeTeamVisual(name,dp(92),true);row.addView(visual,new LinearLayout.LayoutParams(dp(92),dp(92)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(13),0,0,0);
        copy.addView(label(t2("CLUB PROFILE","PROFIL KLUBA","KLUBPROFIL","PERFIL DEL CLUB","PROFIL DU CLUB"),11,Color.rgb(255,224,133),true));
        String clubCenterDisplayName=displayTeamName(name);
        int clubCenterTitleSize=clubCenterDisplayName.length()>24?19:(clubCenterDisplayName.length()>18?21:24);
        TextView clubTitle=label(clubCenterDisplayName,clubCenterTitleSize,Color.WHITE,true);
        clubTitle.setMaxLines(2);clubTitle.setEllipsize(null);clubTitle.setLineSpacing(0,0.94f);copy.addView(clubTitle);
        ArrayList<String> identity=new ArrayList<String>();
        identity.add(clubCountryFlag(name)+" "+clubCountry(name));
        if(profile!=null&&profile.founded>0)identity.add(t2("Founded","Osnovan","Gegründet","Fundado","Fondé")+" "+profile.founded);
        copy.addView(label(joinParts(identity,"  •  "),13,Color.WHITE,false));
        copy.addView(label("🏆 "+displayCompetitionName(league),13,Color.WHITE,true));
        copy.addView(label("● "+clubProfileStatusText(name),11,Color.rgb(255,224,133),true));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(row);
        addClubCenterQuickStats(hero,name);

        LinearLayout actions=hrow();
        boolean followed=isFavoriteClubName(name);
        Button follow=followed?outline("✓ "+t2("Following","Pratim","Gefolgt","Siguiendo","Suivi")):btn("＋ "+t2("Follow club","Prati klub","Klub folgen","Seguir club","Suivre le club"));
        follow.setOnClickListener(v->{toggleFavoriteClub(name);showClubCenterTab(name,currentClubTab);});actions.addView(follow,new LinearLayout.LayoutParams(0,dp(50),1));
        Button primary=sameTeam(name,favoriteClub)?outline("★ "+t2("Primary club","Glavni klub","Hauptklub","Club principal","Club principal")):outline("☆ "+t2("Set primary","Postavi kao glavni","Als Hauptklub","Hacer principal","Définir principal"));
        primary.setEnabled(!sameTeam(name,favoriteClub));primary.setOnClickListener(v->{makePrimaryClub(name);showClubCenterTab(name,currentClubTab);});
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(50),1);ap.setMargins(dp(8),0,0,0);actions.addView(primary,ap);hero.addView(actions);
    }

    String clubRecentFormText(String club){
        ArrayList<Match> finished=finishedClubMatches(club);
        int first=Math.max(0,finished.size()-5);
        if(first>=finished.size())return "—";
        StringBuilder form=new StringBuilder();
        for(int i=first;i<finished.size();i++){
            if(form.length()>0)form.append(" ");
            form.append(clubResultCode(finished.get(i),club));
        }
        return form.toString();
    }

    void addClubCenterQuickStats(LinearLayout hero,String club){
        JSONObject standing=clubStandingRow(club);
        int playerCount=playersForClub(club).size();
        String position=standing==null?"—":String.valueOf(standing.optInt("position",0))+".";
        String points=standing==null?"—":String.valueOf(standing.optInt("points",0));
        String squad=playerCount>0?String.valueOf(playerCount):"—";
        LinearLayout stats=hrow();stats.setPadding(0,dp(9),0,dp(9));
        stats.addView(homeStat(position,t2("Position","Pozicija","Position","Posición","Position"),standing==null?null:v->showClubCenterTab(club,"table")),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);
        stats.addView(homeStat(points,t2("Points","Bodovi","Punkte","Puntos","Points"),null),middle);
        stats.addView(homeStat(squad,t2("Players","Igrača","Spieler","Jugadores","Joueurs"),playerCount>0?v->showClubCenterTab(club,"players"):null),new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(stats);
    }

    String clubProfileStatusText(String club){
        TeamProfileRecord profile=teamProfileForClub(club);int playerCount=playersForClub(club).size();int available=0,total=8;
        if(profile!=null){if(profile.area.length()>0)available++;if(profile.founded>0)available++;if(profile.venue.length()>0)available++;if(profile.coachName.length()>0)available++;if(profile.clubColors.length()>0)available++;if(profile.address.length()>0)available++;if(profile.website.length()>0)available++;}
        if(playerCount>0)available++;
        if(available>=7)return t2("Profile data complete","Profil gotovo potpun","Profildaten vollständig","Perfil casi completo","Profil presque complet");
        if(available>=4)return t2("Verified profile data available","Dostupni provjereni podaci","Verifizierte Profildaten verfügbar","Datos verificados disponibles","Données vérifiées disponibles");
        return t2("Additional profile data is not yet available","Dodatni podaci profila još nisu dostupni","Zusätzliche Profildaten sind noch nicht verfügbar","Los datos adicionales del perfil aún no están disponibles","Les données supplémentaires du profil ne sont pas encore disponibles");
    }

    String cleanProfileTimestamp(String value){
        if(value==null||value.trim().isEmpty())return "";String out=value.trim().replace('T',' ').replace("Z","");
        if(out.length()>16)out=out.substring(0,16);return out;
    }

    void addClubInfoLine(LinearLayout parent,String caption,String value){
        if(value==null||value.trim().isEmpty())return;
        LinearLayout row=hrow();row.setGravity(Gravity.TOP);row.setPadding(dp(2),dp(7),dp(2),dp(7));
        TextView left=label(caption,12,subText,true);left.setMaxLines(2);row.addView(left,new LinearLayout.LayoutParams(dp(116),-2));
        TextView right=label(value.trim(),14,text,true);right.setGravity(Gravity.END);right.setMaxLines(3);right.setEllipsize(android.text.TextUtils.TruncateAt.END);row.addView(right,new LinearLayout.LayoutParams(0,-2,1));
        parent.addView(row);
    }

    void addClubMatchSnapshot(String club){
        LinearLayout center=card();center.addView(label("⚽ "+t2("Match center","Centar utakmica","Spielzentrum","Centro de partidos","Centre des matchs"),21,text,true));
        Match next=nextMatchForTeam(club);center.addView(label(t2("NEXT MATCH","SLJEDEĆA UTAKMICA","NÄCHSTES SPIEL","PRÓXIMO PARTIDO","PROCHAIN MATCH"),11,subText,true));
        if(next!=null)addDynamicHomeMatch(center,next,true,false,true);
        else if(hnlAwaitingResultConfirmationForTeam(club))center.addView(label(t2("Waiting for verified HNL match status before showing the next fixture.","Čeka se potvrda HNL podataka prije prikaza sljedeće utakmice.","Vor der Anzeige des nächsten Spiels wird auf bestätigte HNL-Daten gewartet.","Se espera la confirmación HNL antes de mostrar el próximo partido.","En attente de données HNL confirmées avant d’afficher le prochain match."),13,subText,false));
        else center.addView(label(t2("No upcoming verified match is available.","Nema dostupne sljedeće provjerene utakmice.","Kein nächstes verifiziertes Spiel verfügbar.","No hay próximo partido verificado.","Aucun prochain match vérifié disponible."),13,subText,false));
        Button fixtures=outline("📅 "+t2("Open full schedule","Otvori cijeli raspored","Gesamten Spielplan öffnen","Abrir calendario completo","Ouvrir tout le calendrier"));fixtures.setOnClickListener(v->showClubCenterTab(club,"fixtures"));center.addView(fixtures);
        Match last=lastResultForClub(club);center.addView(label(t2("LAST RESULT","POSLJEDNJI REZULTAT","LETZTES ERGEBNIS","ÚLTIMO RESULTADO","DERNIER RÉSULTAT"),11,subText,true));
        if(last!=null)addDynamicHomeMatch(center,last,true,true,false);else center.addView(label(t2("No completed verified match is available.","Nema dostupne završene provjerene utakmice.","Kein abgeschlossenes verifiziertes Spiel verfügbar.","No hay partido verificado finalizado.","Aucun match vérifié terminé disponible."),13,subText,false));
        Button results=outline("✓ "+t2("Open all results","Otvori sve rezultate","Alle Ergebnisse öffnen","Abrir todos los resultados","Ouvrir tous les résultats"));results.setOnClickListener(v->showClubCenterTab(club,"results"));center.addView(results);
    }

    void addClubDataCoverageCard(String club){
        TeamProfileRecord profile=teamProfileForClub(club);int playerCount=playersForClub(club).size();int identityFields=0;
        if(profile!=null){if(profile.area.length()>0)identityFields++;if(profile.founded>0)identityFields++;if(profile.venue.length()>0)identityFields++;if(profile.coachName.length()>0)identityFields++;if(profile.clubColors.length()>0)identityFields++;if(profile.address.length()>0)identityFields++;if(profile.website.length()>0)identityFields++;}
        LinearLayout coverage=card();coverage.addView(label("✓ "+t2("Data coverage","Pokrivenost podataka","Datenabdeckung","Cobertura de datos","Couverture des données"),21,text,true));
        String extraDetails=identityFields>0?String.valueOf(identityFields):"—";
        LinearLayout row=hrow();row.addView(homeStat(extraDetails,t2("Additional club details","Dodatni podaci kluba","Zusätzliche Klubdaten","Datos adicionales del club","Données supplémentaires du club"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams squadParams=new LinearLayout.LayoutParams(0,-2,1);squadParams.setMargins(dp(8),0,0,0);row.addView(homeStat(playerCount>0?String.valueOf(playerCount):"—",t2("Squad profiles","Profili igrača","Kaderprofile","Perfiles de plantilla","Profils d’effectif"),playerCount>0?v->showClubCenterTab(club,"players"):null),squadParams);coverage.addView(row);
        String updated=profile==null?"":cleanProfileTimestamp(profile.lastUpdated);if(updated.length()>0)coverage.addView(label("↻ "+t2("Profile updated","Profil ažuriran","Profil aktualisiert","Perfil actualizado","Profil actualisé")+": "+updated,12,subText,false));
        coverage.addView(label(t2("Missing values are left empty and will appear automatically only when the connected verified source supplies them.","Podaci koji nedostaju ostaju prazni i automatski će se prikazati samo kada ih dostavi povezani provjereni izvor.","Fehlende Werte bleiben leer und erscheinen automatisch, sobald die verifizierte Quelle sie liefert.","Los valores faltantes permanecerán vacíos y aparecerán cuando la fuente verificada los proporcione.","Les valeurs manquantes restent vides et apparaissent lorsque la source vérifiée les fournit."),12,subText,false));
        Button refresh=outline("↻ "+t2("Refresh profile data","Osvježi podatke profila","Profildaten aktualisieren","Actualizar perfil","Actualiser le profil"));refresh.setOnClickListener(v->refreshOnlineSafe(true));coverage.addView(refresh);
    }


    void addClubCenterTabs(String club,String selected){
        LinearLayout tabs=card();
        String[][] values={{"overview","⌂ "+t2("Overview","Pregled","Übersicht","Resumen","Aperçu")},{"fixtures","📅 "+t2("Fixtures","Raspored","Spielplan","Calendario","Calendrier")},{"results","✓ "+t2("Results","Rezultati","Ergebnisse","Resultados","Résultats")},{"table","▤ "+t2("Table","Tablica","Tabelle","Tabla","Classement")},{"statistics","📊 "+t2("Statistics","Statistika","Statistiken","Estadísticas","Statistiques")},{"players","👥 "+t2("Players","Igrači","Spieler","Jugadores","Joueurs")}};
        for(int r=0;r<2;r++){
            LinearLayout line=hrow();
            for(int c=0;c<3;c++){
                int i=r*3+c;String key=values[i][0];
                Button b=key.equals(selected)?btn(values[i][1]):outline(values[i][1]);b.setTextSize(11);
                b.setOnClickListener(v->showClubCenterTab(club,key));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);if(c>0)lp.setMargins(dp(6),0,0,0);line.addView(b,lp);
            }
            tabs.addView(line);if(r==0){Space gap=new Space(this);tabs.addView(gap,new LinearLayout.LayoutParams(1,dp(7)));}
        }
    }

    void showClubOverviewTab(String name,String league){
        JSONObject standing=clubStandingRow(name);
        int[] totals=clubVerifiedTotals(name);
        LinearLayout season=card();season.addView(label("📈 "+t2("Season overview","Pregled sezone","Saisonübersicht","Resumen de temporada","Aperçu de la saison"),21,text,true));
        LinearLayout top=hrow();
        String position=standing==null?"—":String.valueOf(standing.optInt("position",0))+".";
        String points=standing==null?"—":String.valueOf(standing.optInt("points",0));
        String record=(standing!=null&&standing.has("won")&&standing.has("draw")&&standing.has("lost"))
                ?standing.optInt("won",0)+"-"+standing.optInt("draw",0)+"-"+standing.optInt("lost",0)
                :(totals[0]>0?totals[1]+"-"+totals[2]+"-"+totals[3]:"—");
        top.addView(homeStat(position,t2("Position","Pozicija","Position","Posición","Position"),standing==null?null:v->showClubCenterTab(name,"table")),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(7),0,dp(7),0);top.addView(homeStat(points,t2("Points","Bodovi","Punkte","Puntos","Points"),null),mid);
        top.addView(homeStat(record,t2("W-D-L","P-N-I","S-U-N","G-E-P","V-N-D"),totals[0]>0?v->showClubCenterTab(name,"statistics"):null),new LinearLayout.LayoutParams(0,-2,1));season.addView(top);
        season.addView(label(t2("Last five verified matches","Zadnjih pet provjerenih utakmica","Letzte fünf verifizierte Spiele","Últimos cinco partidos verificados","Cinq derniers matchs vérifiés"),13,subText,true));addClubFormStrip(season,name);
        if(standing==null&&totals[0]==0)season.addView(label(t2("Season data will fill automatically as verified matches and tables arrive.","Podaci sezone automatski će se popunjavati dolaskom provjerenih utakmica i tablica.","Saisondaten werden automatisch mit verifizierten Spielen und Tabellen ergänzt.","Los datos de la temporada se completarán al llegar partidos y tablas verificados.","Les données de saison se compléteront avec les matchs et classements vérifiés."),12,subText,false));

        addClubIdentityCard(name,league);
        addClubMatchSnapshot(name);
        addClubSquadPreview(name);
        addClubDataCoverageCard(name);
    }

    ArrayList<Match> clubUpcomingMatches(String club){
        ArrayList<Match> result=new ArrayList<Match>();
        for(Match m:clubMatches(club))if(matchIsUpcoming(m))result.add(m);
        return result;
    }

    ArrayList<Match> clubRecentResults(String club){
        ArrayList<Match> result=new ArrayList<Match>();for(Match m:clubMatches(club))if(matchIsFinished(m))result.add(0,m);return result;
    }

    void showClubFixturesTab(String name){
        ArrayList<Match> matches=clubUpcomingMatches(name);LinearLayout section=card();section.addView(label("📅 "+t2("All upcoming fixtures","Sve nadolazeće utakmice","Alle kommenden Spiele","Todos los próximos partidos","Tous les prochains matchs"),21,text,true));
        if(matches.isEmpty())section.addView(label(t2("No upcoming verified fixtures are available.","Nema dostupnih nadolazećih provjerenih utakmica.","Keine kommenden verifizierten Spiele verfügbar.","No hay próximos partidos verificados.","Aucun prochain match vérifié disponible."),14,subText,false));
        else for(Match match:matches)addDynamicHomeMatch(section,match,true,false,true);
    }

    void showClubResultsTab(String name){
        ArrayList<Match> matches=clubRecentResults(name);LinearLayout section=card();section.addView(label("✅ "+t2("Completed matches","Završene utakmice","Abgeschlossene Spiele","Partidos finalizados","Matchs terminés"),21,text,true));
        if(matches.isEmpty())section.addView(label(t2("No completed verified results are available.","Nema dostupnih završenih provjerenih rezultata.","Keine abgeschlossenen verifizierten Ergebnisse verfügbar.","No hay resultados verificados finalizados.","Aucun résultat vérifié terminé disponible."),14,subText,false));
        else for(Match match:matches)addDynamicHomeMatch(section,match);
    }

    void showClubTableTab(String name,String league){
        JSONArray table=verifiedTotalStandingTable(league);LinearLayout tableCard=card();tableCard.addView(label("🏆 "+displayCompetitionName(league),21,text,true));
        if(table==null)tableCard.addView(label(t2("The verified table is still synchronizing.","Provjerena tablica još se sinkronizira.","Die verifizierte Tabelle wird noch synchronisiert.","La tabla verificada aún se sincroniza.","Le classement vérifié se synchronise encore."),14,subText,false));
        else{
            tableCard.addView(verifiedStandingHeader());
            for(int i=0;i<table.length();i++){
                JSONObject item=table.optJSONObject(i);if(item==null)continue;JSONObject team=item.optJSONObject("team");String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
                LinearLayout row=verifiedStandingRow(item);if(sameTeam(teamName,name))row.setBackground(round(Color.argb(70,235,31,86),dp(12),1));tableCard.addView(row);
            }
        }
    }

    int[] clubVerifiedSplitTotals(String club,boolean homeOnly){
        int played=0,wins=0,draws=0,losses=0,goalsFor=0,goalsAgainst=0;
        for(Match match:clubMatches(club)){
            if(!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)continue;
            boolean isHome=sameTeam(match.home,club);
            if(isHome!=homeOnly)continue;
            int own=isHome?match.homeGoals:match.awayGoals;
            int opponent=isHome?match.awayGoals:match.homeGoals;
            played++;goalsFor+=own;goalsAgainst+=opponent;
            if(own>opponent)wins++;else if(own<opponent)losses++;else draws++;
        }
        return new int[]{played,wins,draws,losses,goalsFor,goalsAgainst};
    }

    int clubCleanSheets(String club){int count=0;for(Match match:clubMatches(club)){if(!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)continue;boolean home=sameTeam(match.home,club);int conceded=home?match.awayGoals:match.homeGoals;if(conceded==0)count++;}return count;}
    int clubFailedToScore(String club){int count=0;for(Match match:clubMatches(club)){if(!matchIsFinished(match)||match.homeGoals<0||match.awayGoals<0)continue;boolean home=sameTeam(match.home,club);int scored=home?match.homeGoals:match.awayGoals;if(scored==0)count++;}return count;}


    View clubSplitStatCard(String title,int[] totals){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(14),dp(14),dp(14));box.setBackground(round(chipBg,dp(18),1));
        TextView heading=label(title,15,text,true);heading.setGravity(Gravity.CENTER);box.addView(heading);
        String record=totals[0]==0?"—":totals[1]+"-"+totals[2]+"-"+totals[3];
        TextView main=label(record,24,RED,true);main.setGravity(Gravity.CENTER);box.addView(main);
        String detail=totals[0]==0?t2("No data","Nema podataka","Keine Daten","Sin datos","Aucune donnée"):
                totals[0]+" "+t2("played","odigrano","gespielt","jugados","joués")+"  •  "+totals[4]+":"+totals[5];
        TextView meta=label(detail,12,subText,false);meta.setGravity(Gravity.CENTER);box.addView(meta);
        return box;
    }

    void showClubStatisticsTab(String name){
        int[] totals=clubVerifiedTotals(name);LinearLayout performance=card();performance.addView(label("📊 "+t2("Club statistics","Statistika kluba","Klubstatistik","Estadísticas del club","Statistiques du club"),21,text,true));
        if(totals[0]==0){performance.addView(label(t2("No completed verified matches are available for statistics.","Nema završenih provjerenih utakmica za statistiku.","Keine abgeschlossenen verifizierten Spiele für Statistiken verfügbar.","No hay partidos verificados finalizados para estadísticas.","Aucun match vérifié terminé pour les statistiques."),14,subText,false));return;}
        double winRate=totals[1]*100.0/totals[0];double pointsPerMatch=(totals[1]*3.0+totals[2])/totals[0];
        LinearLayout first=hrow();first.addView(homeStat(String.valueOf(totals[1]),t2("Wins","Pobjede","Siege","Victorias","Victoires"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams middle=new LinearLayout.LayoutParams(0,-2,1);middle.setMargins(dp(7),0,dp(7),0);first.addView(homeStat(String.valueOf(totals[2]),t2("Draws","Neriješeno","Remis","Empates","Nuls"),null),middle);first.addView(homeStat(String.valueOf(totals[3]),t2("Losses","Porazi","Niederlagen","Derrotas","Défaites"),null),new LinearLayout.LayoutParams(0,-2,1));performance.addView(first);
        LinearLayout rates=hrow();rates.addView(homeStat(String.format(Locale.US,"%.0f%%",winRate),t2("Win rate","Postotak pobjeda","Siegquote","Porcentaje de victorias","Taux de victoire"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams rateRight=new LinearLayout.LayoutParams(0,-2,1);rateRight.setMargins(dp(7),0,0,0);rates.addView(homeStat(String.format(Locale.US,"%.2f",pointsPerMatch),t2("Points / match","Bodovi / utakmica","Punkte / Spiel","Puntos / partido","Points / match"),null),rateRight);performance.addView(rates);
        LinearLayout goals=hrow();goals.addView(homeStat(String.format(Locale.US,"%.2f",totals[4]/(double)totals[0]),t2("Scored / match","Dani golovi / utakmica","Tore / Spiel","Goles / partido","Buts / match"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams concededParams=new LinearLayout.LayoutParams(0,-2,1);concededParams.setMargins(dp(7),0,0,0);goals.addView(homeStat(String.format(Locale.US,"%.2f",totals[5]/(double)totals[0]),t2("Conceded / match","Primljeni / utakmica","Gegentore / Spiel","Encajados / partido","Encaissés / match"),null),concededParams);performance.addView(goals);
        LinearLayout clean=hrow();clean.addView(homeStat(String.valueOf(clubCleanSheets(name)),t2("Clean sheets","Bez primljenog gola","Zu null","Porterías a cero","Clean sheets"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams failedParams=new LinearLayout.LayoutParams(0,-2,1);failedParams.setMargins(dp(7),0,0,0);clean.addView(homeStat(String.valueOf(clubFailedToScore(name)),t2("Failed to score","Bez postignutog gola","Ohne Tor","Sin marcar","Sans marquer"),null),failedParams);performance.addView(clean);
        performance.addView(label("🔥 "+t2("Recent form","Nedavna forma","Aktuelle Form","Forma reciente","Forme récente"),14,subText,true));addClubFormStrip(performance,name);
        performance.addView(label("⌂ / ✈ "+t2("Home and away record","Učinak doma i u gostima","Heim- und Auswärtsbilanz","Rendimiento local y visitante","Bilan domicile et extérieur"),14,subText,true));
        LinearLayout split=hrow();split.addView(clubSplitStatCard("⌂ "+t2("Home","Doma","Heim","Local","Domicile"),clubVerifiedSplitTotals(name,true)),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams awayParams=new LinearLayout.LayoutParams(0,-2,1);awayParams.setMargins(dp(8),0,0,0);split.addView(clubSplitStatCard("✈ "+t2("Away","U gostima","Auswärts","Visitante","Extérieur"),clubVerifiedSplitTotals(name,false)),awayParams);performance.addView(split);
        performance.addView(label(t2("Calculated only from completed matches supplied by the connected source.","Izračunato samo iz završenih utakmica koje je dostavio povezani izvor.","Nur aus abgeschlossenen Spielen der verbundenen Quelle berechnet.","Calculado solo con partidos finalizados de la fuente conectada.","Calculé uniquement à partir des matchs terminés de la source connectée."),12,subText,false));
    }

    void showClubPlayersTab(String name){
        LinearLayout squad=card();squad.addView(label("👥 "+t2("Squad","Kadar","Kader","Plantilla","Effectif"),21,text,true));
        ArrayList<PlayerRecord> players=playersForClub(name);
        if(players.isEmpty()){
            if(ENABLE_PLAYER_DATA_MODULES){
                squad.addView(label(t2("The connected data feed does not currently contain a complete squad. Football Fun will automatically show verified player profiles as soon as the updater supplies them.","Povezani izvor podataka trenutačno ne sadrži kompletan kadar. Football Fun će automatski prikazati provjerene profile igrača čim ih updater dostavi.","Die verbundene Datenquelle enthält derzeit keinen vollständigen Kader. Verifizierte Spielerprofile erscheinen automatisch nach dem nächsten Update.","La fuente conectada aún no contiene una plantilla completa. Los perfiles verificados aparecerán automáticamente tras la actualización.","La source connectée ne contient pas encore l’effectif complet. Les profils vérifiés apparaîtront automatiquement après la mise à jour."),14,subText,false));
            }else{
                squad.addView(label(t2("Player data is currently unavailable. The Player Center is ready and will populate automatically when a verified data source is connected.","Podaci o igračima trenutačno nisu dostupni. Centar igrača je pripremljen i automatski će se popuniti kada povežemo provjereni izvor podataka.","Spielerdaten sind derzeit nicht verfügbar. Das Spielerzentrum ist vorbereitet und wird automatisch gefüllt, sobald eine verifizierte Datenquelle verbunden ist.","Los datos de jugadores no están disponibles actualmente. El centro de jugadores está preparado y se completará automáticamente cuando conectemos una fuente de datos verificada.","Les données des joueurs ne sont actuellement pas disponibles. Le centre des joueurs est prêt et se remplira automatiquement lorsqu’une source de données vérifiée sera connectée."),14,subText,false));
            }
            LinearLayout coverage=hrow();coverage.addView(homeStat("✓",t2("Player Center ready","Centar igrača spreman","Spielerzentrum bereit","Centro listo","Centre prêt"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams sourceParams=new LinearLayout.LayoutParams(0,-2,1);sourceParams.setMargins(dp(8),0,0,0);coverage.addView(homeStat("↻",ENABLE_PLAYER_DATA_MODULES?t2("Waiting for verified data","Čeka provjerene podatke","Wartet auf verifizierte Daten","Esperando datos verificados","En attente de données vérifiées"):t2("Automatic population","Automatsko popunjavanje","Automatische Befüllung","Carga automática","Remplissage automatique"),null),sourceParams);squad.addView(coverage);
            if(ENABLE_PLAYER_DATA_MODULES){Button unavailable=outline("↻ "+t2("Refresh player data","Osvježi podatke igrača","Spielerdaten aktualisieren","Actualizar jugadores","Actualiser les joueurs"));unavailable.setOnClickListener(v->refreshOnlineSafe(true));squad.addView(unavailable);}
            return;
        }
        addClubSquadSummary(squad,players);
        squad.addView(label(clubSquadPositionSummary(players),12,subText,true));
        EditText search=new EditText(this);search.setHint(t2("Search player or position","Pretraži igrača ili poziciju","Spieler oder Position suchen","Buscar jugador o posición","Rechercher joueur ou poste"));search.setTextColor(text);search.setHintTextColor(subText);search.setSingleLine(true);search.setPadding(dp(14),dp(10),dp(14),dp(10));search.setBackground(round(chipBg,dp(16),1));LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(-1,dp(50));searchParams.setMargins(0,dp(10),0,dp(8));squad.addView(search,searchParams);
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);squad.addView(results);
        renderClubSquadDirectory(results,players,"");
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence value,int start,int count,int after){}public void onTextChanged(CharSequence value,int start,int before,int count){renderClubSquadDirectory(results,players,value==null?"":value.toString());}public void afterTextChanged(Editable editable){}});
    }

    void addClubIdentityCard(String club,String league){
        LinearLayout identity=card();identity.addView(label("◇ "+t2("Club information","Podaci o klubu","Klubinformationen","Información del club","Informations du club"),21,text,true));
        TeamProfileRecord profile=teamProfileForClub(club);int playerCount=playersForClub(club).size();
        String country=profile!=null&&profile.area.length()>0?profile.area:clubCountry(club);
        addClubInfoLine(identity,t2("Official name","Puni naziv","Offizieller Name","Nombre oficial","Nom officiel"),profile!=null&&profile.name.length()>0?profile.name:displayTeamName(club));
        addClubInfoLine(identity,t2("Country","Država","Land","País","Pays"),clubCountryFlag(club)+" "+country);
        addClubInfoLine(identity,t2("Domestic competition","Domaće natjecanje","Nationaler Wettbewerb","Competición nacional","Compétition nationale"),displayCompetitionName(league));
        if(profile!=null&&profile.tla.length()>0)addClubInfoLine(identity,t2("Abbreviation","Kratica","Kürzel","Abreviatura","Abréviation"),profile.tla);
        if(profile!=null&&profile.founded>0)addClubInfoLine(identity,t2("Founded","Godina osnutka","Gegründet","Fundado","Fondé"),String.valueOf(profile.founded));
        if(profile!=null&&profile.venue.length()>0)addClubInfoLine(identity,t2("Stadium","Stadion","Stadion","Estadio","Stade"),profile.venue);
        if(profile!=null&&profile.clubColors.length()>0)addClubInfoLine(identity,t2("Club colors","Boje kluba","Vereinsfarben","Colores","Couleurs"),profile.clubColors);
        if(profile!=null&&profile.address.length()>0)addClubInfoLine(identity,t2("Address","Adresa","Adresse","Dirección","Adresse"),profile.address);
        addClubInfoLine(identity,t2("Verified squad","Provjereni kadar","Verifizierter Kader","Plantilla verificada","Effectif vérifié"),playerCount>0?playerCount+" "+t2("players","igrača","Spieler","jugadores","joueurs"):t2("Not available yet","Još nije dostupan","Noch nicht verfügbar","Aún no disponible","Pas encore disponible"));
        if(profile!=null&&profile.website.length()>0){Button website=outline("🌐 "+t2("Open official website","Otvori službenu web-stranicu","Offizielle Website öffnen","Abrir sitio oficial","Ouvrir le site officiel"));website.setOnClickListener(v->openWebAddress(profile.website));identity.addView(website);}
    }

    void addClubSquadPreview(String club){
        ArrayList<PlayerRecord> players=playersForClub(club);if(players.isEmpty())return;
        LinearLayout preview=card();preview.addView(label("👥 "+t2("Squad preview","Pregled kadra","Kadervorschau","Vista de plantilla","Aperçu de l’effectif"),21,text,true));
        int shown=Math.min(5,players.size());for(int i=0;i<shown;i++)addPlayerDirectoryRow(preview,players.get(i));
        Button all=outline(t2("Open full squad","Otvori cijeli kadar","Gesamten Kader öffnen","Abrir plantilla completa","Ouvrir tout l’effectif")+"  "+players.size());all.setOnClickListener(v->showClubCenterTab(club,"players"));preview.addView(all);
    }

    ArrayList<PlayerRecord> playersForClub(String club){
        ArrayList<PlayerRecord> result=new ArrayList<PlayerRecord>();
        if(!ENABLE_PLAYER_DATA_MODULES)return result;
        for(PlayerRecord player:playerIndex.values())if(sameTeam(player.club,club))result.add(player);
        Collections.sort(result,(a,b)->{
            int group=playerPositionRank(a)-playerPositionRank(b);if(group!=0)return group;
            int an=a.shirtNumber>0?a.shirtNumber:999,bn=b.shirtNumber>0?b.shirtNumber:999;
            if(an!=bn)return an-bn;return a.name.compareToIgnoreCase(b.name);
        });
        return result;
    }

    int playerPositionRank(PlayerRecord player){
        String group=playerPositionGroup(player);if(group.equals("goalkeeper"))return 0;if(group.equals("defender"))return 1;if(group.equals("midfielder"))return 2;if(group.equals("forward"))return 3;return 4;
    }
    String playerPositionGroup(PlayerRecord player){
        String value=player==null?"":player.position;String key=value==null?"":value.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        if(key.equals("GOALKEEPER")||key.equals("GK"))return "goalkeeper";
        if(key.equals("DEFENDER")||key.equals("DEFENCE")||key.equals("CB")||key.equals("LB")||key.equals("RB")||key.equals("LWB")||key.equals("RWB"))return "defender";
        if(key.equals("MIDFIELDER")||key.equals("MIDFIELD")||key.equals("CM")||key.equals("DM")||key.equals("AM")||key.equals("CDM")||key.equals("CAM")||key.equals("LM")||key.equals("RM"))return "midfielder";
        if(key.equals("FORWARD")||key.equals("ATTACKER")||key.equals("ST")||key.equals("CF")||key.equals("LW")||key.equals("RW"))return "forward";
        return "other";
    }
    String playerPositionGroupTitle(String group){
        if("goalkeeper".equals(group))return t2("Goalkeepers","Vratari","Torhüter","Porteros","Gardiens");
        if("defender".equals(group))return t2("Defenders","Braniči","Verteidiger","Defensas","Défenseurs");
        if("midfielder".equals(group))return t2("Midfielders","Vezni igrači","Mittelfeldspieler","Centrocampistas","Milieux");
        if("forward".equals(group))return t2("Forwards","Napadači","Stürmer","Delanteros","Attaquants");
        return t2("Other players","Ostali igrači","Weitere Spieler","Otros jugadores","Autres joueurs");
    }
    int countPlayerGroup(ArrayList<PlayerRecord> players,String group){int count=0;for(PlayerRecord player:players)if(playerPositionGroup(player).equals(group))count++;return count;}

    String clubSquadPositionSummary(ArrayList<PlayerRecord> players){
        int goalkeepers=countPlayerGroup(players,"goalkeeper"),defenders=countPlayerGroup(players,"defender"),midfielders=countPlayerGroup(players,"midfielder"),forwards=countPlayerGroup(players,"forward");
        return t2("Goalkeepers","Vratari","Torhüter","Porteros","Gardiens")+" "+goalkeepers+"  •  "+t2("Defenders","Braniči","Verteidiger","Defensas","Défenseurs")+" "+defenders+"  •  "+t2("Midfielders","Vezni","Mittelfeld","Centrocampistas","Milieux")+" "+midfielders+"  •  "+t2("Forwards","Napadači","Stürmer","Delanteros","Attaquants")+" "+forwards;
    }

    boolean playerMatchesSquadSearch(PlayerRecord player,String query){
        if(player==null)return false;if(query==null||query.trim().isEmpty())return true;String q=query.trim().toLowerCase(Locale.ROOT);
        String hay=(player.name+" "+player.position+" "+localizedPlayerPosition(player.position)+" "+player.nationality+" "+localizedCountryName(player.nationality)+" "+(player.shirtNumber>0?String.valueOf(player.shirtNumber):"")).toLowerCase(Locale.ROOT);
        return hay.contains(q);
    }

    void renderClubSquadDirectory(LinearLayout parent,ArrayList<PlayerRecord> players,String query){
        parent.removeAllViews();String lastGroup="";int visible=0;
        for(PlayerRecord player:players){if(!playerMatchesSquadSearch(player,query))continue;String group=playerPositionGroup(player);if(!group.equals(lastGroup)){TextView heading=label(playerPositionGroupTitle(group)+"  "+countMatchingPlayerGroup(players,group,query),13,subText,true);heading.setPadding(dp(3),dp(12),dp(3),dp(4));parent.addView(heading);lastGroup=group;}addPlayerDirectoryRow(parent,player);visible++;}
        if(visible==0)parent.addView(label(t2("No player matches this search.","Nijedan igrač ne odgovara pretrazi.","Kein Spieler entspricht der Suche.","Ningún jugador coincide con la búsqueda.","Aucun joueur ne correspond à la recherche."),14,subText,false));
    }

    int countMatchingPlayerGroup(ArrayList<PlayerRecord> players,String group,String query){int count=0;for(PlayerRecord player:players)if(playerPositionGroup(player).equals(group)&&playerMatchesSquadSearch(player,query))count++;return count;}


    void addClubSquadSummary(LinearLayout parent,ArrayList<PlayerRecord> players){
        LinearLayout row=hrow();
        row.addView(homeStat(String.valueOf(players.size()),t2("Source profiles","Profili izvora","Quellenprofile","Perfiles de fuente","Profils source"),null),new LinearLayout.LayoutParams(0,-2,1));
        int numbered=0;for(PlayerRecord p:players)if(p.shirtNumber>0)numbered++;
        LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1);right.setMargins(dp(8),0,0,0);
        row.addView(homeStat(String.valueOf(numbered),t2("With shirt number","S brojem dresa","Mit Rückennummer","Con dorsal","Avec numéro"),null),right);parent.addView(row);
    }


    void addPlayerDirectoryRow(LinearLayout parent,PlayerRecord player){
        LinearLayout row=hrow();row.setPadding(dp(10),dp(9),dp(8),dp(9));row.setBackground(round(chipBg,dp(15),1));row.setClickable(true);applyPressFeedback(row);
        boolean globalDirectory="Players".equals(currentScreen)||"Favorites".equals(currentScreen);
        if(globalDirectory&&player.club!=null&&!player.club.trim().isEmpty()){View crest=homeTeamVisual(player.club,dp(42),false);row.addView(crest,new LinearLayout.LayoutParams(dp(42),dp(42)));}
        else{TextView number=centerLabel(player.shirtNumber>0?String.valueOf(player.shirtNumber):"—",16,RED,true);number.setBackground(round(cardBg,dp(20),1));row.addView(number,new LinearLayout.LayoutParams(dp(42),dp(42)));}
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(11),0,dp(5),0);
        TextView playerName=label(player.name,15,text,true);playerName.setSingleLine(true);playerName.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(playerName);
        ArrayList<String> meta=new ArrayList<String>();if(globalDirectory&&player.club.length()>0)meta.add(displayTeamName(player.club));if(player.position.length()>0)meta.add(localizedPlayerPosition(player.position));if(player.nationality.length()>0)meta.add(localizedCountryName(player.nationality));
        TextView metaView=label(joinParts(meta," • "),12,subText,false);metaView.setSingleLine(true);metaView.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(metaView);row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        String symbol=hasProAccess()?(isFavoritePlayer(player)?"★":"☆"):"🔒";TextView favorite=centerLabel(symbol,hasProAccess()?20:15,hasProAccess()&&isFavoritePlayer(player)?GOLD:subText,true);
        favorite.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));return;}toggleFavoritePlayer(player);if("Players".equals(currentScreen))showPlayersHub();else if("Favorites".equals(currentScreen))showFavorites();else showClubCenterTab(player.club,"players");});row.addView(favorite,new LinearLayout.LayoutParams(dp(42),dp(42)));
        row.addView(label("›",24,RED,true));row.setOnClickListener(v->showPlayerCenter(player));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(4),0,dp(4));parent.addView(row,lp);
    }

    void showPlayerCenter(PlayerRecord player){
        playerCenterOriginScreen=currentScreen;
        currentPlayerTab="overview";
        showPlayerCenterTab(player,"overview");
    }

    void showPlayerCenterTab(PlayerRecord player,String selectedTab){
        if(player==null||player.name.trim().length()==0)return;
        if(!isPlausiblePlayer(player)){
            String possibleClub=player.club==null||player.club.trim().isEmpty()?player.name:player.club;
            if(teamProfileForClub(possibleClub)!=null||availableClubProfile(possibleClub)!=null){showClubCenter(possibleClub);return;}
            return;
        }
        openPlayerKey=player.key();playerIndex.put(openPlayerKey,player);currentPlayerTab=(selectedTab==null||selectedTab.trim().isEmpty())?"overview":selectedTab;
        clear(player.name,player.club,"PlayerCenter");addPlayerHero(player);addPlayerCenterTabs(player,currentPlayerTab);
        if("statistics".equals(currentPlayerTab)){
            addPlayerSeasonStatistics(player);
            addPlayerDataCoverage(player);
        }else if("matches".equals(currentPlayerTab)){
            addPlayerClubMatchContext(player);
            addPlayerUpcomingMatches(player);
            addPlayerRecentMatches(player);
            addPlayerFollowCard(player);
        }else{
            addPlayerPremiumOverview(player);
            addPlayerCurrentClubCard(player);
            addPlayerIdentityCard(player);
            if(!player.recentForm.isEmpty())addPlayerForm(player);
            if(player.history.length()>0)addPlayerHistory(player);
            addPlayerSourceCard(player);
        }
    }

    void addPlayerCenterTabs(PlayerRecord player,String selected){
        LinearLayout tabs=card();
        String[][] values={
                {"overview","◇ "+t2("Overview","Pregled","Übersicht","Resumen","Aperçu")},
                {"statistics","📊 "+t2("Performance","Učinak","Leistung","Rendimiento","Performance")},
                {"matches","📅 "+t2("Club matches","Utakmice kluba","Klubspiele","Partidos del club","Matchs du club")}
        };
        LinearLayout row=hrow();
        for(int i=0;i<values.length;i++){
            String key=values[i][0];
            Button b=key.equals(selected)?btn(values[i][1]):outline(values[i][1]);
            b.setTextSize(10);
            b.setSingleLine(true);
            b.setEllipsize(android.text.TextUtils.TruncateAt.END);
            b.setOnClickListener(v->showPlayerCenterTab(player,key));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
            if(i>0)lp.setMargins(dp(6),0,0,0);
            row.addView(b,lp);
        }
        tabs.addView(row);
    }

    void addPlayerHero(PlayerRecord player){
        LinearLayout hero=card();
        hero.setBackground(gradient(Color.rgb(53,24,105),Color.rgb(235,31,86),dp(24)));
        hero.setPadding(dp(18),dp(18),dp(18),dp(17));

        LinearLayout row=hrow();
        row.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout avatarHolder=new FrameLayout(this);
        View portrait=playerVisual(player,dp(88));
        avatarHolder.addView(portrait,new FrameLayout.LayoutParams(dp(88),dp(88),Gravity.CENTER));
        if(player.club!=null&&!player.club.trim().isEmpty()){
            View crest=homeTeamVisual(player.club,dp(30),false);
            FrameLayout.LayoutParams crestParams=new FrameLayout.LayoutParams(dp(34),dp(34),Gravity.END|Gravity.BOTTOM);
            avatarHolder.addView(crest,crestParams);
        }
        row.addView(avatarHolder,new LinearLayout.LayoutParams(dp(96),dp(96)));

        LinearLayout copy=new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(14),0,0,0);
        TextView playerName=label(player.name,24,Color.WHITE,true);
        playerName.setMaxLines(2);
        playerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        copy.addView(playerName);
        ArrayList<String> main=new ArrayList<String>();
        if(player.shirtNumber>0)main.add("#"+player.shirtNumber);
        if(player.position.length()>0)main.add(localizedPlayerPosition(player.position));
        if(player.club.length()>0)main.add(displayTeamName(player.club));
        if(!main.isEmpty())copy.addView(label(joinParts(main," • "),14,Color.WHITE,true));
        ArrayList<String> meta=new ArrayList<String>();
        if(player.nationality.length()>0)meta.add(localizedCountryName(player.nationality));
        if(player.age>0)meta.add(player.age+" "+t2("years","god.","Jahre","años","ans"));
        if(player.height.length()>0)meta.add(player.height);
        if(!meta.isEmpty())copy.addView(label(joinParts(meta," • "),12,Color.WHITE,false));
        TextView verified=label("✓ "+t2("Verified profile","Provjeren profil","Verifiziertes Profil","Perfil verificado","Profil vérifié"),11,Color.WHITE,true);
        verified.setPadding(0,dp(7),0,0);
        copy.addView(verified);
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(row);

        LinearLayout actions=hrow();
        boolean fav=isFavoritePlayer(player);
        Button favorite=hasProAccess()?outline((fav?"★ ":"☆ ")+t2(fav?"Following":"Follow",fav?"Pratim":"Prati",fav?"Gefolgt":"Folgen",fav?"Siguiendo":"Seguir",fav?"Suivi":"Suivre")):outline("🔒 Pro");
        favorite.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));return;}toggleFavoritePlayer(player);showPlayerCenterTab(player,currentPlayerTab);});
        actions.addView(favorite,new LinearLayout.LayoutParams(0,dp(50),1));
        boolean nationalTeam=isKnownNationalTeam(player.club);
        Button club=outline("🛡 "+t2(nationalTeam?"Open team":"Open club",nationalTeam?"Otvori reprezentaciju":"Otvori klub",nationalTeam?"Team öffnen":"Klub öffnen",nationalTeam?"Abrir selección":"Abrir club",nationalTeam?"Ouvrir l’équipe":"Ouvrir le club"));
        club.setEnabled(player.club!=null&&!player.club.trim().isEmpty());
        club.setOnClickListener(v->showClubCenter(player.club));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(50),1);cp.setMargins(dp(8),0,0,0);
        actions.addView(club,cp);
        hero.addView(actions);
    }

    View playerVisual(PlayerRecord player,int sizePx){
        FrameLayout frame=new FrameLayout(this);
        frame.setBackground(round(Color.argb(45,255,255,255),dp(42),1));
        frame.setClipToOutline(true);
        TextView fallback=centerLabel(playerInitials(player==null?"":player.name),28,Color.WHITE,true);
        fallback.setGravity(Gravity.CENTER);
        frame.addView(fallback,new FrameLayout.LayoutParams(-1,-1));
        if(player!=null&&player.photoUrl!=null&&!player.photoUrl.trim().isEmpty()){
            ImageView photo=new ImageView(this);
            photo.setVisibility(View.INVISIBLE);
            photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            frame.addView(photo,new FrameLayout.LayoutParams(-1,-1));
            if(clubCrestCache!=null)clubCrestCache.loadCover(photo,"player_"+player.key(),player.photoUrl.trim());
        }
        return frame;
    }

    String playerInitials(String name){
        if(name==null||name.trim().isEmpty())return "⚽";
        String[] parts=name.trim().split("\\s+");
        StringBuilder out=new StringBuilder();
        if(parts.length>0&&parts[0].length()>0)out.append(parts[0].substring(0,1));
        if(parts.length>1&&parts[parts.length-1].length()>0)out.append(parts[parts.length-1].substring(0,1));
        return out.toString().toUpperCase(homeLocale());
    }

    boolean isKnownNationalTeam(String name){
        if(name==null||name.trim().isEmpty()||data==null)return false;
        for(String team:data.teams)if(sameTeam(team,name))return true;
        return false;
    }

    void addPlayerPremiumOverview(PlayerRecord p){
        LinearLayout section=card();section.addView(label("◇ "+t2("PLAYER OVERVIEW","SAŽETAK IGRAČA","SPIELERÜBERSICHT","RESUMEN DEL JUGADOR","APERÇU DU JOUEUR"),19,text,true));
        boolean hasSeasonStats=p.appearances>=0||p.minutes>=0||p.goals>=0||p.assists>=0;
        int contributions=(p.goals>0?p.goals:0)+(p.assists>0?p.assists:0);
        LinearLayout row=hrow();LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(8),0,dp(8),0);
        if(hasSeasonStats){
            row.addView(playerOverviewStat(p.appearances>=0?String.valueOf(p.appearances):"—",t2("Appearances","Nastupi","Einsätze","Partidos","Matchs")),new LinearLayout.LayoutParams(0,-2,1));
            row.addView(playerOverviewStat((p.goals>=0||p.assists>=0)?String.valueOf(contributions):"—",t2("Goals + assists","Golovi + asistencije","Tore + Vorlagen","Goles + asistencias","Buts + passes")),mid);
            row.addView(playerOverviewStat(p.minutes>=0?String.valueOf(p.minutes):"—",t2("Minutes","Minute","Minuten","Minutos","Minutes")),new LinearLayout.LayoutParams(0,-2,1));
        }else{
            row.addView(playerOverviewStat(p.shirtNumber>0?"#"+p.shirtNumber:"—",t2("Number","Broj","Nummer","Número","Numéro")),new LinearLayout.LayoutParams(0,-2,1));
            row.addView(playerOverviewStat(p.position.length()>0?localizedPlayerPosition(p.position):"—",t2("Position","Pozicija","Position","Posición","Poste")),mid);
            row.addView(playerOverviewStat(playerProfileCoverageScore(p)+"/6",t2("Coverage","Pokrivenost","Abdeckung","Cobertura","Couverture")),new LinearLayout.LayoutParams(0,-2,1));
        }
        section.addView(row);
        ArrayList<String> identity=new ArrayList<String>();if(p.position.length()>0)identity.add(localizedPlayerPosition(p.position));if(p.club.length()>0)identity.add(displayTeamName(p.club));if(p.nationality.length()>0)identity.add(localizedCountryName(p.nationality));
        if(!identity.isEmpty())section.addView(label(joinParts(identity," • "),13,subText,true));
        section.addView(label(t2("Profile level","Razina profila","Profilstufe","Nivel de perfil","Niveau du profil")+": "+playerProfileLevel(p),12,subText,true));
    }

    int playerProfileCoverageScore(PlayerRecord p){
        if(p==null)return 0;int score=0;if(p.position.length()>0)score++;if(p.club.length()>0)score++;if(p.nationality.length()>0)score++;if(p.dateOfBirth.length()>0||p.age>0)score++;if(p.shirtNumber>0)score++;if(p.appearances>=0||p.minutes>=0||p.goals>=0||p.assists>=0)score++;return score;
    }

    String playerProfileLevel(PlayerRecord p){
        int score=playerProfileCoverageScore(p);if(score>=5)return t2("Complete","Potpuni","Vollständig","Completo","Complet");if(score>=3)return t2("Extended","Prošireni","Erweitert","Ampliado","Étendu");return t2("Basic","Osnovni","Basis","Básico","Basique");
    }

    void addPlayerIdentityCard(PlayerRecord p){
        LinearLayout section=card();section.addView(label("👤 "+t2("Personal profile","Osobni profil","Persönliches Profil","Perfil personal","Profil personnel"),21,text,true));
        LinearLayout first=hrow();first.addView(homeStat(p.position.length()>0?localizedPlayerPosition(p.position):"—",t2("Position","Pozicija","Position","Posición","Poste"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1);right.setMargins(dp(8),0,0,0);first.addView(homeStat(p.shirtNumber>0?"#"+p.shirtNumber:"—",t2("Shirt number","Broj dresa","Rückennummer","Dorsal","Numéro"),null),right);section.addView(first);
        LinearLayout second=hrow();second.addView(homeStat(p.nationality.length()>0?localizedCountryName(p.nationality):"—",t2("Nationality","Nacionalnost","Nationalität","Nacionalidad","Nationalité"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1);rp.setMargins(dp(8),0,0,0);second.addView(homeStat(p.age>0?String.valueOf(p.age):"—",t2("Age","Dob","Alter","Edad","Âge"),null),rp);section.addView(second);
        LinearLayout third=hrow();third.addView(homeStat(p.height.length()>0?p.height:"—",t2("Height","Visina","Größe","Altura","Taille"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,-2,1);wp.setMargins(dp(8),0,0,0);third.addView(homeStat(p.weight.length()>0?p.weight:"—",t2("Weight","Težina","Gewicht","Peso","Poids"),null),wp);section.addView(third);
        if(p.dateOfBirth.length()>0)section.addView(label("🎂 "+t2("Date of birth","Datum rođenja","Geburtsdatum","Fecha de nacimiento","Date de naissance")+": "+formatPlayerDate(p.dateOfBirth),13,subText,true));
    }

    void addPlayerCurrentClubCard(PlayerRecord p){
        if(p==null||p.club==null||p.club.trim().isEmpty())return;
        LinearLayout section=card();
        boolean nationalTeam=isKnownNationalTeam(p.club);
        section.addView(label("🛡 "+t2(nationalTeam?"Current team":"Current club",nationalTeam?"Trenutačna reprezentacija":"Trenutačni klub",nationalTeam?"Aktuelles Team":"Aktueller Klub",nationalTeam?"Selección actual":"Club actual",nationalTeam?"Équipe actuelle":"Club actuel"),21,text,true));
        LinearLayout row=hrow();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10),dp(10),dp(10),dp(10));
        row.setBackground(round(chipBg,dp(18),1));
        View crest=homeTeamVisual(p.club,dp(58),false);
        row.addView(crest,new LinearLayout.LayoutParams(dp(58),dp(58)));
        LinearLayout copy=new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(dp(12),0,dp(6),0);
        copy.addView(label(displayTeamName(p.club),17,text,true));
        ArrayList<String> meta=new ArrayList<String>();
        if(nationalTeam){
            meta.add(t2("National team","Reprezentacija","Nationalmannschaft","Selección nacional","Équipe nationale"));
            TeamProfileRecord teamProfile=teamProfileForClub(p.club);if(teamProfile!=null&&teamProfile.area.length()>0)meta.add(teamProfile.area);
        }else{
            String league=clubLeague(p.club);if(league.length()>0)meta.add(displayCompetitionName(league));
            String country=clubCountry(p.club);if(country.length()>0)meta.add(country);
        }
        if(!meta.isEmpty())copy.addView(label(joinParts(meta," • "),12,subText,false));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(label("›",25,RED,true),new LinearLayout.LayoutParams(dp(24),-2));
        row.setOnClickListener(v->showClubCenter(p.club));
        section.addView(row);
        Match next=nextMatchForTeam(p.club);
        if(next!=null){
            TextView nextLabel=label(t2("NEXT VERIFIED CLUB MATCH","SLJEDEĆA PROVJERENA UTAKMICA KLUBA","NÄCHSTES VERIFIZIERTES KLUBSPIEL","PRÓXIMO PARTIDO VERIFICADO","PROCHAIN MATCH VÉRIFIÉ"),11,subText,true);
            nextLabel.setPadding(0,dp(12),0,0);
            section.addView(nextLabel);
            addDynamicHomeMatch(section,next);
        }
    }

    String formatPlayerDate(String raw){
        if(raw==null||raw.trim().length()<10)return raw==null?"":raw.trim();
        try{
            Date value=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(raw.trim().substring(0,10));
            return value==null?raw.trim():new SimpleDateFormat("d. MMM yyyy.",homeLocale()).format(value);
        }catch(Exception ignored){return raw.trim();}
    }

    int playerCoveragePercent(PlayerRecord p){
        if(p==null)return 0;
        int present=0,total=16;
        if(p.position.length()>0)present++;if(p.club.length()>0)present++;if(p.nationality.length()>0)present++;
        if(p.age>0||p.dateOfBirth.length()>0)present++;if(p.shirtNumber>0)present++;if(p.height.length()>0)present++;if(p.weight.length()>0)present++;
        if(p.appearances>=0)present++;if(p.minutes>=0)present++;if(p.goals>=0)present++;if(p.assists>=0)present++;
        if(p.yellowCards>=0)present++;if(p.redCards>=0)present++;if(p.rating.length()>0)present++;
        if(!p.recentForm.isEmpty())present++;if(p.history.length()>0)present++;
        return Math.max(0,Math.min(100,(int)Math.round(present*100.0/total)));
    }

    void addPlayerSourceCard(PlayerRecord p){
        LinearLayout section=card();
        section.addView(label("✓ "+t2("Profile quality","Kvaliteta profila","Profilqualität","Calidad del perfil","Qualité du profil"),21,text,true));
        int coverage=playerCoveragePercent(p);
        LinearLayout row=hrow();
        row.addView(homeStat(coverage+"%",t2("Data coverage","Pokrivenost podataka","Datenabdeckung","Cobertura","Couverture"),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams verifiedParams=new LinearLayout.LayoutParams(0,-2,1);verifiedParams.setMargins(dp(8),0,0,0);
        row.addView(homeStat("✓",t2("Verified source","Provjeren izvor","Verifizierte Quelle","Fuente verificada","Source vérifiée"),null),verifiedParams);
        section.addView(row);
        TeamProfileRecord profile=teamProfileForClub(p.club);
        String updated=profile==null?"":cleanProfileTimestamp(profile.lastUpdated);
        if(updated.length()>0)section.addView(label("↻ "+t2("Squad updated","Kadar ažuriran","Kader aktualisiert","Plantilla actualizada","Effectif actualisé")+": "+updated,12,subText,true));
        section.addView(label(t2("Football Fun shows only fields supplied by the connected verified source. Missing statistics remain empty instead of being estimated or invented.","Football Fun prikazuje samo podatke koje dostavlja povezani provjereni izvor. Statistika koja nedostaje ostaje prazna umjesto da se procjenjuje ili izmišlja.","Football Fun zeigt nur Daten aus der verbundenen verifizierten Quelle. Fehlende Statistiken bleiben leer und werden nicht geschätzt.","Football Fun muestra solo datos de la fuente verificada. Las estadísticas ausentes quedan vacías y no se estiman.","Football Fun affiche uniquement les données de la source vérifiée. Les statistiques absentes restent vides et ne sont pas estimées."),12,subText,false));
        if(ENABLE_PLAYER_DATA_MODULES){
            Button refresh=outline("↻ "+t2("Refresh player data","Osvježi podatke igrača","Spielerdaten aktualisieren","Actualizar jugador","Actualiser le joueur"));
            refresh.setOnClickListener(v->refreshOnlineSafe(true));
            section.addView(refresh);
        }
    }

    void addPlayerClubMatchContext(PlayerRecord p){
        LinearLayout section=card();
        section.addView(label("ℹ "+t2("Club match context","Kontekst utakmica kluba","Kontext der Klubspiele","Contexto de partidos","Contexte des matchs"),19,text,true));
        section.addView(label(t2("This tab shows verified matches for the player's current club. Football Fun marks an individual appearance only when reliable lineup or event data is supplied.","Ova kartica prikazuje provjerene utakmice trenutačnog kluba igrača. Football Fun označava pojedinačni nastup samo kada su dostupni pouzdani podaci o sastavu ili događajima.","Dieser Bereich zeigt verifizierte Spiele des aktuellen Klubs. Ein persönlicher Einsatz wird nur bei zuverlässigen Aufstellungs- oder Ereignisdaten markiert.","Esta sección muestra partidos verificados del club actual. Una aparición individual solo se marca con datos fiables de alineación o eventos.","Cette section affiche les matchs vérifiés du club actuel. Une apparition individuelle n’est indiquée qu’avec des données fiables de composition ou d’événements."),13,subText,false));
    }

    void addPlayerFollowCard(PlayerRecord p){
        LinearLayout section=card();
        section.addView(label("★ "+t2("Follow player","Praćenje igrača","Spieler folgen","Seguir jugador","Suivre le joueur"),21,text,true));
        boolean followed=isFavoritePlayer(p);
        section.addView(label(t2(followed?"This player is saved in your favorites and stays available for quick access.":"Save this player to your favorites for quick access from the personal center.",followed?"Ovaj igrač spremljen je u favoritima i dostupan je za brz pristup.":"Spremi ovog igrača u favorite za brz pristup iz osobnog centra.",followed?"Dieser Spieler ist in deinen Favoriten gespeichert.":"Speichere diesen Spieler für schnellen Zugriff.",followed?"Este jugador está guardado en favoritos.":"Guarda este jugador para acceso rápido.",followed?"Ce joueur est enregistré dans tes favoris.":"Enregistre ce joueur pour un accès rapide."),13,subText,false));
        Button toggle=hasProAccess()?(followed?outline("★ "+t2("Stop following","Prestani pratiti","Nicht mehr folgen","Dejar de seguir","Ne plus suivre")):btn("☆ "+t2("Follow player","Prati igrača","Spieler folgen","Seguir jugador","Suivre le joueur"))):lockedProButton(t2("Follow player","Prati igrača","Spieler folgen","Seguir jugador","Suivre le joueur"),t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));
        toggle.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));return;}toggleFavoritePlayer(p);showPlayerCenterTab(p,"matches");});
        section.addView(toggle);
        section.addView(label(t2("Goal and lineup alerts will be offered only after the live source supplies player events reliably.","Obavijesti o golovima i sastavu bit će ponuđene tek kada izvor uživo pouzdano dostavlja događaje igrača.","Tor- und Aufstellungsalarme werden erst bei zuverlässigen Spielerereignissen angeboten.","Las alertas de gol y alineación se ofrecerán cuando la fuente proporcione eventos fiables.","Les alertes de but et de composition seront proposées lorsque la source fournira des événements fiables."),11,subText,false));
    }

    void addPlayerDataCoverage(PlayerRecord p){
        LinearLayout section=card();section.addView(label("✓ "+t2("Data coverage","Pokrivenost podataka","Datenabdeckung","Cobertura de datos","Couverture des données"),21,text,true));
        int identity=0;if(p.position.length()>0)identity++;if(p.club.length()>0)identity++;if(p.nationality.length()>0)identity++;if(p.age>0||p.dateOfBirth.length()>0)identity++;if(p.shirtNumber>0)identity++;
        int season=0;if(p.appearances>=0)season++;if(p.minutes>=0)season++;if(p.goals>=0)season++;if(p.assists>=0)season++;if(p.rating.length()>0)season++;
        LinearLayout row=hrow();row.addView(homeStat(identity+" / 5",t2("Identity","Identitet","Identität","Identidad","Identité"),null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1);rp.setMargins(dp(8),0,0,0);row.addView(homeStat(season+" / 5",t2("Season","Sezona","Saison","Temporada","Saison"),null),rp);section.addView(row);
        TeamProfileRecord profile=teamProfileForClub(p.club);String updated=profile==null?"":cleanProfileTimestamp(profile.lastUpdated);
        if(updated.length()>0)section.addView(label("↻ "+t2("Squad updated","Kadar ažuriran","Kader aktualisiert","Plantilla actualizada","Effectif actualisé")+": "+updated,12,subText,true));
        section.addView(label(t2("Missing values stay empty until the connected verified source supplies them; Football Fun never invents player statistics.","Podaci koji nedostaju ostaju prazni dok ih ne dostavi povezani provjereni izvor; Football Fun nikada ne izmišlja statistiku igrača.","Fehlende Werte bleiben leer, bis eine verifizierte Quelle sie liefert; Football Fun erfindet keine Spielerstatistiken.","Los valores ausentes permanecen vacíos hasta que los aporte una fuente verificada; Football Fun nunca inventa estadísticas.","Les valeurs manquantes restent vides jusqu’à leur fourniture par une source vérifiée ; Football Fun n’invente jamais de statistiques."),12,subText,false));
        if(ENABLE_PLAYER_DATA_MODULES){Button refresh=outline("↻ "+t2("Refresh statistics","Osvježi statistiku","Statistik aktualisieren","Actualizar estadísticas","Actualiser les statistiques"));refresh.setOnClickListener(v->refreshOnlineSafe(true));section.addView(refresh);}
    }

    LinearLayout playerOverviewStat(String value,String title){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(7),dp(13),dp(7),dp(11));box.setBackground(round(chipBg,dp(18),1));
        TextView main=centerLabel(value,22,text,true);main.setSingleLine(true);box.addView(main);
        TextView caption=centerLabel(title,10,subText,true);caption.setMaxLines(2);box.addView(caption);return box;
    }

    String localizedPlayerPosition(String value){
        if(value==null)return "";String key=value.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        if(key.equals("GOALKEEPER")||key.equals("GK"))return t2("Goalkeeper","Vratar","Torwart","Portero","Gardien");
        if(key.equals("DEFENDER")||key.equals("DEFENCE")||key.equals("CB")||key.equals("LB")||key.equals("RB")||key.equals("LWB")||key.equals("RWB"))return t2("Defender","Branič","Verteidiger","Defensa","Défenseur");
        if(key.equals("MIDFIELDER")||key.equals("MIDFIELD")||key.equals("CM")||key.equals("DM")||key.equals("AM")||key.equals("CDM")||key.equals("CAM")||key.equals("LM")||key.equals("RM"))return t2("Midfielder","Vezni igrač","Mittelfeldspieler","Centrocampista","Milieu");
        if(key.equals("FORWARD")||key.equals("ATTACKER")||key.equals("ST")||key.equals("CF")||key.equals("LW")||key.equals("RW"))return t2("Forward","Napadač","Stürmer","Delantero","Attaquant");
        return value.replace('_',' ');
    }

    boolean isFavoritePlayer(PlayerRecord player){return player!=null&&favoritePlayers.contains(player.key());}
    void toggleFavoritePlayer(PlayerRecord player){
        if(!hasProAccess()){showPremium(t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));return;}
        if(player==null)return;String key=player.key();
        if(favoritePlayers.contains(key))favoritePlayers.remove(key);else{favoritePlayers.add(key);playerIndex.put(key,player);}
        saveFavoritePlayerProfiles();
    }

    void addPlayerSeasonStatistics(PlayerRecord p){
        LinearLayout section=card();section.addView(label("📊 "+t2("Season statistics","Statistika sezone","Saisonstatistik","Estadísticas de temporada","Statistiques de saison"),21,text,true));
        boolean any=p.appearances>=0||p.minutes>=0||p.goals>=0||p.assists>=0||p.yellowCards>=0||p.redCards>=0||p.rating.length()>0;
        if(!any){section.addView(label(t2("Player statistics are not present in the current connected feed. The profile remains fully usable and this section will activate automatically when verified statistics are supplied.","Statistika igrača nije prisutna u trenutačno povezanom izvoru. Profil je i dalje potpuno funkcionalan, a ovaj će se dio automatski aktivirati kada stignu provjerene statistike.","Spielerstatistiken sind in der aktuell verbundenen Datenquelle nicht vorhanden. Dieser Bereich aktiviert sich automatisch, sobald verifizierte Statistiken geliefert werden.","Las estadísticas no están presentes en la fuente conectada actual. Esta sección se activará automáticamente cuando se proporcionen estadísticas verificadas.","Les statistiques ne sont pas présentes dans la source connectée actuelle. Cette section s’activera automatiquement lorsque des statistiques vérifiées seront fournies."),14,subText,false));return;}
        addPlayerStatRow(section,t2("Appearances","Nastupi","Einsätze","Partidos","Matchs"),p.appearances,t2("Minutes","Minute","Minuten","Minutos","Minutes"),p.minutes);
        addPlayerStatRow(section,t2("Goals","Golovi","Tore","Goles","Buts"),p.goals,t2("Assists","Asistencije","Vorlagen","Asistencias","Passes"),p.assists);
        addPlayerStatRow(section,t2("Yellow cards","Žuti kartoni","Gelbe Karten","Amarillas","Cartons jaunes"),p.yellowCards,t2("Red cards","Crveni kartoni","Rote Karten","Rojas","Cartons rouges"),p.redCards);
        if(p.rating.length()>0)section.addView(homeStat(p.rating,t2("Average rating","Prosječna ocjena","Durchschnittsnote","Nota media","Note moyenne"),null));
        if(p.minutes>0&&(p.goals>=0||p.assists>=0)){
            int contributions=(p.goals>0?p.goals:0)+(p.assists>0?p.assists:0);double per90=contributions*90.0/p.minutes;
            section.addView(homeStat(String.format(Locale.US,"%.2f",per90),t2("Goal contributions / 90","Doprinosi golu / 90 min","Torbeiträge / 90","Contribuciones / 90","Contributions / 90"),null));
        }
    }
    void addPlayerStatRow(LinearLayout section,String left,int lv,String right,int rv){LinearLayout row=hrow();row.addView(homeStat(lv>=0?String.valueOf(lv):"—",left,null),new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1);rp.setMargins(dp(8),0,0,0);row.addView(homeStat(rv>=0?String.valueOf(rv):"—",right,null),rp);section.addView(row);}

    void addPlayerForm(PlayerRecord p){LinearLayout section=card();section.addView(label("🔥 "+t2("Last five appearances","Zadnjih pet nastupa","Letzte fünf Einsätze","Últimas cinco apariciones","Cinq dernières apparitions"),21,text,true));if(p.recentForm.isEmpty())section.addView(label(t2("Verified appearance-by-appearance data is not available from the current source.","Provjereni podaci po pojedinom nastupu nisu dostupni iz trenutačnog izvora.","Verifizierte Daten je Einsatz sind aus der aktuellen Quelle nicht verfügbar.","No hay datos verificados por aparición en la fuente actual.","Les données vérifiées par apparition ne sont pas disponibles."),14,subText,false));else for(String item:p.recentForm)section.addView(label(item,14,text,false));}
    void addPlayerHistory(PlayerRecord p){LinearLayout section=card();section.addView(label("🕘 "+t2("Club history","Povijest klubova","Vereinsverlauf","Historial de clubes","Historique des clubs"),21,text,true));if(p.history.length()==0)section.addView(label(t2("Previous clubs and transfer years will be displayed only when a verified source supplies them.","Prethodni klubovi i godine prelazaka prikazat će se samo kada ih dostavi provjereni izvor.","Frühere Vereine und Transferjahre werden nur aus verifizierter Quelle angezeigt.","Los clubes anteriores y años de traspaso se mostrarán solo con una fuente verificada.","Les anciens clubs et années de transfert seront affichés uniquement avec une source vérifiée."),14,subText,false));else section.addView(label(p.history,14,text,false));}
    void addPlayerUpcomingMatches(PlayerRecord p){LinearLayout section=card();section.addView(label("📅 "+t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),21,text,true));ArrayList<Match> matches=clubUpcomingMatches(p.club);if(matches.isEmpty())section.addView(label(t2("No upcoming verified club matches are available.","Nema dostupnih nadolazećih provjerenih utakmica kluba.","Keine kommenden verifizierten Klubspiele verfügbar.","No hay próximos partidos verificados del club.","Aucun prochain match vérifié du club."),14,subText,false));else for(int i=0;i<Math.min(5,matches.size());i++)addDynamicHomeMatch(section,matches.get(i),true,false,true);}
    void addPlayerRecentMatches(PlayerRecord p){
        LinearLayout section=card();section.addView(label("✅ "+t2("Recent club results","Nedavni rezultati kluba","Letzte Klubresultate","Resultados recientes","Résultats récents"),21,text,true));
        ArrayList<Match> matches=clubRecentResults(p.club);
        if(matches.isEmpty())section.addView(label(t2("No completed verified club matches are available.","Nema dostupnih završenih provjerenih utakmica kluba.","Keine abgeschlossenen verifizierten Klubspiele verfügbar.","No hay partidos verificados finalizados.","Aucun match de club terminé et vérifié."),14,subText,false));
        else for(int i=0;i<Math.min(5,matches.size());i++)addDynamicHomeMatch(section,matches.get(i));
    }
    boolean isFollowedMatch(Match m){return m!=null&&followedMatches.contains(personalMatchKey(m));}
    void saveFollowedMatches(){prefs.edit().putStringSet("followed_matches",new LinkedHashSet<String>(followedMatches)).apply();}
    void toggleFollowedMatch(Match m){
        if(!hasProAccess()){showPremium(t2("Following matches","Praćenje utakmica","Spiele folgen","Seguimiento de partidos","Suivi des matchs"));return;}
        if(m==null)return;
        String key=personalMatchKey(m);
        boolean added;
        if(followedMatches.contains(key)){followedMatches.remove(key);added=false;}else{followedMatches.add(key);added=true;}
        saveFollowedMatches();
        // A specifically followed match is also an explicit reminder target. Refresh the
        // local AlarmManager schedule immediately so the Notification Center reflects
        // the change without requiring a favorite club/competition or an app restart.
        syncMatchRemindersAsync();
        toast(added?t2("Match added to tracker","Utakmica dodana u praćenje","Spiel wird verfolgt","Partido añadido al seguimiento","Match ajouté au suivi"):t2("Match removed from tracker","Utakmica uklonjena iz praćenja","Spiel nicht mehr verfolgt","Partido eliminado del seguimiento","Match retiré du suivi"));
    }
    ArrayList<Match> followedMatchList(){
        ArrayList<Match> out=new ArrayList<Match>();
        if(data==null)return out;
        for(Match m:data.matches)if(isFollowedMatch(m))out.add(m);
        out=dedupeFavoriteMatches(out);
        Collections.sort(out,(a,b)->{
            if(matchIsLive(a)!=matchIsLive(b))return matchIsLive(a)?-1:1;
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
        return out;
    }

    String favoriteClubMatchStatus(String club){
        boolean tomorrow=false;
        ArrayList<Match> clubMatches=new ArrayList<Match>();
        for(Match m:data.matches)if(sameTeam(m.home,club)||sameTeam(m.away,club))clubMatches.add(m);
        for(Match m:dedupeFavoriteMatches(clubMatches)){
            if(matchIsLive(m))return "● "+t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT");
            if(matchIsToday(m)&&!matchIsFinished(m))return t2("TODAY","DANAS","HEUTE","HOY","AUJOURD’HUI");
            if(matchIsTomorrow(m))tomorrow=true;
        }
        return tomorrow?t2("TOMORROW","SUTRA","MORGEN","MAÑANA","DEMAIN"):"";
    }

    ArrayList<PlayerRecord> favoritePlayerList(){
        ArrayList<PlayerRecord> out=new ArrayList<PlayerRecord>();
        if(!ENABLE_PLAYER_DATA_MODULES)return out;
        for(PlayerRecord player:playerIndex.values())if(isFavoritePlayer(player))out.add(player);
        Collections.sort(out,(a,b)->{int club=a.club.compareToIgnoreCase(b.club);return club!=0?club:a.name.compareToIgnoreCase(b.name);});
        return out;
    }

    void showFavorites(){
        currentClubOriginScreen="";
        if(!hasProAccess()){showPremium(t2("Favorites and following","Favoriti i praćenje","Favoriten und Folgen","Favoritos y seguimiento","Favoris et suivi"),"Favorites");return;}
        clear(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),t2("Your personal football feed","Tvoj osobni nogometni sadržaj","Dein persönlicher Fußball-Feed","Tu contenido personalizado","Ton fil football personnel"),"Favorites");
        String club=primaryFavoriteClub();
        addFavoritesHero(club);
        addFavoritesTabs();
        if("clubs".equals(favoritesSection))addFavoriteClubsSection();
        else if("players".equals(favoritesSection))addFavoritePlayersSection();
        else if("matches".equals(favoritesSection))addFavoriteMatchesSection();
        else if("competitions".equals(favoritesSection))addFavoriteCompetitionsSection();
        else addFavoritesOverview();
    }

    void addFavoritesHero(String club){
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(69,18,88),Color.rgb(245,36,91),dp(24)));
        if(club==null||club.trim().isEmpty()){
            hero.addView(label("⭐ "+t2("Your favorites","Tvoji favoriti","Deine Favoriten","Tus favoritos","Tes favoris"),23,Color.WHITE,true));
            hero.addView(label(t2("Choose a club below to start your personal football feed. You can follow several clubs and set one as primary.","Odaberi klub ispod kako bi pokrenuo svoj osobni nogometni sadržaj. Možeš pratiti više klubova i jedan postaviti kao glavni.","Wähle unten einen Klub, um deinen persönlichen Fußball-Feed zu starten. Du kannst mehreren Klubs folgen und einen als Hauptklub festlegen.","Elige un club para iniciar tu contenido personal. Puedes seguir varios clubes y marcar uno como principal.","Choisis un club ci-dessous pour démarrer ton fil personnel. Tu peux suivre plusieurs clubs et en définir un principal."),14,Color.WHITE,false));
            Button choose=outline("＋ "+t2("Choose a club","Odaberi klub","Klub auswählen","Elegir club","Choisir un club"));
            choose.setOnClickListener(v->{favoritesSection="clubs";showFavorites();});hero.addView(choose);
            return;
        }
        LinearLayout heroRow=hrow();
        View clubLogo=homeTeamVisual(club,dp(82),true);heroRow.addView(clubLogo,new LinearLayout.LayoutParams(dp(82),dp(82)));
        LinearLayout heroCopy=new LinearLayout(this);heroCopy.setOrientation(LinearLayout.VERTICAL);heroCopy.setPadding(dp(12),0,0,0);
        heroCopy.addView(label(t2("PRIMARY FAVORITE","GLAVNI FAVORIT","HAUPTFAVORIT","FAVORITO PRINCIPAL","FAVORI PRINCIPAL"),12,Color.WHITE,true));
        String clubHeroDisplayName=displayTeamName(club);int clubHeroTextSize=clubHeroDisplayName.length()>24?19:(clubHeroDisplayName.length()>18?21:24);TextView clubName=label(clubHeroDisplayName,clubHeroTextSize,Color.WHITE,true);clubName.setMaxLines(2);clubName.setEllipsize(null);clubName.setLineSpacing(0,0.94f);heroCopy.addView(clubName);
        heroCopy.addView(label(clubCountryFlag(club)+" "+displayCompetitionName(clubLeague(club)),15,Color.WHITE,true));
        heroRow.addView(heroCopy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(heroRow);
        Button openClub=outline(t2("Open club center","Otvori centar kluba","Klubzentrum öffnen","Abrir centro del club","Ouvrir le centre du club"));openClub.setOnClickListener(v->showClubCenter(club));hero.addView(openClub);
    }

    void addFavoritesTabs(){
        LinearLayout tabs=card();tabs.setPadding(dp(10),dp(10),dp(10),dp(10));
        HorizontalScrollView scroll=premiumHorizontalScroll();
        LinearLayout row=hrow();row.setPadding(dp(2),0,dp(20),0);
        final TextView[] activeFavoriteTab=new TextView[1];
        String[][] sections={
                {"overview",t2("Overview","Pregled","Übersicht","Resumen","Aperçu")},
                {"clubs",t2("Clubs","Klubovi","Klubs","Clubes","Clubs")},
                {"players",t2("Players","Igrači","Spieler","Jugadores","Joueurs")},
                {"matches",t2("Matches","Utakmice","Spiele","Partidos","Matchs")},
                {"competitions",t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions")}
        };
        for(int i=0;i<sections.length;i++){
            String key=sections[i][0];TextView tab=chip(sections[i][1]);tab.setSingleLine(true);tab.setMinWidth(dp(88));
            if(key.equals(favoritesSection)){tab.setTextColor(Color.WHITE);tab.setBackground(gradient(RED_DARK,RED,dp(18)));activeFavoriteTab[0]=tab;}
            tab.setOnClickListener(v->{favoritesSection=key;showFavorites();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));if(i>0)lp.setMargins(dp(7),0,0,0);row.addView(tab,lp);
        }
        scroll.addView(row,new HorizontalScrollView.LayoutParams(-2,-2));tabs.addView(horizontalMenuRail(scroll,dp(48)),new LinearLayout.LayoutParams(-1,dp(48)));
        scroll.post(()->centerHorizontalChild(scroll,activeFavoriteTab[0]));
    }

    String localizedCountNoun(int count,String category){
        boolean one=count==1;
        if("HR".equals(lang)){
            int mod10=Math.abs(count)%10,mod100=Math.abs(count)%100;boolean few=mod10>=2&&mod10<=4&&!(mod100>=12&&mod100<=14);
            if("club".equals(category))return one?"klub":(few?"kluba":"klubova");
            if("team".equals(category))return one?"tim":(few?"tima":"timova");
            if("player".equals(category))return one?"igrač":(few?"igrača":"igrača");
            if("match".equals(category))return one?"utakmica":(few?"utakmice":"utakmica");
            if("competition".equals(category))return one?"natjecanje":(few?"natjecanja":"natjecanja");
        }
        if("club".equals(category))return t2(one?"club":"clubs",one?"klub":"klubova",one?"Klub":"Klubs",one?"club":"clubes",one?"club":"clubs");
        if("team".equals(category))return t2(one?"team":"teams",one?"tim":"timova",one?"Team":"Teams",one?"equipo":"equipos",one?"équipe":"équipes");
        if("player".equals(category))return t2(one?"player":"players",one?"igrač":"igrača",one?"Spieler":"Spieler",one?"jugador":"jugadores",one?"joueur":"joueurs");
        if("match".equals(category))return t2(one?"match":"matches",one?"utakmica":"utakmica",one?"Spiel":"Spiele",one?"partido":"partidos",one?"match":"matchs");
        return t2(one?"competition":"competitions",one?"natjecanje":"natjecanja",one?"Wettbewerb":"Wettbewerbe",one?"competición":"competiciones",one?"compétition":"compétitions");
    }

    void addFavoritesOverview(){
        LinearLayout summary=card();summary.addView(label("⭐ "+t2("Your football","Tvoj nogomet","Dein Fußball","Tu fútbol","Ton football"),21,text,true));
        LinearLayout first=hrow();
        int clubCount=favoriteClubs.size(),playerCount=favoritePlayerList().size(),competitionCount=followedCompetitions.size();
        first.addView(homeStat(String.valueOf(clubCount),localizedCountNoun(clubCount,"club"),v->{favoritesSection="clubs";showFavorites();}),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(8),0,dp(8),0);
        first.addView(homeStat(String.valueOf(playerCount),localizedCountNoun(playerCount,"player"),v->{favoritesSection="players";showFavorites();}),mid);
        first.addView(homeStat(String.valueOf(competitionCount),localizedCountNoun(competitionCount,"competition"),v->{favoritesSection="competitions";showFavorites();}),new LinearLayout.LayoutParams(0,-2,1));summary.addView(first);

        Match next=nextFavoriteMatch();
        LinearLayout nextCard=card();nextCard.addView(label("📅 "+t2("Next for you","Sljedeće za tebe","Als Nächstes für dich","Lo próximo para ti","À venir pour toi"),21,text,true));
        if(next!=null)addDynamicHomeMatch(nextCard,next);else nextCard.addView(label(t2("No upcoming verified favorite match is available.","Nema dostupne nadolazeće provjerene utakmice favorita.","Kein kommendes verifiziertes Favoritenspiel verfügbar.","No hay próximo partido verificado de favoritos.","Aucun prochain match vérifié de favoris."),14,subText,false));
        Button allMatches=outline(t2("Open favorite matches","Otvori utakmice favorita","Favoritenspiele öffnen","Abrir partidos favoritos","Ouvrir les matchs favoris"));allMatches.setOnClickListener(v->{matchFavoritesOnly=true;matchDateFilter="ALL";matchStatusFilter="All";matchCenterPage=0;showMatches();});nextCard.addView(allMatches);

        LinearLayout quick=card();quick.addView(label("⚡ "+t2("Quick access","Brzi pristup","Schnellzugriff","Acceso rápido","Accès rapide"),21,text,true));
        LinearLayout r1=hrow();Button clubs=outline("⭐ "+t2("Clubs","Klubovi","Klubs","Clubes","Clubs"));clubs.setOnClickListener(v->{favoritesSection="clubs";showFavorites();});Button players=outline("👤 "+t2("Players","Igrači","Spieler","Jugadores","Joueurs"));players.setOnClickListener(v->{favoritesSection="players";showFavorites();});r1.addView(clubs,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams p1=new LinearLayout.LayoutParams(0,dp(52),1);p1.setMargins(dp(8),0,0,0);r1.addView(players,p1);quick.addView(r1);
        LinearLayout r2=hrow();Button matches=outline("📌 "+t2("Tracked matches","Praćene utakmice","Verfolgte Spiele","Partidos seguidos","Matchs suivis"));matches.setOnClickListener(v->{favoritesSection="matches";showFavorites();});Button competitions=outline("🏆 "+t2("Competitions","Natjecanja","Wettbewerbe","Competiciones","Compétitions"));competitions.setOnClickListener(v->{favoritesSection="competitions";showFavorites();});r2.addView(matches,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams p2=new LinearLayout.LayoutParams(0,dp(52),1);p2.setMargins(dp(8),dp(8),0,0);r2.addView(competitions,p2);quick.addView(r2);

        LinearLayout notifications=card();notifications.addView(label("🔔 "+t2("Notifications","Obavijesti","Benachrichtigungen","Notificaciones","Notifications"),21,text,true));
        notifications.addView(label(t2("Open the notification center for real alerts created from synchronized favorite data.","Otvori centar obavijesti za stvarne obavijesti nastale iz sinkroniziranih podataka favorita.","Öffne die Benachrichtigungszentrale für echte Hinweise aus synchronisierten Favoritendaten.","Abre el centro de avisos reales creados con datos sincronizados de favoritos.","Ouvre le centre pour les vraies alertes issues des favoris synchronisés."),14,subText,false));
        Button openNotifications=outline(t2("Open notification center","Otvori centar obavijesti","Benachrichtigungen öffnen","Abrir centro de avisos","Ouvrir les notifications"));openNotifications.setOnClickListener(v->showNotificationCenter());notifications.addView(openNotifications);
    }

    void addFavoriteClubsSection(){
        LinearLayout selectedClubs=card();selectedClubs.addView(label("⭐ "+t2("Clubs you follow","Klubovi koje pratiš","Gefolgte Klubs","Clubes que sigues","Clubs suivis"),21,text,true));
        if(favoriteClubs.isEmpty())selectedClubs.addView(label(t2("You are not following any clubs yet.","Još ne pratiš nijedan klub.","Du folgst noch keinem Klub.","Aún no sigues ningún club.","Tu ne suis encore aucun club."),14,subText,false));
        for(String selectedClub:favoriteClubs){
            final String selectedName=selectedClub;LinearLayout selectedRow=hrow();selectedRow.setPadding(dp(9),dp(9),dp(9),dp(9));selectedRow.setGravity(Gravity.CENTER_VERTICAL);selectedRow.setBackground(round(chipBg,dp(17),1));
            selectedRow.addView(homeTeamVisual(selectedName,dp(52),false),new LinearLayout.LayoutParams(dp(52),dp(52)));
            LinearLayout selectedCopy=new LinearLayout(this);selectedCopy.setOrientation(LinearLayout.VERTICAL);selectedCopy.setPadding(dp(11),0,0,0);selectedCopy.addView(label(displayTeamName(selectedName),15,text,true));
            selectedCopy.addView(label((sameTeam(selectedName,favoriteClub)?"★ "+t2("Primary","Glavni","Haupt","Principal","Principal")+"  •  ":"")+displayCompetitionName(clubLeague(selectedName)),12,sameTeam(selectedName,favoriteClub)?RED:subText,true));selectedRow.addView(selectedCopy,new LinearLayout.LayoutParams(0,-2,1));
            String favoriteStatus=favoriteClubMatchStatus(selectedName);if(favoriteStatus.length()>0){TextView statusBadge=centerLabel(favoriteStatus,10,Color.WHITE,true);statusBadge.setPadding(dp(8),dp(5),dp(8),dp(5));statusBadge.setBackground(round(favoriteStatus.startsWith("●")?RED:Color.rgb(61,69,88),dp(12),0));selectedRow.addView(statusBadge);}
            selectedRow.addView(label("›",25,RED,true),new LinearLayout.LayoutParams(dp(32),dp(42)));selectedRow.setOnClickListener(v->showClubCenter(selectedName));LinearLayout.LayoutParams selectedLp=new LinearLayout.LayoutParams(-1,-2);selectedLp.setMargins(0,dp(4),0,dp(4));selectedClubs.addView(selectedRow,selectedLp);
        }

        LinearLayout choose=card();choose.addView(label("🔎 "+t2("Club directory","Imenik klubova","Klubverzeichnis","Directorio de clubes","Annuaire des clubs"),21,text,true));
        choose.addView(label(t2("Search clubs, follow several and choose one primary club. Changes are saved automatically.","Pretraži klubove, prati ih više i odaberi jedan glavni klub. Promjene se spremaju automatski.","Suche Klubs, folge mehreren und wähle einen Hauptklub. Änderungen werden automatisch gespeichert.","Busca clubes, sigue varios y elige uno principal. Los cambios se guardan automáticamente.","Recherche des clubs, suis-en plusieurs et choisis un club principal. Les changements sont enregistrés automatiquement."),13,subText,false));
        EditText search=new EditText(this);search.setHint(t2("Search club","Traži klub","Klub suchen","Buscar club","Rechercher un club"));search.setText(favoriteClubSearch);search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(subText);search.setTextSize(14);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(chipBg,dp(16),1));choose.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        ArrayList<ClubProfile> profiles=favoriteClubDirectoryProfiles();ArrayList<String> competitionValues=clubCompetitionOptions(profiles);ArrayList<String> competitionLabels=new ArrayList<String>();competitionLabels.add(t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"));for(String value:competitionValues)competitionLabels.add(displayCompetitionName(value));
        int selectedIndex=0;if(!favoriteClubCompetitionFilter.equals("ALL")){for(int i=0;i<competitionValues.size();i++)if(competitionValues.get(i).equals(favoriteClubCompetitionFilter)){selectedIndex=i+1;break;}}
        Spinner competitionSpinner=spinner(competitionLabels,competitionLabels.get(Math.min(selectedIndex,competitionLabels.size()-1)));choose.addView(competitionSpinner,new LinearLayout.LayoutParams(-1,dp(54)));
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);choose.addView(results);renderClubPicker(results);
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence value,int start,int count,int after){}public void onTextChanged(CharSequence value,int start,int before,int count){favoriteClubSearch=value==null?"":value.toString();favoriteClubPickerLimit=18;renderClubPicker(results);}public void afterTextChanged(Editable editable){}});
        final boolean[] initial={true};competitionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> parent){}public void onItemSelected(AdapterView<?> parent,View view,int position,long id){if(initial[0]){initial[0]=false;return;}favoriteClubCompetitionFilter=position<=0?"ALL":competitionValues.get(position-1);favoriteClubPickerLimit=18;renderClubPicker(results);}});

        LinearLayout teamCard=card();teamCard.addView(label("🌍 "+t2("National team","Reprezentacija","Nationalteam","Selección","Équipe nationale"),21,text,true));teamCard.addView(label(t2("The selected national team is saved automatically.","Odabrana reprezentacija sprema se automatski.","Das gewählte Nationalteam wird automatisch gespeichert.","La selección se guarda automáticamente.","L’équipe nationale est enregistrée automatiquement."),13,subText,false));Spinner team=spinner(data.teams,myTeam);teamCard.addView(team);final boolean[] teamInitial={true};team.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> parent){}public void onItemSelected(AdapterView<?> parent,View view,int position,long id){if(teamInitial[0]){teamInitial[0]=false;return;}String selected=parent.getItemAtPosition(position).toString();if(!sameTeam(selected,myTeam)){myTeam=selected;userPreferences.saveNationalTeam(myTeam);syncMatchRemindersAsync();toast(t2("Saved automatically","Automatski spremljeno","Automatisch gespeichert","Guardado automáticamente","Enregistré automatiquement"));}}});
    }

    void addFavoritePlayersSection(){
        LinearLayout followedPlayers=card();followedPlayers.addView(label("👤 "+t2("Players you follow","Igrači koje pratiš","Gefolgte Spieler","Jugadores que sigues","Joueurs suivis"),21,text,true));
        if(!ENABLE_PLAYER_DATA_MODULES){
            followedPlayers.addView(label(t2("Player favorites will become available automatically when a verified player data source is connected.","Favoriti igrača postat će automatski dostupni kada povežemo provjereni izvor podataka o igračima.","Spielerfavoriten werden automatisch verfügbar, sobald eine verifizierte Spielerdatenquelle verbunden ist.","Los favoritos de jugadores estarán disponibles automáticamente al conectar una fuente verificada.","Les favoris joueurs seront disponibles automatiquement lorsqu’une source vérifiée sera connectée."),14,subText,false));
            return;
        }
        ArrayList<PlayerRecord> savedPlayers=favoritePlayerList();
        if(savedPlayers.isEmpty())followedPlayers.addView(label(t2("Follow players from a club squad or open the player directory.","Prati igrače iz kadra kluba ili otvori imenik igrača.","Folge Spielern aus einem Kader oder öffne das Spielerverzeichnis.","Sigue jugadores desde una plantilla o abre el directorio.","Suis des joueurs depuis un effectif ou ouvre l’annuaire."),14,subText,false));else for(PlayerRecord savedPlayer:savedPlayers)addPlayerDirectoryRow(followedPlayers,savedPlayer);
        Button playerDirectory=outline("👥 "+t2("Open player directory","Otvori imenik igrača","Spielerverzeichnis öffnen","Abrir directorio","Ouvrir l’annuaire"));playerDirectory.setOnClickListener(v->showPlayersHub());followedPlayers.addView(playerDirectory);
    }

    void addFavoriteMatchesSection(){
        LinearLayout tracked=card();tracked.addView(label("📌 "+t2("Tracked matches","Praćene utakmice","Verfolgte Spiele","Partidos seguidos","Matchs suivis"),21,text,true));ArrayList<Match> trackedMatches=followedMatchList();
        if(trackedMatches.isEmpty()){tracked.addView(label(t2("Open any match and tap Follow match to keep it here.","Otvori bilo koju utakmicu i pritisni Prati utakmicu kako bi ostala ovdje.","Öffne ein Spiel und tippe auf Spiel verfolgen.","Abre un partido y pulsa Seguir partido.","Ouvre un match et touche Suivre le match."),14,subText,false));Button browseMatches=outline("⚽ "+t2("Browse matches","Pregledaj utakmice","Spiele ansehen","Ver partidos","Voir les matchs"));browseMatches.setOnClickListener(v->{matchStatusFilter="All";matchDateFilter="ALL";showMatches();});tracked.addView(browseMatches);}else for(Match trackedMatch:trackedMatches)addDynamicHomeMatch(tracked,trackedMatch);
    }

    void addFavoriteCompetitionsSection(){
        LinearLayout followed=card();followed.addView(label("🏆 "+t2("Competitions you follow","Natjecanja koja pratiš","Gefolgte Wettbewerbe","Competiciones seguidas","Compétitions suivies"),21,text,true));
        if(followedCompetitions.isEmpty())followed.addView(label(t2("No competitions followed yet.","Još ne pratiš nijedno natjecanje.","Noch keine Wettbewerbe gefolgt.","Aún no sigues competiciones.","Aucune compétition suivie."),14,subText,false));else for(String comp:followedCompetitions){final String cn=comp;TextView competitionRow=label(competitionIcon(comp)+"  "+displayCompetitionName(comp)+"   ›",15,text,true);competitionRow.setPadding(dp(10),dp(11),dp(10),dp(11));competitionRow.setBackground(round(chipBg,dp(15),0));competitionRow.setOnClickListener(v->showCompetitionHub(cn,competitionRegion(cn)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));followed.addView(competitionRow,lp);}
        Button all=outline(t2("Browse all competitions","Pregledaj sva natjecanja","Alle Wettbewerbe ansehen","Ver todas las competiciones","Voir toutes les compétitions"));all.setOnClickListener(v->showLeagues());followed.addView(all);
    }

    void showMatches(){
        normalizeMatchCenterFilters();
        String filterSignature=competitionFilter+"|"+groupFilter+"|"+matchDateFilter+"|"+matchStatusFilter+"|"+matchFavoritesOnly+"|"+matchFilter;
        if(!filterSignature.equals(lastMatchCenterFilterSignature)){matchCenterPage=0;lastMatchCenterFilterSignature=filterSignature;}
        clear(tr("Matches"),t2("Live scores, fixtures and results","Rezultati uživo, raspored i završene utakmice","Live-Ergebnisse, Spielplan und Resultate","Resultados en vivo, calendario y resultados","Scores en direct, calendrier et résultats"),"Matches");
        final int renderGeneration=screenGeneration;

        LinearLayout sync=card();sync.setPadding(dp(15),dp(13),dp(15),dp(13));
        LinearLayout sr=hrow();sr.setGravity(Gravity.CENTER_VERTICAL);String last=prefs.getString("online_lastChecked","");
        TextView syncDot=centerLabel("●",13,GREEN,true);syncDot.setBackground(round(Color.argb(28,44,201,142),dp(18),0));
        sr.addView(syncDot,new LinearLayout.LayoutParams(dp(36),dp(36)));
        LinearLayout sc=new LinearLayout(this);sc.setOrientation(LinearLayout.VERTICAL);sc.setPadding(dp(10),0,dp(8),0);
        TextView syncTitle=label(t2("Synchronized","Sinkronizirano","Synchronisiert","Sincronizado","Synchronisé"),14,text,true);
        sc.addView(syncTitle);
        String updateText=(last==null||last.trim().isEmpty())
                ?t2("not yet checked","još nije provjereno","noch nicht geprüft","aún no comprobado","pas encore vérifié")
                :displayLocalDateTime(last);
        TextView update=label(t2("Last check: ","Zadnja provjera: ","Letzte Prüfung: ","Última comprobación: ","Dernière vérification : ")+updateText,10,subText,false);update.setMaxLines(2);update.setEllipsize(android.text.TextUtils.TruncateAt.END);matchCenterLastUpdateView=update;sc.addView(update);
        sr.addView(sc,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=centerLabel("↻  "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"),11,RED,true);
        refresh.setSingleLine(true);refresh.setBackground(round(chipBg,dp(18),1));refresh.setOnClickListener(v->animateSelection(v,()->refreshOnlineSafe(true)));sr.addView(refresh,new LinearLayout.LayoutParams(dp(100),dp(44)));sync.addView(sr);

        addLiveNowOverview();
        addMatchDateSelector();
        addMatchCenterFilters();

        final LinearLayout loading=card();
        loading.setGravity(Gravity.CENTER);
        ProgressBar progress=new ProgressBar(this);loading.addView(progress,new LinearLayout.LayoutParams(dp(34),dp(34)));
        loading.addView(centerLabel(t2("Preparing matches…","Priprema utakmica…","Spiele werden vorbereitet…","Preparando partidos…","Préparation des matchs…"),13,subText,true));

        final String f=matchFilter.toLowerCase(homeLocale()).trim();
        final String competitionFilterSnapshot=competitionFilter;
        final String groupFilterSnapshot=groupFilter;
        final String dateFilterSnapshot=matchDateFilter;
        final String statusFilterSnapshot=matchStatusFilter;
        final boolean favoritesOnlySnapshot=matchFavoritesOnly;
        final ArrayList<Match> source=new ArrayList<Match>(data==null?Collections.<Match>emptyList():data.matches);
        final int requestedPage=Math.max(0,matchCenterPage);

        matchCenterExecutor.execute(()->{
            ArrayList<Match> shown=new ArrayList<Match>();
            for(Match m:source){
                if(!matchBelongsToCompetition(m,competitionFilterSnapshot))continue;
                if(!groupFilterSnapshot.equals("All")&&!m.group.equals(groupFilterSnapshot))continue;
                if(!dateFilterSnapshot.equals("ALL")&&!dateFilterSnapshot.equals(localDateKey(m)))continue;
                if(favoritesOnlySnapshot&&!matchMatchesFavorites(m))continue;
                if(f.length()>0){
                    String hay=(m.group+" "+m.home+" "+m.away+" "+displayTeamName(m.home)+" "+displayTeamName(m.away)+" "+m.venue+" "+m.competition+" "+friendlyCompetitionName(m)+" "+displayCompetitionName(friendlyCompetitionName(m))).toLowerCase(homeLocale());
                    if(!hay.contains(f))continue;
                }
                if(statusFilterSnapshot.equals("Finished")&&!matchIsFinished(m))continue;
                if(statusFilterSnapshot.equals("Live")&&!matchIsLive(m))continue;
                if(statusFilterSnapshot.equals("Upcoming")&&!matchIsUpcoming(m))continue;
                shown.add(m);
            }
            shown=dedupeCompetitionMatchList(shown);
            Collections.sort(shown,(a,b)->compareMatchCenterOrder(a,b));
            final int total=shown.size();
            final int pageCount=Math.max(1,(total+MATCH_CENTER_PAGE_SIZE-1)/MATCH_CENTER_PAGE_SIZE);
            final int safePage=Math.min(requestedPage,pageCount-1);
            final int from=Math.min(total,safePage*MATCH_CENTER_PAGE_SIZE);
            final int to=Math.min(total,from+MATCH_CENTER_PAGE_SIZE);
            final ArrayList<Match> pageMatches=new ArrayList<Match>(shown.subList(from,to));
            final LinkedHashMap<String,ArrayList<Match>> days=new LinkedHashMap<String,ArrayList<Match>>();
            for(Match match:pageMatches){String day=localDateKey(match);if(!days.containsKey(day))days.put(day,new ArrayList<Match>());days.get(day).add(match);}

            runOnUiThread(()->{
                if(screenGeneration!=renderGeneration||!"Matches".equals(currentScreen))return;
                matchCenterPage=safePage;
                try{content.removeView(loading);}catch(Exception ignored){}
                if(total==0){
                    LinearLayout empty=card();empty.setGravity(Gravity.CENTER);
                    empty.addView(centerLabel("⚽",34,text,true));
                    empty.addView(centerLabel(matchCenterEmptyTitle(),20,text,true));
                    empty.addView(centerLabel(matchCenterEmptyDetail(),13,subText,false));
                    LinearLayout actions=hrow();
                    Button reset=btn(t2("Reset filters","Poništi filtre","Filter zurücksetzen","Restablecer filtros","Réinitialiser"));
                    reset.setOnClickListener(v->{matchDateFilter="ALL";matchStatusFilter="All";matchFavoritesOnly=false;matchFilter="";competitionFilter="All";matchCenterPage=0;showMatches();});
                    actions.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));empty.addView(actions);
                    return;
                }
                addMatchCenterPageStatus(total,from,to,safePage,pageCount);
                ArrayList<Map.Entry<String,ArrayList<Match>>> sections=new ArrayList<Map.Entry<String,ArrayList<Match>>>(days.entrySet());
                renderMatchDaySectionsChunked(sections,0,renderGeneration);
            });
        });
    }

    void addMatchCenterPageStatus(int total,int from,int to,int page,int pageCount){
        LinearLayout pager=card();pager.setPadding(dp(14),dp(10),dp(14),dp(10));
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);
        Button previous=outline("‹");previous.setEnabled(page>0);previous.setAlpha(page>0?1f:.35f);
        previous.setOnClickListener(v->{if(matchCenterPage>0){matchCenterPage--;showMatches();}});
        row.addView(previous,new LinearLayout.LayoutParams(dp(52),dp(46)));
        TextView status=centerLabel((from+1)+"–"+to+" / "+total+"  •  "+t2("Page ","Stranica ","Seite ","Página ","Page ")+(page+1)+"/"+pageCount,12,subText,true);
        row.addView(status,new LinearLayout.LayoutParams(0,dp(46),1));
        Button next=outline("›");next.setEnabled(page+1<pageCount);next.setAlpha(page+1<pageCount?1f:.35f);
        next.setOnClickListener(v->{if(matchCenterPage+1<pageCount){matchCenterPage++;showMatches();}});
        row.addView(next,new LinearLayout.LayoutParams(dp(52),dp(46)));
        pager.addView(row);
    }

    void renderMatchDaySectionsChunked(final ArrayList<Map.Entry<String,ArrayList<Match>>> sections,final int index,final int generation){
        if(generation!=screenGeneration||!"Matches".equals(currentScreen)||index>=sections.size())return;
        int end=Math.min(sections.size(),index+2);
        for(int i=index;i<end;i++)addMatchDaySection(sections.get(i).getValue());
        if(end<sections.size())handler.postDelayed(()->renderMatchDaySectionsChunked(sections,end,generation),12);
    }

    String matchCenterEmptyTitle(){
        if("Finished".equals(matchStatusFilter))return t2("No finished matches for these filters","Nema završenih utakmica za odabrane filtre","Keine beendeten Spiele für diese Filter","No hay partidos finalizados para estos filtros","Aucun match terminé pour ces filtres");
        if("Live".equals(matchStatusFilter))return t2("No live matches right now","Trenutačno nema utakmica uživo","Derzeit keine Live-Spiele","No hay partidos en vivo ahora","Aucun match en direct actuellement");
        if("Upcoming".equals(matchStatusFilter))return t2("No upcoming matches for these filters","Nema nadolazećih utakmica za odabrane filtre","Keine kommenden Spiele für diese Filter","No hay próximos partidos para estos filtros","Aucun match à venir pour ces filtres");
        return t2("No matches for these filters","Nema utakmica za odabrane filtre","Keine Spiele für diese Filter","No hay partidos para estos filtros","Aucun match pour ces filtres");
    }

    String matchCenterEmptyDetail(){
        int competitionTotal=0, competitionUpcoming=0, competitionFinished=0, competitionLive=0;
        for(Match m:data.matches){
            if(!matchBelongsToCompetition(m,competitionFilter))continue;
            competitionTotal++;
            if(matchIsLive(m))competitionLive++;
            else if(matchIsFinished(m))competitionFinished++;
            else if(matchIsUpcoming(m))competitionUpcoming++;
        }
        if(!"All".equals(competitionFilter) && competitionTotal==0){
            return t2("The connected data source currently returned no matches for "+displayCompetitionName(competitionFilter)+".",
                    "Povezani izvor podataka trenutačno nije vratio nijednu utakmicu za "+displayCompetitionName(competitionFilter)+".",
                    "Die verbundene Datenquelle lieferte derzeit keine Spiele für "+displayCompetitionName(competitionFilter)+".",
                    "La fuente conectada no devolvió partidos para "+displayCompetitionName(competitionFilter)+".",
                    "La source connectée n’a renvoyé aucun match pour "+displayCompetitionName(competitionFilter)+".");
        }
        if("Finished".equals(matchStatusFilter) && competitionUpcoming>0){
            return t2("There are "+competitionUpcoming+" upcoming matches. Select Upcoming or All.",
                    "Postoji "+competitionUpcoming+" nadolazećih utakmica. Odaberi Nadolazeće ili Sve.",
                    "Es gibt "+competitionUpcoming+" kommende Spiele. Wähle Demnächst oder Alle.",
                    "Hay "+competitionUpcoming+" próximos partidos. Elige Próximos o Todos.",
                    "Il y a "+competitionUpcoming+" matchs à venir. Choisis À venir ou Tous.");
        }
        if("Upcoming".equals(matchStatusFilter) && competitionFinished>0){
            return t2("Only finished matches are available for the selected filters.","Za odabrane filtre dostupne su samo završene utakmice.","Für die gewählten Filter sind nur beendete Spiele verfügbar.","Solo hay partidos finalizados para estos filtros.","Seuls des matchs terminés sont disponibles pour ces filtres.");
        }
        return t2("Choose another date, competition or status, or turn off the My filter.","Odaberi drugi datum, natjecanje ili status ili isključi filtar „Moji”.","Wähle ein anderes Datum, einen Wettbewerb oder einen Status oder deaktiviere den Filter „Meine“.","Elige otra fecha, competición o estado, o desactiva el filtro «Mis».","Choisis une autre date, compétition ou un autre statut, ou désactive le filtre «Mes».");
    }

    void addLiveNowOverview(){
        ArrayList<Match> liveMatches=new ArrayList<>();
        for(Match match:data.matches)if(matchIsLive(match))liveMatches.add(match);
        if(liveMatches.isEmpty())return;
        Collections.sort(liveMatches,(a,b)->compareMatchCenterOrder(a,b));
        LinearLayout panel=card();panel.setPadding(dp(14),dp(14),dp(14),dp(14));panel.setBackground(gradient(Color.rgb(45,12,65),Color.rgb(121,20,72),dp(22)));
        LinearLayout head=hrow();head.setGravity(Gravity.CENTER_VERTICAL);
        TextView pulse=centerLabel("●",18,Color.rgb(255,70,104),true);head.addView(pulse,new LinearLayout.LayoutParams(dp(28),dp(28)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.addView(label(t2("ALL LIVE MATCHES","SVE UTAKMICE UŽIVO","ALLE LIVE-SPIELE","TODOS LOS PARTIDOS EN VIVO","TOUS LES MATCHS EN DIRECT"),17,Color.WHITE,true));copy.addView(label(liveMatchCountText(liveMatches.size()),11,Color.rgb(225,207,231),false));head.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView open=label(t2("Open all  ›","Otvori sve  ›","Alle öffnen  ›","Abrir todos  ›","Tout ouvrir  ›"),12,Color.WHITE,true);open.setOnClickListener(v->{matchStatusFilter="Live";matchDateFilter="ALL";showMatches();});head.addView(open);panel.addView(head);
        int limit=Math.min(5,liveMatches.size());for(int i=0;i<limit;i++)panel.addView(liveOverviewRow(liveMatches.get(i)));
        pulse.animate().alpha(.25f).scaleX(.72f).scaleY(.72f).setDuration(700).withEndAction(()->pulse.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()).start();
    }

    LinearLayout liveOverviewRow(Match match){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackground(round(Color.argb(36,255,255,255),dp(15),1));row.setClickable(true);row.setOnClickListener(v->showMatchDetails(match));applyPressFeedback(row);
        TextView minute=centerLabel(liveMinuteLabel(match),11,Color.WHITE,true);minute.setBackground(round(RED,dp(12),0));row.addView(minute,new LinearLayout.LayoutParams(dp(55),dp(34)));
        LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);names.setPadding(dp(10),0,dp(7),0);TextView teams=label(displayTeamName(match.home)+"  –  "+displayTeamName(match.away),13,Color.WHITE,true);teams.setSingleLine(true);teams.setEllipsize(android.text.TextUtils.TruncateAt.END);names.addView(teams);TextView comp=label(compactCompetitionName(friendlyCompetitionName(match)),10,Color.rgb(220,205,226),false);comp.setSingleLine(true);names.addView(comp);row.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        String score=(match.homeGoals>=0&&match.awayGoals>=0)?match.homeGoals+" : "+match.awayGoals:"LIVE";row.addView(centerLabel(score,18,Color.WHITE,true),new LinearLayout.LayoutParams(dp(62),dp(38)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,0);row.setLayoutParams(lp);return row;
    }

    String liveMinuteLabel(Match match){
        String status=MatchStatus.normalize(match==null?"":match.status);
        if(status.equals("half_time")||status.equals("ht")||status.equals("paused"))return "HT";
        if(status.equals("extra_time"))return "ET";
        if(status.equals("penalty_shootout"))return "PEN";
        String minute=match==null?"":match.minute;if(minute==null||minute.trim().length()==0)return "LIVE";return minute.replace("′","").replace("'","")+"′";
    }

    void normalizeMatchCenterFilters(){
        if(matchDateFilter==null||matchDateFilter.length()==0||matchDateFilter.equals("TODAY"))matchDateFilter=dateKeyOffset(0);
        if(matchStatusFilter.equals("Today")){matchDateFilter=dateKeyOffset(0);matchStatusFilter="All";}
        if(matchStatusFilter.equals("Tomorrow")){matchDateFilter=dateKeyOffset(1);matchStatusFilter="All";}
        if(!matchStatusFilter.equals("All")&&!matchStatusFilter.equals("Live")&&!matchStatusFilter.equals("Upcoming")&&!matchStatusFilter.equals("Finished"))matchStatusFilter="All";
    }

    String dateKeyOffset(int offset){
        Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,offset);
        return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
    }

    void addMatchDateSelector(){
        LinearLayout dateCard=card();dateCard.setPadding(dp(12),dp(11),dp(12),dp(11));
        LinearLayout head=hrow();head.addView(label(t2("MATCHDAY","DAN UTAKMICA","SPIELTAG","JORNADA","JOURNÉE"),14,text,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView allDates=label(t2("All dates","Svi datumi","Alle Daten","Todas las fechas","Toutes les dates"),12,matchDateFilter.equals("ALL")?RED:subText,true);
        allDates.setOnClickListener(v->{matchDateFilter="ALL";showMatches();});head.addView(allDates);dateCard.addView(head);
        HorizontalScrollView scroll=premiumHorizontalScroll();
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setPadding(dp(2),dp(4),dp(20),0);
        final TextView[] selectedChip=new TextView[1];
        TextView allChip=addMatchDateChip(row,"ALL",t2("ALL\nDATES","SVI\nDATUMI","ALLE\nDATEN","TODAS\nFECHAS","TOUTES\nDATES"));
        if("ALL".equals(matchDateFilter)) selectedChip[0]=allChip;
        for(int offset=-2;offset<=5;offset++){
            Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_YEAR,offset);
            String key=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
            String caption;
            if(offset==-1)caption=t2("YESTERDAY","JUČER","GESTERN","AYER","HIER")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else if(offset==0)caption=t2("TODAY","DANAS","HEUTE","HOY","AUJOURD’HUI")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else if(offset==1)caption=t2("TOMORROW","SUTRA","MORGEN","MAÑANA","DEMAIN")+"\n"+new SimpleDateFormat("d.M.",homeLocale()).format(c.getTime());
            else caption=MatchCenterFormatter.dateChip(c.getTime(),lang);
            TextView chip=addMatchDateChip(row,key,caption);
            if(key.equals(matchDateFilter)) selectedChip[0]=chip;
        }
        scroll.addView(row);dateCard.addView(horizontalMenuRail(scroll,dp(69)),new LinearLayout.LayoutParams(-1,dp(69)));
        scroll.post(()->centerHorizontalChild(scroll,selectedChip[0]));
    }

    TextView addMatchDateChip(LinearLayout row,String key,String caption){
        boolean selected=key.equals(matchDateFilter);
        TextView chip=centerLabel(caption,11,selected?Color.WHITE:subText,true);chip.setGravity(Gravity.CENTER);chip.setSingleLine(false);chip.setMinLines(2);
        chip.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        chip.setOnClickListener(v->animateSelection(v,()->{matchDateFilter=key;showMatches();}));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(86),dp(58));lp.setMargins(dp(3),dp(3),dp(3),dp(3));row.addView(chip,lp);
        return chip;
    }

    void addMatchCenterFilters(){
        LinearLayout filters=card();filters.setPadding(dp(14),dp(13),dp(14),dp(13));
        HorizontalScrollView quickScroll=premiumHorizontalScroll();
        LinearLayout quick=hrow();quick.setPadding(dp(2),0,dp(20),0);
        final TextView[] activeStatusChip=new TextView[1];
        TextView allStatus=addMatchStatusChip(quick,"All",t2("All","Sve","Alle","Todos","Tous"));if("All".equals(matchStatusFilter)&&!matchFavoritesOnly)activeStatusChip[0]=allStatus;
        TextView liveStatus=addMatchStatusChip(quick,"Live",t2("Live","Uživo","Live","En vivo","Direct"));if("Live".equals(matchStatusFilter)&&!matchFavoritesOnly)activeStatusChip[0]=liveStatus;
        TextView upcomingStatus=addMatchStatusChip(quick,"Upcoming",t2("Upcoming","Nadolazeće","Demnächst","Próximos","À venir"));if("Upcoming".equals(matchStatusFilter)&&!matchFavoritesOnly)activeStatusChip[0]=upcomingStatus;
        TextView finishedStatus=addMatchStatusChip(quick,"Finished",t2("Finished","Završeno","Beendet","Finalizados","Terminés"));if("Finished".equals(matchStatusFilter)&&!matchFavoritesOnly)activeStatusChip[0]=finishedStatus;
        TextView favorites=centerLabel("★ "+t2("My","Moji","Meine","Mis","Mes"),11,matchFavoritesOnly?Color.WHITE:text,true);favorites.setSingleLine(true);favorites.setMinWidth(dp(76));favorites.setPadding(dp(14),0,dp(14),0);favorites.setBackground(matchFavoritesOnly?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));favorites.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Favorite match filters","Filtri omiljenih utakmica","Favoritenfilter","Filtros de favoritos","Filtres des favoris"));return;}animateSelection(v,()->{matchFavoritesOnly=!matchFavoritesOnly;matchCenterPage=0;showMatches();});});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-2,dp(44));fp.setMargins(dp(4),dp(3),dp(2),dp(3));quick.addView(favorites,fp);if(matchFavoritesOnly)activeStatusChip[0]=favorites;
        quickScroll.addView(quick,new HorizontalScrollView.LayoutParams(-2,-2));filters.addView(horizontalMenuRail(quickScroll,dp(50)),new LinearLayout.LayoutParams(-1,dp(50)));
        quickScroll.post(()->centerHorizontalChild(quickScroll,activeStatusChip[0]));

        TextView competition=label("🏆 "+(competitionFilter.equals("All")?t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"):displayCompetitionName(competitionFilter))+"  ▾",13,text,true);competition.setSingleLine(true);competition.setEllipsize(android.text.TextUtils.TruncateAt.END);competition.setGravity(Gravity.CENTER_VERTICAL);competition.setPadding(dp(13),0,dp(13),0);competition.setBackground(round(chipBg,dp(16),1));competition.setOnClickListener(v->showMatchCompetitionDialog());LinearLayout.LayoutParams competitionParams=new LinearLayout.LayoutParams(-1,dp(50));competitionParams.setMargins(0,dp(8),0,0);filters.addView(competition,competitionParams);

        LinearLayout searchRow=hrow();
        EditText search=new EditText(this);search.setHint(t2("Team or competition","Klub ili natjecanje","Team oder Wettbewerb","Equipo o competición","Équipe ou compétition"));search.setText(matchFilter);search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(subText);search.setTextSize(14);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(chipBg,dp(16),1));
        Button apply=btn("⌕");apply.setTextSize(19);apply.setContentDescription(t2("Search","Pretraži","Suchen","Buscar","Rechercher"));apply.setOnClickListener(v->{matchFilter=search.getText().toString().trim();matchCenterPage=0;showMatches();});
        Button clear=outline("✕");clear.setTextSize(16);clear.setContentDescription(t2("Clear search","Očisti pretragu","Suche löschen","Limpiar búsqueda","Effacer la recherche"));clear.setOnClickListener(v->{matchFilter="";matchCenterPage=0;showMatches();});
        searchRow.addView(search,new LinearLayout.LayoutParams(0,dp(50),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(54),dp(50));ap.setMargins(dp(5),0,0,0);searchRow.addView(apply,ap);if(matchFilter.trim().length()>0){LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(dp(54),dp(50));cp.setMargins(dp(5),0,0,0);searchRow.addView(clear,cp);}LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(-1,-2);searchParams.setMargins(0,dp(8),0,0);filters.addView(searchRow,searchParams);
    }

    TextView addMatchStatusChip(LinearLayout row,String key,String caption){
        boolean selected=key.equals(matchStatusFilter)&&!matchFavoritesOnly;TextView chip=centerLabel(caption,11,selected?Color.WHITE:text,true);chip.setSingleLine(true);chip.setMinWidth(key.equals("Upcoming")?dp(112):dp(78));chip.setPadding(dp(14),0,dp(14),0);chip.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));chip.setOnClickListener(v->animateSelection(v,()->{matchFavoritesOnly=false;matchStatusFilter=key;if(key.equals("Finished")||key.equals("Upcoming"))matchDateFilter="ALL";matchCenterPage=0;showMatches();}));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(44));lp.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(chip,lp);return chip;
    }

    HorizontalScrollView premiumHorizontalScroll(){
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setHorizontalFadingEdgeEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(2),0,dp(2),0);
        return scroll;
    }

    LinearLayout horizontalMenuRail(HorizontalScrollView scroll,int height){
        LinearLayout rail=hrow();
        rail.setGravity(Gravity.CENTER_VERTICAL);
        TextView previous=centerLabel("‹",20,subText,true);
        TextView next=centerLabel("›",20,subText,true);
        previous.setContentDescription(t2("Previous options","Prethodne opcije","Vorherige Optionen","Opciones anteriores","Options précédentes"));
        next.setContentDescription(t2("More options","Još opcija","Weitere Optionen","Más opciones","Plus d’options"));
        previous.setBackground(round(Color.TRANSPARENT,dp(12),0));
        next.setBackground(round(Color.TRANSPARENT,dp(12),0));
        rail.addView(previous,new LinearLayout.LayoutParams(dp(24),height));
        rail.addView(scroll,new LinearLayout.LayoutParams(0,height,1));
        rail.addView(next,new LinearLayout.LayoutParams(dp(24),height));
        Runnable update=()->{
            boolean canPrevious=scroll.canScrollHorizontally(-1);
            boolean canNext=scroll.canScrollHorizontally(1);
            previous.setEnabled(canPrevious);previous.setAlpha(canPrevious?1f:.22f);
            next.setEnabled(canNext);next.setAlpha(canNext?1f:.22f);
        };
        int step=Math.max(dp(150),(int)(getResources().getDisplayMetrics().widthPixels*.55f));
        previous.setOnClickListener(v->scroll.smoothScrollBy(-step,0));
        next.setOnClickListener(v->scroll.smoothScrollBy(step,0));
        scroll.setOnScrollChangeListener((v,scrollX,scrollY,oldScrollX,oldScrollY)->update.run());
        rail.post(update);
        return rail;
    }

    void centerHorizontalChild(HorizontalScrollView scroll,View child){
        if(scroll==null||child==null)return;
        View parent=(View)child.getParent();
        int maxScroll=parent==null?0:Math.max(0,parent.getWidth()-scroll.getWidth());
        int x=child.getLeft()-(scroll.getWidth()-child.getWidth())/2;
        scroll.smoothScrollTo(Math.min(maxScroll,Math.max(0,x)),0);
    }

    void showMatchCompetitionDialog(){
        ArrayList<String> values=new ArrayList<>();values.add("All");values.addAll(CompetitionCatalog.all().keySet());
        String[] labels=new String[values.size()];int checked=0;
        for(int i=0;i<values.size();i++){
            String value=values.get(i);labels[i]=value.equals("All")?t2("All competitions","Sva natjecanja","Alle Wettbewerbe","Todas las competiciones","Toutes les compétitions"):displayCompetitionName(value);
            if(value.equals(competitionFilter))checked=i;
        }
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle(t2("Choose competition","Odaberi natjecanje","Wettbewerb wählen","Elegir competición","Choisir une compétition"))
                .setSingleChoiceItems(labels,checked,(d,which)->{competitionFilter=values.get(which);matchDateFilter="ALL";matchCenterPage=0;d.dismiss();showMatches();})
                .setNegativeButton(t2("Cancel","Odustani","Abbrechen","Cancelar","Annuler"),null)
                .create();
        dialog.show();
    }

    boolean matchMatchesFavorites(Match m){
        if(m==null)return false;
        if(sameTeam(m.home,myTeam)||sameTeam(m.away,myTeam))return true;
        if(favoriteClubs!=null)for(String club:favoriteClubs)if(sameTeam(m.home,club)||sameTeam(m.away,club))return true;
        String competition=friendlyCompetitionName(m);
        return followedCompetitions!=null&&followedCompetitions.contains(competition);
    }

    String croatianMatchNoun(int count){
        int absolute=Math.abs(count);
        int lastTwo=absolute%100;
        int last=absolute%10;
        if(lastTwo>=12&&lastTwo<=14)return "utakmica";
        if(last>=2&&last<=4)return "utakmice";
        return "utakmica";
    }

    String matchCountText(int count){
        if("HR".equals(lang))return count+" "+croatianMatchNoun(count);
        return count+" "+(count==1?t2("match","utakmica","Spiel","partido","match"):t2("matches","utakmice","Spiele","partidos","matchs"));
    }

    String liveMatchCountText(int count){
        if("HR".equals(lang))return count+" "+croatianMatchNoun(count)+" u tijeku";
        return count+" "+(count==1?t2("match in progress","utakmica u tijeku","laufendes Spiel","partido en curso","match en cours"):t2("matches in progress","utakmice u tijeku","laufende Spiele","partidos en curso","matchs en cours"));
    }

    String duplicateTeamKey(String team){
        String key=teamKey(team);
        if(key==null)return "";
        key=key.trim();

        // Provider naming variants.  These suffixes do not change club identity
        // and are safe to ignore only when deciding whether two fixtures are the
        // same match.
        String[] suffixes=new String[]{
                "associationfootballclub",
                "footballclub",
                "athleticfootballclub",
                "associationfc",
                "afc",
                "fc"
        };
        boolean changed=true;
        while(changed&&key.length()>0){
            changed=false;
            for(String suffix:suffixes){
                if(key.length()>suffix.length()+2&&key.endsWith(suffix)){
                    key=key.substring(0,key.length()-suffix.length());
                    changed=true;
                    break;
                }
            }
        }

        // Known provider variants that are not pure suffix differences.
        if(key.equals("wolverhamptonwanderers")||key.equals("wolverhampton"))return "wolverhamptonwanderers";
        if(key.equals("blackburnrovers"))return "blackburnrovers";
        if(key.equals("boltonwanderers"))return "boltonwanderers";
        if(key.equals("prestonnorthend"))return "prestonnorthend";
        if(key.equals("bristolcity"))return "bristolcity";
        if(key.equals("queensparkrangers")||key.equals("qpr"))return "queensparkrangers";

        return key;
    }

    String duplicateMatchDayKey(Match match){
        if(match==null||match.date==null||match.date.trim().isEmpty())return "";
        String day=localDateKey(match);
        if(day!=null&&day.length()>=10)return day.substring(0,10);
        String raw=match.date.trim();
        return raw.length()>=10?raw.substring(0,10):"";
    }

    String duplicateCompetitionKey(Match match){
        if(match==null)return "";
        String raw=match.competition==null?"":match.competition.trim();
        if(raw.isEmpty())raw=friendlyCompetitionName(match);

        // Resolve every known provider code/name through the same catalog that
        // the UI uses. This lets bundled "Eredivisie" match remote "DED", and
        // bundled "Primeira Liga" match remote "PPL", etc.
        for(String known:CompetitionCatalog.all().keySet()){
            if(competitionIdentityMatches(raw,known)){
                return Normalizer.normalize(known.toLowerCase(Locale.ROOT),Normalizer.Form.NFD)
                        .replaceAll("\\p{M}+","")
                        .replaceAll("[^a-z0-9]+","");
            }
        }

        raw=displayCompetitionName(raw);
        return Normalizer.normalize(raw.toLowerCase(Locale.ROOT),Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","")
                .replaceAll("[^a-z0-9]+","");
    }

    String duplicateMatchKey(Match match){
        if(match==null)return "";
        ClubProfile knownHome=ClubIdentityRegistry.resolve(match.home);
        ClubProfile knownAway=ClubIdentityRegistry.resolve(match.away);
        if(knownHome!=null)match.home=knownHome.name;
        if(knownAway!=null)match.away=knownAway.name;
        String homeKey=duplicateTeamKey(match.home),awayKey=duplicateTeamKey(match.away);
        if(homeKey.isEmpty()||awayKey.isEmpty())return "";
        String first=homeKey.compareTo(awayKey)<=0?homeKey:awayKey;
        String second=homeKey.compareTo(awayKey)<=0?awayKey:homeKey;
        // Domestic return legs can involve the same two clubs again months later.
        // When a verified matchday exists, it is a safer fixture identity than
        // the date because postponed matches may later receive a replacement day.
        if(match.matchday>0)
            return first+"|"+second+"|md:"+match.matchday+"|"+duplicateCompetitionKey(match);
        String dayKey=duplicateMatchDayKey(match);
        if(dayKey.isEmpty())return "";
        return first+"|"+second+"|day:"+dayKey+"|"+duplicateCompetitionKey(match);
    }

    int matchDataRichness(Match match){
        if(match==null)return 0;
        int score=0;
        if(match.apiId>0)score+=12;
        if(match.detailsAvailable)score+=10;
        if(match.homeGoals>=0&&match.awayGoals>=0)score+=8;
        if(match.eventsText!=null&&!match.eventsText.trim().isEmpty())score+=8;
        if(match.statsText!=null&&!match.statsText.trim().isEmpty())score+=7;
        if(match.homeLineupText!=null&&!match.homeLineupText.trim().isEmpty())score+=6;
        if(match.awayLineupText!=null&&!match.awayLineupText.trim().isEmpty())score+=6;
        if(match.actualVenue!=null&&!match.actualVenue.trim().isEmpty())score+=4;
        if(match.refereeText!=null&&!match.refereeText.trim().isEmpty())score+=3;
        if(match.date!=null&&match.date.trim().length()>10)score+=2;
        if(match.status!=null&&!match.status.trim().isEmpty())score+=2;
        return score;
    }

    String canonicalDuplicateDisplayName(String team){
        String key=duplicateTeamKey(team);
        if(key.equals("telstar"))return "Telstar";
        if(key.equals("sportingcp"))return "Sporting CP";
        if(key.equals("blackburnrovers"))return "Blackburn Rovers";
        if(key.equals("boltonwanderers"))return "Bolton Wanderers";
        if(key.equals("prestonnorthend"))return "Preston North End";
        if(key.equals("wolverhamptonwanderers"))return "Wolverhampton Wanderers";
        return team==null?"":team.trim();
    }

    void mergeDuplicateMatchBasics(Match target,Match source){
        if(target==null||source==null)return;

        String canonicalHome=canonicalDuplicateDisplayName(target.home);
        String canonicalAway=canonicalDuplicateDisplayName(target.away);
        if(canonicalHome.length()>0)target.home=canonicalHome;
        if(canonicalAway.length()>0)target.away=canonicalAway;

        // Keep cleaner visible club names when the two rows differ only by a
        // provider suffix such as "FC". The fixture identity has already been
        // confirmed by duplicateMatchKey().
        if(duplicateTeamKey(target.home).equals(duplicateTeamKey(source.home))
                &&target.home!=null&&source.home!=null
                &&target.home.trim().length()>source.home.trim().length()
                &&target.home.trim().toLowerCase(Locale.ROOT).endsWith(" fc")){
            target.home=source.home;
        }
        if(duplicateTeamKey(target.away).equals(duplicateTeamKey(source.away))
                &&target.away!=null&&source.away!=null
                &&target.away.trim().length()>source.away.trim().length()
                &&target.away.trim().toLowerCase(Locale.ROOT).endsWith(" fc")){
            target.away=source.away;
        }

        if((target.competition==null||target.competition.trim().isEmpty())&&source.competition!=null)target.competition=source.competition;
        if((target.date==null||target.date.trim().isEmpty())&&source.date!=null)target.date=source.date;
        if((target.venue==null||target.venue.trim().isEmpty())&&source.venue!=null)target.venue=source.venue;
        if((target.roundName==null||target.roundName.trim().isEmpty())&&source.roundName!=null)target.roundName=source.roundName;
        if((target.status==null||target.status.trim().isEmpty())&&source.status!=null)target.status=source.status;
        if((target.minute==null||target.minute.trim().isEmpty())&&source.minute!=null)target.minute=source.minute;
        if(target.matchday<=0&&source.matchday>0)target.matchday=source.matchday;
        if(target.apiId<=0&&source.apiId>0)target.apiId=source.apiId;
    }

    int removeDuplicateMatches(){
        if(data==null||data.matches==null||data.matches.size()<2)return 0;
        ArrayList<Match> unique=new ArrayList<Match>();
        LinkedHashMap<String,Integer> positions=new LinkedHashMap<String,Integer>();
        int removed=0;
        for(Match candidate:data.matches){
            String key=duplicateMatchKey(candidate);
            if(key.isEmpty()){
                unique.add(candidate);
                continue;
            }
            Integer position=positions.get(key);
            if(position==null){
                positions.put(key,unique.size());
                unique.add(candidate);
                continue;
            }
            Match current=unique.get(position);
            Match preferred=matchDataRichness(candidate)>matchDataRichness(current)?candidate:current;
            Match other=preferred==current?candidate:current;
            mergeDuplicateMatchBasics(preferred,other);
            unique.set(position,preferred);
            removed++;
        }
        if(removed>0){
            data.matches.clear();
            data.matches.addAll(unique);
        }
        return removed;
    }

    int compareMatchCenterOrder(Match a,Match b){
        Date da=localMatchDate(a),db=localMatchDate(b);
        if(!matchDateFilter.equals("ALL")){
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        }
        int pa=matchIsLive(a)?0:matchIsUpcoming(a)?1:2;
        int pb=matchIsLive(b)?0:matchIsUpcoming(b)?1:2;
        if(pa!=pb)return pa-pb;
        if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;
        return pa==2?db.compareTo(da):da.compareTo(db);
    }

    void addMatchDaySection(ArrayList<Match> matches){
        if(matches==null||matches.isEmpty())return;
        Match first=matches.get(0);Date date=localMatchDate(first);
        String heading=displayMatchDayHeading(first);
        LinearLayout dayHead=hrow();dayHead.setGravity(Gravity.CENTER_VERTICAL);TextView name=label(heading,18,text,true);dayHead.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        String dayCount=matchCountText(matches.size());
        TextView dayBadge=centerLabel(dayCount,10,subText,true);dayBadge.setPadding(dp(9),dp(4),dp(9),dp(4));dayBadge.setBackground(round(chipBg,dp(13),1));dayHead.addView(dayBadge,new LinearLayout.LayoutParams(-2,dp(28)));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.setMargins(dp(4),dp(8),dp(4),dp(7));content.addView(dayHead,hp);

        LinkedHashMap<String,ArrayList<Match>> groups=new LinkedHashMap<>();
        for(Match m:matches){String competition=friendlyCompetitionName(m);if(!groups.containsKey(competition))groups.put(competition,new ArrayList<Match>());groups.get(competition).add(m);}
        for(Map.Entry<String,ArrayList<Match>> entry:groups.entrySet())addCompetitionMatchCard(entry.getKey(),entry.getValue());
    }

    LinearLayout compactMatchTeamLine(String team){
        LinearLayout line=hrow();
        line.setGravity(Gravity.CENTER_VERTICAL);
        View crest=homeTeamVisual(team,dp(22),false);
        line.addView(crest,new LinearLayout.LayoutParams(dp(22),dp(22)));
        String visibleName=compactTeamCardName(canonicalDuplicateDisplayName(team));
        int nameSize=compactTeamCardTextSize(visibleName);
        TextView name=label(visibleName,nameSize,text,true);
        name.setMaxLines(2);
        name.setEllipsize(null);
        name.setLineSpacing(0,0.92f);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(44),1);
        np.setMargins(dp(8),0,0,0);
        line.addView(name,np);
        return line;
    }

    String displayMatchDayHeading(Match m){
        Date d=localMatchDate(m);if(d==null)return t2("Matches","Utakmice","Spiele","Partidos","Matchs");
        String key=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);
        if(key.equals(dateKeyOffset(0)))return t2("Today","Danas","Heute","Hoy","Aujourd’hui")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        if(key.equals(dateKeyOffset(1)))return t2("Tomorrow","Sutra","Morgen","Mañana","Demain")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        if(key.equals(dateKeyOffset(-1)))return t2("Yesterday","Jučer","Gestern","Ayer","Hier")+" • "+new SimpleDateFormat("d.M.",homeLocale()).format(d);
        return MatchCenterFormatter.dayHeading(d,lang);
    }

    void addCompetitionMatchCard(String competition,ArrayList<Match> matches){
        LinearLayout group=card();group.setPadding(dp(13),dp(11),dp(13),dp(8));
        LinearLayout head=hrow();
        head.addView(label(competitionIcon(competition)+" "+displayCompetitionName(competition),14,text,true),new LinearLayout.LayoutParams(0,-2,1));
        int live=0;for(Match m:matches)if(matchIsLive(m))live++;
        TextView count=centerLabel(live>0?"● "+live+" "+t2("live","uživo","live","en vivo","direct"):String.valueOf(matches.size()),11,Color.WHITE,true);
        count.setPadding(dp(9),dp(4),dp(9),dp(4));count.setBackground(round(live>0?RED:Color.rgb(61,69,88),dp(12),0));
        head.addView(count,new LinearLayout.LayoutParams(-2,dp(28)));group.addView(head);
        for(int i=0;i<matches.size();i++){
            if(i>0){View divider=new View(this);divider.setBackgroundColor(stroke);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(1));dl.setMargins(0,dp(5),0,dp(5));group.addView(divider,dl);}
            addCompactMatchRow(group,matches.get(i));
        }
    }

    void addCompactMatchRow(LinearLayout parent,Match m){
        final Match selected=m;
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(1),dp(7),dp(1),dp(7));row.setClickable(true);applyPressFeedback(row);row.setOnClickListener(v->showMatchDetails(selected));
        LinearLayout main=hrow();main.setGravity(Gravity.CENTER_VERTICAL);

        String leftStatus=compactMatchStatus(m);
        int statusColor=matchIsLive(m)?Color.rgb(19,156,101):matchIsFinished(m)?Color.rgb(61,69,88):Color.rgb(127,43,67);
        String statusPrefix=matchIsLive(m)?"● ":matchIsFinished(m)?"✓ ":"⏰ ";
        TextView status=centerLabel(statusPrefix+leftStatus,10,Color.WHITE,true);status.setSingleLine(true);status.setPadding(dp(6),0,dp(6),0);status.setBackground(round(statusColor,dp(13),0));
        LinearLayout.LayoutParams statusLp=new LinearLayout.LayoutParams(dp(94),dp(36));statusLp.setMargins(0,dp(12),0,dp(12));main.addView(status,statusLp);

        LinearLayout teams=new LinearLayout(this);teams.setOrientation(LinearLayout.VERTICAL);teams.setPadding(dp(5),0,dp(5),0);
        teams.addView(compactMatchTeamLine(m.home),new LinearLayout.LayoutParams(-1,dp(46)));
        teams.addView(compactMatchTeamLine(m.away),new LinearLayout.LayoutParams(-1,dp(46)));
        main.addView(teams,new LinearLayout.LayoutParams(0,dp(92),1));

        LinearLayout scores=new LinearLayout(this);scores.setOrientation(LinearLayout.VERTICAL);scores.setGravity(Gravity.CENTER);
        if(m.homeGoals<0&&m.awayGoals<0&&!matchIsLive(m)&&!matchIsFinished(m)){
            scores.addView(centerLabel("VS",13,subText,true),new LinearLayout.LayoutParams(dp(38),dp(92)));
        }else{
            String hs=m.homeGoals>=0?String.valueOf(m.homeGoals):"–";String as=m.awayGoals>=0?String.valueOf(m.awayGoals):"–";
            scores.addView(centerLabel(hs,17,matchIsLive(m)?RED:text,true),new LinearLayout.LayoutParams(dp(32),dp(28)));
            scores.addView(centerLabel(as,17,matchIsLive(m)?RED:text,true),new LinearLayout.LayoutParams(dp(32),dp(28)));
        }
        main.addView(scores,new LinearLayout.LayoutParams(dp(40),dp(92)));
        TextView arrow=centerLabel("›",20,subText,true);main.addView(arrow,new LinearLayout.LayoutParams(dp(22),dp(88)));row.addView(main);
        String phase=stageLabel(m);if(phase.length()>0){TextView phaseView=label(phase,11,subText,false);phaseView.setPadding(dp(94),0,dp(5),0);row.addView(phaseView);}
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
    }

    String compactMatchStatus(Match m){
        if(matchIsLive(m)){
            String minute=m.minute==null?"":m.minute.replace("'","").replace("′","").trim();
            return minute.length()>0?minute+"′":t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT");
        }
        if(matchIsFinished(m))return t2("FT","KRAJ","ENDE","FINAL","FIN");
        return compactHomeTimeLabel(m,false);
    }

    String matchDetailDateLabel(Match m){
        Date date=localMatchDate(m);if(date==null)return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        if(!isMatchTimeTba(m))return MatchCenterFormatter.fullDate(date,lang);
        String value=new SimpleDateFormat("EEEE, d. MMMM",homeLocale()).format(date);
        if(value.length()>0)value=Character.toUpperCase(value.charAt(0))+value.substring(1);
        return value+"  •  "+t2("Time TBA","Vrijeme naknadno","Zeit offen","Hora pendiente","Horaire à confirmer");
    }

    String displayCompetitionName(String competition){
        if(competition==null)return "";
        String value=competition.trim();
        String key=value.toLowerCase(Locale.ROOT)
                .replace("–","-")
                .replace("—","-");
        if(key.equals("wc")||key.equals("world cup")||key.equals("world cup 2026")||key.equals("fifa world cup"))return t2("World Cup 2026","Svjetsko prvenstvo 2026","Weltmeisterschaft 2026","Mundial 2026","Coupe du monde 2026");
        if(key.equals("ec")||key.equals("euro")||key.equals("uefa european championship"))return t2("UEFA European Championship","UEFA Europsko prvenstvo","UEFA-Europameisterschaft","Campeonato Europeo de la UEFA","Championnat d’Europe UEFA");
        if(key.equals("cl")||key.equals("champions league")||key.equals("uefa champions league")||key.equals("liga prvaka"))return t2("UEFA Champions League","Liga prvaka","UEFA Champions League","Liga de Campeones","Ligue des champions");
        if(key.equals("el")||key.equals("uefa europa league")||key.equals("europa league"))return t2("UEFA Europa League","Europska liga","UEFA Europa League","Liga Europa","Ligue Europa");
        if(key.equals("uecl")||key.equals("uefa conference league")||key.equals("uefa europa conference league")||key.equals("conference league"))return t2("UEFA Conference League","Konferencijska liga","UEFA Conference League","Liga Conferencia","Ligue Conférence");
        if(key.equals("pl")||key.equals("premier league"))return "Premier League";
        if(key.equals("pd")||key.equals("primera division")||key.equals("la liga"))return "La Liga";
        if(key.equals("bl1")||key.equals("bundesliga"))return "Bundesliga";
        if(key.equals("sa")||key.equals("serie a"))return "Serie A";
        if(key.equals("fl1")||key.equals("ligue 1"))return "Ligue 1";
        if(key.equals("ded")||key.equals("eredivisie"))return "Eredivisie";
        if(key.equals("ppl")||key.equals("primeira liga"))return "Primeira Liga";
        if(key.equals("elc")||key.equals("championship"))return t2("Championship","Championship","Championship","Championship","Championship");
        if(key.equals("hnl")||key.contains("hrvatska nogometna liga"))return "HNL";
        if(key.equals("bsa")||key.contains("brasileir"))return t2("Brazilian Série A","Brazilska Série A","Brasilianische Série A","Série A de Brasil","Série A brésilienne");
        return value;
    }

    String localizedCountryName(String country){
        if(country==null)return "";
        String value=country.trim();
        if(value.length()==0)return "";
        String key=value.toLowerCase(Locale.ROOT);
        if(key.equals("germany")||key.equals("deutschland")||key.equals("njemačka"))return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(key.equals("belgium")||key.equals("belgija"))return t2("Belgium","Belgija","Belgien","Bélgica","Belgique");
        if(key.equals("croatia")||key.equals("hrvatska"))return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(key.equals("spain")||key.equals("španjolska")||key.equals("espana")||key.equals("españa"))return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(key.equals("france")||key.equals("francuska"))return t2("France","Francuska","Frankreich","Francia","France");
        if(key.equals("italy")||key.equals("italija"))return t2("Italy","Italija","Italien","Italia","Italie");
        if(key.equals("england")||key.equals("engleska"))return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(key.equals("scotland")||key.equals("škotska"))return t2("Scotland","Škotska","Schottland","Escocia","Écosse");
        if(key.equals("wales")||key.equals("vels"))return t2("Wales","Wales","Wales","Gales","Pays de Galles");
        if(key.equals("netherlands")||key.equals("the netherlands")||key.equals("holland")||key.equals("nizozemska"))return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(key.equals("portugal"))return "Portugal";
        if(key.equals("austria")||key.equals("austrija"))return t2("Austria","Austrija","Österreich","Austria","Autriche");
        if(key.equals("switzerland")||key.equals("švicarska"))return t2("Switzerland","Švicarska","Schweiz","Suiza","Suisse");
        if(key.equals("denmark")||key.equals("danska"))return t2("Denmark","Danska","Dänemark","Dinamarca","Danemark");
        if(key.equals("sweden")||key.equals("švedska"))return t2("Sweden","Švedska","Schweden","Suecia","Suède");
        if(key.equals("norway")||key.equals("norveška"))return t2("Norway","Norveška","Norwegen","Noruega","Norvège");
        if(key.equals("finland")||key.equals("finska"))return t2("Finland","Finska","Finnland","Finlandia","Finlande");
        if(key.equals("poland")||key.equals("poljska"))return t2("Poland","Poljska","Polen","Polonia","Pologne");
        if(key.equals("czech republic")||key.equals("czechia")||key.equals("češka"))return t2("Czechia","Češka","Tschechien","Chequia","Tchéquie");
        if(key.equals("slovakia")||key.equals("slovačka"))return t2("Slovakia","Slovačka","Slowakei","Eslovaquia","Slovaquie");
        if(key.equals("slovenia")||key.equals("slovenija"))return t2("Slovenia","Slovenija","Slowenien","Eslovenia","Slovénie");
        if(key.equals("serbia")||key.equals("srbija"))return t2("Serbia","Srbija","Serbien","Serbia","Serbie");
        if(key.equals("bosnia and herzegovina")||key.equals("bosnia-herzegovina")||key.equals("bosna i hercegovina"))return t2("Bosnia and Herzegovina","Bosna i Hercegovina","Bosnien und Herzegowina","Bosnia y Herzegovina","Bosnie-Herzégovine");
        if(key.equals("montenegro")||key.equals("crna gora"))return t2("Montenegro","Crna Gora","Montenegro","Montenegro","Monténégro");
        if(key.equals("albania")||key.equals("albanija"))return t2("Albania","Albanija","Albanien","Albania","Albanie");
        if(key.equals("greece")||key.equals("grčka"))return t2("Greece","Grčka","Griechenland","Grecia","Grèce");
        if(key.equals("turkey")||key.equals("türkiye")||key.equals("turska"))return t2("Türkiye","Turska","Türkei","Turquía","Turquie");
        if(key.equals("ukraine")||key.equals("ukrajina"))return t2("Ukraine","Ukrajina","Ukraine","Ucrania","Ukraine");
        if(key.equals("romania")||key.equals("rumunjska"))return t2("Romania","Rumunjska","Rumänien","Rumanía","Roumanie");
        if(key.equals("hungary")||key.equals("mađarska"))return t2("Hungary","Mađarska","Ungarn","Hungría","Hongrie");
        if(key.equals("brazil")||key.equals("brazil"))return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        if(key.equals("argentina"))return "Argentina";
        if(key.equals("uruguay"))return "Uruguay";
        if(key.equals("colombia")||key.equals("kolumbija"))return t2("Colombia","Kolumbija","Kolumbien","Colombia","Colombie");
        if(key.equals("united states")||key.equals("usa")||key.equals("united states of america"))return t2("United States","SAD","Vereinigte Staaten","Estados Unidos","États-Unis");
        if(key.equals("canada")||key.equals("kanada"))return t2("Canada","Kanada","Kanada","Canadá","Canada");
        if(key.equals("mexico")||key.equals("meksiko"))return t2("Mexico","Meksiko","Mexiko","México","Mexique");
        if(key.equals("japan")||key.equals("japan"))return t2("Japan","Japan","Japan","Japón","Japon");
        if(key.equals("south korea")||key.equals("korea republic")||key.equals("južna koreja"))return t2("South Korea","Južna Koreja","Südkorea","Corea del Sur","Corée du Sud");
        if(key.equals("australia")||key.equals("australija"))return t2("Australia","Australija","Australien","Australia","Australie");
        if(key.equals("morocco")||key.equals("maroko"))return t2("Morocco","Maroko","Marokko","Marruecos","Maroc");
        if(key.equals("senegal"))return "Senegal";
        if(key.equals("nigeria")||key.equals("nigerija"))return t2("Nigeria","Nigerija","Nigeria","Nigeria","Nigeria");
        return value;
    }

    LinearLayout matchDetailTeamBlock(String team){
        LinearLayout block=new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        block.setGravity(Gravity.CENTER);

        View crest=homeTeamVisual(team,dp(84),false);
        crest.setElevation(dp(6));
        block.addView(crest,new LinearLayout.LayoutParams(dp(84),dp(84)));

        String displayName=displayTeamName(team);
        TextView name=centerLabel(twoLineClubName(displayName),smartMatchTeamTextSize(displayName),Color.WHITE,true);
        name.setSingleLine(false);
        name.setMaxLines(2);
        name.setMinLines(2);
        name.setHorizontallyScrolling(false);
        name.setEllipsize(null);
        name.setGravity(Gravity.CENTER);
        name.setLineSpacing(0f,1.02f);
        name.setPadding(dp(2),dp(8),dp(2),dp(2));
        block.addView(name,new LinearLayout.LayoutParams(-1,dp(58)));
        return block;
    }

    int smartMatchTeamTextSize(String value){
        int length=value==null?0:value.trim().length();
        if(length>24)return 12;
        if(length>18)return 13;
        if(length>14)return 15;
        return 17;
    }

    int smartInfoTextSize(String value){
        int length=value==null?0:value.trim().length();
        if(length>42)return 12;
        if(length>30)return 13;
        if(length>22)return 14;
        return 15;
    }

    boolean hasPlausibleHalfTimeScore(Match m){
        if(m==null||m.halfTimeScore==null||m.halfTimeScore.trim().isEmpty())return false;
        int[] pair=parseScorePair(m.halfTimeScore);
        if(pair==null)return false;
        if(pair[0]<0||pair[1]<0)return false;
        if(m.homeGoals>=0&&pair[0]>m.homeGoals)return false;
        if(m.awayGoals>=0&&pair[1]>m.awayGoals)return false;
        return true;
    }

    void showMatchDetails(Match m){
        if(!"MatchDetails".equals(currentScreen)) matchDetailsOriginScreen=currentScreen==null?"Matches":currentScreen;
        rememberLastDestination("match",personalMatchKey(m),displayTeamName(m.home)+" – "+displayTeamName(m.away));
        if(m==null){showMatches();return;}
        rememberOpenMatch(m);
        clear(displayCompetitionName(friendlyCompetitionName(m)),stageLabel(m),"MatchDetails");

        LinearLayout hero=card();hero.setPadding(dp(16),dp(20),dp(16),dp(18));hero.setBackground(gradient(Color.rgb(62,15,82),Color.rgb(237,29,83),dp(24)));
        LinearLayout.LayoutParams heroLp=(LinearLayout.LayoutParams)hero.getLayoutParams();heroLp.setMargins(0,0,0,dp(10));hero.setLayoutParams(heroLp);
        LinearLayout teams=hrow();teams.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout home=matchDetailTeamBlock(m.home);
        home.setClickable(true);home.setOnClickListener(v->showClubCenter(m.home));applyPressFeedback(home);
        LinearLayout center=new LinearLayout(this);center.setOrientation(LinearLayout.VERTICAL);center.setGravity(Gravity.CENTER);center.setPadding(dp(4),dp(2),dp(4),0);
        String result=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" : "+m.awayGoals:(matchHasResultUnavailable(m)?"—":"VS");
        TextView scoreView=centerLabel(result,result.equals("VS")?18:36,Color.WHITE,true);scoreView.setSingleLine(true);scoreView.setMaxLines(1);scoreView.setLetterSpacing(result.equals("VS")?.06f:0f);center.addView(scoreView);
        String status=matchIsUpcoming(m)?homeTimeLabel(m):homeCenterStatus(m);
        TextView statusView=centerLabel(status,11,Color.WHITE,true);statusView.setPadding(dp(13),dp(5),dp(13),dp(5));statusView.setBackground(matchStatusBadgeBackground(m));
        LinearLayout.LayoutParams statusLp=new LinearLayout.LayoutParams(-2,-2);statusLp.setMargins(0,dp(8),0,0);center.addView(statusView,statusLp);
        LinearLayout away=matchDetailTeamBlock(m.away);
        away.setClickable(true);away.setOnClickListener(v->showClubCenter(m.away));applyPressFeedback(away);
        teams.addView(home,new LinearLayout.LayoutParams(0,-2,1));teams.addView(center,new LinearLayout.LayoutParams(dp(112),-2));teams.addView(away,new LinearLayout.LayoutParams(0,-2,1));hero.addView(teams);

        ArrayList<String> metaParts=new ArrayList<>();
        metaParts.add(matchDetailDateLabel(m));
        String stadium=matchDetailStadium(m);
        if(stadium.length()>0)metaParts.add(stadium);
        TextView meta=centerLabel(joinParts(metaParts," • "),12,Color.WHITE,false);hero.addView(meta);
        if(hasPlausibleHalfTimeScore(m)&&(matchIsLive(m)||matchIsFinished(m)))hero.addView(centerLabel(t2("Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps")+": "+m.halfTimeScore,11,Color.WHITE,false));
        if(m.extraTimeScore!=null&&m.extraTimeScore.length()>0)hero.addView(centerLabel(t2("After extra time","Nakon produžetaka","Nach Verlängerung","Tras prórroga","Après prolongation")+": "+m.extraTimeScore,11,Color.WHITE,true));
        if(m.penaltyScore!=null&&m.penaltyScore.length()>0)hero.addView(centerLabel(t2("Penalties","Jedanaesterci","Elfmeterschießen","Penaltis","Tirs au but")+": "+m.penaltyScore,11,Color.rgb(255,230,150),true));
        ArrayList<String> officialParts=new ArrayList<>();
        if(m.refereeText!=null&&m.refereeText.length()>0)officialParts.add("🧑‍⚖️ "+m.refereeText);
        if(m.attendance>0)officialParts.add("👥 "+String.format(homeLocale(),"%,d",m.attendance));
        if(!officialParts.isEmpty())hero.addView(centerLabel(joinParts(officialParts,"   •   "),11,Color.WHITE,false));
        if(matchIsLive(m))hero.addView(centerLabel("● "+t2("Live updates every minute","Osvježavanje uživo svake minute","Live-Aktualisierung jede Minute","Actualización en vivo cada minuto","Actualisation en direct chaque minute"),11,Color.rgb(255,230,150),true));

        // Build 255: keep match opening instant. The old implementation built the
        // complete long-form Match Center synchronously inside the tap callback.
        // On devices under memory/GC pressure this could hold the main thread long
        // enough for Android to report an ANR before the detail screen appeared.
        final int detailGeneration=screenGeneration;
        final boolean hasEvents=m.eventsText!=null&&m.eventsText.trim().length()>0;
        final boolean hasStats=m.statsText!=null&&m.statsText.trim().length()>0;
        final boolean hasLineups=(m.homeLineupText!=null&&m.homeLineupText.trim().length()>0)||(m.awayLineupText!=null&&m.awayLineupText.trim().length()>0);
        renderMatchDetailsProgressively(m,stadium,hasEvents,hasStats,hasLineups,detailGeneration);
    }

    boolean matchDetailGenerationActive(int generation){
        return generation==screenGeneration&&"MatchDetails".equals(currentScreen);
    }

    void renderMatchDetailsProgressively(final Match m,final String stadium,final boolean hasEvents,final boolean hasStats,final boolean hasLineups,final int generation){
        // Phase 1 is intentionally posted instead of executed in the row click.
        // This gives Android a frame to present the hero and complete the input
        // dispatch before any secondary cards are constructed.
        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            addMatchDetailActions(m);
            addMatchInformationCard(m,stadium);
        },16);

        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            addPremiumMatchSnapshot(m,hasEvents,hasStats,hasLineups);
            addMatchAvailabilityCard(m,hasEvents,hasStats,hasLineups);
        },48);

        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            if(hasEvents)addTimelineCard(m);
            if(hasStats)addStatisticsCard(m.statsText);
            if(hasLineups){
                LinearLayout lineups=card();
                lineups.addView(label("👕 "+t2("Lineups","Sastavi","Aufstellungen","Alineaciones","Compositions"),21,text,true));
                addClickableLineup(lineups,m.home,m.homeFormation);
                addClickableLineup(lineups,m.away,m.awayFormation);
            }
        },80);

        // These three sections do the heaviest historical/standing scans. Keeping
        // them in separate frames prevents their combined cost from forming one
        // long main-thread stall while preserving the exact same final content.
        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            addFootballIntelligenceCard(m);
        },128);
        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            addMatchCenterOverview(m);
        },176);
        handler.postDelayed(()->{
            if(!matchDetailGenerationActive(generation))return;
            addHeadToHeadCard(m);
            startLiveMatchDetailsRefresh(m);
        },224);
    }

    void addMatchAvailabilityCard(Match m,boolean hasEvents,boolean hasStats,boolean hasLineups){
        LinearLayout availability=card();availability.setPadding(dp(16),dp(14),dp(16),dp(14));
        LinearLayout.LayoutParams availabilityLp=(LinearLayout.LayoutParams)availability.getLayoutParams();availabilityLp.setMargins(0,0,0,dp(10));availability.setLayoutParams(availabilityLp);
        availability.addView(label(t2("MATCH DATA","PODACI UTAKMICE","SPIELDATEN","DATOS DEL PARTIDO","DONNÉES DU MATCH"),13,text,true));
        LinearLayout availableRow=hrow();availableRow.setPadding(0,dp(9),0,dp(3));
        availableRow.addView(detailAvailabilityChip("⚡ "+t2("Timeline","Tijek","Verlauf","Cronología","Chronologie"),hasEvents),new LinearLayout.LayoutParams(0,dp(44),1));
        availableRow.addView(detailAvailabilityChip("📊 "+t2("Stats","Statistika","Statistik","Estadísticas","Stats"),hasStats),new LinearLayout.LayoutParams(0,dp(44),1));
        availableRow.addView(detailAvailabilityChip("👕 "+t2("Lineups","Sastavi","Aufstellungen","Alineaciones","Compos"),hasLineups),new LinearLayout.LayoutParams(0,dp(44),1));
        availability.addView(availableRow);
        if(!hasEvents&&!hasStats&&!hasLineups){
            availability.addView(label(matchIsLive(m)?t2("The live score is available. Detailed match data will appear automatically when the verified source publishes it.","Rezultat uživo je dostupan. Detaljni podaci utakmice pojavit će se automatski kada ih objavi provjereni izvor.","Der Live-Spielstand ist verfügbar. Detaildaten erscheinen automatisch, sobald die verifizierte Quelle sie veröffentlicht.","El marcador en vivo está disponible. Los datos detallados aparecerán automáticamente cuando los publique la fuente verificada.","Le score en direct est disponible. Les données détaillées apparaîtront automatiquement lorsqu’elles seront publiées par la source vérifiée."):t2("Detailed match data is not available for this match yet. Football Fun never fills missing values with estimates.","Detaljni podaci za ovu utakmicu još nisu dostupni. Football Fun podatke koji nedostaju nikada ne popunjava procjenama.","Für dieses Spiel sind noch keine Detaildaten verfügbar. Football Fun ergänzt fehlende Werte niemals durch Schätzungen.","Los datos detallados de este partido aún no están disponibles. Football Fun nunca completa valores ausentes con estimaciones.","Les données détaillées de ce match ne sont pas encore disponibles. Football Fun ne complète jamais les valeurs manquantes par des estimations."),13,subText,false));
            addUnavailableMatchDataSummary(availability);
            Button refresh=outline("↻  "+t2("Check for details","Provjeri detalje","Details prüfen","Comprobar detalles","Vérifier les détails"));
            refresh.setTextSize(14);refresh.setMinHeight(dp(44));
            refresh.setOnClickListener(v->{v.animate().rotationBy(180f).setDuration(260).start();refreshOnlineSafe(true);});
            LinearLayout.LayoutParams refreshLp=new LinearLayout.LayoutParams(-1,dp(46));refreshLp.setMargins(0,dp(10),0,0);availability.addView(refresh,refreshLp);
        }else if(!hasEvents||!hasStats||!hasLineups){
            availability.addView(label(t2("Only verified details supplied for this match are shown. Missing sections will appear automatically when they become available.","Prikazuju se samo provjereni detalji dostupni za ovu utakmicu. Dijelovi koji nedostaju pojavit će se automatski kada postanu dostupni.","Es werden nur verifizierte, für dieses Spiel verfügbare Details angezeigt. Fehlende Bereiche erscheinen automatisch, sobald sie verfügbar sind.","Solo se muestran los detalles verificados disponibles para este partido. Las secciones que faltan aparecerán automáticamente cuando estén disponibles.","Seuls les détails vérifiés disponibles pour ce match sont affichés. Les sections manquantes apparaîtront automatiquement lorsqu’elles seront disponibles."),12,subText,false));
        }
    }

    void addUnavailableMatchDataSummary(LinearLayout parent){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(12),dp(10));box.setBackground(round(chipBg,dp(16),1));
        addMatchDataWaitingRow(box,"📊",t2("Match statistics","Statistika utakmice","Spielstatistik","Estadísticas del partido","Statistiques du match"));
        addMatchDataWaitingRow(box,"🟨",t2("Events and cards","Događaji i kartoni","Ereignisse und Karten","Eventos y tarjetas","Événements et cartons"));
        addMatchDataWaitingRow(box,"👕",t2("Lineups and substitutions","Sastavi i zamjene","Aufstellungen und Wechsel","Alineaciones y cambios","Compositions et remplacements"));
        LinearLayout.LayoutParams boxLp=new LinearLayout.LayoutParams(-1,-2);boxLp.setMargins(0,dp(10),0,0);parent.addView(box,boxLp);
    }

    void addMatchDataWaitingRow(LinearLayout parent,String icon,String title){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(6),0,dp(6));
        TextView name=label(icon+"  "+title,13,text,true);name.setGravity(Gravity.CENTER_VERTICAL);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView state=centerLabel(t2("Not available","Nije dostupno","Nicht verfügbar","No disponible","Indisponible"),10,subText,true);state.setSingleLine(true);state.setPadding(dp(9),dp(4),dp(9),dp(4));state.setBackground(round(cardBg,dp(12),1));row.addView(state);
        parent.addView(row);
    }

    void addClickableLineup(LinearLayout parent,String club,String formation){
        ArrayList<PlayerRecord> players=playersForClub(club);if(players.isEmpty())return;
        parent.addView(label(flag(club)+" "+displayTeamName(club)+(formation!=null&&formation.length()>0?" • "+formation:""),16,RED,true));
        for(PlayerRecord player:players)addPlayerDirectoryRow(parent,player);
    }

    void addMatchDetailActions(Match m){
        LinearLayout actions=card();actions.setPadding(dp(12),dp(12),dp(12),dp(12));
        LinearLayout row=hrow();
        boolean homeFavorite=isFavoriteClubName(m.home);
        Button home=outline((homeFavorite?"★ ":"☆ ")+displayTeamName(m.home));
        home.setTextColor(homeFavorite?GOLD:text);
        home.setTextSize(12);home.setSingleLine(true);home.setOnClickListener(v->{toggleFavoriteClub(m.home);showMatchDetails(m);});
        row.addView(home,new LinearLayout.LayoutParams(0,dp(48),1));
        boolean awayFavorite=isFavoriteClubName(m.away);
        Button away=outline((awayFavorite?"★ ":"☆ ")+displayTeamName(m.away));
        away.setTextColor(awayFavorite?GOLD:text);
        away.setTextSize(12);away.setSingleLine(true);away.setOnClickListener(v->{toggleFavoriteClub(m.away);showMatchDetails(m);});
        LinearLayout.LayoutParams awayLp=new LinearLayout.LayoutParams(0,dp(48),1);awayLp.setMargins(dp(7),0,0,0);row.addView(away,awayLp);
        actions.addView(row);

        String competition=friendlyCompetitionName(m);
        LinearLayout quick=hrow();
        Button competitionButton=outline("🏆 "+displayCompetitionName(competition));competitionButton.setTextSize(12);competitionButton.setSingleLine(true);
        competitionButton.setOnClickListener(v->showCompetitionHub(competition,competitionRegion(competition)));
        quick.addView(competitionButton,new LinearLayout.LayoutParams(0,dp(48),1));
        Button table=outline("📊 "+t2("Table","Tablica","Tabelle","Tabla","Classement"));table.setTextSize(12);table.setEnabled(hasVerifiedStandings(competition));table.setOnClickListener(v->showLeagueStandings(competition));
        LinearLayout.LayoutParams tableLp=new LinearLayout.LayoutParams(0,dp(48),1);tableLp.setMargins(dp(7),0,0,0);quick.addView(table,tableLp);
        LinearLayout.LayoutParams quickLp=new LinearLayout.LayoutParams(-1,-2);quickLp.setMargins(0,dp(7),0,0);actions.addView(quick,quickLp);

        if(matchIsFinished(m)){
            Button share=outline("↗ "+t2("Share","Podijeli","Teilen","Compartir","Partager"));share.setTextSize(12);
            share.setOnClickListener(v->shareMatchDetails(m));
            LinearLayout.LayoutParams shareLp=new LinearLayout.LayoutParams(-1,dp(48));shareLp.setMargins(0,dp(7),0,0);actions.addView(share,shareLp);
        }else{
            Button followMatch=isFollowedMatch(m)?btn("✓ "+t2("Following this match","Pratiš ovu utakmicu","Du verfolgst dieses Spiel","Sigues este partido","Tu suis ce match")):outline("📌 "+t2("Follow this match","Prati ovu utakmicu","Dieses Spiel verfolgen","Seguir este partido","Suivre ce match"));
            followMatch.setTextSize(14);followMatch.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Following matches","Praćenje utakmica","Spiele folgen","Seguimiento de partidos","Suivi des matchs"));return;}toggleFollowedMatch(m);showMatchDetails(m);});
            LinearLayout.LayoutParams followLp=new LinearLayout.LayoutParams(-1,dp(50));followLp.setMargins(0,dp(7),0,0);actions.addView(followMatch,followLp);

            LinearLayout tools=hrow();
            Button reminder=outline("🔔 "+t2("Reminders","Podsjetnici","Erinnerungen","Recordatorios","Rappels"));reminder.setTextSize(11);
            reminder.setOnClickListener(v->{
                if(!favoriteNotifications){toast(t2("Enable match reminders in Notifications","Uključi podsjetnike u Obavijestima","Aktiviere Erinnerungen unter Benachrichtigungen","Activa los recordatorios en Notificaciones","Active les rappels dans Notifications"));}
                showNotificationCenter();
            });
            tools.addView(reminder,new LinearLayout.LayoutParams(0,dp(48),1));
            Button calendar=outline("📅 "+t2("Calendar","Kalendar","Kalender","Calendario","Calendrier"));calendar.setTextSize(11);
            Date calendarDate=localMatchDate(m);
            calendar.setEnabled(calendarDate!=null&&calendarDate.getTime()>System.currentTimeMillis());
            calendar.setOnClickListener(v->addMatchToCalendar(m));
            LinearLayout.LayoutParams calendarLp=new LinearLayout.LayoutParams(0,dp(48),1);calendarLp.setMargins(dp(7),0,0,0);tools.addView(calendar,calendarLp);
            Button share=outline("↗ "+t2("Share","Podijeli","Teilen","Compartir","Partager"));share.setTextSize(11);
            share.setOnClickListener(v->shareMatchDetails(m));
            LinearLayout.LayoutParams shareLp=new LinearLayout.LayoutParams(0,dp(48),1);shareLp.setMargins(dp(7),0,0,0);tools.addView(share,shareLp);
            LinearLayout.LayoutParams toolsLp=new LinearLayout.LayoutParams(-1,-2);toolsLp.setMargins(0,dp(7),0,0);actions.addView(tools,toolsLp);
        }
    }

    void addMatchToCalendar(Match m){
        if(m==null)return;
        Date kickoff=localMatchDate(m);
        if(kickoff==null){toast(t2("Match time is not available","Vrijeme utakmice nije dostupno","Spielzeit ist nicht verfügbar","La hora del partido no está disponible","L’heure du match n’est pas disponible"));return;}
        if(kickoff.getTime()<=System.currentTimeMillis()){toast(t2("Only upcoming matches can be added","U kalendar se mogu dodati samo nadolazeće utakmice","Nur kommende Spiele können hinzugefügt werden","Solo se pueden añadir partidos próximos","Seuls les matchs à venir peuvent être ajoutés"));return;}
        String title=displayTeamName(m.home)+" vs "+displayTeamName(m.away);
        StringBuilder description=new StringBuilder();
        description.append(displayCompetitionName(friendlyCompetitionName(m)));
        if(m.roundName!=null&&m.roundName.trim().length()>0)description.append(" • ").append(m.roundName.trim());
        description.append("\n\nFootball Fun");
        Intent intent=new Intent(Intent.ACTION_INSERT);
        intent.setData(Uri.parse("content://com.android.calendar/events"));
        intent.putExtra("title",title);
        intent.putExtra("description",description.toString());
        intent.putExtra("beginTime",kickoff.getTime());
        intent.putExtra("endTime",kickoff.getTime()+2L*60L*60L*1000L);
        String stadium=matchDetailStadium(m);if(stadium.length()>0)intent.putExtra("eventLocation",stadium);
        try{startActivity(intent);}catch(Exception e){toast(t2("No calendar app is available","Nije dostupna aplikacija kalendara","Keine Kalender-App verfügbar","No hay una aplicación de calendario disponible","Aucune application de calendrier disponible"));}
        hideSystemBars();
    }

    void shareMatchDetails(Match m){
        if(m==null)return;
        StringBuilder message=new StringBuilder();
        message.append("⚽ ").append(displayTeamName(m.home)).append(" vs ").append(displayTeamName(m.away)).append("\n");
        if(m.homeGoals>=0&&m.awayGoals>=0)message.append(m.homeGoals).append(" : ").append(m.awayGoals).append("\n");
        message.append(displayCompetitionName(friendlyCompetitionName(m)));
        String date=matchDetailDateLabel(m);if(date!=null&&date.length()>0)message.append("\n").append(date);
        String stadium=matchDetailStadium(m);if(stadium.length()>0)message.append("\n🏟️ ").append(stadium);
        message.append("\n\nFootball Fun");
        shareText(message.toString());
    }

    ArrayList<Match> headToHeadMatches(Match selected){
        ArrayList<Match> out=new ArrayList<Match>();
        if(selected==null)return out;
        for(Match candidate:data.matches){
            if(candidate==selected)continue;
            boolean samePair=(sameTeam(candidate.home,selected.home)&&sameTeam(candidate.away,selected.away))||(sameTeam(candidate.home,selected.away)&&sameTeam(candidate.away,selected.home));
            if(samePair&&matchIsFinished(candidate))out.add(candidate);
        }
        Collections.sort(out,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);});
        return out;
    }



    void addFootballIntelligenceCard(Match selected){
        if(selected==null)return;
        ArrayList<Match> homeRecent=recentFinishedMatches(selected.home,5,selected);
        ArrayList<Match> awayRecent=recentFinishedMatches(selected.away,5,selected);
        ArrayList<Match> h2h=headToHeadMatches(selected);
        JSONObject homeStanding=clubStandingRow(selected.home);
        JSONObject awayStanding=clubStandingRow(selected.away);
        int verifiedSignals=(homeRecent.isEmpty()?0:1)+(awayRecent.isEmpty()?0:1)+(homeStanding==null?0:1)+(awayStanding==null?0:1)+(h2h.isEmpty()?0:1);
        if(verifiedSignals==0)return;

        LinearLayout intelligence=card();intelligence.setPadding(dp(16),dp(16),dp(16),dp(16));
        LinearLayout titleRow=hrow();titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.addView(label("🧠 "+t2("Football Intelligence","Nogometna inteligencija","Fußball-Intelligenz","Inteligencia futbolística","Intelligence football"),21,text,true),new LinearLayout.LayoutParams(0,-2,1));

        boolean enoughRecentData=homeRecent.size()>=3&&awayRecent.size()>=3;
        boolean enoughContext=(homeStanding!=null&&awayStanding!=null)||h2h.size()>=2;
        boolean reliableComparison=enoughRecentData&&enoughContext;
        if(!reliableComparison){
            String limited=t2("INSUFFICIENT DATA","NEDOVOLJNO PODATAKA","ZU WENIG DATEN","DATOS INSUFICIENTES","DONNÉES INSUFFISANTES");
            TextView badge=centerLabel(limited,8,Color.WHITE,true);badge.setPadding(dp(8),dp(5),dp(8),dp(5));badge.setBackground(round(Color.rgb(90,78,96),dp(12),0));titleRow.addView(badge);intelligence.addView(titleRow);
            TextView message=label(t2("There is not enough verified data for a reliable comparison yet.","Nedovoljno podataka za pouzdanu usporedbu.","Noch nicht genügend verifizierte Daten für einen zuverlässigen Vergleich.","Todavía no hay suficientes datos verificados para una comparación fiable.","Il n’y a pas encore assez de données vérifiées pour une comparaison fiable."),15,text,true);
            message.setPadding(dp(12),dp(13),dp(12),dp(13));message.setBackground(round(chipBg,dp(15),1));intelligence.addView(message);
            TextView detail=label(t2("Percentages will appear only after both teams have enough recent results and verified context.","Postoci će se prikazati tek kada obje ekipe imaju dovoljno nedavnih rezultata i provjerenog konteksta.","Prozentwerte erscheinen erst, wenn beide Teams genügend aktuelle Ergebnisse und verifizierten Kontext haben.","Los porcentajes aparecerán cuando ambos equipos tengan suficientes resultados recientes y contexto verificado.","Les pourcentages apparaîtront lorsque les deux équipes disposeront de suffisamment de résultats récents et de contexte vérifié."),12,subText,false);
            detail.setPadding(0,dp(10),0,0);intelligence.addView(detail);
            return;
        }

        String coverage=verifiedSignals>=5?t2("STRONG DATA","JAKI PODACI","STARKE DATEN","DATOS SÓLIDOS","DONNÉES SOLIDES"):t2("VERIFIED","PROVJERENO","VERIFIZIERT","VERIFICADO","VÉRIFIÉ");
        TextView badge=centerLabel(coverage,10,Color.WHITE,true);badge.setPadding(dp(9),dp(5),dp(9),dp(5));badge.setBackground(round(verifiedSignals>=5?GREEN:Color.rgb(76,91,126),dp(12),0));titleRow.addView(badge);intelligence.addView(titleRow);
        intelligence.addView(label(t2("A transparent comparison built only from synchronized results and standings.","Transparentna usporedba izrađena samo iz sinkroniziranih rezultata i tablice.","Transparenter Vergleich nur aus synchronisierten Ergebnissen und Tabellen.","Comparación transparente basada solo en resultados y clasificación sincronizados.","Comparaison transparente basée uniquement sur les résultats et classements synchronisés."),12,subText,false));

        TeamInsight homeInsight=buildTeamInsight(selected.home,homeRecent,homeStanding);
        TeamInsight awayInsight=buildTeamInsight(selected.away,awayRecent,awayStanding);
        int[] balance=intelligenceBalance(homeInsight,awayInsight,h2h,selected);
        LinearLayout balanceRow=hrow();balanceRow.setPadding(0,dp(13),0,dp(5));
        balanceRow.addView(intelligenceSignal(displayTeamName(selected.home),balance[0],homeInsight.form),new LinearLayout.LayoutParams(0,dp(82),1));
        LinearLayout.LayoutParams drawLp=new LinearLayout.LayoutParams(0,dp(82),1);drawLp.setMargins(dp(7),0,dp(7),0);
        balanceRow.addView(intelligenceSignal(t2("Draw","Neriješeno","Remis","Empate","Nul"),balance[1],"—"),drawLp);
        balanceRow.addView(intelligenceSignal(displayTeamName(selected.away),balance[2],awayInsight.form),new LinearLayout.LayoutParams(0,dp(82),1));
        intelligence.addView(balanceRow);
        TextView note=centerLabel(t2("Data balance — not betting odds","Omjer podataka — nije kladioničarska kvota","Datenbalance — keine Wettquote","Balance de datos — no son cuotas","Équilibre des données — pas des cotes"),10,subText,false);note.setPadding(0,dp(1),0,dp(9));intelligence.addView(note);

        LinearLayout metrics=hrow();
        String formPoints=homeInsight.points+"/"+(homeInsight.played*3)+" : "+awayInsight.points+"/"+(awayInsight.played*3);
        metrics.addView(intelligenceMetric(formPoints,t2("Form points","Bodovi forme","Formpunkte","Puntos de forma","Points de forme")),new LinearLayout.LayoutParams(0,dp(68),1));
        LinearLayout.LayoutParams metricMid=new LinearLayout.LayoutParams(0,dp(68),1);metricMid.setMargins(dp(7),0,dp(7),0);
        metrics.addView(intelligenceMetric(formatOneDecimal(homeInsight.goalsForAverage)+" : "+formatOneDecimal(awayInsight.goalsForAverage),t2("Goals / match","Golovi / utakmica","Tore / Spiel","Goles / partido","Buts / match")),metricMid);
        String positions=(homeInsight.position>0?homeInsight.position+".":"—")+" : "+(awayInsight.position>0?awayInsight.position+".":"—");
        String thirdCaption=(homeInsight.position>0||awayInsight.position>0)?t2("League position","Mjesto na tablici","Tabellenplatz","Posición","Classement"):t2("Verified H2H","Provjereni H2H","Verifiziertes H2H","H2H verificado","H2H vérifié");
        String thirdValue=(homeInsight.position>0||awayInsight.position>0)?positions:String.valueOf(Math.min(5,h2h.size()));
        metrics.addView(intelligenceMetric(thirdValue,thirdCaption),new LinearLayout.LayoutParams(0,dp(68),1));
        intelligence.addView(metrics);

        String summary=intelligenceSummary(selected,homeInsight,awayInsight,h2h,balance);
        TextView summaryView=label("✨ "+summary,14,text,true);summaryView.setPadding(dp(12),dp(12),dp(12),dp(12));summaryView.setBackground(round(chipBg,dp(15),1));
        LinearLayout.LayoutParams summaryLp=new LinearLayout.LayoutParams(-1,-2);summaryLp.setMargins(0,dp(11),0,0);intelligence.addView(summaryView,summaryLp);
    }

    static final class TeamInsight{
        int played,points,goalsFor,goalsAgainst,position;
        String form="—";
        double goalsForAverage;
    }

    TeamInsight buildTeamInsight(String team,ArrayList<Match> recent,JSONObject standing){
        TeamInsight insight=new TeamInsight();StringBuilder form=new StringBuilder();
        if(recent!=null)for(Match match:recent){
            if(match.homeGoals<0||match.awayGoals<0)continue;
            boolean home=sameTeam(match.home,team);int gf=home?match.homeGoals:match.awayGoals,ga=home?match.awayGoals:match.homeGoals;
            insight.played++;insight.goalsFor+=gf;insight.goalsAgainst+=ga;
            if(gf>ga){insight.points+=3;form.append("W");}else if(gf==ga){insight.points+=1;form.append("D");}else form.append("L");
        }
        insight.form=form.length()>0?form.toString():"—";
        insight.goalsForAverage=insight.played>0?((double)insight.goalsFor/insight.played):0d;
        insight.position=standing==null?0:standing.optInt("position",0);
        return insight;
    }

    int[] intelligenceBalance(TeamInsight home,TeamInsight away,ArrayList<Match> h2h,Match selected){
        double homeScore=50,awayScore=50;
        if(home.played>0)homeScore+=((double)home.points/(home.played*3)-.5)*40;
        if(away.played>0)awayScore+=((double)away.points/(away.played*3)-.5)*40;
        homeScore+=(home.goalsFor-home.goalsAgainst)*1.5;awayScore+=(away.goalsFor-away.goalsAgainst)*1.5;
        if(home.position>0&&away.position>0){double gap=Math.min(12,Math.abs(home.position-away.position))*1.4;if(home.position<away.position)homeScore+=gap;else if(away.position<home.position)awayScore+=gap;}
        if(h2h!=null&&!h2h.isEmpty()){
            int limit=Math.min(5,h2h.size());
            for(int i=0;i<limit;i++){Match m=h2h.get(i);boolean selectedHomeAtHome=sameTeam(m.home,selected.home);int hg=selectedHomeAtHome?m.homeGoals:m.awayGoals,ag=selectedHomeAtHome?m.awayGoals:m.homeGoals;if(hg>ag)homeScore+=2;else if(ag>hg)awayScore+=2;}
        }
        double diff=homeScore-awayScore;int draw=(int)Math.round(Math.max(20,34-Math.min(14,Math.abs(diff)*.45)));
        int remaining=100-draw;int homePct=(int)Math.round(remaining*(.5+Math.max(-.28,Math.min(.28,diff/120d))));homePct=Math.max(20,Math.min(65,homePct));int awayPct=100-draw-homePct;
        if(awayPct<20){awayPct=20;homePct=100-draw-awayPct;}return new int[]{homePct,draw,awayPct};
    }

    LinearLayout intelligenceSignal(String name,int value,String form){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setGravity(Gravity.CENTER);block.setPadding(dp(5),dp(7),dp(5),dp(7));block.setBackground(round(chipBg,dp(15),1));
        TextView number=centerLabel(value+"%",20,value>=40?RED:text,true);block.addView(number);
        TextView title=centerLabel(name,10,text,true);title.setSingleLine(true);title.setEllipsize(android.text.TextUtils.TruncateAt.END);block.addView(title);
        if(form!=null&&!form.equals("—")){TextView f=centerLabel(form,9,subText,true);f.setLetterSpacing(.08f);block.addView(f);}return block;
    }

    LinearLayout intelligenceMetric(String value,String caption){
        LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(dp(5),dp(7),dp(5),dp(7));item.setBackground(round(Color.argb(24,255,255,255),dp(14),1));
        TextView main=centerLabel(value,14,text,true);main.setSingleLine(true);item.addView(main);TextView sub=centerLabel(caption.toUpperCase(homeLocale()),8,subText,true);sub.setMaxLines(2);sub.setGravity(Gravity.CENTER);sub.setPadding(0,dp(3),0,0);item.addView(sub);return item;
    }

    String intelligenceSummary(Match selected,TeamInsight home,TeamInsight away,ArrayList<Match> h2h,int[] balance){
        if(matchIsFinished(selected))return t2("The verified result is final; the comparison below explains the teams’ incoming data profile.","Rezultat je potvrđen; usporedba prikazuje podatkovni profil s kojim su ekipe ušle u susret.","Das Ergebnis ist bestätigt; der Vergleich zeigt das Datenprofil vor dem Spiel.","El resultado está confirmado; la comparación muestra el perfil previo de ambos equipos.","Le résultat est confirmé; la comparaison montre le profil des équipes avant le match.");
        int best=Math.max(balance[0],Math.max(balance[1],balance[2]));
        if(best==balance[1])return t2("The available data points to a balanced match without a clear advantage.","Dostupni podaci upućuju na izjednačen susret bez jasne prednosti.","Die verfügbaren Daten deuten auf ein ausgeglichenes Spiel ohne klaren Vorteil.","Los datos apuntan a un partido equilibrado sin ventaja clara.","Les données indiquent un match équilibré sans avantage net.");
        boolean homeEdge=balance[0]>balance[2];String leader=displayTeamName(homeEdge?selected.home:selected.away);TeamInsight lead=homeEdge?home:away,other=homeEdge?away:home;
        String reason;
        if(lead.points>other.points)reason=t2("stronger recent form","bolje nedavne forme","der stärkeren jüngsten Form","su mejor forma reciente","sa meilleure forme récente");
        else if(lead.position>0&&other.position>0&&lead.position<other.position)reason=t2("the better league position","boljeg položaja na tablici","der besseren Tabellenposition","su mejor posición en liga","sa meilleure position au classement");
        else reason=t2("the combined verified indicators","zbroja provjerenih pokazatelja","der kombinierten verifizierten Indikatoren","los indicadores verificados combinados","les indicateurs vérifiés combinés");
        return leader+" "+t2("has a small data edge because of ","ima malu podatkovnu prednost zbog ","hat einen kleinen Datenvorteil aufgrund ","tiene una ligera ventaja por ","possède un léger avantage grâce à ")+reason+".";
    }

    String formatOneDecimal(double value){return String.format(homeLocale(),"%.1f",value);}

    void addMatchCenterOverview(Match selected){
        if(selected==null)return;
        boolean hasForm=hasRecentFormData(selected.home)||hasRecentFormData(selected.away);
        JSONObject homeStanding=clubStandingRow(selected.home);
        JSONObject awayStanding=clubStandingRow(selected.away);
        ArrayList<Match> homeRecent=recentFinishedMatches(selected.home,5,selected);
        ArrayList<Match> awayRecent=recentFinishedMatches(selected.away,5,selected);
        ArrayList<Match> homeNext=upcomingMatches(selected.home,5,selected);
        ArrayList<Match> awayNext=upcomingMatches(selected.away,5,selected);
        if(!hasForm&&homeStanding==null&&awayStanding==null&&homeRecent.isEmpty()&&awayRecent.isEmpty()&&homeNext.isEmpty()&&awayNext.isEmpty())return;

        LinearLayout overview=card();
        overview.addView(label("⚽ "+t2("Match Center","Centar utakmice","Match-Zentrale","Centro del partido","Centre du match"),22,text,true));
        overview.addView(label(t2("Verified team form, league position and schedule","Provjerena forma, položaj na tablici i raspored ekipa","Verifizierte Form, Tabellenplatz und Spielplan","Forma, posición y calendario verificados","Forme, classement et calendrier vérifiés"),13,subText,false));

        if(hasForm){
            TextView heading=label("📈 "+t2("FORM — LAST 5","FORMA — ZADNJIH 5","FORM — LETZTE 5","FORMA — ÚLTIMOS 5","FORME — 5 DERNIERS"),12,subText,true);
            heading.setPadding(0,dp(14),0,dp(7));overview.addView(heading);
            addMatchFormRow(overview,selected.home);
            addMatchFormRow(overview,selected.away);
        }

        if(homeStanding!=null||awayStanding!=null){
            TextView heading=label("🏆 "+t2("LEAGUE POSITION","POLOŽAJ NA TABLICI","TABELLENPLATZ","POSICIÓN EN LIGA","CLASSEMENT"),12,subText,true);
            heading.setPadding(0,dp(15),0,dp(7));overview.addView(heading);
            LinearLayout standings=hrow();
            standings.addView(matchStandingBlock(selected.home,homeStanding),new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout.LayoutParams awayLp=new LinearLayout.LayoutParams(0,-2,1);awayLp.setMargins(dp(8),0,0,0);
            standings.addView(matchStandingBlock(selected.away,awayStanding),awayLp);
            overview.addView(standings);
        }

        addTeamSchedulePreview(overview,t2("Recent matches","Posljednje utakmice","Letzte Spiele","Últimos partidos","Derniers matchs"),"🕘",selected.home,homeRecent);
        addTeamSchedulePreview(overview,t2("Recent matches","Posljednje utakmice","Letzte Spiele","Últimos partidos","Derniers matchs"),"🕘",selected.away,awayRecent);
        addTeamSchedulePreview(overview,t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),"📅",selected.home,homeNext);
        addTeamSchedulePreview(overview,t2("Next matches","Sljedeće utakmice","Nächste Spiele","Próximos partidos","Prochains matchs"),"📅",selected.away,awayNext);
    }

    void addMatchFormRow(LinearLayout target,String team){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(0,dp(4),0,dp(4));
        View crest=homeTeamVisual(team,dp(34),false);row.addView(crest,new LinearLayout.LayoutParams(dp(34),dp(34)));
        String displayed=displayTeamName(team);
        TextView name=label(displayed,smartMatchTeamTextSize(displayed),text,true);name.setSingleLine(false);name.setMaxLines(2);name.setEllipsize(null);name.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams nameLp=new LinearLayout.LayoutParams(0,-2,1);nameLp.setMargins(dp(9),0,dp(6),0);row.addView(name,nameLp);
        String[] form=recentForm(team,5);
        for(String code:form){
            int color="W".equals(code)?GREEN:("L".equals(code)?RED:("D".equals(code)?Color.rgb(113,124,145):chipBg));
            TextView chip=centerLabel(code,11,"–".equals(code)?subText:Color.WHITE,true);chip.setBackground(round(color,dp(15),1));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(28),dp(28));lp.setMargins(dp(3),0,0,0);row.addView(chip,lp);
        }
        target.addView(row);
    }

    LinearLayout matchStandingBlock(String club,JSONObject standing){
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setGravity(Gravity.CENTER);block.setPadding(dp(10),dp(12),dp(10),dp(12));block.setBackground(round(chipBg,dp(16),1));
        TextView name=centerLabel(displayTeamName(club),13,text,true);name.setMaxLines(2);block.addView(name);
        if(standing==null){
            TextView empty=centerLabel(t2("No verified table","Nema provjerene tablice","Keine verifizierte Tabelle","Sin tabla verificada","Aucun classement vérifié"),11,subText,false);empty.setPadding(0,dp(8),0,0);block.addView(empty);return block;
        }
        int position=standing.optInt("position",0), played=standing.optInt("playedGames",0), points=standing.optInt("points",0), gd=standing.optInt("goalDifference",0);
        TextView pos=centerLabel(position>0?position+".":"—",30,RED,true);pos.setPadding(0,dp(5),0,0);block.addView(pos);
        block.addView(centerLabel(t2("position","mjesto","Platz","posición","place"),10,subText,true));
        String meta=played+" "+t2("played","odigrano","Spiele","jugados","joués")+"  •  "+points+" "+t2("pts","bod.","Pkt.","pts","pts")+"  •  GD "+signedNumber(gd);
        TextView stats=centerLabel(meta,11,text,true);stats.setPadding(0,dp(7),0,0);block.addView(stats);
        return block;
    }

    ArrayList<Match> recentFinishedMatches(String team,int limit,Match selected){
        ArrayList<Match> out=new ArrayList<>();
        Date selectedDate=localMatchDate(selected);
        for(Match match:data.matches){
            if(match==selected||!matchIsFinished(match))continue;
            if(!sameTeam(match.home,team)&&!sameTeam(match.away,team))continue;
            Date date=localMatchDate(match);
            if(selectedDate!=null&&date!=null&&date.after(selectedDate))continue;
            out.add(match);
        }
        Collections.sort(out,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);});
        if(out.size()>limit)return new ArrayList<Match>(out.subList(0,limit));
        return out;
    }

    ArrayList<Match> upcomingMatches(String team,int limit,Match selected){
        ArrayList<Match> out=new ArrayList<>();
        Date selectedDate=localMatchDate(selected);
        for(Match match:data.matches){
            if(match==selected||(!matchIsUpcoming(match)&&!matchIsLive(match)))continue;
            if(!sameTeam(match.home,team)&&!sameTeam(match.away,team))continue;
            Date date=localMatchDate(match);
            if(selectedDate!=null&&date!=null&&date.before(selectedDate))continue;
            out.add(match);
        }
        Collections.sort(out,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);});
        if(out.size()>limit)return new ArrayList<Match>(out.subList(0,limit));
        return out;
    }

    void addTeamSchedulePreview(LinearLayout target,String titleText,String icon,String team,ArrayList<Match> matches){
        if(matches==null||matches.isEmpty())return;
        TextView heading=label(icon+" "+titleText.toUpperCase(homeLocale())+" — "+displayTeamName(team),12,subText,true);heading.setPadding(0,dp(15),0,dp(6));target.addView(heading);
        for(Match match:matches)target.addView(matchCenterCompactMatch(match,team));
    }

    String croatianClubGenitive(String club){
        String display=displayTeamName(club);
        if(!"hr".equalsIgnoreCase(lang))return display;
        String key=teamKey(display);
        if(key.equals("dinamozagreb"))return "Dinama Zagreb";
        if(key.equals("fcthun"))return "FC Thuna";
        if(key.equals("hajduksplit"))return "Hajduka Split";
        if(key.equals("rijeka"))return "Rijeke";
        if(key.equals("rudes"))return "Rudeša";
        if(key.equals("varazdin"))return "Varaždina";
        if(key.equals("gorica"))return "Gorice";
        if(key.equals("osijek"))return "Osijeka";
        if(key.equals("istra1961"))return "Istre 1961";
        if(key.equals("slavenbelupo"))return "Slaven Belupa";
        if(key.equals("lokomotivazagreb"))return "Lokomotive Zagreb";
        return "ekipe "+display;
    }

    String scheduleOpponentLabel(Match match,String focusTeam){
        if(match==null)return "";
        boolean focusIsHome=sameTeam(match.home,focusTeam);
        String opponent=focusIsHome?match.away:match.home;
        if("hr".equalsIgnoreCase(lang)){
            if(!focusIsHome&&teamKey(displayTeamName(opponent)).equals("dinamozagreb"))return "u gostima kod Dinama Zagreba";
            return (focusIsHome?"protiv ":"u gostima kod ")+croatianClubGenitive(opponent);
        }
        if("de".equalsIgnoreCase(lang))return (focusIsHome?"gegen ":"bei ")+displayTeamName(opponent);
        if("es".equalsIgnoreCase(lang))return (focusIsHome?"contra ":"de visitante ante ")+displayTeamName(opponent);
        if("fr".equalsIgnoreCase(lang))return (focusIsHome?"contre ":"chez ")+displayTeamName(opponent);
        return (focusIsHome?"vs ":"at ")+displayTeamName(opponent);
    }

    LinearLayout matchCenterCompactMatch(Match match,String focusTeam){
        LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(8),dp(10),dp(8));row.setBackground(round(chipBg,dp(14),1));row.setClickable(true);row.setOnClickListener(v->showMatchDetails(match));applyPressFeedback(row);
        Date date=localMatchDate(match);
        String day=date==null?"—":new SimpleDateFormat("d. MMM",homeLocale()).format(date);
        TextView dateView=centerLabel(day,10,subText,true);dateView.setMaxLines(2);row.addView(dateView,new LinearLayout.LayoutParams(dp(56),dp(46)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(7),0,dp(6),0);
        String fixture=scheduleOpponentLabel(match,focusTeam);
        TextView fixtureView=label(fixture,12,text,true);fixtureView.setSingleLine(false);fixtureView.setMaxLines(2);fixtureView.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(fixtureView);
        TextView comp=label(compactCompetitionName(friendlyCompetitionName(match)),10,subText,false);comp.setSingleLine(true);comp.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(comp);
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        boolean noResult=matchHasResultUnavailable(match);
        boolean unconfirmed=matchIsUpcoming(match)&&!hasConfirmedKickoffTime(match);
        String result=matchIsFinished(match)&&match.homeGoals>=0&&match.awayGoals>=0?match.homeGoals+":"+match.awayGoals:(matchIsLive(match)?homeCenterStatus(match):(noResult?homeCenterStatus(match):(unconfirmed?t2("Time not confirmed","Uskoro","Termin nicht bestätigt","Hora no confirmada","Horaire non confirmé"):homeTimeLabel(match))));
        boolean multiLineStatus=unconfirmed||noResult;
        TextView resultView=centerLabel(result,multiLineStatus?9:12,matchIsLive(match)?RED:(multiLineStatus?subText:text),true);
        resultView.setMaxLines(multiLineStatus?2:1);resultView.setMinLines(multiLineStatus?2:1);resultView.setSingleLine(!multiLineStatus);resultView.setGravity(Gravity.CENTER);
        resultView.setLineSpacing(0f,.96f);
        if(multiLineStatus){resultView.setBackground(round(Color.argb(25,255,255,255),dp(12),0));row.addView(resultView,new LinearLayout.LayoutParams(dp(104),dp(48)));}
        else{resultView.setBackground(round(Color.argb(25,255,255,255),dp(12),0));row.addView(resultView,new LinearLayout.LayoutParams(dp(62),dp(36)));}
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));row.setLayoutParams(lp);return row;
    }

    void addHeadToHeadCard(Match selected){
        ArrayList<Match> h2h=headToHeadMatches(selected);
        LinearLayout card=card();card.addView(label("🤝 "+t2("Head-to-head","Međusobne utakmice","Direkter Vergleich","Enfrentamientos","Confrontations"),20,text,true));
        if(h2h.isEmpty()){
            card.addView(label(t2("No previous verified meetings are available yet.","Još nema dostupnih prethodnih provjerenih međusobnih utakmica.","Noch keine früheren verifizierten Duelle verfügbar.","Aún no hay enfrentamientos verificados disponibles.","Aucune confrontation vérifiée antérieure n’est disponible."),13,subText,false));
            return;
        }
        int homeWins=0,awayWins=0,draws=0;
        for(Match match:h2h){
            boolean selectedHomeIsHome=sameTeam(match.home,selected.home);
            int selectedHomeGoals=selectedHomeIsHome?match.homeGoals:match.awayGoals;
            int selectedAwayGoals=selectedHomeIsHome?match.awayGoals:match.homeGoals;
            if(selectedHomeGoals>selectedAwayGoals)homeWins++;else if(selectedHomeGoals<selectedAwayGoals)awayWins++;else draws++;
        }
        LinearLayout summary=hrow();
        summary.addView(homeStat(String.valueOf(homeWins),displayTeamName(selected.home),null),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams mid=new LinearLayout.LayoutParams(0,-2,1);mid.setMargins(dp(7),0,dp(7),0);summary.addView(homeStat(String.valueOf(draws),t2("Draws","Neriješeno","Unentschieden","Empates","Nuls"),null),mid);
        summary.addView(homeStat(String.valueOf(awayWins),displayTeamName(selected.away),null),new LinearLayout.LayoutParams(0,-2,1));card.addView(summary);
        int limit=Math.min(5,h2h.size());
        for(int i=0;i<limit;i++)addHeadToHeadMatch(card,h2h.get(i));
    }

    void addHeadToHeadMatch(LinearLayout parent,Match match){
        Date date=localMatchDate(match);
        if(date!=null){
            TextView dateLabel=label("📅 "+new SimpleDateFormat("d. MMM yyyy.",homeLocale()).format(date),11,subText,true);
            dateLabel.setPadding(dp(5),dp(13),0,0);parent.addView(dateLabel);
        }
        addDynamicHomeMatch(parent,match);
    }


    String normalizedStadiumName(String value){
        if(value==null)return "";
        String clean=value.trim().replaceAll("\\s+"," ");
        String key=Normalizer.normalize(clean.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]","");
        if(key.contains("maksimirstadium")||key.contains("maksimirstadion")||key.contains("stadionmaksimir"))
            return t2("Maksimir Stadium","Stadion Maksimir","Maksimir-Stadion","Estadio Maksimir","Stade Maksimir");
        // Canonical La Liga venue names. Provider spelling variants are folded
        // here so the same stadium is shown identically on every screen.
        if(key.equals("sanmames")||key.equals("sanmamesbarria"))return "San Mamés";
        if(key.contains("metropolitano"))return "Riyadh Air Metropolitano";
        if(key.equals("campnou")||key.equals("spotifycampnou"))return "Spotify Camp Nou";
        if(key.contains("santiagobernabeu")||key.equals("bernabeu"))return "Santiago Bernabéu";
        if(key.contains("balaidos"))return "Estadio ABANCA Balaídos";
        if(key.equals("benitovillamarin")||key.contains("olimpicocartuja"))return "Estadio de La Cartuja";
        if(key.contains("ceramica"))return "Estadio de la Cerámica";
        if(key.equals("mestalla")||key.contains("mestalla"))return "Estadio de Mestalla";
        if(key.contains("anoeta")||key.contains("reale arena".replace(" ","")))return "Reale Arena";
        if(key.contains("sanchezpizjuan"))return "Ramón Sánchez-Pizjuán";
        if(key.contains("sadar"))return "El Sadar";
        if(key.contains("mendizorroza"))return "Mendizorrotza";
        if(key.contains("martinezvalero"))return "Estadio Martínez Valero";
        if(key.contains("coliseum"))return "Coliseum";
        if(key.contains("ciudaddevalencia"))return "Estadi Ciutat de València";
        if(key.contains("vallecas"))return "Estadio de Vallecas";
        if(key.contains("stagefront")||key.contains("cornellaelprat")||key.contains("rcdestadium"))return "RCDE Stadium";
        if(key.contains("sardinero"))return "El Sardinero";
        if(key.contains("riazor"))return "Estadio ABANCA-Riazor";
        if(key.contains("rosaleda"))return "La Rosaleda";
        // Canonical Bundesliga venue names.
        if(key.contains("allianzarena"))return "Allianz Arena";
        if(key.contains("signalidunapark")||key.contains("westfalenstadion"))return "SIGNAL IDUNA PARK";
        if(key.contains("redbullarena"))return "Red Bull Arena";
        if(key.contains("europaparkstadion"))return "Europa-Park Stadion";
        if(key.contains("wwkarena"))return "WWK ARENA";
        if(key.contains("mewaarena"))return "MEWA ARENA";
        if(key.contains("altenforsterei"))return "Stadion An der Alten Försterei";
        if(key.contains("rheinenergiestadion"))return "RheinEnergieSTADION";
        if(key.contains("ursapharmarena")||key.contains("kaiserlinde"))return "URSAPHARM-Arena an der Kaiserlinde";
        if(key.contains("mhparena"))return "MHPArena";
        if(key.contains("prezeroarena"))return "PreZero Arena";
        if(key.contains("bayarena"))return "BayArena";
        if(key.contains("deutschebankpark"))return "Deutsche Bank Park";
        if(key.contains("borussiapark"))return "BORUSSIA-PARK";
        if(key.contains("volksparkstadion"))return "Volksparkstadion";
        if(key.contains("weserstadion"))return "Weserstadion";
        if(key.contains("veltinsarena"))return "VELTINS-Arena";
        if(key.contains("homedeluxearena")||key.contains("bentelerarena"))return "Home Deluxe Arena";
        // Canonical Serie A venue names.
        if(key.contains("newbalancearena")||key.contains("gewissstadium")||key.contains("atletiazzurriditalia"))return "New Balance Arena";
        if(key.contains("renatodallara")||key.equals("dallara"))return "Stadio Renato Dall'Ara";
        if(key.contains("unipoldomus")||key.contains("sardegnaarena"))return "Unipol Domus";
        if(key.contains("giuseppesinigaglia")||key.equals("sinigaglia"))return "Stadio Giuseppe Sinigaglia";
        if(key.contains("artemiofranchi"))return "Stadio Artemio Franchi";
        if(key.contains("benitostirpe")||key.contains("matusa"))return "Stadio Benito Stirpe";
        if(key.contains("luigiferraris")||key.equals("marassi"))return "Stadio Luigi Ferraris";
        if(key.contains("giuseppemeazza")||key.equals("sansiro")||key.contains("stadiogmeazza"))return "Stadio Giuseppe Meazza";
        if(key.contains("allianzstadium")||key.contains("juventusstadium"))return "Allianz Stadium";
        if(key.equals("stadioolimpico")||key.equals("olimpico")||key.contains("olimpicoroma"))return "Stadio Olimpico";
        if(key.contains("viadelmare")||key.contains("ettoregiardiniero"))return "Stadio Ettore Giardiniero - Via del Mare";
        if(key.contains("upowerstadium")||key.contains("stadiobrianteo")||key.equals("brianteo"))return "U-Power Stadium";
        if(key.contains("diegoarmandomaradona")||key.contains("sanpaolo"))return "Stadio Diego Armando Maradona";
        if(key.contains("enniotardini")||key.equals("tardini"))return "Stadio Ennio Tardini";
        if(key.contains("mapeistadium")||key.contains("cittadeltricolore"))return "Mapei Stadium - Città del Tricolore";
        if(key.contains("olimpicograndetorino")||key.contains("stadiocomunaleditorino"))return "Stadio Olimpico Grande Torino";
        if(key.contains("bluenergystadium")||key.contains("daciaarena")||key.contains("stadiofriuli"))return "Bluenergy Stadium";
        if(key.contains("pierluigipenzo")||key.equals("penzo"))return "Stadio Pier Luigi Penzo";
        return clean;
    }

    String confirmedStadiumName(String value){
        if(!isUsefulMatchInfoValue(value)||looksLikeCompetitionStage(value))return "";
        String clean=normalizedStadiumName(value);
        String folded=Normalizer.normalize(clean.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","").trim();
        String compact=folded.replaceAll("[^a-z0-9]+","");
        if(isIncompleteVenueFragment(clean))return "";
        String[] words=folded.split("\\s+");
        if(words.length>=2&&clean.length()>=8)return clean;
        if(words.length==1&&clean.length()>=11&&(compact.endsWith("vollur")||compact.endsWith("vallen")||compact.endsWith("stadion")||compact.endsWith("stadium")))return clean;
        return "";
    }

    String matchDetailStadium(Match m){
        if(m==null)return "";
        String actual=confirmedStadiumName(m.actualVenue);
        if(actual.length()>0)return actual;
        if(m.venue!=null&&!m.venue.trim().equalsIgnoreCase(m.group==null?"":m.group.trim())){
            String venue=confirmedStadiumName(m.venue);
            if(venue.length()>0)return venue;
        }
        return "";
    }

    boolean isUsefulMatchInfoValue(String value){
        if(value==null)return false;
        String v=value.trim();
        if(v.length()==0)return false;
        String u=v.toUpperCase(Locale.US);
        return !(u.equals("NULL")||u.equals("N/A")||u.equals("NA")||u.equals("TBD")||u.equals("TBA")||u.equals("UNKNOWN")||u.equals("-")||u.equals("?"));
    }

    boolean looksLikeCompetitionStage(String value){
        if(value==null)return false;
        String u=value.trim().replace('-','_').replace(' ','_').toUpperCase(Locale.US);
        return u.equals("GROUP")||u.equals("GROUP_STAGE")||u.equals("REGULAR_SEASON")||u.matches("GROUP_[A-L]")||
                u.contains("THIRD_PLACE")||u.contains("3RD_PLACE")||u.contains("ROUND_OF_32")||u.contains("LAST_32")||
                u.contains("ROUND_OF_16")||u.contains("LAST_16")||u.contains("QUARTER")||u.contains("SEMI")||
                u.equals("FINAL")||u.endsWith("_FINAL")||u.contains("PLAYOFF");
    }

    void addMatchInformationCard(Match m,String stadium){
        ArrayList<String[]> rows=new ArrayList<>();
        if(stadium!=null&&stadium.length()>0)rows.add(new String[]{"🏟️",t2("Stadium","Stadion","Stadion","Estadio","Stade"),stadium});
        if(isUsefulMatchInfoValue(m.refereeText))rows.add(new String[]{"🧑‍⚖️",t2("Referee","Sudac","Schiedsrichter","Árbitro","Arbitre"),m.refereeText.trim()});
        if(m.attendance>0)rows.add(new String[]{"👥",t2("Attendance","Gledatelji","Zuschauer","Asistencia","Affluence"),String.format(homeLocale(),"%,d",m.attendance)});
        String round=stageLabel(m);
        if(round.length()==0&&m.roundName!=null)round=m.roundName.trim();
        if(round.length()==0&&m.matchday>0)round=t2("Matchday","Kolo","Spieltag","Jornada","Journée")+" "+m.matchday;
        if(round.length()>0)rows.add(new String[]{"🏁",t2("Round","Faza / kolo","Runde","Ronda","Tour"),round});
        if(rows.isEmpty())return;
        LinearLayout info=card();info.setPadding(dp(18),dp(17),dp(18),dp(15));
        LinearLayout.LayoutParams infoLp=(LinearLayout.LayoutParams)info.getLayoutParams();infoLp.setMargins(0,0,0,dp(10));info.setLayoutParams(infoLp);
        info.addView(label("ℹ️  "+t2("Match information","Informacije o utakmici","Spielinformationen","Información del partido","Informations du match"),20,text,true));
        for(int i=0;i<rows.size();i++){
            String[] row=rows.get(i);
            if(i>0){View divider=new View(this);divider.setBackgroundColor(stroke);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,dp(1));dl.setMargins(dp(44),dp(2),0,dp(2));info.addView(divider,dl);}
            LinearLayout line=hrow();line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(0,dp(8),0,dp(8));
            TextView icon=centerLabel(row[0],20,text,false);icon.setBackground(round(chipBg,dp(14),0));line.addView(icon,new LinearLayout.LayoutParams(dp(40),dp(40)));
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(12),0,0,0);
            copy.addView(label(row[1].toUpperCase(homeLocale()),10,subText,true));
            TextView value=label(row[2],smartInfoTextSize(row[2]),text,true);
            value.setMaxLines(2);
            value.setEllipsize(android.text.TextUtils.TruncateAt.END);
            value.setPadding(0,dp(2),0,0);
            copy.addView(value);
            line.addView(copy,new LinearLayout.LayoutParams(0,-2,1));info.addView(line);
        }
    }

    void addPremiumMatchSnapshot(Match match,boolean hasEvents,boolean hasStats,boolean hasLineups){
        LinearLayout snapshot=card();snapshot.setPadding(dp(14),dp(13),dp(14),dp(13));
        LinearLayout.LayoutParams snapshotLp=(LinearLayout.LayoutParams)snapshot.getLayoutParams();snapshotLp.setMargins(0,0,0,dp(10));snapshot.setLayoutParams(snapshotLp);
        snapshot.addView(label("◈  "+t2("MATCH SNAPSHOT","SAŽETAK UTAKMICE","SPIELÜBERSICHT","RESUMEN DEL PARTIDO","APERÇU DU MATCH"),14,text,true));
        LinearLayout row=hrow();row.setPadding(0,dp(10),0,0);
        String status=matchIsLive(match)?("● "+homeCenterStatus(match)):matchIsFinished(match)?t2("Finished","Završeno","Beendet","Finalizado","Terminé"):matchHasResultUnavailable(match)?homeCenterStatus(match):t2("Upcoming","Nadolazeća","Bevorstehend","Próximo","À venir");
        row.addView(matchSnapshotItem(status,t2("Status","Status","Status","Estado","Statut")),new LinearLayout.LayoutParams(0,dp(70),1));
        int eventCount=countDetailLines(match==null?"":match.eventsText);
        LinearLayout.LayoutParams midLp=new LinearLayout.LayoutParams(0,dp(70),1);midLp.setMargins(dp(6),0,dp(6),0);
        String eventCaption=eventCount==1
                ?t2("Event","Događaj","Ereignis","Evento","Événement")
                :t2("Events","Događaji","Ereignisse","Eventos","Événements");
        row.addView(matchSnapshotItem(String.valueOf(eventCount),eventCaption),midLp);
        int modules=(hasEvents?1:0)+(hasStats?1:0)+(hasLineups?1:0);
        String detailValue=modules==0?t2("Not available","Nisu dostupni","Nicht verfügbar","No disponibles","Indisponibles"):modules==3?t2("Available","Dostupni","Verfügbar","Disponibles","Disponibles"):t2("Partially available","Djelomično dostupni","Teilweise verfügbar","Parcialmente disponibles","Partiellement disponibles");
        row.addView(matchSnapshotItem(detailValue,t2("Details","Detalji","Details","Detalles","Détails")),new LinearLayout.LayoutParams(0,dp(70),1));
        snapshot.addView(row);
    }

    LinearLayout matchSnapshotItem(String value,String caption){
        LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);item.setPadding(dp(6),dp(7),dp(6),dp(7));item.setBackground(round(chipBg,dp(15),1));
        TextView main=centerLabel(value,value.length()>11?11:15,text,true);main.setSingleLine(false);main.setMaxLines(2);main.setEllipsize(android.text.TextUtils.TruncateAt.END);main.setGravity(Gravity.CENTER);item.addView(main);
        TextView sub=centerLabel(caption.toUpperCase(homeLocale()),9,subText,true);sub.setPadding(0,dp(3),0,0);sub.setSingleLine(true);item.addView(sub);
        return item;
    }

    int countDetailLines(String value){
        if(value==null||value.trim().isEmpty())return 0;int count=0;for(String line:value.split("\n"))if(line!=null&&!line.trim().isEmpty())count++;return count;
    }

    void addTimelineCard(Match match){
        String timelineText=match==null?"":match.eventsText;
        LinearLayout events=card();
        LinearLayout heading=hrow();heading.setGravity(Gravity.CENTER_VERTICAL);
        String timelineHeading=matchIsLive(match)?t2("LIVE TIMELINE","TIJEK UŽIVO","LIVE-VERLAUF","CRONOLOGÍA EN VIVO","CHRONOLOGIE LIVE"):t2("MATCH TIMELINE","TIJEK UTAKMICE","SPIELVERLAUF","CRONOLOGÍA DEL PARTIDO","CHRONOLOGIE DU MATCH");
        heading.addView(label("⚡ "+timelineHeading,21,text,true),new LinearLayout.LayoutParams(0,-2,1));
        String badgeText=matchIsFinished(match)?t2("FULL TIME","KRAJ","ENDE","FINAL","TERMINÉ"):matchIsLive(match)?"● "+t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT"):t2("MATCH EVENTS","DOGAĐAJI","EREIGNISSE","EVENTOS","ÉVÉNEMENTS");
        TextView live=centerLabel(badgeText,11,Color.WHITE,true);live.setPadding(dp(10),dp(5),dp(10),dp(5));live.setBackground(matchIsLive(match)?gradient(RED_DARK,RED,dp(13)):round(Color.rgb(65,72,92),dp(13),0));heading.addView(live);events.addView(heading);

        int currentMinute=matchIsFinished(match)?120:Math.max(currentTimelineMinute(timelineText),parseMinuteValue(match==null?"":match.minute));
        ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(120);progress.setProgress(Math.min(120,Math.max(1,currentMinute)));
        if(Build.VERSION.SDK_INT>=21){progress.setProgressTintList(android.content.res.ColorStateList.valueOf(matchIsFinished(match)?GREEN:RED));progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(stroke));}
        LinearLayout.LayoutParams progressLp=new LinearLayout.LayoutParams(-1,dp(5));progressLp.setMargins(0,dp(13),0,dp(7));events.addView(progress,progressLp);
        LinearLayout scale=hrow();scale.addView(label("0′",10,subText,true),new LinearLayout.LayoutParams(0,-2,1));TextView mid=centerLabel("45′",10,subText,true);scale.addView(mid,new LinearLayout.LayoutParams(0,-2,1));TextView end=centerLabel("90′+",10,subText,true);end.setGravity(Gravity.RIGHT);scale.addView(end,new LinearLayout.LayoutParams(0,-2,1));events.addView(scale);

        String[] lines=timelineText.split("\n");int delay=0;
        for(String raw:lines){
            String lineText=raw==null?"":raw.trim();if(lineText.length()==0)continue;
            LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(12),dp(12),dp(12),dp(12));row.setBackground(round(chipBg,dp(16),1));

            TextView minute=centerLabel(timelineMinuteLabel(lineText),12,subText,true);minute.setGravity(Gravity.CENTER);minute.setSingleLine(true);
            row.addView(minute,new LinearLayout.LayoutParams(dp(48),dp(44)));

            TextView marker=centerLabel(timelineIcon(lineText),timelineIcon(lineText).length()>2?10:18,text,true);marker.setBackground(round(eventAccent(lineText),dp(14),0));
            LinearLayout.LayoutParams markerLp=new LinearLayout.LayoutParams(dp(44),dp(44));markerLp.setMargins(dp(4),0,dp(12),0);row.addView(marker,markerLp);

            TextView event=label(timelineEventBody(lineText),15,text,true);event.setGravity(Gravity.CENTER_VERTICAL);event.setMaxLines(3);event.setLineSpacing(0f,1.08f);row.addView(event,new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(6),0,dp(6));events.addView(row,lp);
            row.setAlpha(0f);row.setTranslationY(dp(10));final LinearLayout animated=row;handler.postDelayed(()->animated.animate().alpha(1f).translationY(0f).setDuration(230).start(),delay);delay+=55;
        }
        if(matchIsLive(match))live.animate().alpha(.42f).setDuration(650).withEndAction(()->live.animate().alpha(1f).setDuration(650).start()).start();
    }

    int parseMinuteValue(String value){
        if(value==null)return 0;java.util.regex.Matcher m=java.util.regex.Pattern.compile("(\\d{1,3})").matcher(value);if(m.find())try{return Integer.parseInt(m.group(1));}catch(Exception ignored){}return 0;
    }

    int currentTimelineMinute(String timelineText){
        int latest=0;if(timelineText==null)return latest;
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("(\\d{1,3})(?:\\+\\d+)?[′']").matcher(timelineText);
        while(matcher.find())try{latest=Math.max(latest,Integer.parseInt(matcher.group(1)));}catch(Exception ignored){}
        return latest;
    }

    String timelineIcon(String line){
        String upper=line==null?"":line.toUpperCase(Locale.US);
        if(line.contains("⚽")||line.contains("🥅"))return upper.contains("PONIŠ")||upper.contains("CANCEL")||upper.contains("DISALLOW")?"NO":"⚽";
        if(line.contains("🟥"))return "🟥";
        if(line.contains("🟨"))return "🟨";
        if(line.contains("🔄"))return "↔";
        if(line.contains("📺")||upper.contains("VAR"))return "VAR";
        if(line.contains("🎯"))return "⚽";
        if(line.contains("⏸"))return "HT";
        if(line.contains("▶"))return "2H";
        if(line.contains("🏁"))return "FT";
        if(line.contains("⏱"))return "ET";
        return "●";
    }

    int eventAccent(String line){
        String upper=line==null?"":line.toUpperCase(Locale.US);
        if(upper.contains("PONIŠ")||upper.contains("CANCEL")||upper.contains("DISALLOW"))return Color.rgb(112,48,78);
        if(line.contains("⚽")||line.contains("🥅")||line.contains("🎯"))return Color.rgb(28,104,75);
        if(line.contains("🟥"))return Color.rgb(126,31,45);
        if(line.contains("🟨"))return Color.rgb(135,111,30);
        if(line.contains("📺")||upper.contains("VAR"))return Color.rgb(69,51,128);
        if(line.contains("⏸")||line.contains("▶")||line.contains("🏁"))return Color.rgb(50,76,112);
        return Color.rgb(43,50,68);
    }

    String timelineMinuteLabel(String line){
        if(line==null)return "";
        java.util.regex.Matcher minute=java.util.regex.Pattern.compile("(\\d{1,3}(?:\\+\\d+)?)\\s*[′']").matcher(line);
        if(minute.find())return minute.group(1)+"′";
        String icon=timelineIcon(line);
        if(icon.equals("HT"))return "45′";
        if(icon.equals("2H"))return "46′";
        if(icon.equals("FT"))return "90′";
        if(icon.equals("ET"))return "90′+";
        return "•";
    }

    String timelineEventBody(String line){
        if(line==null)return "";
        String value=line.trim();
        value=value.replaceFirst("^(⚽|🥅|🟥|🟨|🔄|📺|🎯|⏸️?|▶️?|🏁|⏱️?|●)\\s*","");
        value=value.replaceFirst("^\\d{1,3}(?:\\+\\d+)?\\s*[′']\\s*[-–—•:]?\\s*","");
        if(value.trim().length()==0){
            String icon=timelineIcon(line);
            if(icon.equals("HT"))return t2("Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps");
            if(icon.equals("2H"))return t2("Second half","Početak drugog poluvremena","Zweite Halbzeit","Segunda parte","Deuxième mi-temps");
            if(icon.equals("FT"))return t2("Full-time","Kraj utakmice","Spielende","Final del partido","Fin du match");
        }
        return value.trim();
    }

    String stripLeadingTimelineIcon(String line){
        return timelineEventBody(line);
    }

    void addStatisticsCard(String statisticsText){
        LinearLayout stats=card();
        stats.addView(label("📊 "+t2("Match statistics","Statistika utakmice","Spielstatistik","Estadísticas","Statistiques"),21,text,true));
        String[] lines=statisticsText.split("\n");
        for(int i=0;i<lines.length;i++){
            String lineText=lines[i]==null?"":lines[i].trim();if(lineText.length()==0)continue;
            TextView stat=label(lineText,i==0?13:14,i==0?subText:text,i==0);stat.setGravity(Gravity.CENTER);stat.setPadding(dp(10),dp(9),dp(10),dp(9));
            if(i>0)stat.setBackground(round(chipBg,dp(13),1));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));stats.addView(stat,lp);
        }
    }

    TextView detailAvailabilityChip(String caption,boolean available){
        TextView chip=centerLabel(caption,11,available?Color.WHITE:subText,true);chip.setSingleLine(true);chip.setGravity(Gravity.CENTER);
        chip.setBackground(available?gradient(Color.rgb(102,18,108),Color.rgb(225,29,84),dp(16)):round(chipBg,dp(16),1));
        chip.setAlpha(available?1f:.72f);
        chip.setOnTouchListener((v,e)->{if(!available)return false;if(e.getAction()==0)v.animate().scaleX(.97f).scaleY(.97f).setDuration(70).start();else if(e.getAction()==1||e.getAction()==3)v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1);lp.setMargins(dp(3),dp(2),dp(3),dp(2));chip.setLayoutParams(lp);return chip;
    }

    Drawable matchStatusBadgeBackground(Match m){
        int color;
        if(matchIsLive(m))color=Color.rgb(215,42,62);
        else if(matchIsFinished(m))color=Color.argb(105,255,255,255);
        else if(matchHasResultUnavailable(m))color=Color.rgb(76,84,101);
        else if(isMatchTimeTba(m))color=Color.rgb(178,93,137);
        else color=Color.rgb(85,91,166);

        GradientDrawable badge=new GradientDrawable();
        badge.setColor(color);
        badge.setCornerRadius(dp(14));
        return badge;
    }

    boolean hasRecentFormData(String team){
        String[] form=recentForm(team,5);for(String value:form)if(!"–".equals(value))return true;return false;
    }

    String joinParts(List<String> parts,String separator){
        StringBuilder sb=new StringBuilder();
        for(String part:parts){
            if(part==null||part.trim().length()==0)continue;
            if(sb.length()>0)sb.append(separator);
            sb.append(part.trim());
        }
        return sb.toString();
    }

    void populateMatchDetails(Match m,JSONObject o){
        if(m==null||o==null)return;
        m.apiId=o.optInt("id",m.apiId);
        m.actualVenue=o.optString("venue",m.actualVenue==null?"":m.actualVenue);
        m.attendance=o.optInt("attendance",m.attendance);
        JSONObject homeObj=o.optJSONObject("homeTeam");
        JSONObject awayObj=o.optJSONObject("awayTeam");
        if(homeObj!=null){
            m.homeFormation=homeObj.optString("formation","");
            m.homeLineupText=formatLineup(homeObj);
            registerTeamPlayers(homeObj,m.home);
        }
        if(awayObj!=null){
            m.awayFormation=awayObj.optString("formation","");
            m.awayLineupText=formatLineup(awayObj);
            registerTeamPlayers(awayObj,m.away);
        }
        registerPlayersFromMatchEvents(o.optJSONArray("events"),m.home,m.away);
        registerPlayersFromMatchEvents(o.optJSONArray("goals"),m.home,m.away);
        registerPlayersFromMatchEvents(o.optJSONArray("bookings"),m.home,m.away);
        registerPlayersFromMatchEvents(o.optJSONArray("substitutions"),m.home,m.away);
        m.eventsText=formatMatchEvents(o);
        m.statsText=formatMatchStatistics(homeObj,awayObj,m.home,m.away);
        m.refereeText=formatReferees(o.optJSONArray("referees"));
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject half=score.optJSONObject("halfTime");
            if(half!=null && !half.isNull("home") && !half.isNull("away")) m.halfTimeScore=half.optInt("home")+" : "+half.optInt("away");
            JSONObject extra=score.optJSONObject("extraTime");
            if(extra!=null && !extra.isNull("home") && !extra.isNull("away")) m.extraTimeScore=extra.optInt("home")+" : "+extra.optInt("away");
            JSONObject penalties=score.optJSONObject("penalties");
            if(penalties!=null && !penalties.isNull("home") && !penalties.isNull("away")) m.penaltyScore=penalties.optInt("home")+" : "+penalties.optInt("away");
        }
        m.detailsAvailable=(m.eventsText.length()>0||m.statsText.length()>0||m.homeLineupText.length()>0||m.awayLineupText.length()>0||m.refereeText.length()>0);
    }

    boolean hasPlayerPayload(JSONObject item){
        if(item==null)return false;
        if(item.has("position")||item.has("playerPosition")||item.has("shirtNumber")||item.has("jerseyNumber")||item.has("number"))return true;
        if(item.has("dateOfBirth")||item.has("birthDate")||item.has("nationality")||item.has("countryOfBirth"))return true;
        if(item.has("photo")||item.has("photoUrl")||item.has("image")||item.has("height")||item.has("weight"))return true;
        if(item.has("statistics")||item.has("stats")||item.has("appearances")||item.has("minutes")||item.has("goals")||item.has("assists"))return true;
        if(item.has("recentForm")||item.has("clubHistory")||item.has("history"))return true;
        String role=item.optString("role","").trim().toUpperCase(Locale.ROOT);
        return role.equals("PLAYER")||role.equals("GOALKEEPER")||role.equals("DEFENDER")||role.equals("MIDFIELDER")||role.equals("FORWARD");
    }

    boolean isPlausiblePlayer(PlayerRecord player){
        if(player==null||player.name==null||player.name.trim().length()==0)return false;
        if(player.position.length()>0||player.nationality.length()>0||player.dateOfBirth.length()>0||player.photoUrl.length()>0)return true;
        if(player.height.length()>0||player.weight.length()>0||player.history.length()>0||!player.recentForm.isEmpty())return true;
        if(player.shirtNumber>0||player.age>0||player.appearances>=0||player.minutes>=0||player.goals>=0||player.assists>=0)return true;
        String role=player.role==null?"":player.role.trim().toUpperCase(Locale.ROOT);
        return role.equals("PLAYER")||role.equals("PLAYER_EVENT")||role.equals("GOALKEEPER")||role.equals("DEFENDER")||role.equals("MIDFIELDER")||role.equals("FORWARD");
    }

    void purgeInvalidPlayerRecords(){
        ArrayList<String> remove=new ArrayList<String>();
        for(Map.Entry<String,PlayerRecord> entry:playerIndex.entrySet()){
            PlayerRecord player=entry.getValue();
            if(!isPlausiblePlayer(player))remove.add(entry.getKey());
        }
        if(remove.isEmpty())return;
        for(String key:remove){playerIndex.remove(key);favoritePlayers.remove(key);if(key.equals(openPlayerKey))openPlayerKey="";}
        saveFavoritePlayerProfiles();
    }

    void registerTeamSquadFeed(JSONArray teams){
        if(teams==null)return;
        for(int i=0;i<teams.length();i++){
            JSONObject team=teams.optJSONObject(i);if(team==null)continue;
            String club=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();
            registerPlayerArray(team.optJSONArray("squad"),club);
            registerPlayerArray(team.optJSONArray("players"),club);
            registerPlayerArray(team.optJSONArray("lineup"),club);
            registerPlayerArray(team.optJSONArray("bench"),club);
            registerTeamSquadFeed(team.optJSONArray("teams"));
            registerTeamSquadFeed(team.optJSONArray("clubs"));
        }
    }

    void registerPlayerFeed(JSONArray players,String fallbackClub){
        if(players==null)return;
        for(int i=0;i<players.length();i++){
            JSONObject item=players.optJSONObject(i);if(item==null)continue;
            String club=fallbackClub==null?"":fallbackClub;
            Object clubValue=item.opt("club");Object teamValue=item.opt("team");
            if(clubValue instanceof String)club=String.valueOf(clubValue);
            else if(teamValue instanceof String)club=String.valueOf(teamValue);
            JSONObject clubObject=item.optJSONObject("club");if(clubObject==null)clubObject=item.optJSONObject("team");
            if(clubObject!=null)club=clubObject.optString("shortName",clubObject.optString("name",club));
            JSONArray nested=item.optJSONArray("players");if(nested==null)nested=item.optJSONArray("squad");if(nested==null)nested=item.optJSONArray("lineup");
            if(nested!=null){if(club.length()==0)club=item.optString("shortName",item.optString("name",fallbackClub));registerPlayerArray(nested,club);registerPlayerArray(item.optJSONArray("bench"),club);continue;}
            if(!hasPlayerPayload(item))continue;
            PlayerRecord player=playerFromJson(item,club);registerVerifiedPlayer(player);
        }
    }
    void registerVerifiedPlayer(PlayerRecord player){
        if(!isPlausiblePlayer(player))return;
        String key=player.key();String existingKey=key;PlayerRecord existing=playerIndex.get(key);
        if(existing==null){
            for(Map.Entry<String,PlayerRecord> entry:playerIndex.entrySet()){
                PlayerRecord candidate=entry.getValue();
                if(candidate.name.equalsIgnoreCase(player.name)&&sameTeam(candidate.club,player.club)){existing=candidate;existingKey=entry.getKey();break;}
            }
        }
        if(existing==null){playerIndex.put(key,player);return;}
        mergePlayer(existing,player);
        String mergedKey=existing.key();
        if(!mergedKey.equals(existingKey)){
            playerIndex.remove(existingKey);playerIndex.put(mergedKey,existing);
            if(favoritePlayers.remove(existingKey))favoritePlayers.add(mergedKey);
        }
    }
    void registerPlayersFromMatchEvents(JSONArray events,String homeClub,String awayClub){
        if(events==null)return;
        for(int i=0;i<events.length();i++){
            JSONObject event=events.optJSONObject(i);if(event==null)continue;
            String club="";JSONObject team=event.optJSONObject("team");
            if(team!=null)club=team.optString("shortName",team.optString("name",""));
            if(club.length()==0)club=event.optString("teamName",event.optString("club",""));
            if(club.length()==0){String side=event.optString("side","");club=side.equalsIgnoreCase("home")?homeClub:(side.equalsIgnoreCase("away")?awayClub:"");}
            String[] playerKeys={"player","playerIn","playerOut","scorer","assist"};
            for(String playerKey:playerKeys){
                JSONObject playerObject=event.optJSONObject(playerKey);if(playerObject==null)continue;
                PlayerRecord eventPlayer=playerFromJson(playerObject,club);if(eventPlayer.role.length()==0)eventPlayer.role="PLAYER_EVENT";registerVerifiedPlayer(eventPlayer);
            }
            String playerName=event.optString("playerName",event.optString("name",""));
            if(playerName.length()>0){PlayerRecord player=new PlayerRecord();player.name=playerName;player.club=club;player.role="PLAYER_EVENT";registerVerifiedPlayer(player);}
        }
    }

    void registerTeamPlayers(JSONObject team,String club){
        if(team==null)return;String resolved=club==null?"":club;if(resolved.length()==0)resolved=team.optString("shortName",team.optString("name",""));registerPlayerArray(team.optJSONArray("lineup"),resolved);registerPlayerArray(team.optJSONArray("bench"),resolved);registerPlayerArray(team.optJSONArray("squad"),resolved);registerPlayerArray(team.optJSONArray("players"),resolved);
    }
    void registerPlayerArray(JSONArray players,String club){
        if(players==null)return;for(int i=0;i<players.length();i++){JSONObject o=players.optJSONObject(i);if(o==null)continue;registerVerifiedPlayer(playerFromJson(o,club));}
    }
    int playerAgeFromBirthDate(String raw){
        if(raw==null||raw.trim().length()<10)return -1;try{String value=raw.trim().substring(0,10);SimpleDateFormat parser=new SimpleDateFormat("yyyy-MM-dd",Locale.US);parser.setLenient(false);Date birth=parser.parse(value);if(birth==null)return -1;Calendar born=Calendar.getInstance();born.setTime(birth);Calendar now=Calendar.getInstance();int age=now.get(Calendar.YEAR)-born.get(Calendar.YEAR);if(now.get(Calendar.DAY_OF_YEAR)<born.get(Calendar.DAY_OF_YEAR))age--;return age>=0&&age<70?age:-1;}catch(Exception ignored){return -1;}
    }
    String playerHistoryFromJson(JSONObject o){
        String direct=o.optString("history","").trim();if(direct.length()>0)return direct;JSONArray clubs=o.optJSONArray("clubHistory");if(clubs==null)clubs=o.optJSONArray("history");if(clubs==null)return "";StringBuilder out=new StringBuilder();for(int i=0;i<clubs.length();i++){Object item=clubs.opt(i);String value="";if(item instanceof JSONObject){JSONObject obj=(JSONObject)item;value=obj.optString("club",obj.optString("team",obj.optString("name","")));String years=obj.optString("years",obj.optString("season",""));if(years.length()>0)value+=(value.length()>0?" • ":"")+years;}else if(item!=null)value=String.valueOf(item);if(value.trim().length()>0){if(out.length()>0)out.append("\n");out.append(value.trim());}}return out.toString();
    }
    PlayerRecord playerFromJson(JSONObject o,String club){
        PlayerRecord p=new PlayerRecord();p.id=o.optInt("id",-1);p.name=o.optString("name",o.optString("playerName","")).trim();p.club=club==null?"":club.trim();
        JSONObject team=o.optJSONObject("team");if(p.club.length()==0&&team!=null)p.club=team.optString("shortName",team.optString("name",""));
        p.role=o.optString("role","");String roleKey=p.role.toUpperCase(Locale.ROOT);if(roleKey.contains("COACH")||roleKey.contains("STAFF")||roleKey.contains("MANAGER")){p.name="";return p;}
        p.shirtNumber=o.optInt("shirtNumber",o.optInt("number",o.optInt("jerseyNumber",-1)));p.position=o.optString("position",o.optString("playerPosition",""));p.nationality=o.optString("nationality",o.optString("countryOfBirth",""));p.photoUrl=o.optString("photo",o.optString("photoUrl",o.optString("image","")));p.dateOfBirth=o.optString("dateOfBirth",o.optString("birthDate",""));p.age=o.optInt("age",-1);if(p.age<0)p.age=playerAgeFromBirthDate(p.dateOfBirth);p.height=o.optString("height","");p.weight=o.optString("weight","");
        JSONObject stats=o.optJSONObject("statistics");if(stats==null)stats=o.optJSONObject("stats");JSONObject source=stats==null?o:stats;
        p.appearances=source.optInt("appearances",source.optInt("played",-1));p.minutes=source.optInt("minutes",-1);p.goals=source.optInt("goals",-1);p.assists=source.optInt("assists",-1);p.yellowCards=source.optInt("yellowCards",source.optInt("yellow",-1));p.redCards=source.optInt("redCards",source.optInt("red",-1));p.rating=source.optString("rating",source.optString("averageRating",""));p.history=playerHistoryFromJson(o);
        JSONArray form=o.optJSONArray("recentForm");if(form!=null)for(int i=0;i<form.length();i++){String item=form.optString(i,"").trim();if(item.length()>0)p.recentForm.add(item);}return p;
    }
    void mergePlayer(PlayerRecord a,PlayerRecord b){if(a.id<0)a.id=b.id;if(a.shirtNumber<0)a.shirtNumber=b.shirtNumber;if(a.position.length()==0)a.position=b.position;if(a.club.length()==0)a.club=b.club;if(a.nationality.length()==0)a.nationality=b.nationality;if(a.photoUrl.length()==0)a.photoUrl=b.photoUrl;if(a.dateOfBirth.length()==0)a.dateOfBirth=b.dateOfBirth;if(a.role.length()==0)a.role=b.role;if(a.age<0)a.age=b.age;if(a.height.length()==0)a.height=b.height;if(a.weight.length()==0)a.weight=b.weight;if(a.appearances<0)a.appearances=b.appearances;if(a.minutes<0)a.minutes=b.minutes;if(a.goals<0)a.goals=b.goals;if(a.assists<0)a.assists=b.assists;if(a.yellowCards<0)a.yellowCards=b.yellowCards;if(a.redCards<0)a.redCards=b.redCards;if(a.rating.length()==0)a.rating=b.rating;if(a.history.length()==0)a.history=b.history;for(String item:b.recentForm)if(!a.recentForm.contains(item))a.recentForm.add(item);}

    /** Loads API-independent stable club facts before the first screen is rendered.
     * Dynamic fields (coach, squad, cards, player stats) are deliberately not bundled. */
    void registerBundledStaticClubProfiles(){
        for(StaticClubProfileRegistry.Profile item:StaticClubProfileRegistry.all()){
            if(item==null||item.name==null||item.name.trim().length()==0)continue;
            TeamProfileRecord incoming=new TeamProfileRecord();
            incoming.name=item.name;incoming.shortName=item.name;incoming.area=item.country;
            incoming.founded=item.founded;incoming.venue=item.venue;incoming.website=item.website;incoming.clubColors=item.colors;
            String key=teamKey(item.name);
            TeamProfileRecord existing=teamProfileIndex.get(key);
            if(existing==null)teamProfileIndex.put(key,incoming);else mergeTeamProfile(existing,incoming);
        }
    }

    void registerTeamProfileFeed(JSONArray teams){
        if(teams==null)return;
        for(int i=0;i<teams.length();i++){
            JSONObject item=teams.optJSONObject(i);if(item==null)continue;
            JSONArray nested=item.optJSONArray("teams");if(nested!=null)registerTeamProfileFeed(nested);
            registerTeamProfile(item);
        }
    }

    void registerTeamProfile(JSONObject team){
        if(team==null)return;
        String name=team.optString("shortName",team.optString("name",team.optString("tla",""))).trim();
        if(name.length()==0)return;
        TeamProfileRecord incoming=new TeamProfileRecord();
        incoming.id=team.optInt("id",-1);
        incoming.name=team.optString("name","").trim();
        incoming.shortName=team.optString("shortName","").trim();
        incoming.tla=team.optString("tla","").trim();
        incoming.crest=team.optString("crest",team.optString("crestUrl",team.optString("crestURI",""))).trim();
        incoming.address=team.optString("address","").trim();
        incoming.website=team.optString("website","").trim();
        incoming.clubColors=team.optString("clubColors","").trim();
        incoming.venue=team.optString("venue","").trim();
        incoming.founded=team.optInt("founded",-1);
        incoming.lastUpdated=team.optString("lastUpdated",team.optString("_profileFetchedAt","")).trim();
        JSONObject area=team.optJSONObject("area");if(area!=null)incoming.area=area.optString("name",area.optString("code","")).trim();
        JSONObject coach=team.optJSONObject("coach");
        if(coach!=null){incoming.coachName=coach.optString("name","").trim();incoming.coachNationality=coach.optString("nationality","").trim();}
        String key=teamKey(incoming.displayName());if(key.length()==0)return;
        TeamProfileRecord existing=teamProfileIndex.get(key);
        if(existing==null){
            for(Map.Entry<String,TeamProfileRecord> entry:teamProfileIndex.entrySet()){
                TeamProfileRecord candidate=entry.getValue();
                if(sameTeam(candidate.displayName(),incoming.displayName())||sameTeam(candidate.name,incoming.name)){existing=candidate;key=entry.getKey();break;}
            }
        }
        if(existing==null)teamProfileIndex.put(key,incoming);else mergeTeamProfile(existing,incoming);
        registerTeamPlayers(team,incoming.name.length()>0?incoming.name:incoming.displayName());
    }

    void mergeTeamProfile(TeamProfileRecord a,TeamProfileRecord b){
        if(b.id>0)a.id=b.id;if(b.founded>0)a.founded=b.founded;
        if(b.name.length()>0)a.name=b.name;if(b.shortName.length()>0)a.shortName=b.shortName;if(b.tla.length()>0)a.tla=b.tla;
        if(b.area.length()>0)a.area=b.area;if(b.crest.length()>0)a.crest=b.crest;if(b.address.length()>0)a.address=b.address;
        if(b.website.length()>0)a.website=b.website;if(b.clubColors.length()>0)a.clubColors=b.clubColors;if(b.venue.length()>0)a.venue=b.venue;
        if(b.coachName.length()>0)a.coachName=b.coachName;if(b.coachNationality.length()>0)a.coachNationality=b.coachNationality;
        if(b.lastUpdated.length()>0)a.lastUpdated=b.lastUpdated;
    }

    TeamProfileRecord teamProfileForClub(String club){
        if(club==null||club.trim().length()==0)return null;
        TeamProfileRecord direct=teamProfileIndex.get(teamKey(club));if(direct!=null)return direct;
        for(TeamProfileRecord profile:teamProfileIndex.values()){
            if(sameTeam(profile.name,club)||sameTeam(profile.shortName,club)||sameTeam(profile.tla,club))return profile;
        }
        return null;
    }

    JSONObject playerToJson(PlayerRecord p){
        JSONObject o=new JSONObject();
        try{
            o.put("id",p.id);o.put("name",p.name);o.put("club",p.club);o.put("position",p.position);o.put("shirtNumber",p.shirtNumber);
            o.put("nationality",p.nationality);o.put("dateOfBirth",p.dateOfBirth);o.put("age",p.age);o.put("height",p.height);o.put("weight",p.weight);
            o.put("photoUrl",p.photoUrl);o.put("appearances",p.appearances);o.put("minutes",p.minutes);o.put("goals",p.goals);o.put("assists",p.assists);
            o.put("yellowCards",p.yellowCards);o.put("redCards",p.redCards);o.put("rating",p.rating);o.put("history",p.history);o.put("role",p.role);
            JSONArray form=new JSONArray();for(String item:p.recentForm)form.put(item);o.put("recentForm",form);
        }catch(Exception ignored){}
        return o;
    }

    void saveFavoritePlayerProfiles(){
        JSONArray saved=new JSONArray();
        for(String key:favoritePlayers){
            PlayerRecord p=playerIndex.get(key);
            if(p==null)for(PlayerRecord candidate:playerIndex.values())if(candidate.key().equals(key)){p=candidate;break;}
            if(p!=null)saved.put(playerToJson(p));
        }
        prefs.edit().putStringSet("favorite_players",new LinkedHashSet<String>(favoritePlayers)).putString("favorite_player_profiles",saved.toString()).apply();
    }

    void restoreFavoritePlayerProfiles(){
        String raw=prefs.getString("favorite_player_profiles","");
        if(raw==null||raw.trim().length()==0)return;
        try{
            JSONArray saved=new JSONArray(raw);
            boolean cleaned=false;
            for(int i=0;i<saved.length();i++){
                JSONObject item=saved.optJSONObject(i);if(item==null)continue;
                PlayerRecord player=playerFromJson(item,item.optString("club",""));
                if(isPlausiblePlayer(player))registerVerifiedPlayer(player);
                else{favoritePlayers.remove(player.key());cleaned=true;}
            }
            if(cleaned)saveFavoritePlayerProfiles();
        }catch(Exception ignored){}
    }

    void openWebAddress(String address){
        if(address==null||address.trim().length()==0)return;
        try{
            String url=address.trim();if(!url.startsWith("http://")&&!url.startsWith("https://"))url="https://"+url;
            Intent browser=new Intent(Intent.ACTION_VIEW,Uri.parse(url));startActivity(browser);
        }catch(Exception e){toast(t2("Unable to open website.","Web-stranicu nije moguće otvoriti.","Website kann nicht geöffnet werden.","No se puede abrir el sitio.","Impossible d’ouvrir le site."));}
    }

    String formatLineup(JSONObject team){
        if(team==null)return "";
        JSONArray lineup=team.optJSONArray("lineup");
        JSONArray bench=team.optJSONArray("bench");
        StringBuilder sb=new StringBuilder();
        appendPlayers(sb,lineup,t2("Starting XI","Početnih 11","Startelf","Once inicial","Onze de départ"));
        appendPlayers(sb,bench,t2("Bench","Klupa","Bank","Suplentes","Remplaçants"));
        return sb.toString().trim();
    }

    void appendPlayers(StringBuilder sb,JSONArray players,String heading){
        if(players==null||players.length()==0)return;
        if(sb.length()>0)sb.append("\n\n");
        sb.append(heading).append("\n");
        for(int i=0;i<players.length();i++){
            JSONObject p=players.optJSONObject(i); if(p==null)continue;
            int number=p.optInt("shirtNumber",-1);
            String name=p.optString("name","");
            String position=p.optString("position","");
            if(number>0)sb.append(number).append(". ");
            sb.append(name);
            if(position.length()>0)sb.append(" — ").append(position);
            if(i<players.length()-1)sb.append("\n");
        }
    }

    String formatMatchEvents(JSONObject match){
        return timelineProviderManager.format(match,new TimelineEnvironment(){
            public String text(String en,String hr,String de,String es,String fr){return t2(en,hr,de,es,fr);}
            public String displayTeamName(String team){return MainActivity.this.displayTeamName(team);}
            public int parseMinute(String value){return parseMinuteValue(value);}
            public boolean isFinished(String status){return MatchStatus.isFinished(status);}
        });
    }

    void appendPeriodEvents(ArrayList<DetailEvent> all,LinkedHashSet<String> seen,JSONObject match){
        String status=match.optString("status",match.optString("state","")).toUpperCase(Locale.US);
        String minuteText=match.optString("minute",match.optString("elapsed",match.optString("clock","")));
        int minute=parseMinuteValue(minuteText);
        JSONObject score=match.optJSONObject("score");
        JSONObject half=score==null?null:score.optJSONObject("halfTime");
        boolean hasHalf=half!=null&&!half.isNull("home")&&!half.isNull("away");
        if(hasHalf||status.contains("HALF")||status.equals("HT")||minute>=46){
            String detail=hasHalf?" • "+half.optInt("home")+" : "+half.optInt("away"):"";
            addNormalizedEvent(all,seen,45,"⏸️ 45′ "+t2("Half-time","Poluvrijeme","Halbzeit","Descanso","Mi-temps")+detail);
        }
        if(minute>=46&&(status.contains("LIVE")||status.contains("IN_PLAY")||status.contains("SECOND")||status.contains("2H")||status.contains("PAUSED"))){
            addNormalizedEvent(all,seen,46,"▶️ 46′ "+t2("Second half started","Početak drugog poluvremena","Zweite Halbzeit begonnen","Comenzó la segunda parte","Début de la seconde période"));
        }
        if(MatchStatus.isFinished(status)){
            addNormalizedEvent(all,seen,90,"🏁 90′ "+t2("Full-time","Kraj utakmice","Spielende","Final del partido","Fin du match"));
        }
    }

    void addNormalizedEvent(ArrayList<DetailEvent> all,LinkedHashSet<String> seen,int minute,String text){
        String normalized=text==null?"":text.replaceAll("\\s+"," ").trim();if(normalized.length()==0)return;String key=minute+"|"+normalized.toLowerCase(Locale.US);if(seen.add(key))all.add(new DetailEvent(minute,normalized));
    }

    void appendGenericEventArray(ArrayList<DetailEvent> all,LinkedHashSet<String> seen,JSONArray events){
        if(events==null)return;for(int i=0;i<events.length();i++){JSONObject event=events.optJSONObject(i);if(event==null)continue;int minute=event.optInt("minute",event.optInt("time",0)),injury=event.optInt("injuryTime",event.optInt("addedTime",0));String type=event.optString("type",event.optString("eventType",event.optString("detail",""))).toUpperCase(Locale.US);String detail=event.optString("detail",event.optString("reason",event.optString("description","")));String player=objectName(event.optJSONObject("player"));if(player.length()==0)player=event.optString("playerName",event.optString("name",""));String team=objectName(event.optJSONObject("team"));if(team.length()==0)team=event.optString("teamName","");String icon="●",caption=detail;
            if(type.contains("CANCELLED_GOAL")||type.contains("DISALLOWED_GOAL")||type.contains("GOAL_CANCEL")||type.contains("GOAL_DISALLOW")){icon="⚽";caption=t2("Goal disallowed","Poništen gol","Tor aberkannt","Gol anulado","But refusé")+(detail.length()>0?" — "+detail:"");}
            else if(type.contains("VAR")){icon="📺";caption=t2("VAR check","VAR provjera","VAR-Prüfung","Revisión VAR","Vérification VAR")+(detail.length()>0?" — "+detail:"");}
            else if(type.contains("PENALTY")||type.contains("PEN")){icon="🎯";caption=type.contains("MISS")?t2("Penalty missed","Promašen jedanaesterac","Elfmeter verschossen","Penalti fallado","Penalty manqué"):t2("Penalty","Jedanaesterac","Elfmeter","Penalti","Penalty");if(detail.length()>0)caption+=" — "+detail;}
            else if(type.contains("GOAL")){icon="⚽";caption=detail.length()>0?detail:t2("Goal","Gol","Tor","Gol","But");}
            else if(type.contains("RED")){icon="🟥";caption=detail;}
            else if(type.contains("YELLOW")||type.contains("CARD")){icon="🟨";caption=detail;}
            else if(type.contains("SUB")){icon="🔄";caption=detail;}
            else if(type.contains("EXTRA_TIME")||type.equals("ET")){icon="⏱️";caption=t2("Extra time","Produžeci","Verlängerung","Prórroga","Prolongation");}
            if(caption==null||caption.trim().length()==0)caption=type.length()>0?type:t2("Match event","Događaj utakmice","Spielereignis","Evento del partido","Événement du match");String text=icon+" "+minuteLabel(minute,injury)+" "+caption;if(player.length()>0&&!caption.toLowerCase(Locale.US).contains(player.toLowerCase(Locale.US)))text+=" • "+player;if(team.length()>0)text+=" • "+displayTeamName(team);addNormalizedEvent(all,seen,minute,text);
        }
    }

    String minuteLabel(int minute,int injury){
        if(injury>0)return minute+"+"+injury+"′";
        return minute>0?minute+"′":"";
    }

    String objectName(JSONObject o){return o==null?"":o.optString("name",o.optString("shortName",""));}

    String formatMatchStatistics(JSONObject homeObj,JSONObject awayObj,String home,String away){
        if(homeObj==null||awayObj==null)return "";
        JSONObject hs=homeObj.optJSONObject("statistics"), as=awayObj.optJSONObject("statistics");
        if(hs==null||as==null)return "";
        StringBuilder sb=new StringBuilder();
        sb.append(flag(home)).append(" ").append(displayTeamName(home)).append("     ").append(flag(away)).append(" ").append(displayTeamName(away));
        appendStat(sb,hs,as,"ball_possession",t2("Possession","Posjed","Ballbesitz","Posesión","Possession"),"%");
        appendStat(sb,hs,as,"shots",t2("Shots","Udarci","Schüsse","Tiros","Tirs"),"");
        appendStat(sb,hs,as,"shots_on_goal",t2("Shots on target","U okvir","Schüsse aufs Tor","A puerta","Cadrés"),"");
        appendStat(sb,hs,as,"corner_kicks",t2("Corners","Korneri","Ecken","Córners","Corners"),"");
        appendStat(sb,hs,as,"offsides",t2("Offsides","Zaleđa","Abseits","Fueras de juego","Hors-jeu"),"");
        appendStat(sb,hs,as,"fouls",t2("Fouls","Prekršaji","Fouls","Faltas","Fautes"),"");
        appendStat(sb,hs,as,"saves",t2("Saves","Obrane","Paraden","Paradas","Arrêts"),"");
        appendStat(sb,hs,as,"yellow_cards",t2("Yellow cards","Žuti kartoni","Gelbe Karten","Amarillas","Cartons jaunes"),"");
        appendStat(sb,hs,as,"red_cards",t2("Red cards","Crveni kartoni","Rote Karten","Rojas","Cartons rouges"),"");
        return sb.toString();
    }

    void appendStat(StringBuilder sb,JSONObject home,JSONObject away,String key,String label,String suffix){
        if(!home.has(key)&&!away.has(key))return;
        String h=home.isNull(key)?"-":home.optString(key,"-");
        String a=away.isNull(key)?"-":away.optString(key,"-");
        if(suffix.length()>0){if(!h.equals("-"))h+=suffix;if(!a.equals("-"))a+=suffix;}
        sb.append("\n").append(h).append("   ").append(label).append("   ").append(a);
    }

    String formatReferees(JSONArray refs){
        if(refs==null)return "";
        for(int i=0;i<refs.length();i++){
            JSONObject r=refs.optJSONObject(i); if(r==null)continue;
            String type=r.optString("type","");
            if(type.equals("REFEREE")||type.equals("MAIN_REFEREE"))return r.optString("name","");
        }
        return "";
    }

    int change(int v,int d){if(v<0)v=0;v+=d;if(v<0)v=0;return v;} String display(int v){return v>=0?""+v:"-";}
    TextView scoreLabel(int v){TextView t=label(display(v),21,text,true);t.setGravity(Gravity.CENTER);t.setBackground(round(chipBg,dp(14),0));return t;} String shortName(String s){return s;}

    void showGroups(){
        clear(tr("Groups"),"P/W/D/L/GD/Pts","Groups");
        addOnlineCard();
        Map<String,List<TeamRow>> map=data.standings();
        for(String g:data.groups){LinearLayout c=card();c.addView(label("Group "+g,23,RED,true));c.addView(tableRow("#","Team","P","W","D","L","GD","Pts",true,subText));List<TeamRow> rows=map.get(g);for(int i=0;i<rows.size();i++){TeamRow r=rows.get(i);int col=i<2?GREEN:(i==2?GOLD:subText);c.addView(tableRow((i+1)+"",flag(r.team)+" "+r.team,r.p+"",r.w+"",r.d+"",r.l+"",(r.gf-r.ga)+"",r.pts+"",false,col));}}
        LinearLayout third=card();third.addView(label("🥉 Best third-placed teams",22,text,true));List<TeamRow> th=data.bestThirds();for(int i=0;i<th.size();i++){TeamRow r=th.get(i);third.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,i<8?GREEN:subText,false));}
    }
    LinearLayout tableRow(String pos,String team,String p,String w,String d,String l,String gd,String pts,boolean bold,int color){LinearLayout r=hrow();r.setPadding(0,dp(4),0,dp(4));r.addView(cell(pos,.45f,bold,color));r.addView(cell(team,2.4f,bold,color));r.addView(cell(p,.55f,bold,color));r.addView(cell(w,.55f,bold,color));r.addView(cell(d,.55f,bold,color));r.addView(cell(l,.55f,bold,color));r.addView(cell(gd,.7f,bold,color));r.addView(cell(pts,.8f,true,color));return r;}
    TextView cell(String s,float w,boolean bold,int color){TextView t=label(s,12,color,bold);t.setGravity(Gravity.CENTER_VERTICAL);t.setSingleLine(true);t.setTextSize(s.length()>14?10:12);t.setLayoutParams(new LinearLayout.LayoutParams(0,dp(34),w));return t;}

    
    String groupLineFor(String team) {
        if (team == null) return "";
        for (String g : data.groups) {
            ArrayList<String> names = new ArrayList<>();
            for (Match m : data.matches) {
                if (m.group.equals(g)) {
                    if (!names.contains(m.home)) names.add(m.home);
                    if (!names.contains(m.away)) names.add(m.away);
                }
            }
            if (names.contains(team)) {
                String line = "Group " + g + ": ";
                for (int i=0; i<names.size(); i++) {
                    if (i>0) line += ", ";
                    line += names.get(i);
                }
                return line;
            }
        }
        return "";
    }

    String groupOfTeam(String team) {
        if (team == null) return "";
        for (Match m : data.matches) {
            if ((m.home.equals(team) || m.away.equals(team)) && isGroupLetter(m.group)) return m.group;
        }
        return "";
    }

    boolean isGroupLetter(String g){
        return g!=null && g.length()==1 && g.compareTo("A")>=0 && g.compareTo("L")<=0;
    }

    String canonicalStageLabel(Match m){
        if(m==null) return "";
        if(isGroupLetter(m.group)) return "Group "+m.group;
        return normalizeStage(m.venue);
    }

    String stageLabel(Match m){
        if(m==null) return "";
        return MatchCenterFormatter.stage(m.group,m.venue,lang);
    }

    String normalizeStage(String raw){
        if(raw==null) return "";
        String x=raw.trim();
        if(x.length()==0 || x.equalsIgnoreCase("null") || x.equals("?")) return "";
        String u=x.replace("-","_").replace(" ","_").toUpperCase(Locale.US);
        if(u.equals("GROUP") || u.equals("GROUP_STAGE") || u.equals("REGULAR_SEASON")) return "";
        if(u.equals("QUALIFICATION_ROUND_1")) return "1. pretkolo";
        if(u.equals("QUALIFICATION_ROUND_2")) return "2. pretkolo";
        if(u.equals("QUALIFICATION_ROUND_3")) return "3. pretkolo";
        if(u.equals("QUALIFICATION") || u.equals("PRELIMINARY_ROUND")) return "Kvalifikacije";
        if(u.equals("PLAYOFFS") || u.equals("PLAYOFF_ROUND_1") || u.equals("PLAYOFF_ROUND_2")) return "Play-off";
        if(u.contains("THIRD_PLACE") || u.contains("3RD_PLACE") || u.contains("THIRDPLACE")) return "Third-place match";
        if(u.contains("ROUND_OF_32") || u.contains("LAST_32") || u.contains("R32")) return "Round of 32";
        if(u.contains("ROUND_OF_16") || u.contains("LAST_16") || u.contains("R16")) return "Round of 16";
        if(u.contains("QUARTER")) return "Quarter-final";
        if(u.contains("SEMI")) return "Semi-final";
        if(u.equals("FINAL") || u.endsWith("_FINAL")) return "Final";
        if(x.toLowerCase(Locale.US).startsWith("round of 32")) return "Round of 32";
        if(x.toLowerCase(Locale.US).startsWith("round of 16")) return "Round of 16";
        return x;
    }

    boolean hasWonStage(String team,String stage){
        if(team==null || stage==null) return false;
        for(Match m:data.matches){
            if(!stage.equals(canonicalStageLabel(m))) continue;
            if(!matchIsFinished(m)) continue;
            if(sameTeam(m.home,team) && m.homeGoals>m.awayGoals) return true;
            if(sameTeam(m.away,team) && m.awayGoals>m.homeGoals) return true;
        }
        return false;
    }


    void addOnlineCard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online update",23,text,true));
        onlineStatusView=label(onlineStatus,14,subText,false);
        c.addView(onlineStatusView);
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0){
            onlineLastUpdateView=label(dataFreshnessLabel(),13,subText,false);
        }else{
            onlineLastUpdateView=label(dataFreshnessLabel(),13,subText,false);
        }
        c.addView(onlineLastUpdateView);
        Button r=outline(t2("↻  Refresh data","↻  Osvježi podatke","↻  Daten aktualisieren","↻  Actualizar datos","↻  Actualiser les données"));
        r.setOnClickListener(v->refreshOnlineSafe(true));
        c.addView(r);
    }
    void addFinishedMatchesCard(){
        addOnlineMatchCenterCard(false);
    }

    void addOnlineMatchCenterCard(boolean compact){
        String live=prefs.getString("online_liveMatches","");
        String jsonUpcoming=prefs.getString("online_upcomingMatches","");
        LinearLayout c=card();
        c.addView(label("⚽ Online match center",23,text,true));
        int liveCount=lineCount(live);
        int finished=displayPlayedCount();
        int upcoming=displayUpcomingCount();
        c.addView(label("🔴 Live: "+liveCount+"   ✅ Finished: "+finished+"   📅 Upcoming: "+upcoming,14,subText,false));

        if(live!=null && live.trim().length()>0){
            c.addView(label("🔴 Live matches",18,RED,true));
            c.addView(label(limitLines(live, compact?3:10),15,subText,false));
        }

        c.addView(label("✅ Finished matches",18,RED,true));
        String onlineFinished=prefs.getString("online_finishedMatches","");
        if(onlineFinished!=null && onlineFinished.trim().length()>0){
            c.addView(label(limitLines(onlineFinished, compact?8:9999),15,subText,false));
            int fc=lineCount(onlineFinished);
            if(compact && fc>8)c.addView(label("+"+(fc-8)+" more finished matches",14,subText,false));
        }else{
            int count=0;
            for(Match m:data.matches){
                if(matchIsFinished(m)){
                    count++;
                    if(!compact || count<=8)c.addView(label(flag(m.home)+" "+m.home+" "+m.homeGoals+" - "+m.awayGoals+" "+flag(m.away)+" "+m.away+" • Group "+m.group,14,subText,false));
                }
            }
            if(count==0)c.addView(label("No finished matches yet.",15,subText,false));
            else if(compact && count>8)c.addView(label("+"+(count-8)+" more finished matches",14,subText,false));
        }

        c.addView(label("📅 Upcoming matches",18,RED,true));
        if(jsonUpcoming!=null && jsonUpcoming.trim().length()>0){
            c.addView(label(limitLines(jsonUpcoming, compact?4:8),15,subText,false));
        }else{
            int shown=0;
            for(Match m:data.matches){
                if(matchIsUpcoming(m)){
                    shown++;
                    if(!compact || shown<=5)c.addView(label(displayLocalDateTime(m.date)+" • Group "+m.group+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away,14,subText,false));
                }
            }
            if(shown==0)c.addView(label("No upcoming matches.",15,subText,false));
            else if(compact && shown>5)c.addView(label("+"+(shown-5)+" more upcoming matches",14,subText,false));
        }
    }

    void addHomeOnlineDashboard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online dashboard",23,text,true));
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        int live=lineCount(prefs.getString("online_liveMatches",""));
        c.addView(kpiRow("Live",""+live,"Finished",""+displayPlayedCount(),"Upcoming",""+displayUpcomingCount(),false));
        if(ENABLE_PLAYER_DATA_MODULES){
            String topScorer=firstRankingLine(gb,t2("Scorer stats coming soon","Statistika strijelaca uskoro","Torschützenstatistik folgt","Estadística de goleadores pronto","Statistiques buteurs bientôt"));
            String topMvp=firstRankingLine(mv,t2("MVP ranking coming soon","MVP poredak uskoro","MVP-Rangliste folgt","Ranking MVP pronto","Classement MVP bientôt"));
            c.addView(label("🥇 "+topScorer,15,subText,false));
            c.addView(label("⭐ "+topMvp,15,subText,false));
        }else{
            c.addView(label(t2("Live matches, results and tables are active.","Rezultati, utakmice i tablice su online.","Live-Spiele, Ergebnisse und Tabellen sind aktiv.","Partidos, resultados y tablas en vivo activos.","Matchs, résultats et tableaux en direct actifs."),15,subText,false));
        }
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0)c.addView(label(lastUpdateLabel(last),13,subText,false));
    }

    int countUpcoming(){int c=0;for(Match m:data.matches)if(matchIsUpcoming(m))c++;return c;}
    int lineCount(String s){if(s==null || s.trim().length()==0)return 0;return s.split("\\n").length;}
    String firstRankingLine(String s,String fallback){if(s==null || s.trim().length()==0)return fallback;String[] lines=s.split("\\n");if(lines.length==0)return fallback;String first=lines[0].trim();first=first.replaceFirst("^\\d+\\.\\s*","");return first.length()>0?first:fallback;}
    int displayPlayedCount(){int v=prefs.getInt("online_playedCount",-1);return v>=0?v:data.playedCount();}
    int displayTotalGoals(){int v=prefs.getInt("online_totalGoals",-1);return v>=0?v:data.totalGoals();}
    int displayUpcomingCount(){int v=prefs.getInt("online_upcomingCount",-1);return v>=0?v:countUpcoming();}
    int displayTotalMatches(){int v=prefs.getInt("online_totalMatches",TOURNAMENT_TOTAL_MATCHES);return v>0?v:TOURNAMENT_TOTAL_MATCHES;}
    int displayProgressPercent(){return (int)Math.round(displayPlayedCount()*100.0/displayTotalMatches());}

    int onlineTotalMatches(JSONObject root){
        if(root==null) return TOURNAMENT_TOTAL_MATCHES;
        JSONObject rs=root.optJSONObject("resultSet");
        if(rs!=null && rs.optInt("count",0)>0) return rs.optInt("count",TOURNAMENT_TOTAL_MATCHES);
        JSONArray arr=root.optJSONArray("matches");
        if(arr!=null && arr.length()>72) return arr.length();
        return TOURNAMENT_TOTAL_MATCHES;
    }
    int onlineFinishedCount(JSONObject root){
        if(root==null) return 0;
        // Never trust an aggregate "played" counter as proof of a result.
        // Football Fun counts a played match only when the exact fixture carries
        // a final status and both verified scores.
        JSONArray fin=root.optJSONArray("finished");
        int c=countVerifiedFinishedJson(fin);
        if(fin!=null) return c;
        return countVerifiedFinishedJson(root.optJSONArray("matches"));
    }
    int countVerifiedFinishedJson(JSONArray arr){
        int c=0;
        if(arr==null)return 0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o!=null && isFinishedStatus(o.optString("status","")) && jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0)c++;
        }
        return c;
    }
    int onlineUpcomingCount(JSONObject root){
        if(root==null) return -1;
        JSONArray up=root.optJSONArray("upcoming");
        if(up!=null) return up.length();
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) return -1;
        int c=0;
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null && isUpcomingStatus(o.optString("status","")))c++;}
        return c;
    }
    int onlineTotalGoals(JSONObject root){
        if(root==null) return 0;
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) arr=root.optJSONArray("finished");
        int g=0;
        if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); int h=jsonHomeGoals(o), a=jsonAwayGoals(o); if(h>=0 && a>=0 && isFinishedStatus(o.optString("status",""))) g+=h+a;}
        return g;
    }

    String limitLines(String s,int max){if(s==null)return "";String[] lines=s.split("\\n");StringBuilder sb=new StringBuilder();for(int i=0;i<lines.length && i<max;i++){if(i>0)sb.append("\n");sb.append(lines[i]);}if(lines.length>max)sb.append("\n+").append(lines.length-max).append(" more");return sb.toString();}

    void addOnlineRankingsPreview(){
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        if((gb==null || gb.trim().length()==0) && (mv==null || mv.trim().length()==0)) return;
        LinearLayout c=card();
        c.addView(label("🌐 Online rankings",23,text,true));
        if(gb!=null && gb.trim().length()>0){
            c.addView(label("🥇 "+tr("Golden Boot"),18,RED,true));
            c.addView(label(gb,15,subText,false));
        }
        if(mv!=null && mv.trim().length()>0){
            c.addView(label("⭐ "+tr("MVP Prediction"),18,RED,true));
            c.addView(label(mv,15,subText,false));
        }
    }


    void migrateToCentralUclV221(){
        if(prefs.getBoolean("migration_central_ucl_v221",false))return;
        try{
            synchronized(dataApplyLock){
                ArrayList<Match> keep=new ArrayList<Match>();
                for(Match match:data.matches){
                    if(match==null)continue;
                    boolean oldSynthetic=matchBelongsToCompetition(match,"UEFA Champions League")&&match.apiId<=0;
                    if(!oldSynthetic)keep.add(match);
                }
                if(keep.size()!=data.matches.size()){
                    data.matches.clear();
                    data.matches.addAll(keep);
                    refreshCentralTeamIndex();
                    rebuildTeamMatchIndex();
                    data.save();
                    data.saveCentralCache();
                }
                String cached=prefs.getString("online_rawJson","");
                if(cached!=null&&!cached.trim().isEmpty()){
                    try{
                        JSONObject root=new JSONObject(cached);
                        String[] arrays={"matches","live","finished","upcoming"};
                        for(String key:arrays){
                            JSONArray source=root.optJSONArray(key);
                            if(source==null)continue;
                            JSONArray clean=new JSONArray();
                            for(int i=0;i<source.length();i++){
                                JSONObject row=source.optJSONObject(i);
                                if(row==null)continue;
                                boolean isCl=jsonMatchBelongsToCompetition(row,"UEFA Champions League");
                                Object rawId=row.opt("id");
                                boolean positiveNumeric=false;
                                if(rawId instanceof Number)positiveNumeric=((Number)rawId).longValue()>0;
                                else{try{positiveNumeric=Long.parseLong(String.valueOf(rawId))>0;}catch(Exception ignored){}}
                                if(isCl&&!positiveNumeric)continue;
                                clean.put(row);
                            }
                            root.put(key,clean);
                        }
                        prefs.edit().putString("online_rawJson",root.toString()).apply();
                    }catch(Exception ignored){}
                }
                // Force exactly one fresh authoritative download after the schema
                // migration so the first updater payload containing central UCL
                // qualifiers cannot be hidden behind an older HTTP ETag.
                prefs.edit().remove("online_etag").putBoolean("migration_central_ucl_v221",true).apply();
                invalidateCompetitionCaches();
            }
        }catch(Exception ignored){
            prefs.edit().remove("online_etag").putBoolean("migration_central_ucl_v221",true).apply();
        }
    }

    void warmStartDataAsync(){
        bundledBaselineLoading=true;
        try{
            appSerialExecutor.execute(new Runnable(){ public void run(){
                boolean cacheLoaded=false;
                boolean baselineReady=false;
                boolean homeReadyPosted=false;
                try{
                    migrateToCentralUclV221();
                    if(data.hasCentralCache()){
                        migrateOfficialHnlScheduleIfNeeded();
                        restoreCompactCrestIndex();
                        // The persisted central cache is written only after normalization
                        // and deduplication. Do not repeat those full-model passes on every
                        // launch. Build the team index immediately because Home needs it.
                        refreshCentralTeamIndex();
                        rebuildTeamMatchIndex();
                        baselineReady=true;
                        cacheLoaded=true;
                        bundledBaselineLoading=false;
                        postHomeBaselineReady(true);
                        homeReadyPosted=true;
                        // Lower-priority competition snapshots can finish after Home is usable.
                        refreshCompetitionSourceSnapshot();
                        invalidateCompetitionCaches();
                    }else{
                        seedBundledCompetitionsIntoCentralModel();
                        String cached=prefs.getString("online_rawJson","");
                        if(cached!=null&&cached.trim().length()>0){applyOnlineJson(cached);cacheLoaded=true;}
                        rebuildTeamMatchIndex();
                        data.saveCentralCache();
                        baselineReady=true;
                        bundledBaselineLoading=false;
                        postHomeBaselineReady(cacheLoaded);
                        homeReadyPosted=true;
                    }
                    warmClubProfileCacheAsync();
                }catch(Exception ignored){}
                bundledBaselineLoading=false;
                if(!homeReadyPosted&&baselineReady)postHomeBaselineReady(cacheLoaded);
                syncMatchRemindersAsync();
                refreshOnlineSafe(false);
            }});
        }catch(Exception ignored){bundledBaselineLoading=false;}
    }

    void postHomeBaselineReady(final boolean loaded){
        runOnUiThread(new Runnable(){ public void run(){
            if(isFinishing()||isDestroyed())return;
            if(loaded)onlineStatus="🟢 "+t2("Cached data loaded","Spremljeni podaci učitani","Zwischengespeicherte Daten geladen","Datos guardados cargados","Données enregistrées chargées");
            if(onlineStatusView!=null)onlineStatusView.setText("🟢 Ready for live data".equals(onlineStatus)
                        ?"🟢 "+t2("Ready for live data","Spremno za podatke uživo","Bereit für Live-Daten","Listo para datos en vivo","Prêt pour les données en direct")
                        :onlineStatus);
            if("Home".equals(currentScreen))showHome();
        }});
    }

    void migrateOfficialHnlScheduleIfNeeded(){
        final int requiredRevision=235;
        if(prefs.getInt("hnl_schedule_revision",0)>=requiredRevision)return;
        try{
            synchronized(dataApplyLock){
                String seed=prefs.getString("online_rawJson","");
                if(seed==null||seed.trim().isEmpty())seed="{}";
                String normalized=liveDataClient.mergeOfficialHnlFixtures(seed);
                JSONObject root=new JSONObject(normalized);
                JSONArray matches=root.optJSONArray("matches");
                JSONArray hnlRows=new JSONArray();
                if(matches!=null)for(int i=0;i<matches.length();i++){
                    JSONObject row=matches.optJSONObject(i);
                    if(row!=null&&jsonMatchBelongsToCompetition(row,"HNL")){
                        hnlRows.put(new JSONObject(row.toString()));
                    }
                }
                if(hnlRows.length()>0){
                    syncMatchesFromArray(hnlRows);
                    MatchConsistency.normalizeAll(data.matches);
                    removeDuplicateMatches();
                    data.save();
                    data.saveCentralCache();
                }
                onlineRootCache=root;
                onlineRootCacheRaw=normalized;
                prefs.edit()
                        .putString("online_rawJson",normalized)
                        .putInt("hnl_schedule_revision",requiredRevision)
                        .apply();
            }
        }catch(Exception ignored){}
    }

    void seedBundledCompetitionsIntoCentralModel(){
        try{
            synchronized(dataApplyLock){
                String merged=liveDataClient.mergeBundledFixtures("{}");
                JSONObject root=new JSONObject(merged);
                JSONArray matches=root.optJSONArray("matches");
                if(matches!=null&&matches.length()>0){
                    syncMatchesFromArray(matches);
                    MatchConsistency.normalizeAll(data.matches);
                    removeDuplicateMatches();
                    refreshCentralTeamIndex();
                    rebuildTeamMatchIndex();
                    data.save();
                }
                onlineRootCache=root;
                onlineRootCacheRaw=merged;
                rebuildClubCrestIndex(root);
                invalidateClubProfileCache();
                refreshCompetitionSourceSnapshot();
                invalidateCompetitionCaches();
            }
        }catch(Exception ignored){}
    }


    void restoreCachedOnlineData(){
        String cached=prefs.getString("online_rawJson","");
        if(cached==null || cached.trim().length()==0) return;
        try{
            applyOnlineJson(cached);
            onlineStatus="🟢 "+t2("Cached data loaded","Spremljeni podaci učitani","Zwischengespeicherte Daten geladen","Datos guardados cargados","Données enregistrées chargées");
        }catch(Exception ignored){}
    }


    void refreshOnlineSafe(){
        refreshOnlineSafe(true);
    }

    void refreshOnlineSafe(final boolean showToast){
        if(System.currentTimeMillis()<onlineRateLimitUntilMs){
            if(showToast)toast(t2("Refresh temporarily paused","Osvježavanje je privremeno pauzirano","Aktualisierung kurz pausiert","Actualización pausada temporalmente","Actualisation temporairement en pause"));
            return;
        }
        if(onlineRefreshInProgress){
            if(showToast)toast(t2("Update is already in progress","Ažuriranje je već u tijeku","Aktualisierung läuft bereits","La actualización ya está en curso","La mise à jour est déjà en cours"));
            return;
        }
        onlineRefreshInProgress=true;
        onlineStatus=t2("Checking for new data...","Provjera novih podataka...","Neue Daten werden geprüft...","Comprobando datos nuevos...","Vérification des nouvelles données...");
        if(onlineStatusView!=null)onlineStatusView.setText("🟢 Ready for live data".equals(onlineStatus)
                        ?"🟢 "+t2("Ready for live data","Spremno za podatke uživo","Bereit für Live-Daten","Listo para datos en vivo","Prêt pour les données en direct")
                        :onlineStatus);
        try{
            appSerialExecutor.execute(new Runnable(){ public void run(){
                String result;
                String last=prefs.getString("online_lastUpdate","");
                boolean changedData=false;
                try{
                    String previousEtag=prefs.getString("online_etag","");
                    LiveDataClient.DownloadResult remote=liveDataClient.downloadLatest(previousEtag);
                    if(remote.notModified){
                        prefs.edit().putString("online_lastChecked",nowStamp()).apply();
                        result="🟢 "+t2("Data already up to date","Podaci su već ažurni","Daten sind bereits aktuell","Los datos ya están actualizados","Les données sont déjà à jour");
                    }else{
                        if(remote.json==null||remote.json.trim().length()==0)throw new Exception("Empty online file");
                        int changed=applyOnlineJson(remote.json);
                        changedData=changed>0;
                        SharedPreferences.Editor editor=prefs.edit().putString("online_lastChecked",nowStamp());
                        if(remote.etag!=null&&!remote.etag.trim().isEmpty())editor.putString("online_etag",remote.etag.trim());
                        editor.apply();
                        if(changedData){
                            String activeCompetition=currentCompetitionName;
                            if(activeCompetition!=null&&!activeCompetition.isEmpty())prewarmCompetitionCache(activeCompetition);
                            warmClubProfileCacheAsync();
                        }
                        last=prefs.getString("online_lastUpdate",last);
                        result="🟢 "+(changed>0
                                ?t2("New data saved","Novi podaci spremljeni","Neue Daten gespeichert","Datos nuevos guardados","Nouvelles données enregistrées")
                                :t2("Checked • no new changes","Provjereno • nema novih promjena","Geprüft • keine neuen Änderungen","Comprobado • sin cambios nuevos","Vérifié • aucun nouveau changement"));
                    }
                }catch(Exception e){
                    String error=safeMsg(e);
                    if(error!=null&&error.contains("HTTP 429"))onlineRateLimitUntilMs=System.currentTimeMillis()+ONLINE_RATE_LIMIT_BACKOFF_MS;
                    result=t2("Online data unavailable • ","Online podaci nisu dostupni • ","Online-Daten nicht verfügbar • ","Datos online no disponibles • ","Données en ligne indisponibles • ")+error;
                }
                final String msg=result;
                final String lastText=last;
                final boolean shouldResync=changedData;
                runOnUiThread(new Runnable(){ public void run(){
                    onlineRefreshInProgress=false;
                    if(isFinishing()||isDestroyed())return;
                    onlineStatus=msg;
                    if(onlineStatusView!=null)onlineStatusView.setText(msg);
                    if(onlineLastUpdateView!=null)onlineLastUpdateView.setText(dataFreshnessLabel());
                    if(matchCenterLastUpdateView!=null){
                        String checked=prefs.getString("online_lastChecked","");
                        String shown=(checked==null||checked.trim().isEmpty())
                                ?t2("not yet checked","još nije provjereno","noch nicht geprüft","aún no comprobado","pas encore vérifié")
                                :displayUiTimestamp(checked);
                        matchCenterLastUpdateView.setText(t2("Last check: ","Zadnja provjera: ","Letzte Prüfung: ","Última comprobación: ","Dernière vérification : ")+shown);
                    }
                    if(showToast)toast(msg);
                }});
                if(msg.startsWith("🟢")&&shouldResync)syncMatchRemindersAsync();
            }});
        }catch(Exception e){
            onlineRefreshInProgress=false;
        }
    }


    void rememberOpenMatch(Match m){
        if(m==null)return;
        openMatchApiId=m.apiId;
        openMatchHome=m.home==null?"":m.home;
        openMatchAway=m.away==null?"":m.away;
        openMatchDate=m.date==null?"":m.date;
    }

    Match findOpenMatchDetails(){
        if(data==null||data.matches==null)return null;
        for(Match m:data.matches){
            if(openMatchApiId>0 && m.apiId==openMatchApiId)return m;
        }
        for(Match m:data.matches){
            boolean samePair=(sameTeam(m.home,openMatchHome)&&sameTeam(m.away,openMatchAway))||(sameTeam(m.home,openMatchAway)&&sameTeam(m.away,openMatchHome));
            if(!samePair)continue;
            if(openMatchDate.length()==0||m.date==null||m.date.equals(openMatchDate)||m.date.startsWith(openMatchDate.length()>=10?openMatchDate.substring(0,10):openMatchDate))return m;
        }
        return null;
    }

    void stopLiveMatchDetailsRefresh(){
        try{
            if(liveMatchDetailsRefreshRunnable!=null)handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        liveMatchDetailsRefreshRunnable=null;
    }

    void startLiveMatchDetailsRefresh(Match m){
        stopLiveMatchDetailsRefresh();
        if(m==null||!matchIsLive(m)||!"MatchDetails".equals(currentScreen))return;
        rememberOpenMatch(m);
        liveMatchDetailsRefreshRunnable=new Runnable(){ public void run(){
            if(!"MatchDetails".equals(currentScreen))return;
            Match open=findOpenMatchDetails();
            if(open==null){showMatches();return;}
            if(!matchIsLive(open)){showMatchDetails(open);return;}
            refreshOnlineSafe(false);
            handler.postDelayed(this,AppConfig.LIVE_MATCH_REFRESH_MS);
        }};
        handler.postDelayed(liveMatchDetailsRefreshRunnable,AppConfig.LIVE_MATCH_REFRESH_MS);
    }

    String safeMsg(Exception e){
        if(e==null || e.getMessage()==null) return "check connection";
        String s=e.getMessage();
        return s.length()>70?s.substring(0,70):s;
    }

    String teamKey(String s){
        if(s==null) return "";
        // One identity layer for fixtures, tables, crests, favorites, Club Center
        // and player routing. Provider aliases are normalized before any lookup.
        String canonicalClub=ClubIdentityRegistry.canonicalName(s);
        if(canonicalClub.length()>0)s=canonicalClub;
        String k=Normalizer.normalize(s.toLowerCase(Locale.US),Normalizer.Form.NFD).replaceAll("\\p{M}+","").replace("č","c").replace("ć","c").replace("š","s").replace("ž","z").replace("đ","d");
        k=k.replace("côte d’ivoire","ivorycoast").replace("côte d'ivoire","ivorycoast").replace("cote d’ivoire","ivorycoast").replace("cote d'ivoire","ivorycoast");
        k=k.replace("curaçao","curacao").replace("united states","usa").replace("u.s.a.","usa").replace("u.s.a","usa");
        k=k.replace("south korea","korearepublic").replace("republic of korea","korearepublic");
        k=k.replace("cape verde islands","capeverde").replace("capeverdeislands","capeverde");
        k=k.replace("democratic republic of congo","drcongo").replace("d r congo","drcongo").replace("congo dr","drcongo").replace("drc","drcongo");
        k=k.replace("bosnia & herzegovina","bosniaherzegovina").replace("bosnia and herzegovina","bosniaherzegovina").replace("bosnia-herzegovina","bosniaherzegovina").replace("bosnia herzegovina","bosniaherzegovina");
        k=k.replaceAll("[^a-z0-9]","");
        if(k.equals("dinamo")||k.equals("gnkdinamo")||k.equals("dinamozagreb"))return "dinamozagreb";
        if(k.equals("hajduk")||k.equals("hnkhajduk")||k.equals("hnkhajduksplit")||k.equals("hajduksplit"))return "hajduksplit";
        if(k.equals("lokomotiva")||k.equals("nklokomotiva")||k.equals("nklokomotivaz")||k.equals("lokomotivazagreb"))return "lokomotivazagreb";
        if(k.equals("rudes")||k.equals("nkrudes"))return "rudes";
        if(k.equals("varazdin")||k.equals("nkvarazdin"))return "varazdin";
        if(k.equals("gorica")||k.equals("hnkgorica")||k.equals("hnkgoricasdd"))return "gorica";
        if(k.equals("rijeka")||k.equals("hnkrijeka"))return "rijeka";
        if(k.equals("osijek")||k.equals("nkosijek"))return "osijek";
        if(k.equals("istra1961")||k.equals("nkistra1961")||k.equals("istr1961"))return "istra1961";
        if(k.equals("slavenbelupo")||k.equals("nkslavenbelupo"))return "slavenbelupo";
        // Cross-provider club aliases used by central match identity.
        if(k.equals("telstar1963")||k.equals("sctelstar")||k.equals("telstarijmuiden"))return "telstar";
        if(k.equals("sportingclubedeportugal")||k.equals("sportinglisbon")||k.equals("sportingcp"))return "sportingcp";
        if(k.equals("blackburnroversfc"))return "blackburnrovers";
        if(k.equals("boltonwanderersfc"))return "boltonwanderers";
        if(k.equals("prestonnorthendfc"))return "prestonnorthend";
        if(k.equals("wolverhamptonwanderersfc"))return "wolverhamptonwanderers";
        // Serie A provider aliases: one canonical key across fixtures,
        // standings, favorites, Club Center and crest lookup.
        if(k.equals("atalantabc"))return "atalanta";
        if(k.equals("bolognafc1909")||k.equals("bolognafc"))return "bologna";
        if(k.equals("cagliaricalcio"))return "cagliari";
        if(k.equals("como1907")||k.equals("como1907fc"))return "como";
        if(k.equals("acfiorentina"))return "fiorentina";
        if(k.equals("frosinonecalcio"))return "frosinone";
        if(k.equals("genoacfc"))return "genoa";
        if(k.equals("fcinternazionalemilano")||k.equals("internazionalemilano")||k.equals("intermilan"))return "inter";
        if(k.equals("juventusfc"))return "juventus";
        if(k.equals("sslazio"))return "lazio";
        if(k.equals("uslecce"))return "lecce";
        if(k.equals("acmilan"))return "milan";
        if(k.equals("acmonza"))return "monza";
        if(k.equals("sscnapoli"))return "napoli";
        if(k.equals("parmacalcio1913")||k.equals("parmacalcio"))return "parma";
        if(k.equals("asroma"))return "roma";
        if(k.equals("ussassuolocalcio")||k.equals("sassuolocalcio"))return "sassuolo";
        if(k.equals("torinofc"))return "torino";
        if(k.equals("udinesecalcio"))return "udinese";
        if(k.equals("veneziafc"))return "venezia";
        if(k.equals("botafogofr")||k.equals("botafogo"))return "botafogo";
        if(k.equals("camineiro")||k.equals("atleticomineiro"))return "atleticomineiro";
        if(k.equals("chapecoenseaf")||k.equals("chapecoense"))return "chapecoense";
        if(k.equals("coritibafbc")||k.equals("coritiba"))return "coritiba";
        if(k.equals("crvascodagama")||k.equals("vascodagama"))return "vascodagama";
        if(k.equals("crflamengo")||k.equals("flamengo"))return "flamengo";
        if(k.equals("fluminensefc")||k.equals("fluminense"))return "fluminense";
        if(k.equals("sepalmeiras")||k.equals("palmeiras"))return "palmeiras";
        if(k.equals("saopaulofc")||k.equals("saopaulo"))return "saopaulo";
        if(k.equals("scinternacional")||k.equals("internacional"))return "internacional";
        if(k.equals("gremiofbpa")||k.equals("gremio"))return "gremio";
        if(k.equals("ecbahia")||k.equals("bahia"))return "bahia";
        if(k.equals("ecvitoria")||k.equals("vitoria"))return "vitoria";
        if(k.equals("cruzeiroec")||k.equals("cruzeiro"))return "cruzeiro";
        if(k.equals("fortalezaec")||k.equals("fortaleza"))return "fortaleza";
        if(k.equals("santosfc")||k.equals("santos"))return "santos";
        if(k.equals("clubathleticoparanaense")||k.equals("athleticopr")||k.equals("cap")||k.equals("athleticoparanaense"))return "athleticoparanaense";
        if(k.equals("clubeatleticomineiro")||k.equals("atleticomg")||k.equals("cam"))return "atleticomineiro";
        if(k.equals("esporteclubebahia"))return "bahia";
        if(k.equals("botafogodefuteboleregatas"))return "botafogo";
        if(k.equals("associacaochapecoensedefutebol"))return "chapecoense";
        if(k.equals("sportclubcorinthianspaulista")||k.equals("corinthianspaulista"))return "corinthians";
        if(k.equals("coritibafc"))return "coritiba";
        if(k.equals("cruzeiroesporteclube"))return "cruzeiro";
        if(k.equals("clubederegatasdoflamengo"))return "flamengo";
        if(k.equals("fluminensefootballclub"))return "fluminense";
        if(k.equals("gremiofootballportoalegrense"))return "gremio";
        if(k.equals("sportclubinternacional"))return "internacional";
        if(k.equals("mirassolfc"))return "mirassol";
        if(k.equals("sociedadeesportivapalmeiras"))return "palmeiras";
        if(k.equals("redbullbragantino")||k.equals("rbbragantino")||k.equals("redbullbragantinosp"))return "redbullbragantino";
        if(k.equals("clubedoremo")||k.equals("remopa"))return "remo";
        if(k.equals("santosfutebolclube"))return "santos";
        if(k.equals("saopaulofutebolclube"))return "saopaulo";
        if(k.equals("clubederegatasvascodagama"))return "vascodagama";
        if(k.equals("esporteclubedavitoria"))return "vitoria";
        return k;
    }
    boolean sameTeam(String a,String b){
        String x=teamKey(a), y=teamKey(b);
        if(x.equals(y)) return true;
        if((x.equals("ivorycoast")&&y.equals("cotedivoire"))||(y.equals("ivorycoast")&&x.equals("cotedivoire"))) return true;
        if((x.equals("korearepublic")&&y.equals("korea"))||(y.equals("korearepublic")&&x.equals("korea"))) return true;
        if((x.equals("bosniaherzegovina")&&y.equals("bosniaandherzegovina"))||(y.equals("bosniaherzegovina")&&x.equals("bosniaandherzegovina"))) return true;
        return false;
    }

    boolean isLiveStatus(String st){ return MatchStatus.isLive(st); }

    boolean isFinishedStatus(String st){ return MatchStatus.isFinished(st); }

    boolean isUpcomingStatus(String st){ return MatchStatus.isUpcoming(st); }

    String nowStamp(){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());
    }

    int applyOnlineJson(String json) throws Exception{
        synchronized(dataApplyLock){
            return applyOnlineJsonLocked(json);
        }
    }

    int applyOnlineJsonLocked(String json) throws Exception{
        // Bundled verified schedules are seeded into the central model once during
        // warm start. Online JSON is therefore an incremental overlay only. Do not
        // rebuild all nine large bundled schedules for every refresh.
        // HNL is normalized before ANY remote row is merged into the central model.
        // This guarantees Home, Matches, HNL and Club Center all receive the same
        // authoritative HNL fixture object even when the remote JSON still has an
        // older date-only row.
        String normalizedJson=liveDataClient.mergeOfficialHnlFixtures(json);
        JSONObject root=new JSONObject(normalizedJson);
        onlineRootCache=root;
        onlineRootCacheRaw=normalizedJson;
        int applied=0;
        JSONArray arr=root.optJSONArray("matches");
        JSONArray finishedArr=root.optJSONArray("finished");
        String rootTeamName=root.optString("shortName","");
        if(rootTeamName.length()==0&&root.has("squad"))rootTeamName=root.optString("name","");
        if(root.has("squad")||root.has("venue")||root.has("founded"))registerTeamProfile(root);
        registerTeamProfileFeed(root.optJSONArray("teams"));
        registerTeamProfileFeed(root.optJSONArray("clubs"));
        registerTeamProfileFeed(root.optJSONArray("teamProfiles"));
        registerPlayerFeed(root.optJSONArray("players"), rootTeamName);
        registerPlayerFeed(root.optJSONArray("squad"), rootTeamName);
        registerPlayerFeed(root.optJSONArray("squads"), "");
        registerTeamSquadFeed(root.optJSONArray("teams"));
        registerTeamSquadFeed(root.optJSONArray("clubs"));
        registerTeamSquadFeed(root.optJSONArray("teamProfiles"));
        purgeInvalidPlayerRecords();

        // v13.44: one source of truth. When football-data.org returns the full
        // competition match list, rebuild the in-app match list from that JSON.
        // This prevents the simulator/predict screens from showing old local APK
        // fixtures while the online match center shows fresh data.
        if(arr!=null && arr.length()>0){
            // Never replace the central model with one network snapshot. The
            // authoritative feed may be partial for a competition or season;
            // only new/changed rows are merged and verified local data remains.
            applied += syncMatchesFromArray(arr);
            // The live array can contain a fresher score/status than the full
            // schedule. Merge it into the actual Match objects used by Home,
            // Match Center and all lists before rendering.
            applied += syncMatchesFromArray(root.optJSONArray("live"));
            applied += syncMatchesFromArray(root.optJSONArray("finished"));
        }else{
            applied += syncMatchesFromArray(root.optJSONArray("live"));
            if(finishedArr!=null) applied+=applyResultsFromArray(finishedArr, true);
        }
        MatchConsistency.normalizeAll(data.matches);
        applied+=removeDuplicateMatches();
        if(applied>0){
            refreshCentralTeamIndex();
            data.save();
            data.saveCentralCache();
        }
        String live=formatMatchFeed(root.optJSONArray("live"));
        String upcoming=formatMatchFeed(root.optJSONArray("upcoming"));
        if(arr!=null){
            StringBuilder liveSb=new StringBuilder();
            StringBuilder upSb=new StringBuilder();
            for(int i=0;i<arr.length();i++){
                JSONObject o=arr.optJSONObject(i);
                if(o==null) continue;
                String st=o.optString("status","").toLowerCase(Locale.US);
                boolean hasScore=jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0;
                if(isLiveStatus(st)){ if(liveSb.length()>0)liveSb.append("\n"); liveSb.append(formatOneMatch(o,false)); }
                else if((isUpcomingStatus(st)) && !hasScore){ if(upSb.length()>0)upSb.append("\n"); upSb.append(formatOneMatch(o,true)); }
            }
            if(live.length()==0)live=liveSb.toString();
            if(upcoming.length()==0)upcoming=upSb.toString();
        }
        String finishedFeed=formatMatchFeed(root.optJSONArray("finished"));
        int onlinePlayed=onlineFinishedCount(root);
        int onlineGoals=onlineTotalGoals(root);
        int onlineUpcoming=onlineUpcomingCount(root);
        int onlineTotal=onlineTotalMatches(root);
        if(arr!=null&&arr.length()>0){
            // The central model has already been normalized and deduplicated.
            // All counters must use that same source of truth.
            onlinePlayed=data.playedCount();
            onlineGoals=data.totalGoals();
            onlineUpcoming=countUpcoming();
            onlineTotal=data.matches.size();
        }else{
            if(onlinePlayed<=0)onlinePlayed=data.playedCount();
            if(onlineGoals<=0)onlineGoals=data.totalGoals();
            if(onlineUpcoming<0)onlineUpcoming=countUpcoming();
        }
        String updated=root.optString("lastUpdate",root.optString("updated",""));
        if(updated==null || updated.trim().length()==0) updated=nowStamp();
        prefs.edit()
            .putString("online_lastUpdate",updated)
            .putString("online_rawJson",json)
            .putString("online_finishedMatches",finishedFeed)
            .putInt("online_playedCount",onlinePlayed)
            .putInt("online_totalGoals",onlineGoals)
            .putInt("online_upcomingCount",onlineUpcoming)
            .putInt("online_totalMatches",onlineTotal)
            .putString("online_goldenBoot",formatRanking(root.optJSONArray("goldenBoot"),"goals"))
            .putString("online_mvp",formatRanking(root.optJSONArray("mvp")!=null?root.optJSONArray("mvp"):root.optJSONArray("mvpRanking"),"points"))
            .putString("online_liveMatches",live)
            .putString("online_upcomingMatches",upcoming)
            .apply();
        rebuildClubCrestIndex(root);
        invalidateClubProfileCache();
        rebuildTeamMatchIndex();
        refreshCompetitionSourceSnapshot();
        invalidateCompetitionCaches();
        saveFavoritePlayerProfiles();
        return applied;
    }


    void refreshCentralTeamIndex(){
        if(data==null||data.matches==null||data.teams==null)return;
        LinkedHashSet<String> names=new LinkedHashSet<String>();
        for(Match match:data.matches){
            if(match==null)continue;
            if(match.home!=null&&!match.home.trim().isEmpty())names.add(match.home.trim());
            if(match.away!=null&&!match.away.trim().isEmpty())names.add(match.away.trim());
        }
        ArrayList<String> sorted=new ArrayList<String>(names);
        Collections.sort(sorted);
        data.teams.clear();
        data.teams.addAll(sorted);
    }


    int rebuildMatchesFromOnlineArray(JSONArray arr){
        if(arr==null || arr.length()==0) return 0;
        ArrayList<Match> fresh=new ArrayList<>();
        LinkedHashSet<String> freshTeams=new LinkedHashSet<>();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0 || away.length()==0) continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0) stage="Group stage";

            Match m=new Match(jsonGroup, home, away, jsonDate, stage);
            applyRoundMetadata(m,o);
            m.status=o.optString("status","");
            m.minute=o.optString("minute",o.optString("matchMinute",""));
            m.competition=competitionNameFromJson(o);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=m.status.toLowerCase(Locale.US);
            // Only official live/finished matches get scores. Scheduled matches stay blank.
            if(hg>=0 && ag>=0 && (isFinishedStatus(st) || isLiveStatus(st))){
                m.homeGoals=hg;
                m.awayGoals=ag;
            }else{
                m.homeGoals=-1;
                m.awayGoals=-1;
            }
            populateMatchDetails(m,o);
            fresh.add(m);
            freshTeams.add(home);
            freshTeams.add(away);
        }
        if(fresh.size()==0) return 0;
        data.matches.clear();
        data.matches.addAll(fresh);
        data.teams.clear();
        data.teams.addAll(freshTeams);
        Collections.sort(data.teams);
        return fresh.size();
    }


    int sourceMatchday(JSONObject source){
        if(source==null)return 0;
        return Math.max(0,source.optInt("matchday",source.optInt("roundNumber",source.optInt("week",0))));
    }

    String sourceDateKey(JSONObject source){
        if(source==null)return "";
        String raw=source.optString("utcDate",source.optString("date",source.optString("time",""))).trim();
        return raw.length()>=10?raw.substring(0,10):"";
    }

    String storedDateKey(Match match){
        if(match==null||match.date==null)return "";
        String raw=match.date.trim();
        return raw.length()>=10?raw.substring(0,10):"";
    }

    String canonicalCompetitionKey(JSONObject source){
        if(source==null)return "";
        for(String competitionName:CompetitionCatalog.all().keySet()){
            if(jsonMatchBelongsToCompetition(source,competitionName)){
                String code=competitionApiCode(competitionName);
                if(code!=null&&!code.trim().isEmpty())return code.trim().toUpperCase(Locale.US);
                return competitionName.trim().toLowerCase(Locale.US);
            }
        }
        String raw=competitionNameFromJson(source);
        if(raw==null)return "";
        return java.text.Normalizer.normalize(raw.toLowerCase(Locale.US),java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]","");
    }

    String canonicalCompetitionKey(Match match){
        if(match==null)return "";
        for(String competitionName:CompetitionCatalog.all().keySet()){
            if(matchBelongsToCompetition(match,competitionName)){
                String code=competitionApiCode(competitionName);
                if(code!=null&&!code.trim().isEmpty())return code.trim().toUpperCase(Locale.US);
                return competitionName.trim().toLowerCase(Locale.US);
            }
        }
        String raw=match.competition==null?"":match.competition.trim();
        return java.text.Normalizer.normalize(raw.toLowerCase(Locale.US),java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]","");
    }

    Match findCentralMatchForJson(JSONObject source,String home,String away){
        int sourceRound=sourceMatchday(source);
        String sourceDay=sourceDateKey(source);
        String sourceCompetition=canonicalCompetitionKey(source);
        Match directFallback=null,reverseFallback=null;
        for(Match match:data.matches){
            boolean direct=sameTeam(match.home,home)&&sameTeam(match.away,away);
            boolean reverse=sameTeam(match.home,away)&&sameTeam(match.away,home);
            if(!direct&&!reverse)continue;

            // Competition identity is the first boundary. The same two clubs may
            // meet in league, cup and Europe, and those fixtures must never share
            // status, score or match details.
            if(sourceCompetition.length()>0){
                String matchCompetition=canonicalCompetitionKey(match);
                if(matchCompetition.length()==0||!sourceCompetition.equals(matchCompetition))continue;
            }

            if(sourceRound>0&&match.matchday==sourceRound)return match;
            if(sourceRound<=0&&sourceDay.length()>0&&sourceDay.equals(storedDateKey(match)))return match;
            if(direct&&directFallback==null)directFallback=match;
            if(reverse&&reverseFallback==null)reverseFallback=match;
        }
        String strictCompetition=competitionNameForCanonicalKey(sourceCompetition);
        if(directFallback!=null
                &&competitionHasUniqueHomeAwayPairPerSeason(strictCompetition)
                &&sourceDateIsInActiveCompetitionSeason(source,strictCompetition)
                &&teamBelongsToStrictCompetitionRoster(strictCompetition,home)
                &&teamBelongsToStrictCompetitionRoster(strictCompetition,away)){
            return directFallback;
        }
        if(sourceRound>0||sourceDay.length()>0)return null;
        // With no round/date metadata, only the same home/away orientation is
        // safe enough for legacy enrichment. A reversed pair is ambiguous and
        // must become a separate central fixture rather than being guessed.
        return directFallback;
    }

    final class CentralMatchIndex {
        final Map<Integer,Match> byApiId=new HashMap<Integer,Match>();
        final Map<String,Match> byRound=new HashMap<String,Match>();
        final Map<String,Match> byDay=new HashMap<String,Match>();
        final Map<String,Match> byPair=new HashMap<String,Match>();

        CentralMatchIndex(){
            if(data==null||data.matches==null)return;
            for(Match match:data.matches)add(match);
        }

        String key(String competition,String home,String away,String suffix){
            String c=competition==null?"":competition.trim();
            return c+"|"+teamKey(home)+">"+teamKey(away)+"|"+suffix;
        }

        void add(Match match){
            if(match==null)return;
            if(match.apiId>0&&!byApiId.containsKey(match.apiId))byApiId.put(match.apiId,match);
            String competition=canonicalCompetitionKey(match);
            if(competition.length()==0)return;
            String directPair=key(competition,match.home,match.away,"PAIR");
            if(!byPair.containsKey(directPair))byPair.put(directPair,match);
            if(match.matchday>0){
                String round="R:"+match.matchday;
                String direct=key(competition,match.home,match.away,round);
                String reverse=key(competition,match.away,match.home,round);
                if(!byRound.containsKey(direct))byRound.put(direct,match);
                if(!byRound.containsKey(reverse))byRound.put(reverse,match);
            }
            String day=storedDateKey(match);
            if(day.length()>0){
                String suffix="D:"+day;
                String direct=key(competition,match.home,match.away,suffix);
                String reverse=key(competition,match.away,match.home,suffix);
                if(!byDay.containsKey(direct))byDay.put(direct,match);
                if(!byDay.containsKey(reverse))byDay.put(reverse,match);
            }
        }

        Match find(JSONObject source,String home,String away){
            if(source==null)return null;
            int apiId=source.optInt("id",-1);
            if(apiId>0){
                Match byId=byApiId.get(apiId);
                if(byId!=null)return byId;
            }
            String competition=canonicalCompetitionKey(source);
            if(competition.length()==0)return findCentralMatchForJson(source,home,away);
            String competitionName=competitionNameForCanonicalKey(competition);
            if(competitionHasUniqueHomeAwayPairPerSeason(competitionName)
                    &&sourceDateIsInActiveCompetitionSeason(source,competitionName)
                    &&teamBelongsToStrictCompetitionRoster(competitionName,home)
                    &&teamBelongsToStrictCompetitionRoster(competitionName,away)){
                Match pair=byPair.get(key(competition,home,away,"PAIR"));
                if(pair!=null)return pair;
            }
            int round=sourceMatchday(source);
            if(round>0){
                Match match=byRound.get(key(competition,home,away,"R:"+round));
                if(match!=null)return match;
                // Explicit round metadata is fixture identity. Do not fall back
                // to team-pair guessing when the round is different.
                return null;
            }
            String day=sourceDateKey(source);
            if(day.length()>0){
                Match match=byDay.get(key(competition,home,away,"D:"+day));
                if(match!=null)return match;
                // Explicit date metadata is fixture identity too.
                return null;
            }
            return byPair.get(key(competition,home,away,"PAIR"));
        }
    }

    String matchSyncFingerprint(Match m){
        if(m==null)return "";
        return String.valueOf(m.apiId)+"|"+safeString(m.group)+"|"+safeString(m.date)+"|"+
                safeString(m.venue)+"|"+safeString(m.status)+"|"+safeString(m.minute)+"|"+
                safeString(m.competition)+"|"+m.matchday+"|"+m.homeGoals+"|"+m.awayGoals+"|"+
                safeString(m.roundName)+"|"+safeString(m.actualVenue)+"|"+m.attendance+"|"+
                safeString(m.eventsText)+"|"+safeString(m.statsText)+"|"+
                safeString(m.homeLineupText)+"|"+safeString(m.awayLineupText)+"|"+
                safeString(m.refereeText)+"|"+safeString(m.halfTimeScore)+"|"+
                safeString(m.extraTimeScore)+"|"+safeString(m.penaltyScore)+"|"+m.detailsAvailable;
    }

    String safeString(String value){return value==null?"":value;}

    int syncMatchesFromArray(JSONArray arr){
        if(arr==null||arr.length()==0)return 0;
        int changed=0;
        CentralMatchIndex index=new CentralMatchIndex();
        // WorldCupData intentionally exposes a CopyOnWriteArrayList so UI reads
        // remain snapshot-safe while background refreshes run. Adding thousands
        // of rows one-by-one would copy the whole backing array for every row;
        // collect new fixtures and append them in one atomic batch instead.
        ArrayList<Match> newMatches=new ArrayList<Match>();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null)continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0||away.length()==0)continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            if(jsonGroup.length()==0)jsonGroup=groupOfTeam(home);
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0)stage="Group stage";

            Match target=index.find(o,home,away);
            boolean isNew=target==null;
            if(isNew){
                target=new Match(jsonGroup,home,away,jsonDate,stage);
                newMatches.add(target);
            }
            String before=isNew?"":matchSyncFingerprint(target);

            if(jsonGroup.length()==1&&!safeString(target.group).equals(jsonGroup))target.group=jsonGroup;
            if(stage.length()>0&&!safeString(target.venue).equals(stage))target.venue=stage;
            if(jsonDate.length()>=10&&!safeString(target.date).equals(jsonDate))target.date=jsonDate;

            applyRoundMetadata(target,o);
            target.status=o.optString("status",target.status);
            target.minute=o.optString("minute",o.optString("matchMinute",target.minute));
            String incomingCompetition=competitionNameFromJson(o);
            if(incomingCompetition!=null&&!incomingCompetition.trim().isEmpty())target.competition=incomingCompetition;
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=safeString(target.status).toLowerCase(Locale.US);
            if(hg>=0&&ag>=0&&(isFinishedStatus(st)||isLiveStatus(st))){
                if(sameTeam(target.home,home)){target.homeGoals=hg;target.awayGoals=ag;}
                else{target.homeGoals=ag;target.awayGoals=hg;}
            }
            populateMatchDetails(target,o);

            if(isNew){
                changed++;
                index.add(target);
            }else if(!before.equals(matchSyncFingerprint(target))){
                changed++;
                // Add any newly learned date/round/api-id keys so later rows in
                // this same payload can find the updated central object in O(1).
                index.add(target);
            }
        }
        if(!newMatches.isEmpty())data.matches.addAll(newMatches);
        return changed;
    }

    int applyResultsFromArray(JSONArray arr, boolean forceFinished){
        if(arr==null) return 0;
        int applied=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=o.optString("status","").toLowerCase(Locale.US);
            boolean finalResult = forceFinished || isFinishedStatus(st);
            if(home.length()==0 || away.length()==0 || hg<0 || ag<0 || !finalResult) continue;
            Match matched=findCentralMatchForJson(o,home,away);
            boolean found=matched!=null;
            if(found){
                Match m=matched;
                if(sameTeam(m.home,home)){m.homeGoals=hg;m.awayGoals=ag;}else{m.homeGoals=ag;m.awayGoals=hg;}
                String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                if(jsonGroup.length()==1) m.group=jsonGroup;
                String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                if(stage.length()==0) stage="Group stage";
                if(stage.length()>0) m.venue=stage;
                String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                if(jsonDate.length()>=10) m.date=jsonDate;
                applyRoundMetadata(m,o);
                m.status=o.optString("status","FINISHED");
                m.minute=o.optString("minute",o.optString("matchMinute",""));
                m.competition=competitionNameFromJson(o);
                populateMatchDetails(m,o);
                applied++;
            }
            if(!found){
                String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                if(stage.length()==0) stage="Group stage";
                Match extra=new Match(jsonGroup,home,away,jsonDate,stage);
                applyRoundMetadata(extra,o);
                extra.status=o.optString("status","FINISHED");
                extra.minute=o.optString("minute",o.optString("matchMinute",""));
                extra.competition=competitionNameFromJson(o);
                extra.homeGoals=hg;
                extra.awayGoals=ag;
                populateMatchDetails(extra,o);
                data.matches.add(extra);
                applied++;
            }
        }
        return applied;
    }

    void applyRoundMetadata(Match match,JSONObject source){
        if(match==null||source==null)return;
        match.matchday=source.optInt("matchday",source.optInt("roundNumber",source.optInt("week",0)));
        String rawRound=source.optString("roundName",source.optString("matchdayName",source.optString("round",source.optString("stageName",source.optString("stage",""))))).trim();
        if(rawRound.equalsIgnoreCase("null"))rawRound="";
        String normalized=normalizeStage(rawRound);
        match.roundName=normalized.length()>0?normalized:rawRound;
        String canonical=normalizeStage(match.venue);
        if(canonical.length()>0&&match.roundName.length()==0)match.roundName=canonical;
        // A knockout-stage match must not retain a group letter inherited from
        // an older schedule row for the same teams.
        String stageForCheck=normalizeStage(match.roundName.length()>0?match.roundName:match.venue);
        if(stageForCheck.length()>0&&!stageForCheck.equalsIgnoreCase("Group stage"))match.group="";
    }

    String teamNameFromJson(JSONObject o, boolean home){
        String a=home?o.optString("home",""):o.optString("away","");
        if(a.length()>0) return a;
        JSONObject obj=home?o.optJSONObject("homeTeam"):o.optJSONObject("awayTeam");
        if(obj!=null){
            a=obj.optString("name",obj.optString("shortName",obj.optString("tla","")));
            if(a.length()>0) return a;
        }
        a=home?o.optString("homeTeam",""):o.optString("awayTeam","");
        if(a.length()>0 && !a.trim().startsWith("{")) return a;
        a=home?o.optString("home_name",""):o.optString("away_name","");
        if(a.length()>0) return a;
        return "";
    }


    String competitionNameFromJson(JSONObject o){
        if(o==null) return "";
        String c=o.optString("competitionName",o.optString("competition",""));
        if(c!=null && c.length()>0 && !c.trim().startsWith("{")) return c;
        JSONObject competition=o.optJSONObject("competition");
        if(competition!=null) return competition.optString("name",competition.optString("code",""));
        return "";
    }


    int jsonHomeGoals(JSONObject o){ return jsonGoals(o,true); }

    int jsonAwayGoals(JSONObject o){ return jsonGoals(o,false); }

    int jsonGoals(JSONObject o,boolean home){
        if(o==null)return -1;
        String[] direct=home?new String[]{"homeGoals","homeScore","home_score","scoreHome","goalsHome"}:new String[]{"awayGoals","awayScore","away_score","scoreAway","goalsAway"};
        for(String key:direct){int value=jsonIntValue(o,key);if(value>=0)return value;}
        String side=home?"home":"away";
        String[] containers={"score","scores","result","current","live"};
        for(String container:containers){
            JSONObject nested=o.optJSONObject(container);if(nested==null)continue;
            int value=jsonIntValue(nested,side);if(value>=0)return value;
            value=jsonIntValue(nested,home?"homeScore":"awayScore");if(value>=0)return value;
            value=jsonIntValue(nested,home?"homeGoals":"awayGoals");if(value>=0)return value;
            String[] periods={"fullTime","regularTime","current","total","normalTime"};
            for(String period:periods){JSONObject periodObj=nested.optJSONObject(period);if(periodObj==null)continue;value=jsonIntValue(periodObj,side);if(value>=0)return value;}
        }
        String[] textKeys={"score","result","currentScore","displayScore"};
        for(String key:textKeys){String text=o.optString(key,"");int[] pair=parseScorePair(text);if(pair!=null)return home?pair[0]:pair[1];}
        return -1;
    }

    int jsonIntValue(JSONObject object,String key){
        if(object==null||!object.has(key)||object.isNull(key))return -1;
        Object raw=object.opt(key);
        if(raw instanceof Number)return ((Number)raw).intValue();
        try{String value=String.valueOf(raw).trim();if(value.length()==0)return -1;int dot=value.indexOf('.');if(dot>0)value=value.substring(0,dot);return Integer.parseInt(value);}catch(Exception ignored){return -1;}
    }

    int[] parseScorePair(String text){
        if(text==null)return null;String normalized=text.trim().replace('–','-').replace('—','-').replace(':','-');
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("(?<!\\d)(\\d{1,2})\\s*-\\s*(\\d{1,2})(?!\\d)").matcher(normalized);
        if(!matcher.find())return null;
        try{return new int[]{Integer.parseInt(matcher.group(1)),Integer.parseInt(matcher.group(2))};}catch(Exception ignored){return null;}
    }

    String cleanGroup(String g){
        if(g==null) return "";
        g=g.trim();
        if(g.length()==0 || g.equalsIgnoreCase("null") || g.equals("?")) return "";
        if(g.startsWith("GROUP_")) g=g.substring(6);
        if(g.startsWith("Group ")) g=g.substring(6);
        if(g.equals("GROUP_STAGE") || g.equalsIgnoreCase("Group stage")) return "";
        return isGroupLetter(g)?g:"";
    }

    String cleanDate(String d){
        if(d==null) return "";
        d=d.trim();
        if(d.length()==0) return "";
        // API utcDate example: 2026-06-26T19:00:00Z -> 2026-06-26 19:00 UTC
        if(d.contains("T")){
            try{
                String x=d.replace("T"," ").replace("Z","");
                if(x.length()>=16) return x.substring(0,16)+" UTC";
            }catch(Exception ignored){}
        }
        return d;
    }

    String tournamentDateLine(){
        String last=prefs.getString("online_lastUpdate","");
        String local=displayLocalDateTime(last);
        String date=(local!=null && local.length()>=10)?local.substring(0,10):"";
        if(date.length()==0) date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        try{
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);
            String pretty=new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(d);
            return t2("Live data • updated "+pretty, "Podaci uživo • ažurirano "+pretty, "Live-Daten • aktualisiert "+pretty, "Datos en vivo • actualizado "+pretty, "Données en direct • mis à jour "+pretty);
        }catch(Exception e){
            return t2("Live tournament data", "Podaci prvenstva uživo", "Live-Turnierdaten", "Datos del torneo en vivo", "Données du tournoi en direct");
        }
    }

    String formatMatchFeed(JSONArray arr){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            if(sb.length()>0) sb.append("\n");
            sb.append(formatOneMatch(o,false));
        }
        return sb.toString();
    }

    String formatOneMatch(JSONObject o, boolean noScore){
        String home=teamNameFromJson(o,true);
        String away=teamNameFromJson(o,false);
        String group=cleanGroup(o.optString("group",o.optString("stage","")));
        String date=displayLocalDateTime(cleanDate(o.optString("date",o.optString("time",o.optString("utcDate","")))));
        String status=o.optString("status","");
        String minute=o.optString("minute",o.optString("matchMinute",""));
        int hg=jsonHomeGoals(o);
        int ag=jsonAwayGoals(o);
        String st=status.toLowerCase(Locale.US);
        boolean live=isLiveStatus(st);
        boolean hasVerifiedScore=hg>=0&&ag>=0;
        boolean finished=isFinishedStatus(st)&&hasVerifiedScore;
        boolean resultUnavailable=MatchStatus.isResultUnavailable(st)||(isFinishedStatus(st)&&!hasVerifiedScore);
        StringBuilder sb=new StringBuilder();

        if(live) sb.append(liveLabelFromJson(status, minute));
        else if(finished) sb.append("✅ ").append(t2("FT","KRAJ","ENDE","FINAL","FIN"));
        else if(resultUnavailable) sb.append("⚪ ").append(t2("NO RESULT","BEZ REZULTATA","OHNE ERGEBNIS","SIN RESULTADO","SANS RÉSULTAT"));
        else if(noScore || isUpcomingStatus(st)) sb.append("📅");

        if(!live && minute!=null && minute.trim().length()>0){
            if(sb.length()>0) sb.append(" ");
            sb.append(minute.trim());
        }
        if(date.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(date);
        }
        String phase=group.length()>0?("Group "+group):normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName",""))));
        if(phase.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(phase);
        }
        if(sb.length()>0) sb.append(" • ");
        sb.append(flag(home)).append(" ").append(home);
        if(!noScore && hg>=0 && ag>=0) sb.append(" ").append(hg).append(" - ").append(ag).append(" ");
        else sb.append(" vs ");
        sb.append(flag(away)).append(" ").append(away);
        return sb.toString();
    }


    String formatRanking(JSONArray arr,String valueKey){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        boolean isMvp=valueKey!=null && valueKey.equals("points");
        String[] medal={"🥇 ","🥈 ","🥉 ","4️⃣ ","5️⃣ "};
        for(int i=0;i<arr.length() && i<5;i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String name=o.optString("name",o.optString("player",""));
            String team=o.optString("team","");
            String value=o.has(valueKey)?String.valueOf(o.opt(valueKey)):"";
            if(name.length()==0) continue;
            if(isMvp){
                sb.append(medal[i]).append(name);
            }else{
                sb.append(i+1).append(". ").append(name);
            }
            if(team.length()>0) sb.append(" • ").append(flag(team)).append(" ").append(team);
            if(value.length()>0) sb.append(" • ").append(value);
            if(valueKey.equals("goals") && value.length()>0) sb.append(" goals");
            if(valueKey.equals("points") && value.length()>0) sb.append(" pts");
            sb.append("\n");
        }
        return sb.toString().trim();
    }

void showPredictor(){
        clear(tr("Predict"),tr("Prediction Studio"),"Predict");
        LinearLayout c=card();c.addView(label("🔮 "+tr("Prediction Studio"),25,text,true));c.addView(label("Scores → tables → best thirds → bracket → champion → share poster.",15,subText,false));
        Button s=btn(tr("Enter Scores"));s.setOnClickListener(v->showMatches());c.addView(s);Button br=btn(tr("Pro Bracket"));br.setOnClickListener(v->showKnockout());c.addView(br);Button poster=btn(tr("Share Poster"));poster.setOnClickListener(v->showPoster());c.addView(poster);Button df=btn(tr("Dream Final"));df.setOnClickListener(v->showDreamFinal());c.addView(df);
        LinearLayout q=card();q.addView(label("✅ Qualified teams preview",22,text,true));List<TeamRow> qual=data.qualified();for(int i=0;i<Math.min(qual.size(),16);i++){TeamRow r=qual.get(i);q.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,subText,false));}
    }

    String bracketTeam(ArrayList<String> q,int index){if(q==null||q.size()==0)return "TBD";return q.get(index%q.size());}


    ArrayList<String[]> bracketPairs(){
        ArrayList<String> q=new ArrayList<>();
        for(TeamRow r:data.qualified())q.add(r.team);
        if(q.size()<32){
            for(String t:data.teams){ if(!q.contains(t)) q.add(t); if(q.size()>=32)break; }
        }
        ArrayList<String[]> pairs=new ArrayList<>();
        for(int i=0;i<16;i++)pairs.add(new String[]{bracketTeam(q,i*2),bracketTeam(q,i*2+1)});
        return pairs;
    }
    void addBracketPair(LinearLayout parent,String a,String b,boolean withPlaceholder){
        LinearLayout box=inner(parent);
        box.addView(label(flag(a)+" "+a,16,text,true));
        if(withPlaceholder)box.addView(label("        "+tr("Winner")+": —",14,subText,false));
        else box.addView(label("        │",12,subText,false));
        box.addView(label(flag(b)+" "+b,16,text,true));
    }
    void addVisualPair(LinearLayout parent,String a,String b){
        LinearLayout box=inner(parent);
        box.addView(label("┌ "+flag(a)+" "+a,16,text,false));
        box.addView(label("├─ VS",16,subText,false));
        box.addView(label("└ "+flag(b)+" "+b,16,text,false));
    }
void showKnockout(){
        clear(tr("Pro Bracket"),tr("Round of 32")+" → "+tr("Final"),"Predict");
        LinearLayout intro=card();
        intro.setBackground(gradient(RED_DARK,RED,dp(24)));
        intro.addView(label("🏆 "+tr("Pro Bracket"),26,Color.WHITE,true));
        intro.addView(label(tr("Projected path from your group results."),15,Color.WHITE,false));
        LinearLayout c=card();
        c.addView(label(tr("Round of 32"),23,RED,true));
        for(String[] p:bracketPairs())addBracketPair(c,p[0],p[1],true);
    }
    LinearLayout inner(LinearLayout p){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(12),dp(10),dp(12),dp(10));l.setBackground(round(chipBg,dp(18),0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));p.addView(l,lp);return l;}
    String winner(String a,String b){if(a.equals(myTeam))return a;if(b.equals(myTeam))return b;return a.compareTo(b)<=0?a:b;}

    void showPoster(){
        clear(tr("Share Poster"),"Social prediction card","Predict");
        LinearLayout p=card();p.setBackground(gradient(RED_DARK,RED,dp(24)));p.addView(label("FOOTBALL FUN",25,Color.WHITE,true));p.addView(label("MY TOURNAMENT PREDICTION",17,Color.WHITE,false));p.addView(label(flag(myTeam)+" "+tr("My Team")+": "+myTeam,22,Color.WHITE,true));List<TeamRow> q=data.qualified();String champ=q.size()>0?q.get(0).team:myTeam;p.addView(label("🏆 Champion: "+flag(champ)+" "+champ,25,GOLD,true));p.addView(label("Top 4\n"+topLines(4),16,Color.WHITE,false));p.addView(label("Made with Football Fun",13,Color.WHITE,false));Button share=btn(tr("Share Poster"));share.setOnClickListener(v->sharePrediction());p.addView(share);
    }
    String topLines(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++)s+=(i+1)+". "+flag(q.get(i).team)+" "+q.get(i).team+"\n";return s.length()==0?"TBD":s;}
    String topInline(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++){if(i>0)s+=" • ";s+=flag(q.get(i).team)+" "+q.get(i).team;}return s.length()==0?"TBD":s;}

    void showDreamFinal(){clear(tr("Dream Final"),"Build a fan final","Predict");LinearLayout c=card();c.addView(label("🏆 "+tr("Dream Final"),25,text,true));Spinner left=spinner(data.teams,myTeam), right=spinner(data.teams,"Brazil");c.addView(label("Finalist 1",13,subText,true));c.addView(left);c.addView(label("Finalist 2",13,subText,true));c.addView(right);Button share=btn(tr("Share Poster"));share.setOnClickListener(v->{String a=left.getSelectedItem().toString(),b=right.getSelectedItem().toString();shareText("🏆 Dream Final 2026\n\n"+flag(a)+" "+a+" vs "+flag(b)+" "+b+"\n\nFootball Fun");});c.addView(share);}
    Spinner spinner(ArrayList<String> items,String sel){Spinner sp=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);sp.setAdapter(ad);int pos=items.indexOf(sel);if(pos>=0)sp.setSelection(pos);return sp;}

    void showMyTeam(){
        if(!requirePro(t2("National team personalization","Personalizacija reprezentacije","Nationalteam-Personalisierung","Personalización de selección","Personnalisation de l’équipe")))return;
        clear(tr("My Team"),"Team hub","More");
        LinearLayout c=card();
        c.addView(label(flag(myTeam)+" "+myTeam,28,RED,true));
        Spinner sp=spinner(data.teams,myTeam);
        c.addView(sp);
        Button save=btn(t2("Save as main national team","Spremi kao glavnu reprezentaciju","Als Hauptnationalteam speichern","Guardar como selección principal","Enregistrer comme équipe principale"));
        save.setOnClickListener(v->{myTeam = sp.getSelectedItem().toString(); favoriteNationalTeams.add(myTeam); userPreferences.saveNationalTeam(myTeam); userPreferences.saveFavoriteNationalTeams(favoriteNationalTeams); syncMatchRemindersAsync(); toast(t2("National team saved","Reprezentacija spremljena","Nationalteam gespeichert","Selección guardada","Équipe enregistrée")); showHome();});
        c.addView(save);
        Button addFavorite=outline("☆ "+t2("Add to favorite national teams","Dodaj u omiljene reprezentacije","Zu Lieblingsnationalteams","Añadir a selecciones favoritas","Ajouter aux équipes favorites"));
        addFavorite.setOnClickListener(v->{String selected=sp.getSelectedItem().toString();favoriteNationalTeams.add(selected);userPreferences.saveFavoriteNationalTeams(favoriteNationalTeams);toast(t2("Added to favorites","Dodano u favorite","Zu Favoriten hinzugefügt","Añadido a favoritos","Ajouté aux favoris"));showMyTeam();});c.addView(addFavorite);
        if(!favoriteNationalTeams.isEmpty()){
            LinearLayout favorites=card();favorites.addView(label("🌍 "+t2("Favorite national teams","Omiljene reprezentacije","Lieblingsnationalteams","Selecciones favoritas","Équipes nationales favorites"),20,text,true));
            for(String team:new ArrayList<String>(favoriteNationalTeams)){final String selected=team;LinearLayout row=hrow();TextView name=label(flag(team)+" "+displayTeamName(team),15,text,true);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));Button remove=outline("×");remove.setOnClickListener(v->{favoriteNationalTeams.remove(selected);if(sameTeam(myTeam,selected)){myTeam=favoriteNationalTeams.isEmpty()?"":favoriteNationalTeams.iterator().next();userPreferences.saveNationalTeam(myTeam);}userPreferences.saveFavoriteNationalTeams(favoriteNationalTeams);syncMatchRemindersAsync();showMyTeam();});row.addView(remove,new LinearLayout.LayoutParams(dp(48),dp(42)));favorites.addView(row);}
        }

        LinearLayout path=card();
        path.addView(label("Road to Final",22,text,true));
        path.addView(pathPreview(myTeam));

        LinearLayout m=card();
        m.addView(label("⚽ "+tr("Matches"),22,text,true));
        int shown=0;
        for(Match ma:data.matches){
            if(sameTeam(ma.home,myTeam)||sameTeam(ma.away,myTeam)){
                m.addView(label(myTeamMatchLine(ma),14,subText,false));
                shown++;
            }
        }
        if(shown==0)m.addView(label("No matches found for "+myTeam,14,subText,false));
    }

    String myTeamMatchLine(Match ma){
        String date=myTeamDisplayDate(ma.date);
        String score=(ma.homeGoals>=0 && ma.awayGoals>=0)?(" "+ma.homeGoals+" - "+ma.awayGoals+" "):" vs ";
        String status=(ma.homeGoals>=0 && ma.awayGoals>=0)?("✅ "+t2("FT","KRAJ","ENDE","FINAL","FIN")+" • "):"📅 ";
        StringBuilder sb=new StringBuilder();
        sb.append(status);
        if(date.length()>0)sb.append(date).append(" • ");
        String phase=stageLabel(ma);
        if(phase.length()>0)sb.append(phase).append(" • ");
        sb.append(flag(ma.home)).append(" ").append(ma.home).append(score).append(flag(ma.away)).append(" ").append(ma.away);
        return sb.toString();
    }

    String myTeamDisplayDate(String raw){
        if(raw==null)return "";
        String d=raw.trim();
        if(d.length()==0)return "";
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC");
        d=d.replace("UTC","").trim();
        if(d.length()<16)return d;
        return displayLocalDateTime(raw);
    }

    String displayLocalDateTime(String raw){
        if(raw==null)return "";
        String key=raw.trim();
        if(key.length()==0)return "";
        String hit=localDisplayDateCache.get(key);
        if(hit!=null)return hit;
        String d=key;
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC") || d.endsWith("Z");
        d=d.replace("UTC","").replace("Z","").trim();
        String result=d;
        if(d.length()>=16&&hasUtc){
            try{
                SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
                in.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date parsed=in.parse(d.substring(0,16));
                SimpleDateFormat out=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
                out.setTimeZone(TimeZone.getDefault());
                result=out.format(parsed);
            }catch(Exception ignored){result=d;}
        }
        localDisplayDateCache.put(key,result);
        return result;
    }
    void showCities(){clear(tr("Host Cities"),"USA • Mexico • Canada","More");String[][] cities={{"🇲🇽 Mexico City","Opening match energy and historic football culture."},{"🇨🇦 Toronto","Canada showcase city."},{"🇺🇸 Los Angeles","Entertainment capital and massive fan base."},{"🇺🇸 New York/New Jersey","Final atmosphere and huge global audience."},{"🇺🇸 Dallas","Huge stadium, huge matches."},{"🇺🇸 Miami","Latin football culture."},{"🇨🇦 Vancouver","West coast Canadian host."},{"🇺🇸 Atlanta","Modern stadium and fan festival city."},{"🇺🇸 Houston","International city."},{"🇺🇸 Kansas City","American soccer heartland."},{"🇺🇸 Boston","Historic sports city."},{"🇺🇸 Seattle","Strong supporter culture."}};for(String[] ci:cities){LinearLayout c=card();c.addView(label(ci[0],22,text,true));c.addView(label(ci[1],15,subText,false));}}

    
    void showVisualBracket(){
        clear(tr("Visual Bracket"),tr("Tournament tree preview"),"More");
        LinearLayout c=card();
        c.addView(label("🏆 "+tr("Round of 32"),24,RED,true));
        for(String[] p:bracketPairs())addVisualPair(c,p[0],p[1]);
    }

    String projectedWinner(String a, String b) {
        if (a.equals(myTeam)) return a;
        if (b.equals(myTeam)) return b;
        int aa = teamPower(a), bb = teamPower(b);
        if (aa == bb) return a.compareTo(b) <= 0 ? a : b;
        return aa > bb ? a : b;
    }

    int teamPower(String t) {
        String elite = "Brazil Argentina France England Spain Germany Portugal Netherlands Belgium Croatia";
        String strong = "Uruguay Colombia Morocco Switzerland Denmark USA Mexico Japan Senegal";
        if (elite.contains(t)) return 90;
        if (strong.contains(t)) return 78;
        return 65;
    }

    void showScorers(){
        clear(tr("Golden Boot"),tr("Top scorers prediction"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.addView(label("🏆 Top Scorers 2026",25,text,true));
        c.addView(label(scorersIntro(),15,subText,false));
        String gb=prefs.getString("online_goldenBoot","");
        if(gb!=null && gb.trim().length()>0){
            c.addView(label(gb,15,subText,false));
            return;
        }
        String[][] scorers={
            {"Kylian Mbappé","France","7"},
            {"Harry Kane","England","6"},
            {"Lionel Messi","Argentina","5"},
            {"Vinícius Jr","Brazil","5"},
            {"Cristiano Ronaldo","Portugal","4"},
            {"Luka Modrić","Croatia","3"},
            {"Erling Haaland","Norway","3"},
            {"Mohamed Salah","Egypt","3"}
        };
        for(int i=0;i<scorers.length;i++){
            String[] s=scorers[i];
            c.addView(label((i+1)+". "+s[0]+" • "+flag(s[1])+" "+s[1]+" • "+s[2]+" "+tr("goals"),15,i<3?RED:subText,i<3));
        }
    }

    void showMvp(){
        clear(tr("MVP Prediction"),tr("Player of the tournament"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.setBackground(gradient(RED_DARK,RED,dp(24)));
        c.addView(label("⭐ "+tr("MVP Prediction"),26,Color.WHITE,true));
        c.addView(label(flag(myTeam)+" "+myTeam+" MVP Candidate",23,GOLD,true));
        c.addView(label(mvpIntro(),15,Color.WHITE,false));
        LinearLayout list=card();
        list.addView(label("🏆 MVP Power Ranking",22,text,true));
        String mv=prefs.getString("online_mvp","");
        if(mv!=null && mv.trim().length()>0){
            list.addView(label(mv,15,subText,false));
        }else{
            list.addView(label("🥇 "+flag(myTeam)+" "+myTeam+" Leader\n🥈 🇫🇷 France Star\n🥉 🇧🇷 Brazil Star\n4️⃣ 🇬🇧 England Star\n5️⃣ 🇦🇷 Argentina Star",15,subText,false));
        }
    }

    void showCompareTeams() {
        clear(tr("Compare Teams"), tr("Team vs Team"), "More");
        LinearLayout c = card();
        c.addView(label("⚔️ " + tr("Compare Teams"), 25, text, true));
        Spinner a = spinner(data.teams, myTeam);
        Spinner b = spinner(data.teams, "Brazil");
        c.addView(label("Team A", 13, subText, true)); c.addView(a);
        c.addView(label("Team B", 13, subText, true)); c.addView(b);
        Button compare = btn(tr("Compare Teams"));
        compare.setOnClickListener(v -> {
            String ta = a.getSelectedItem().toString();
            String tb = b.getSelectedItem().toString();
            showCompareResult(ta, tb);
        });
        c.addView(compare);
    }

    void showCompareResult(String a, String b) {
        clear("Compare", a + " vs " + b, "More");
        LinearLayout c = card();
        c.addView(label(flag(a) + " " + a + " vs " + flag(b) + " " + b, 22, text, true));
        int pa = teamPower(a), pb = teamPower(b);
        c.addView(label(a + " power: " + pa, 17, pa>=pb?GREEN:subText, true));
        c.addView(label(b + " power: " + pb, 17, pb>=pa?GREEN:subText, true));
        String pick = projectedWinner(a,b);
        c.addView(label("Projected winner: " + flag(pick) + " " + pick, 20, RED, true));
    }

    void showBackupExport() {
        clear(tr("Export Backup"), tr("Export / Import prediction"), "More");
        LinearLayout c = card();
        c.addView(label("💾 " + tr("Export Backup"), 24, text, true));
        c.addView(label("Export code lets fans save or send their prediction. Import can be added later when we move the app from MVP to full account-free backup.", 15, subText, false));
        Button export = btn("Share Backup Code");
        export.setOnClickListener(v -> shareText(buildBackupCode()));
        c.addView(export);
    }

    String buildBackupCode() {
        String code = "WCF2026|" + myTeam + "|" + displayPlayedCount() + "|" + displayTotalGoals() + "|" + displayProgressPercent();
        return "Football Fun backup code:\n\n" + code + "\n\nSave this text for later.";
    }

    void showPdfPosterInfo() {
        clear(tr("PDF Poster Info"), tr("Printable prediction poster"), "More");
        LinearLayout c = card();
        c.addView(label("🖨️ " + tr("PDF Poster Info"), 24, text, true));
        c.addView(label("The app already has the poster layout. Next technical step is Android PDF export. For now, Share Poster creates a clean shareable prediction text/card.", 15, subText, false));
        Button open = btn("Open Share Poster");
        open.setOnClickListener(v -> showPoster());
        c.addView(open);
    }

    void showQuiz() {
        clear(tr("World Cup Quiz"), tr("Fan challenge"), "More");
        LinearLayout c = card();
        c.addView(label("🧠 " + tr("World Cup Quiz"), 25, text, true));
        final int[] score = new int[]{0};
        final int[] answered = new int[]{0};
        TextView scoreView = label(tr("Score") + ": 0/5", 18, RED, true);
        c.addView(scoreView);
        String[][] qa = {
            {"How many teams play in 2026?","48","32","36","40"},
            {"How many groups are there?","12","8","10","16"},
            {"How many teams are in each group?","4","3","5","6"},
            {"Which group is Croatia in?","L","A","D","H"},
            {"How many third-placed teams go through?","8","4","6","12"}
        };
        for (String[] q : qa) {
            LinearLayout box = inner(c);
            box.addView(label("❓ " + q[0], 16, text, true));
            ArrayList<String> opts = new ArrayList<>();
            opts.add(q[1]); opts.add(q[2]); opts.add(q[3]); opts.add(q[4]);
            Collections.shuffle(opts);
            final boolean[] done = new boolean[]{false};
            TextView result = label("", 14, subText, true);
            for(String opt:opts){
                Button b=outline(opt);
                b.setOnClickListener(v->{
                    if(done[0])return;
                    done[0]=true; answered[0]++;
                    if(((Button)v).getText().toString().equals(q[1])){score[0]++; result.setText("✅ "+tr("Correct")); result.setTextColor(GREEN);} 
                    else {result.setText("❌ "+tr("Wrong")+" • "+q[1]); result.setTextColor(RED);} 
                    scoreView.setText(tr("Score")+": "+score[0]+"/5");
                });
                box.addView(b);
            }
            box.addView(result);
        }
        Button again=btn(tr("Try again")); again.setOnClickListener(v->showQuiz()); c.addView(again);
    }

    void showStadiumGuide() {
        clear(tr("Stadium Guide"), tr("Host stadium notes"), "More");
        String[][] stadiums = {
            {"Azteca Stadium","Mexico City • iconic opening venue"},
            {"MetLife Stadium","New York/New Jersey • final-level stadium"},
            {"AT&T Stadium","Dallas • huge capacity"},
            {"SoFi Stadium","Los Angeles • modern showpiece"},
            {"Hard Rock Stadium","Miami • global fan city"},
            {"BC Place","Vancouver • Canadian west coast"}
        };
        for (String[] s : stadiums) {
            LinearLayout c = card();
            c.addView(label("🏟️ " + s[0], 22, text, true));
            c.addView(label(s[1], 15, subText, false));
        }
    }

    void showCityGuidePro() {
        clear(tr("City Guide Pro"), tr("Fan travel notes"), "More");
        String[][] cities = {
            {"Mexico City","Opening energy, football history, altitude factor."},
            {"Los Angeles","Entertainment, big stadium, global fan base."},
            {"New York/New Jersey","Final atmosphere and media center."},
            {"Dallas","Massive stadium and high-scoring indoor-style matches."},
            {"Miami","Latin football culture and beach city vibe."},
            {"Toronto","Canada showcase and multicultural fan base."}
        };
        for (String[] city : cities) {
            LinearLayout c = card();
            c.addView(label("🌎 " + city[0], 22, text, true));
            c.addView(label(city[1], 15, subText, false));
        }
    }

    void showAchievements() {
        clear(tr("Achievements"), tr("Badges and milestones"), "More");
        LinearLayout c = card();
        c.addView(label("🏅 " + tr("Achievements"), 25, text, true));
        int played = displayPlayedCount();
        c.addView(label((played>=1?"✅":"⬜") + " First Prediction", 17, played>=1?GREEN:subText, true));
        c.addView(label((played>=10?"✅":"⬜") + " Group Stage Analyst", 17, played>=10?GREEN:subText, true));
        c.addView(label((played>=24?"✅":"⬜") + " Tournament Expert", 17, played>=24?GREEN:subText, true));
        c.addView(label((displayProgressPercent()>=100?"✅":"⬜") + " Prediction Master", 17, displayProgressPercent()>=100?GOLD:subText, true));
        c.addView(label("My Team badge: " + flag(myTeam) + " " + myTeam + " Fan", 17, RED, true));
    }


    void showHostCityDetails(){
        clear(tr("Host Cities"),tr("16 host cities"),"More");
        String[][] cities={
            {"🇺🇸 Atlanta","Atlanta Stadium","United States","71,000","8","Modern host city, huge airport hub and strong sports culture.","Moderan grad domaćin, veliki zračni čvor i jaka sportska kultura.","Moderner Gastgeber, großer Flughafen-Hub und starke Sportkultur.","Ciudad moderna, gran aeropuerto y fuerte cultura deportiva.","Ville moderne, grand hub aérien et forte culture sportive."},
            {"🇺🇸 Boston","Boston Stadium","United States","65,000","7","Historic sports market with passionate East Coast fans.","Povijesni sportski grad s vatrenim navijačima istočne obale.","Historischer Sportmarkt mit leidenschaftlichen Fans der Ostküste.","Ciudad deportiva histórica con aficionados apasionados.","Marché sportif historique avec fans passionnés."},
            {"🇨🇦 Toronto","Toronto Stadium","Canada","45,000","6","Canada's biggest city and a multicultural football hub.","Najveći kanadski grad i multikulturalno nogometno središte.","Kanadas größte Stadt und multikulturelles Fußballzentrum.","La ciudad más grande de Canadá y centro multicultural del fútbol.","Plus grande ville du Canada et hub football multiculturel."},
            {"🇺🇸 Dallas","Dallas Stadium","United States","80,000","9","One of the biggest venues of the tournament.","Jedan od najvećih stadiona turnira.","Eine der größten Spielstätten des Turniers.","Una de las sedes más grandes del torneo.","L'une des plus grandes enceintes du tournoi."},
            {"🇲🇽 Guadalajara","Guadalajara Stadium","Mexico","49,000","4","Classic Mexican football city with deep local culture.","Klasični meksički nogometni grad s jakom lokalnom kulturom.","Klassische mexikanische Fußballstadt mit tiefer lokaler Kultur.","Ciudad clásica del fútbol mexicano con gran cultura local.","Ville classique du football mexicain avec forte culture locale."},
            {"🇺🇸 Houston","Houston Stadium","United States","72,000","7","Diverse global city with strong Latin football energy.","Raznolik globalni grad s jakom latino nogometnom energijom.","Vielfältige Weltstadt mit starker lateinamerikanischer Fußballenergie.","Ciudad global diversa con fuerte energía futbolera latina.","Ville mondiale diverse avec forte énergie football latino."},
            {"🇺🇸 Kansas City","Kansas City Stadium","United States","76,000","6","Known for loud crowds and supporter culture.","Poznat po glasnim navijačima i jakoj navijačkoj kulturi.","Bekannt für laute Fans und starke Supporter-Kultur.","Conocida por su afición ruidosa y cultura de seguidores.","Connue pour ses foules bruyantes et sa culture supporters."},
            {"🇺🇸 Los Angeles","Los Angeles Stadium","United States","70,000","8","Entertainment capital and premium stadium destination.","Prijestolnica zabave i premium stadionska destinacija.","Entertainment-Hauptstadt und Premium-Stadionziel.","Capital del entretenimiento y sede premium.","Capitale du divertissement et destination stade premium."},
            {"🇺🇸 Miami","Miami Stadium","United States","65,000","7","Beach city, Latin football culture and fan travel appeal.","Grad plaža, latino nogometne kulture i velika navijačka destinacija.","Strandstadt mit lateinamerikanischer Fußballkultur.","Ciudad de playa, cultura latina y gran atractivo para fans.","Ville de plage, culture football latino et forte attractivité fans."},
            {"🇲🇽 Mexico City","Mexico City Stadium","Mexico","87,000","5","Opening-match atmosphere and iconic football history.","Atmosfera utakmice otvaranja i legendarna nogometna povijest.","Eröffnungsspiel-Atmosphäre und ikonische Fußballgeschichte.","Ambiente inaugural e historia futbolística icónica.","Ambiance d'ouverture et histoire football iconique."},
            {"🇲🇽 Monterrey","Monterrey Stadium","Mexico","53,000","4","Modern stadium and intense football culture.","Moderan stadion i intenzivna nogometna kultura.","Modernes Stadion und intensive Fußballkultur.","Estadio moderno y cultura futbolera intensa.","Stade moderne et culture football intense."},
            {"🇺🇸 New York/New Jersey","New York/New Jersey Stadium","United States","82,500","8","Global media capital and final-stage atmosphere.","Globalna medijska prijestolnica i atmosfera završnice.","Globale Medienhauptstadt und Final-Atmosphäre.","Capital mediática global y ambiente de final.","Capitale médiatique mondiale et ambiance de finale."},
            {"🇺🇸 Philadelphia","Philadelphia Stadium","United States","69,000","6","Historic city with passionate sports fans.","Povijesni grad s vrlo strastvenim sportskim navijačima.","Historische Stadt mit leidenschaftlichen Sportfans.","Ciudad histórica con aficionados deportivos intensos.","Ville historique avec fans de sport passionnés."},
            {"🇺🇸 San Francisco Bay Area","Bay Area Stadium","United States","68,500","6","Tech-region host with strong tourism appeal.","Domaćin iz tehnološke regije s velikim turističkim potencijalom.","Tech-Region mit starker touristischer Anziehung.","Región tecnológica con gran atractivo turístico.","Région tech avec fort attrait touristique."},
            {"🇺🇸 Seattle","Seattle Stadium","United States","69,000","6","One of the strongest U.S. soccer cultures.","Jedna od najjačih nogometnih kultura u SAD-u.","Eine der stärksten Fußballkulturen der USA.","Una de las culturas futboleras más fuertes de EE.UU.","Une des plus fortes cultures soccer des États-Unis."},
            {"🇨🇦 Vancouver","Vancouver Stadium","Canada","54,500","7","Beautiful west-coast host city with tourism appeal.","Prekrasan grad domaćin na zapadnoj obali s jakim turizmom.","Schöne Gastgeberstadt an der Westküste mit Tourismus-Reiz.","Hermosa ciudad de la costa oeste con atractivo turístico.","Belle ville hôte de la côte ouest avec attrait touristique."}
        };
        for(String[] x:cities){
            LinearLayout c=card();
            c.addView(label(x[0],23,text,true));
            c.addView(label("🏟️ "+x[1],16,RED,true));
            c.addView(label(tr("Country")+": "+x[2]+"  •  "+tr("Capacity")+": "+x[3]+"  •  "+tr("Matches count")+": "+x[4],14,subText,false));
            c.addView(label(cityDesc(x[5],x[6],x[7],x[8],x[9]),15,subText,false));
        }
    }

    void showTeamHubPro() {
        clear("Team Hub Pro", "Detailed national team view", "More");
        LinearLayout top=card();
        top.addView(label(flag(myTeam)+" "+myTeam,30,RED,true));
        top.addView(label("Group "+groupOfTeam(myTeam)+" • saved My Team • Road to Final ready",16,subText,false));
        top.addView(label("Power rating: "+teamPower(myTeam)+"/100",18,GREEN,true));
        LinearLayout games=card();
        games.addView(label("⚽ Matches",23,text,true));
        for(Match m:data.matches){
            if(m.home.equals(myTeam)||m.away.equals(myTeam)){
                games.addView(label(displayLocalDateTime(m.date)+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away+" • "+m.venue,14,subText,false));
            }
        }
        LinearLayout notes=card();
        notes.addView(label("🔎 Fan notes",22,text,true));
        notes.addView(label("Use this screen later for squad, coach, form, star player and qualification story. It is now ready as the Team Hub base.",15,subText,false));
    }

    void showOnboardingPreview() {
        clear("Onboarding", "First launch preview", "More");
        LinearLayout a=card(); a.setBackground(gradient(RED_DARK, RED, dp(24)));
        a.addView(label("1/3  Pick your team",24,Color.WHITE,true));
        a.addView(label("Choose your national team and follow the road to the final.",16,Color.WHITE,false));
        LinearLayout b=card(); b.addView(label("2/3  Predict results",24,text,true));
        b.addView(label("Enter scores, calculate standings and build the knockout path.",16,subText,false));
        LinearLayout c=card(); c.addView(label("3/3  Share your poster",24,text,true));
        c.addView(label("Create a fan prediction and share it with friends before every matchday.",16,subText,false));
    }

    void showShareImagePlan() {
        clear("Poster Export", "Image/PDF export plan", "More");
        LinearLayout c=card();
        c.addView(label("🖼️ Share Poster Pro",24,text,true));
        c.addView(label("Current version shares prediction text/card. Next native step is PNG generation from the poster view, then PDF export for printable brackets.",15,subText,false));
        Button open=btn("Open Share Poster"); open.setOnClickListener(v->showPoster()); c.addView(open);
        LinearLayout roadmap=card();
        roadmap.addView(label("Export roadmap",22,RED,true));
        roadmap.addView(label("1. Poster preview\n2. Render as bitmap\n3. Save PNG\n4. Android share sheet\n5. PDF bracket export",15,subText,false));
    }

    void showKnockoutRules() {
        clear("Tournament Rules", "48-team format explained", "More");
        LinearLayout c=card();
        c.addView(label("📘 2026 format",24,text,true));
        c.addView(label("48 teams play in 12 groups of four. The top two teams from each group advance, plus the eight best third-placed teams. The knockout stage starts with a Round of 32.",16,subText,false));
        LinearLayout r=card();
        r.addView(label("App logic",22,RED,true));
        r.addView(label("The app calculates group tables from your scores, ranks third-placed teams and builds a predicted knockout path.",15,subText,false));
    }

    void showMonetizationPlan() {
        showPremium();
    }


    String cityDesc(String en, String hr, String de, String es, String fr){
        if(lang.equals("HR"))return hr;
        if(lang.equals("DE"))return de;
        if(lang.equals("ES"))return es;
        if(lang.equals("FR"))return fr;
        return en;
    }
    String playerIntro(){
        if(lang.equals("HR"))return "Centar za Zlatnu kopačku, MVP prognozu i glavne zvijezde turnira.";
        if(lang.equals("DE"))return "Bereich für Goldener Schuh, MVP-Prognose und Turnierstars.";
        if(lang.equals("ES"))return "Sección para Bota de Oro, predicción MVP y estrellas del torneo.";
        if(lang.equals("FR"))return "Section Soulier d'Or, pronostic MVP et stars du tournoi.";
        return "Players hub for Golden Boot, MVP prediction and star-player watch.";
    }
    String scorersIntro(){
        if(lang.equals("HR"))return "Navijačka prognoza najboljih strijelaca. Kasnije se može povezati sa stvarnom statistikom utakmica.";
        if(lang.equals("DE"))return "Fan-Prognose der besten Torschützen. Später kann sie mit echten Spielstatistiken verbunden werden.";
        if(lang.equals("ES"))return "Predicción de goleadores para fans. Luego se puede conectar con estadísticas reales.";
        if(lang.equals("FR"))return "Pronostic des meilleurs buteurs. Plus tard, il pourra être relié aux vraies statistiques.";
        return "Fan prediction list for top scorers. Later this can be connected to real match statistics.";
    }
    String mvpIntro(){
        if(lang.equals("HR"))return "MVP prognoza prati tvoju odabranu reprezentaciju i trenutni navijački kostur.";
        if(lang.equals("DE"))return "Die MVP-Prognose folgt deinem gewählten Team und deinem aktuellen Turnierbaum.";
        if(lang.equals("ES"))return "La predicción MVP sigue tu selección elegida y tu cuadro actual.";
        if(lang.equals("FR"))return "Le pronostic MVP suit ton équipe choisie et ton tableau actuel.";
        return "MVP prediction follows your selected team and current fan bracket.";
    }

void showPlayersHub(){
        clear(t2("Players","Igrači","Spieler","Jugadores","Joueurs"),t2("Player directory from connected sources","Imenik igrača iz povezanih izvora","Spielerverzeichnis aus verbundenen Quellen","Directorio de fuentes conectadas","Annuaire issu des sources connectées"),"Players");
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(48,23,96),Color.rgb(229,32,94),dp(24)));
        hero.addView(label("👥 "+t2("Player Center","Centar igrača","Spielerzentrum","Centro de jugadores","Centre des joueurs"),25,Color.WHITE,true));
        hero.addView(label(t2("Search player profiles supplied by connected football sources. Profile depth depends on the available source data.","Pretraži profile igrača iz povezanih nogometnih izvora. Količina podataka ovisi o dostupnosti izvora.","Durchsuche Spielerprofile aus verbundenen Fußballquellen. Der Profilumfang hängt von den verfügbaren Daten ab.","Busca perfiles de fuentes de fútbol conectadas. El detalle depende de los datos disponibles.","Recherche les profils issus des sources connectées. Le niveau de détail dépend des données disponibles."),14,Color.WHITE,false));
        LinearLayout stats=hrow();
        int extended=countExtendedPlayerProfiles();
        stats.addView(playerOverviewStat(String.valueOf(playerIndex.size()),t2("Profiles","Profili","Profile","Perfiles","Profils")),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams extendedParams=new LinearLayout.LayoutParams(0,-2,1);extendedParams.setMargins(dp(8),0,dp(8),0);
        stats.addView(playerOverviewStat(String.valueOf(extended),t2("Extended","Prošireni","Erweitert","Ampliados","Étendus")),extendedParams);
        stats.addView(playerOverviewStat(hasProAccess()?String.valueOf(favoritePlayerList().size()):"🔒",t2("Following","Pratim","Gefolgt","Siguiendo","Suivis")),new LinearLayout.LayoutParams(0,-2,1));
        hero.addView(stats);

        LinearLayout directory=card();
        directory.addView(label("🔎 "+t2("Find a player","Pronađi igrača","Spieler suchen","Buscar jugador","Rechercher un joueur"),21,text,true));
        EditText search=new EditText(this);
        search.setHint(t2("Player, club, position or nationality","Igrač, klub, pozicija ili nacionalnost","Spieler, Klub, Position oder Nationalität","Jugador, club, posición o nacionalidad","Joueur, club, poste ou nationalité"));
        search.setSingleLine(true);search.setTextColor(text);search.setHintTextColor(subText);search.setTextSize(14);search.setPadding(dp(14),0,dp(14),0);search.setBackground(round(chipBg,dp(16),1));
        search.setText(playerHubQuery);
        if(playerHubQuery.length()>0)search.setSelection(playerHubQuery.length());
        directory.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        addPlayerHubFilters(directory);
        LinearLayout results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);directory.addView(results);
        renderPlayersHubResults(results,playerHubQuery);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence value,int start,int count,int after){}
            public void onTextChanged(CharSequence value,int start,int before,int count){
                playerHubQuery=value==null?"":value.toString();playerHubResultLimit=40;
                if(playerHubSearchRunnable!=null)handler.removeCallbacks(playerHubSearchRunnable);
                playerHubSearchRunnable=()->renderPlayersHubResults(results,playerHubQuery);
                handler.postDelayed(playerHubSearchRunnable,180);
            }
            public void afterTextChanged(Editable editable){}
        });
    }

    int countExtendedPlayerProfiles(){
        int count=0;for(PlayerRecord player:playerIndex.values()){int fields=0;if(player.position.length()>0)fields++;if(player.club.length()>0)fields++;if(player.nationality.length()>0)fields++;if(player.dateOfBirth.length()>0||player.age>0)fields++;if(player.shirtNumber>0)fields++;if(fields>=3)count++;}return count;
    }

    void addPlayerHubFilters(LinearLayout parent){
        HorizontalScrollView scroll=premiumHorizontalScroll();
        LinearLayout row=hrow();row.setPadding(dp(2),dp(10),dp(20),dp(4));
        final TextView[] activePlayerFilter=new TextView[1];
        String[][] filters={
                {"all",t2("All","Svi","Alle","Todos","Tous")},
                {"following",t2("Following","Pratim","Gefolgt","Siguiendo","Suivis")},
                {"goalkeeper",t2("Goalkeepers","Vratari","Torhüter","Porteros","Gardiens")},
                {"defender",t2("Defenders","Braniči","Verteidiger","Defensas","Défenseurs")},
                {"midfielder",t2("Midfielders","Vezni","Mittelfeld","Centrocampistas","Milieux")},
                {"forward",t2("Forwards","Napadači","Stürmer","Delanteros","Attaquants")}
        };
        for(int i=0;i<filters.length;i++){
            String key=filters[i][0];
            TextView option=chip(filters[i][1]+"  "+countPlayerHubFilter(key));
            if(key.equals(playerHubFilter)){option.setTextColor(Color.WHITE);option.setBackground(gradient(RED_DARK,RED,dp(18)));activePlayerFilter[0]=option;}
            option.setOnClickListener(v->{if("following".equals(key)&&!hasProAccess()){showPremium(t2("Following players","Praćenje igrača","Spieler folgen","Seguimiento de jugadores","Suivi des joueurs"));return;}playerHubFilter=key;playerHubResultLimit=40;showPlayersHub();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(42));if(i>0)lp.setMargins(dp(7),0,0,0);row.addView(option,lp);
        }
        scroll.addView(row,new HorizontalScrollView.LayoutParams(-2,-2));
        parent.addView(horizontalMenuRail(scroll,dp(52)),new LinearLayout.LayoutParams(-1,dp(52)));
        scroll.post(()->centerHorizontalChild(scroll,activePlayerFilter[0]));
    }

    int countPlayerHubFilter(String filter){
        int count=0;for(PlayerRecord player:playerIndex.values())if(playerHubFilterMatches(player,filter))count++;return count;
    }

    boolean playerHubFilterMatches(PlayerRecord player,String filter){
        if(player==null)return false;
        if(filter==null||filter.equals("all"))return true;
        if(filter.equals("following"))return isFavoritePlayer(player);
        return playerPositionGroup(player).equals(filter);
    }

    void renderPlayersHubResults(LinearLayout results,String query){
        results.removeAllViews();String needle=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        ArrayList<PlayerRecord> players=new ArrayList<PlayerRecord>();
        for(PlayerRecord player:playerIndex.values()){
            if(!playerHubFilterMatches(player,playerHubFilter))continue;
            String haystack=(player.name+" "+player.club+" "+player.position+" "+localizedPlayerPosition(player.position)+" "+player.nationality+" "+localizedCountryName(player.nationality)).toLowerCase(Locale.ROOT);
            if(needle.length()==0||haystack.contains(needle))players.add(player);
        }
        Collections.sort(players,(a,b)->{
            boolean af=isFavoritePlayer(a),bf=isFavoritePlayer(b);if(af!=bf)return af?-1:1;
            int club=a.club.compareToIgnoreCase(b.club);if(club!=0)return club;return a.name.compareToIgnoreCase(b.name);
        });
        if(players.isEmpty()){
            String message;
            if(playerIndex.isEmpty())message=ENABLE_PLAYER_DATA_MODULES?t2("No player profiles have arrived yet. Refresh data after the squad updater has run.","Profili igrača još nisu stigli. Osvježi podatke nakon što se izvrši updater kadrova.","Noch keine Spielerprofile verfügbar. Aktualisiere nach dem Kader-Update.","Aún no llegaron perfiles. Actualiza tras ejecutar el updater.","Aucun profil reçu. Actualise après l’updater des effectifs."):t2("Player API is not connected yet. The directory is ready and will populate after a verified provider is connected.","API za igrače još nije povezan. Imenik je spreman i popunit će se nakon povezivanja provjerenog izvora.","Die Spieler-API ist noch nicht verbunden. Das Verzeichnis ist bereit und wird nach Anschluss einer verifizierten Quelle gefüllt.","La API de jugadores aún no está conectada. El directorio está listo y se completará al conectar una fuente verificada.","L’API joueurs n’est pas encore connectée. L’annuaire est prêt et se remplira après connexion d’une source vérifiée.");
            else if(playerHubFilter.equals("following")&&needle.length()==0)message=t2("You are not following any players yet.","Još ne pratiš nijednog igrača.","Du folgst noch keinen Spielern.","Aún no sigues a ningún jugador.","Tu ne suis encore aucun joueur.");
            else message=t2("No player matches the selected search and filter.","Nijedan igrač ne odgovara odabranoj pretrazi i filtru.","Kein Spieler entspricht Suche und Filter.","Ningún jugador coincide con la búsqueda y el filtro.","Aucun joueur ne correspond à la recherche et au filtre.");
            results.addView(label(message,14,subText,false));
            if(playerIndex.isEmpty()&&ENABLE_PLAYER_DATA_MODULES){Button refresh=outline("↻ "+t2("Refresh player data","Osvježi podatke igrača","Spielerdaten aktualisieren","Actualizar jugadores","Actualiser les joueurs"));refresh.setOnClickListener(v->refreshOnlineSafe(true));results.addView(refresh);}
            return;
        }
        TextView count=label(players.size()+" "+t2(players.size()==1?"profile":"profiles",players.size()==1?"profil":"profila",players.size()==1?"Profil":"Profile",players.size()==1?"perfil":"perfiles",players.size()==1?"profil":"profils"),12,subText,true);
        count.setPadding(dp(2),dp(7),dp(2),dp(3));results.addView(count);
        int limit=Math.min(players.size(),Math.max(40,playerHubResultLimit));
        for(int i=0;i<limit;i++)addPlayerDirectoryRow(results,players.get(i));
        if(players.size()>limit){
            Button more=outline(t2("Show 40 more","Prikaži još 40","40 weitere anzeigen","Mostrar 40 más","Afficher 40 de plus")+"  •  "+(players.size()-limit));
            more.setOnClickListener(v->{playerHubResultLimit+=40;renderPlayersHubResults(results,playerHubQuery);});results.addView(more);
            TextView hint=centerLabel(t2("Use search and filters for faster results.","Za brži rezultat koristi pretragu i filtre.","Nutze Suche und Filter für schnellere Ergebnisse.","Usa búsqueda y filtros para resultados más rápidos.","Utilise la recherche et les filtres pour aller plus vite."),11,subText,false);hint.setPadding(dp(4),dp(7),dp(4),0);results.addView(hint);
        }
    }


    void showAboutApp(){
        clear(t2("About Football Fun","O aplikaciji","Über Football Fun","Acerca de Football Fun","À propos de Football Fun"),t2("Independent football information app","Neovisna aplikacija za nogometne informacije","Unabhängige Fußball-Informationsapp","Aplicación independiente de información futbolística","Application indépendante d’information football"),"More");
        LinearLayout c=card();
        c.addView(label("⚽ Football Fun",28,text,true));
        c.addView(label(t2("Follow fixtures, results, competitions, clubs and players in one fast, focused app.","Prati rasporede, rezultate, natjecanja, klubove i igrače u jednoj brzoj i preglednoj aplikaciji.","Verfolge Spielpläne, Ergebnisse, Wettbewerbe, Klubs und Spieler in einer schnellen App.","Sigue calendarios, resultados, competiciones, clubes y jugadores en una app rápida.","Suis calendriers, résultats, compétitions, clubs et joueurs dans une application rapide."),16,RED,true));
        c.addView(label(t2("App version","Verzija aplikacije","App-Version","Versión de la aplicación","Version de l’application")+": "+APP_VERSION+" • "+APP_BUILD_CODE,14,subText,false));
        c.addView(label(t2("Live status • Fixtures • Results • Competition centers • Player directory","Status uživo • Raspored • Rezultati • Centri natjecanja • Imenik igrača","Live-Status • Spielplan • Ergebnisse • Wettbewerbszentren • Spielerverzeichnis","Estado en vivo • Calendario • Resultados • Centros de competición • Jugadores","Statut en direct • Calendrier • Résultats • Centres de compétition • Joueurs"),14,subText,false));

        LinearLayout source=card();source.addView(label("🌐 "+t2("Data sources","Izvori podataka","Datenquellen","Fuentes de datos","Sources de données"),22,text,true));
        source.addView(label("Football data provided by the Football-Data.org API",14,text,true));
        source.addView(label(t2("Additional verified sources can be used for competitions not covered by the primary provider. Data can be delayed or corrected by its source.","Za natjecanja koja glavni pružatelj ne pokriva mogu se koristiti dodatni provjereni izvori. Podaci mogu kasniti ili ih izvor može naknadno ispraviti.","Für nicht abgedeckte Wettbewerbe können weitere verifizierte Quellen verwendet werden. Daten können verspätet oder korrigiert werden.","Pueden usarse fuentes verificadas adicionales para competiciones no cubiertas. Los datos pueden retrasarse o corregirse.","Des sources vérifiées supplémentaires peuvent être utilisées. Les données peuvent être retardées ou corrigées."),13,subText,false));

        LinearLayout tools=card();tools.addView(label("🧰 "+t2("App tools","Alati aplikacije","App-Werkzeuge","Herramientas","Outils"),22,text,true));
        Button backup=hasProAccess()?outline(t2("Backup favorites","Sigurnosna kopija favorita","Favoriten sichern","Copia de favoritos","Sauvegarder les favoris")):lockedProButton(t2("Backup favorites","Sigurnosna kopija favorita","Favoriten sichern","Copia de favoritos","Sauvegarder les favoris"),t2("Favorites backup","Sigurnosna kopija favorita","Favoritensicherung","Copia de favoritos","Sauvegarde des favoris"));
        backup.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Favorites backup","Sigurnosna kopija favorita","Favoritensicherung","Copia de favoritos","Sauvegarde des favoris"));return;}shareText("Football Fun backup: "+favoriteClubText()+" | "+followedCompetitionText());});tools.addView(backup);
        Button feedback=outline(t2("Send feedback","Pošalji povratnu informaciju","Feedback senden","Enviar comentarios","Envoyer un avis"));feedback.setOnClickListener(v->openSupportEmail("Football Fun feedback"));tools.addView(feedback);
        Button rate=outline(t2("Rate Football Fun","Ocijeni Football Fun","Football Fun bewerten","Valorar Football Fun","Noter Football Fun"));rate.setOnClickListener(v->toast(t2("Store rating opens after public release.","Ocjenjivanje se otvara nakon javne objave.","Bewertung nach Veröffentlichung.","La valoración se abrirá tras el lanzamiento.","La notation sera disponible après publication.")));tools.addView(rate);

        LinearLayout legal=card();legal.addView(label("⚖️ "+t2("Legal notice","Pravna napomena","Rechtlicher Hinweis","Aviso legal","Mention légale"),22,text,true));
        legal.addView(label(t2("Football Fun is independent and is not affiliated with or endorsed by FIFA, UEFA, national leagues, clubs or players.","Football Fun je neovisan i nije povezan s FIFA-om, UEFA-om, nacionalnim ligama, klubovima ni igračima niti ga oni podržavaju.","Football Fun ist unabhängig und weder mit FIFA, UEFA, nationalen Ligen, Klubs oder Spielern verbunden noch von ihnen unterstützt.","Football Fun es independiente y no está afiliada ni respaldada por FIFA, UEFA, ligas nacionales, clubes o jugadores.","Football Fun est indépendante et n’est ni affiliée ni approuvée par la FIFA, l’UEFA, les ligues nationales, les clubs ou les joueurs."),14,subText,false));
        legal.addView(label(t2("Club names, badges and trademarks belong to their respective owners. Football Fun does not claim ownership of third-party identities.","Nazivi klubova, grbovi i žigovi pripadaju njihovim vlasnicima. Football Fun ne polaže prava na identitete trećih strana.","Klubnamen, Wappen und Marken gehören ihren Eigentümern. Football Fun erhebt keine Eigentumsansprüche.","Los nombres, escudos y marcas pertenecen a sus propietarios. Football Fun no reclama su propiedad.","Les noms, écussons et marques appartiennent à leurs propriétaires. Football Fun n’en revendique pas la propriété."),14,subText,false));
    }


    void showPrivacyPolicy(){
        clear(t2("Privacy policy","Pravila privatnosti","Datenschutzerklärung","Política de privacidad","Politique de confidentialité"),t2("No registration. Local personalization.","Bez registracije. Lokalna personalizacija.","Keine Registrierung. Lokale Personalisierung.","Sin registro. Personalización local.","Sans inscription. Personnalisation locale."),"More");
        LinearLayout c=card();c.addView(label("🔒 "+t2("Privacy policy","Pravila privatnosti","Datenschutzerklärung","Política de privacidad","Politique de confidentialité"),26,text,true));
        c.addView(label(t2("Football Fun does not require registration or a user account.","Football Fun ne zahtijeva registraciju ni korisnički račun.","Football Fun erfordert keine Registrierung und kein Benutzerkonto.","Football Fun no requiere registro ni cuenta de usuario.","Football Fun ne nécessite ni inscription ni compte utilisateur."),16,text,true));
        c.addView(label(t2("The app can store language, theme, selected competitions, favorite clubs and national teams, followed players and matches, local profile fields and notification settings on this device.","Aplikacija na ovom uređaju može spremati jezik, temu, odabrana natjecanja, omiljene klubove i reprezentacije, praćene igrače i utakmice, lokalna polja profila i postavke obavijesti.","Die App kann Sprache, Design, Wettbewerbe, Favoriten, gefolgte Spieler und Spiele, lokale Profilfelder und Benachrichtigungseinstellungen auf diesem Gerät speichern.","La app puede guardar idioma, tema, competiciones, favoritos, jugadores y partidos seguidos, campos de perfil local y ajustes de notificación en este dispositivo.","L’application peut stocker la langue, le thème, les compétitions, favoris, joueurs et matchs suivis, champs de profil local et réglages de notification sur cet appareil."),14,subText,false));
        c.addView(label(t2(
                "Online connections are used to retrieve football information and club images. The Free version uses Google Mobile Ads and Google User Messaging Platform. These Google services may process device identifiers, IP address, app interactions and diagnostic information for advertising, measurement, consent and fraud-prevention purposes. Football Fun does not sell personal data.",
                "Internetska veza koristi se za dohvat nogometnih informacija i slika klubova. Besplatna verzija koristi Google Mobile Ads i Google User Messaging Platform. Te Googleove usluge mogu obrađivati identifikatore uređaja, IP adresu, interakcije u aplikaciji i dijagnostičke podatke radi oglašavanja, mjerenja, privole i sprječavanja prijevara. Football Fun ne prodaje osobne podatke.",
                "Online-Verbindungen laden Fußballdaten und Klubgrafiken. Die kostenlose Version verwendet Google Mobile Ads und die Google User Messaging Platform. Diese Google-Dienste können Gerätekennungen, IP-Adresse, App-Interaktionen und Diagnosedaten für Werbung, Messung, Einwilligung und Betrugsprävention verarbeiten. Football Fun verkauft keine personenbezogenen Daten.",
                "La conexión se usa para obtener información de fútbol e imágenes de clubes. La versión gratuita utiliza Google Mobile Ads y Google User Messaging Platform. Estos servicios de Google pueden tratar identificadores del dispositivo, dirección IP, interacciones en la app y datos de diagnóstico para publicidad, medición, consentimiento y prevención del fraude. Football Fun no vende datos personales.",
                "La connexion sert à récupérer les données football et les images de clubs. La version gratuite utilise Google Mobile Ads et Google User Messaging Platform. Ces services Google peuvent traiter des identifiants d’appareil, l’adresse IP, les interactions dans l’application et des données de diagnostic à des fins de publicité, mesure, consentement et prévention de la fraude. Football Fun ne vend pas de données personnelles."),14,subText,false));
        c.addView(label(t2("Notification permission is requested only if you enable match reminders. Uninstalling the app removes its locally stored preferences.","Dopuštenje za obavijesti traži se samo ako uključiš podsjetnike za utakmice. Deinstalacijom aplikacije uklanjaju se lokalno spremljene postavke.","Die Benachrichtigungsberechtigung wird nur für Spielerinnerungen angefordert. Beim Deinstallieren werden lokale Einstellungen entfernt.","El permiso de notificaciones se solicita solo al activar recordatorios. Al desinstalar se eliminan los ajustes locales.","L’autorisation de notification n’est demandée que pour les rappels. La désinstallation supprime les réglages locaux."),14,subText,false));
        c.addView(label(t2(
                "Football Fun Pro subscriptions are processed by Google Play Billing. Football Fun receives only the purchase/entitlement information needed to unlock Pro; payment-card details are handled by Google Play and are not stored by Football Fun.",
                "Pretplate Football Fun Pro obrađuju se putem Google Play Billinga. Football Fun prima samo podatke o kupnji/pravu pristupa potrebne za otključavanje Pro verzije; podatke platne kartice obrađuje Google Play i Football Fun ih ne pohranjuje.",
                "Football Fun Pro-Abonnements werden über Google Play Billing verarbeitet. Football Fun erhält nur die Kauf-/Berechtigungsinformationen zum Freischalten von Pro; Zahlungskartendaten werden von Google Play verarbeitet und nicht von Football Fun gespeichert.",
                "Las suscripciones Football Fun Pro se procesan mediante Google Play Billing. Football Fun recibe únicamente la información de compra/derecho necesaria para desbloquear Pro; Google Play procesa los datos de la tarjeta y Football Fun no los almacena.",
                "Les abonnements Football Fun Pro sont traités via Google Play Billing. Football Fun reçoit uniquement les informations d’achat/droit nécessaires pour déverrouiller Pro ; les données de carte sont traitées par Google Play et ne sont pas stockées par Football Fun."),14,subText,false));
        LinearLayout safety=card();safety.addView(label("🛡️ "+t2("Data control","Upravljanje podacima","Datenkontrolle","Control de datos","Contrôle des données"),22,RED,true));
        safety.addView(label(t2("You can change or remove saved choices inside the app. Removing the app clears local preferences from the device.","Spremljene odabire možeš promijeniti ili ukloniti unutar aplikacije. Uklanjanjem aplikacije brišu se lokalne postavke s uređaja.","Gespeicherte Auswahlen können in der App geändert oder entfernt werden. Die Deinstallation löscht lokale Einstellungen.","Puedes cambiar o eliminar las opciones guardadas dentro de la app. Al desinstalar se borran los ajustes locales.","Tu peux modifier ou supprimer les choix enregistrés dans l’application. La désinstallation efface les réglages locaux."),14,subText,false));
    }

    boolean matchMatchesPersonalTeams(Match match){
        if(match==null)return false;
        if(favoriteNationalTeams!=null)for(String team:favoriteNationalTeams)if(sameTeam(match.home,team)||sameTeam(match.away,team))return true;
        if(favoriteClubs!=null)for(String club:favoriteClubs)if(sameTeam(match.home,club)||sameTeam(match.away,club))return true;
        return false;
    }

    boolean matchMatchesPersonalSelection(Match match){
        return matchMatchesPersonalTeams(match)||matchMatchesFollowedCompetition(match);
    }

    void sortMatchesAscending(List<Match> matches){
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return da.compareTo(db);
        });
    }

    void sortMatchesDescending(List<Match> matches){
        Collections.sort(matches,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
    }

    Match nextPersonalMatch(){
        ArrayList<Match> candidates=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalSelection(match)&&!hnlMatchNeedsResultConfirmation(match))candidates.add(match);
        candidates=dedupeFavoriteMatches(candidates);
        Match best=null;Date bestDate=null;long now=System.currentTimeMillis();
        for(Match match:candidates){
            if(matchIsLive(match))return match;
            if(!matchIsUpcoming(match))continue;
            Date date=localMatchDate(match);if(date==null)continue;
            boolean dateOnly=match.date==null||displayLocalDateTime(match.date).length()<16;
            long effectiveTime=date.getTime()+(dateOnly?24L*60L*60L*1000L-1L:0L);
            if(effectiveTime<now-AppConfig.MATCH_START_GRACE_MS)continue;
            if(best==null||bestDate==null||date.before(bestDate)){best=match;bestDate=date;}
        }
        return best;
    }

    int personalLiveCount(){
        ArrayList<Match> matches=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalSelection(match)&&matchIsLive(match))matches.add(match);
        return dedupeFavoriteMatches(matches).size();
    }
    int personalTodayCount(){
        ArrayList<Match> matches=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalSelection(match)&&matchIsToday(match)&&!hnlMatchNeedsResultConfirmation(match))matches.add(match);
        return dedupeFavoriteMatches(matches).size();
    }

    int personalUpcomingCount(int days){
        ArrayList<Match> matches=new ArrayList<Match>();long now=System.currentTimeMillis();long end=now+Math.max(1,days)*24L*60L*60L*1000L;
        for(Match match:data.matches){
            if(!matchMatchesPersonalSelection(match)||!matchIsUpcoming(match)||hnlMatchNeedsResultConfirmation(match))continue;
            Date date=localMatchDate(match);if(date!=null&&date.getTime()>=now-AppConfig.MATCH_START_GRACE_MS&&date.getTime()<=end)matches.add(match);
        }
        return dedupeFavoriteMatches(matches).size();
    }

    ArrayList<Match> personalMatchesToday(){
        ArrayList<Match> result=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalSelection(match)&&matchIsToday(match)&&!hnlMatchNeedsResultConfirmation(match))result.add(match);
        result=dedupeFavoriteMatches(result);sortMatchesAscending(result);return result;
    }

    ArrayList<Match> recentPersonalResults(int limit){
        ArrayList<Match> result=new ArrayList<Match>();
        for(Match match:data.matches)if(matchMatchesPersonalSelection(match)&&matchIsFinished(match))result.add(match);
        result=dedupeFavoriteMatches(result);sortMatchesDescending(result);
        if(result.size()>limit)return new ArrayList<Match>(result.subList(0,limit));
        return result;
    }

    int competitionLiveCount(String competition){int count=0;for(Match match:data.matches)if(matchBelongsToCompetition(match,competition)&&matchIsLive(match))count++;return count;}
    int competitionTodayCount(String competition){int count=0;for(Match match:data.matches)if(matchBelongsToCompetition(match,competition)&&matchIsToday(match)&&!hnlMatchNeedsResultConfirmation(match))count++;return count;}
    int competitionUpcomingCount(String competition,int days){
        int count=0;long now=System.currentTimeMillis();long end=now+Math.max(1,days)*24L*60L*60L*1000L;
        for(Match match:data.matches){
            if(!matchBelongsToCompetition(match,competition)||!matchIsUpcoming(match)||hnlMatchNeedsResultConfirmation(match))continue;
            Date date=localMatchDate(match);if(date!=null&&date.getTime()>=now-AppConfig.MATCH_START_GRACE_MS&&date.getTime()<=end)count++;
        }
        return count;
    }

    boolean matchWithinHours(Match match,int hours){
        Date date=localMatchDate(match);if(date==null)return false;
        long distance=date.getTime()-System.currentTimeMillis();
        return distance>=-AppConfig.MATCH_START_GRACE_MS&&distance<=Math.max(1,hours)*60L*60L*1000L;
    }

    boolean resultWithinHours(Match match,int hours){
        Date date=localMatchDate(match);if(date==null)return false;
        long age=System.currentTimeMillis()-date.getTime();
        return age>=0&&age<=Math.max(1,hours)*60L*60L*1000L;
    }

    String personalMatchKey(Match match){
        if(match==null)return "";
        if(match.apiId>0)return "id:"+match.apiId;
        return teamKey(match.home)+"|"+teamKey(match.away)+"|"+(match.date==null?"":match.date);
    }

    // Favorite feeds may receive the same real fixture from several providers or
    // aliases with different API ids. For presentation/counting we therefore use
    // a provider-independent identity based on canonical teams, competition and
    // the normalized local kickoff. This is intentionally separate from
    // personalMatchKey(), which remains suitable for persistence/reminders.
    String favoriteMatchIdentityKey(Match match){
        return duplicateMatchKey(match);
    }

    ArrayList<Match> dedupeFavoriteMatches(Collection<Match> source){
        LinkedHashMap<String,Match> unique=new LinkedHashMap<String,Match>();
        if(source!=null)for(Match match:source){
            if(match==null)continue;
            String key=favoriteMatchIdentityKey(match);
            if(key.isEmpty())key=personalMatchKey(match);
            Match current=unique.get(key);
            if(current==null){unique.put(key,match);continue;}
            // Prefer the richer/current record when duplicate provider rows exist.
            int currentScore=(matchIsFinished(current)?4:0)+(matchIsLive(current)?3:0)+(current.homeGoals>=0&&current.awayGoals>=0?2:0)+(current.detailsAvailable?1:0);
            int candidateScore=(matchIsFinished(match)?4:0)+(matchIsLive(match)?3:0)+(match.homeGoals>=0&&match.awayGoals>=0?2:0)+(match.detailsAvailable?1:0);
            if(candidateScore>currentScore)unique.put(key,match);
        }
        return new ArrayList<Match>(unique.values());
    }

    int personalAlertCount(){
        if(!favoriteNotifications)return 0;
        LinkedHashSet<String> keys=new LinkedHashSet<String>();
        for(Match match:data.matches){
            if(!matchMatchesPersonalSelection(match))continue;
            if(matchIsLive(match)||(matchIsUpcoming(match)&&matchIsToday(match))||(matchIsFinished(match)&&resultWithinHours(match,24)))keys.add(favoriteMatchIdentityKey(match));
        }
        Match next=nextPersonalMatch();if(next!=null&&matchWithinHours(next,48))keys.add(favoriteMatchIdentityKey(next));
        return keys.size();
    }

    LinearLayout briefSectionHeader(String icon,String heading,String action,View.OnClickListener listener){
        LinearLayout row=hrow();
        row.addView(label(icon+" "+heading,20,text,true),new LinearLayout.LayoutParams(0,-2,1));
        if(action!=null&&action.length()>0){TextView open=label(action+"  ›",12,RED,true);if(listener!=null)open.setOnClickListener(listener);row.addView(open);}
        return row;
    }

    void addBriefEmpty(LinearLayout parent,String message){
        TextView empty=label(message,14,subText,false);empty.setPadding(dp(10),dp(10),dp(10),dp(10));empty.setBackground(round(chipBg,dp(16),0));parent.addView(empty);
    }

    void addCompetitionPulseRow(LinearLayout parent,String competition){
        final String selected=competition;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(chipBg,dp(16),1));
        TextView icon=label(competitionIcon(competition),20,text,true);row.addView(icon);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(9),0,0,0);
        copy.addView(label(displayCompetitionName(competition),14,text,true));
        String pulse=t2("Live","Uživo","Live","En vivo","Direct")+" "+competitionLiveCount(competition)+"  •  "+t2("Today","Danas","Heute","Hoy","Aujourd’hui")+" "+competitionTodayCount(competition)+"  •  7d "+competitionUpcomingCount(competition,7);
        copy.addView(label(pulse,11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",22,RED,true));
        row.setOnClickListener(v->showCompetitionHub(selected,competitionRegion(selected)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));parent.addView(row,lp);
    }

    void showDailyBrief(){
        if(!requirePro(t2("Personal football feed","Osobni nogometni sadržaj","Persönlicher Fußball-Feed","Contenido personal","Fil football personnel")))return;
        clear(t2("Your football day","Tvoj nogometni dan","Dein Fußballtag","Tu día de fútbol","Ta journée football"),t2("Verified updates selected for you","Provjerene informacije odabrane za tebe","Verifizierte Updates für dich","Actualizaciones verificadas para ti","Informations vérifiées pour toi"),"DailyBrief");

        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(39,18,84),Color.rgb(197,25,91),dp(24)));
        hero.addView(label("✨ "+new SimpleDateFormat("EEEE, d. MMMM",homeLocale()).format(new Date()),14,Color.WHITE,true));
        hero.addView(label(t2("For your favorites","Za tvoje favorite","Für deine Favoriten","Para tus favoritos","Pour tes favoris"),27,Color.WHITE,true));
        ArrayList<String> selectedLabels=new ArrayList<String>();
        if(!primaryFavoriteClub().isEmpty())selectedLabels.add(displayTeamName(primaryFavoriteClub()));
        if(myTeam!=null&&!myTeam.trim().isEmpty()&&favoriteNationalTeams.contains(myTeam))selectedLabels.add(displayTeamName(myTeam));
        if(followedCompetitions!=null)for(String competition:followedCompetitions){if(selectedLabels.size()>=3)break;selectedLabels.add(displayCompetitionName(competition));}
        hero.addView(label(selectedLabels.isEmpty()?t2("Choose favorites to personalize this screen","Odaberi favorite za personalizaciju ovog ekrana","Wähle Favoriten für diesen Bildschirm","Elige favoritos para personalizar","Choisis des favoris pour personnaliser"):android.text.TextUtils.join("  •  ",selectedLabels),15,Color.WHITE,false));
        hero.addView(kpiRow(t2("Live","Uživo","Live","En vivo","Direct"),String.valueOf(personalLiveCount()),t2("Today","Danas","Heute","Hoy","Aujourd’hui"),String.valueOf(personalTodayCount()),t2("Next 7 days","Sljedećih 7 dana","Nächste 7 Tage","Próximos 7 días","7 prochains jours"),String.valueOf(personalUpcomingCount(7)),true));

        Match next=nextPersonalMatch();
        LinearLayout priority=card();priority.addView(briefSectionHeader("⚽",t2("Next priority match","Sljedeća važna utakmica","Nächstes wichtiges Spiel","Próximo partido prioritario","Prochain match prioritaire"),t2("All matches","Sve utakmice","Alle Spiele","Todos","Tous"),v->{matchDateFilter="ALL";matchStatusFilter="All";matchCenterPage=0;showMatches();}));
        if(next!=null)addDynamicHomeMatch(priority,next);else addBriefEmpty(priority,t2("No upcoming verified match for your selected clubs or national team.","Nema nadolazeće provjerene utakmice za odabrane klubove ili reprezentaciju.","Kein kommendes verifiziertes Spiel für deine Auswahl.","No hay próximo partido verificado para tus selecciones.","Aucun prochain match vérifié pour tes sélections."));

        LinearLayout today=card();today.addView(briefSectionHeader("📅",t2("Today for you","Danas za tebe","Heute für dich","Hoy para ti","Aujourd’hui pour toi"),t2("Open Match Center","Otvori Centar utakmica","Match Center öffnen","Abrir centro de partidos","Ouvrir le centre des matchs"),v->{matchDateFilter=dateKeyOffset(0);matchStatusFilter="All";matchFavoritesOnly=true;showMatches();}));
        ArrayList<Match> todayMatches=personalMatchesToday();
        if(todayMatches.isEmpty())addBriefEmpty(today,t2("None of your selected teams play today.","Danas ne igra nijedan od tvojih odabranih timova.","Keines deiner ausgewählten Teams spielt heute.","Ninguno de tus equipos seleccionados juega hoy.","Aucune de tes équipes sélectionnées ne joue aujourd’hui."));
        else for(int i=0;i<Math.min(4,todayMatches.size());i++)addDynamicHomeMatch(today,todayMatches.get(i));

        LinearLayout results=card();results.addView(briefSectionHeader("✅",t2("Latest verified results","Zadnji provjereni rezultati","Letzte verifizierte Ergebnisse","Últimos resultados verificados","Derniers résultats vérifiés"),"",null));
        ArrayList<Match> recent=recentPersonalResults(3);
        if(recent.isEmpty())addBriefEmpty(results,t2("No completed verified result is available yet.","Još nema dostupnog završenog provjerenog rezultata.","Noch kein verifiziertes Ergebnis verfügbar.","Aún no hay resultados verificados.","Aucun résultat vérifié n’est encore disponible."));
        else for(Match match:recent)addDynamicHomeMatch(results,match);

        LinearLayout competitions=card();competitions.addView(briefSectionHeader("🏆",t2("Competition pulse","Pregled natjecanja","Wettbewerbs-Puls","Pulso de competiciones","Pouls des compétitions"),t2("Manage","Uredi","Verwalten","Gestionar","Gérer"),v->showLeagues()));
        if(followedCompetitions==null||followedCompetitions.isEmpty())addBriefEmpty(competitions,t2("Follow competitions to add them to your daily brief.","Zaprati natjecanja kako bi se prikazivala u dnevnom pregledu.","Folge Wettbewerben für deinen Tagesbrief.","Sigue competiciones para añadirlas a tu resumen.","Suis des compétitions pour les ajouter à ton brief."));
        else{int shown=0;for(String competition:followedCompetitions){if(shown++>=5)break;addCompetitionPulseRow(competitions,competition);}}

        LinearLayout notifications=card();notifications.setBackground(gradient(Color.rgb(26,33,54),Color.rgb(61,38,91),dp(22)));
        LinearLayout notificationHead=hrow();
        LinearLayout notificationCopy=new LinearLayout(this);notificationCopy.setOrientation(LinearLayout.VERTICAL);notificationCopy.addView(label("🔔 "+t2("Reminders and alerts","Podsjetnici i obavijesti","Erinnerungen und Hinweise","Recordatorios y avisos","Rappels et alertes"),19,Color.WHITE,true));notificationCopy.addView(label(t2("Android match reminders and verified in-app alerts","Android podsjetnici za utakmice i provjerene obavijesti u aplikaciji","Android-Spielerinnerungen und geprüfte In-App-Hinweise","Recordatorios Android y avisos verificados en la app","Rappels Android et alertes vérifiées dans l’app"),12,Color.rgb(219,222,234),false));notificationHead.addView(notificationCopy,new LinearLayout.LayoutParams(0,-2,1));
        TextView count=centerLabel(String.valueOf(MatchReminderScheduler.scheduledCount(this)),17,Color.WHITE,true);count.setBackground(round(RED,dp(18),0));notificationHead.addView(count,new LinearLayout.LayoutParams(dp(42),dp(42)));notifications.addView(notificationHead);
        Button openNotifications=outline(t2("Open reminders","Otvori podsjetnike","Erinnerungen öffnen","Abrir recordatorios","Ouvrir les rappels"));openNotifications.setOnClickListener(v->showNotificationCenter());notifications.addView(openNotifications);
    }

    boolean notificationPermissionGranted(){
        return MatchReminderScheduler.hasNotificationPermission(this);
    }

    void requestNotificationPermission(){
        if(Build.VERSION.SDK_INT<33){
            syncMatchRemindersAsync();
            return;
        }
        if(notificationPermissionGranted())return;
        requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATION_PERMISSION);
    }

    boolean matchMatchesFollowedCompetition(Match match){
        if(match==null||followedCompetitions==null||followedCompetitions.isEmpty())return false;
        for(String competition:followedCompetitions)if(matchBelongsToCompetition(match,competition))return true;
        return false;
    }

    void syncMatchRemindersAsync(){
        synchronized(this){
            if(reminderSyncInProgress){reminderSyncRequested=true;return;}
            reminderSyncInProgress=true;
            reminderSyncRequested=false;
        }
        try{
            appSerialExecutor.execute(new Runnable(){public void run(){
                try{
                    do{
                        synchronized(MainActivity.this){reminderSyncRequested=false;}
                        syncMatchReminders();
                        synchronized(MainActivity.this){if(!reminderSyncRequested)break;}
                    }while(true);
                }catch(Exception ignored){}
                finally{synchronized(MainActivity.this){reminderSyncInProgress=false;}}
            }});
        }catch(Exception ignored){synchronized(this){reminderSyncInProgress=false;}}
    }

    int syncMatchReminders(){
        ArrayList<MatchReminderScheduler.Reminder> reminders=new ArrayList<MatchReminderScheduler.Reminder>();
        if(data==null||data.matches==null){
            return MatchReminderScheduler.replaceAll(this,reminders,favoriteNotifications,matchReminderMinutes);
        }
        long now=System.currentTimeMillis();
        long personalHorizon=now+120L*24L*60L*60L*1000L;
        long competitionHorizon=now+21L*24L*60L*60L*1000L;
        LinkedHashMap<String,MatchReminderScheduler.Reminder> unique=new LinkedHashMap<String,MatchReminderScheduler.Reminder>();
        for(Match match:data.matches){
            if(match==null||!matchIsUpcoming(match)||isMatchTimeTba(match))continue;
            Date kickoff=localMatchDate(match);
            if(kickoff==null||kickoff.getTime()<=now)continue;
            boolean personal=matchMatchesPersonalTeams(match);
            boolean explicitlyTracked=isFollowedMatch(match);
            boolean followed=competitionReminders&&matchMatchesFollowedCompetition(match);
            // Explicitly following one concrete fixture must be sufficient to schedule
            // its reminder, even when neither club nor competition is followed.
            if(!personal&&!explicitlyTracked&&!followed)continue;
            long horizon=(personal||explicitlyTracked)?personalHorizon:competitionHorizon;
            if(kickoff.getTime()>horizon)continue;
            String key=personalMatchKey(match);
            String competition=friendlyCompetitionName(match);
            unique.put(key,new MatchReminderScheduler.Reminder(
                    key,
                    displayTeamName(match.home),
                    displayTeamName(match.away),
                    displayCompetitionName(competition),
                    kickoff.getTime()
            ));
        }
        reminders.addAll(unique.values());
        return MatchReminderScheduler.replaceAll(this,reminders,favoriteNotifications,matchReminderMinutes);
    }

    Match findReminderMatch(String home,String away,long kickoffMillis){
        if(data==null||data.matches==null)return null;
        Match best=null;
        long bestDistance=Long.MAX_VALUE;
        for(Match match:data.matches){
            if(match==null)continue;
            boolean samePair=(sameTeam(match.home,home)&&sameTeam(match.away,away))||(sameTeam(match.home,away)&&sameTeam(match.away,home));
            if(!samePair)continue;
            Date kickoff=localMatchDate(match);
            long distance=kickoff==null||kickoffMillis<=0?0L:Math.abs(kickoff.getTime()-kickoffMillis);
            if(best==null||distance<bestDistance){best=match;bestDistance=distance;}
        }
        if(bestDistance>36L*60L*60L*1000L&&kickoffMillis>0)return null;
        return best;
    }

    String scheduledReminderDateLabel(long kickoffMillis){
        if(kickoffMillis<=0)return "";
        Date kickoff=new Date(kickoffMillis);
        String day=new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(kickoff);
        String time=new SimpleDateFormat("HH:mm",homeLocale()).format(kickoff);
        return day+"  •  "+time;
    }

    void addScheduledReminderRow(LinearLayout parent,MatchReminderScheduler.ScheduledReminder reminder){
        if(reminder==null)return;
        final MatchReminderScheduler.ScheduledReminder selected=reminder;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackground(round(chipBg,dp(17),1));
        TextView icon=centerLabel("🔔",20,Color.WHITE,true);icon.setBackground(round(Color.rgb(45,50,68),dp(17),0));row.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);
        copy.addView(label(selected.home+"  •  "+selected.away,14,text,true));
        String meta=scheduledReminderDateLabel(selected.kickoffMillis)+"  •  "+reminderLeadLabel(selected.leadMinutes)+" "+t2("before","prije","vorher","antes","avant");
        if(selected.competition.length()>0)meta+="\n"+selected.competition;
        copy.addView(label(meta,11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",23,RED,true));
        row.setOnClickListener(v->{Match match=findReminderMatch(selected.home,selected.away,selected.kickoffMillis);if(match!=null)showMatchDetails(match);else showNotificationCenter();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));parent.addView(row,lp);
    }

    String reminderLeadLabel(int minutes){
        if(minutes>=1440)return t2("1 day","1 dan","1 Tag","1 día","1 jour");
        if(minutes==60)return t2("1 hour","1 sat","1 Stunde","1 hora","1 heure");
        return minutes+" min";
    }

    void addReminderLeadOption(LinearLayout row,int minutes){
        boolean selected=matchReminderMinutes==minutes;
        TextView option=centerLabel(reminderLeadLabel(minutes),11,selected?Color.WHITE:subText,true);
        option.setBackground(selected?gradient(RED_DARK,RED,dp(17)):round(chipBg,dp(17),1));
        option.setOnClickListener(v->{
            matchReminderMinutes=minutes;
            userPreferences.saveMatchReminderMinutes(minutes);
            syncMatchRemindersAsync();
            showNotificationCenter();
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);
        lp.setMargins(dp(2),0,dp(2),0);
        row.addView(option,lp);
    }

    void addNotificationAlert(LinearLayout parent,String icon,String heading,Match match){
        final Match selected=match;
        LinearLayout row=hrow();row.setPadding(dp(10),dp(10),dp(10),dp(10));row.setBackground(round(chipBg,dp(17),1));
        TextView symbol=centerLabel(icon,21,Color.WHITE,true);symbol.setBackground(round(Color.rgb(45,50,68),dp(17),0));row.addView(symbol,new LinearLayout.LayoutParams(dp(46),dp(46)));
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);copy.addView(label(heading,13,RED,true));copy.addView(label(displayTeamName(match.home)+"  •  "+displayTeamName(match.away),14,text,true));copy.addView(label(homeDateLabel(match)+"  •  "+homeCenterValue(match),11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));row.addView(label("›",23,subText,true));row.setOnClickListener(v->showMatchDetails(selected));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(3),0,dp(3));parent.addView(row,lp);
    }

    void showNotificationCenter(){
        if(!requirePro(t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match")))return;
        clear(t2("Notifications","Obavijesti","Benachrichtigungen","Notificaciones","Notifications"),t2("Match reminders and verified alerts","Podsjetnici za utakmice i provjerene obavijesti","Spielerinnerungen und geprüfte Hinweise","Recordatorios y avisos verificados","Rappels de match et alertes vérifiées"),"Notifications");

        syncMatchRemindersAsync();
        int scheduled=MatchReminderScheduler.scheduledCount(this);
        boolean permission=notificationPermissionGranted();

        LinearLayout control=card();control.setBackground(gradient(Color.rgb(47,23,92),Color.rgb(230,31,96),dp(23)));
        LinearLayout row=hrow();
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(label("🔔 "+t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"),21,Color.WHITE,true));
        copy.addView(label(t2("Android reminders for your clubs and national team","Android podsjetnici za tvoje klubove i reprezentaciju","Android-Erinnerungen für deine Klubs und Nationalmannschaft","Recordatorios Android para tus clubes y selección","Rappels Android pour tes clubs et ta sélection"),12,Color.WHITE,false));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        Switch enabled=new Switch(this);enabled.setChecked(favoriteNotifications);enabled.setContentDescription(t2("Enable match reminders","Uključi podsjetnike za utakmice","Spielerinnerungen aktivieren","Activar recordatorios","Activer les rappels"));row.addView(enabled);control.addView(row);
        enabled.setOnCheckedChangeListener((button,isChecked)->{
            favoriteNotifications=isChecked;
            userPreferences.saveFavoriteNotifications(isChecked);
            syncMatchRemindersAsync();
            if(isChecked&&!notificationPermissionGranted())requestNotificationPermission();
            else showNotificationCenter();
        });
        TextView permissionState=label("● "+(permission?t2("Notification permission granted","Dozvola za obavijesti odobrena","Benachrichtigungen erlaubt","Permiso concedido","Autorisation accordée"):t2("Notification permission required","Potrebna dozvola za obavijesti","Berechtigung erforderlich","Permiso necesario","Autorisation requise")),13,permission?Color.rgb(166,255,220):Color.rgb(255,225,142),true);
        permissionState.setPadding(dp(12),dp(7),dp(12),dp(7));permissionState.setBackground(round(Color.argb(35,255,255,255),dp(15),0));control.addView(permissionState);
        if(!permission){
            Button allow=outline(t2("Allow notifications","Dopusti obavijesti","Benachrichtigungen erlauben","Permitir notificaciones","Autoriser les notifications"));
            allow.setOnClickListener(v->requestNotificationPermission());control.addView(allow);
        }

        LinearLayout timing=card();
        timing.addView(label("⏱️ "+t2("Reminder timing","Vrijeme podsjetnika","Erinnerungszeit","Momento del recordatorio","Moment du rappel"),20,text,true));
        timing.addView(label(t2("Notify me before the match starts","Obavijesti me prije početka utakmice","Vor Spielbeginn benachrichtigen","Avisarme antes del partido","Me prévenir avant le match"),13,subText,false));
        LinearLayout leadRow=hrow();addReminderLeadOption(leadRow,15);addReminderLeadOption(leadRow,30);addReminderLeadOption(leadRow,60);addReminderLeadOption(leadRow,1440);timing.addView(leadRow);

        LinearLayout compRow=hrow();compRow.setPadding(0,dp(10),0,dp(5));
        LinearLayout compCopy=new LinearLayout(this);compCopy.setOrientation(LinearLayout.VERTICAL);
        compCopy.addView(label("🏆 "+t2("Followed competitions too","I utakmice praćenih natjecanja","Auch gefolgte Wettbewerbe","También competiciones seguidas","Aussi les compétitions suivies"),15,text,true));
        compCopy.addView(label(t2("Off by default to avoid too many alerts","Isključeno je zadano kako ne bi bilo previše obavijesti","Standardmäßig aus, um zu viele Hinweise zu vermeiden","Desactivado por defecto para evitar demasiados avisos","Désactivé par défaut pour éviter trop d’alertes"),11,subText,false));
        compRow.addView(compCopy,new LinearLayout.LayoutParams(0,-2,1));
        Switch competitionSwitch=new Switch(this);competitionSwitch.setChecked(competitionReminders);compRow.addView(competitionSwitch);timing.addView(compRow);
        competitionSwitch.setOnCheckedChangeListener((button,isChecked)->{competitionReminders=isChecked;userPreferences.saveCompetitionReminders(isChecked);syncMatchRemindersAsync();showNotificationCenter();});

        timing.addView(label(t2("Scheduled reminders","Zakazani podsjetnici","Geplante Erinnerungen","Recordatorios programados","Rappels programmés")+": "+scheduled,14,text,true));
        List<MatchReminderScheduler.ScheduledReminder> scheduledItems=MatchReminderScheduler.scheduledReminders(this);
        if(!scheduledItems.isEmpty()){
            timing.addView(label("📅 "+t2("Next reminders","Sljedeći podsjetnici","Nächste Erinnerungen","Próximos recordatorios","Prochains rappels"),15,text,true));
            int visible=Math.min(5,scheduledItems.size());
            for(int i=0;i<visible;i++)addScheduledReminderRow(timing,scheduledItems.get(i));
            if(scheduledItems.size()>visible)timing.addView(label("+"+(scheduledItems.size()-visible)+" "+t2("more scheduled","još zakazano","weitere geplant","más programados","autres programmés"),11,subText,false));
        }else{
            timing.addView(label(t2("No reminder can be scheduled until a selected match has a confirmed kickoff time.","Podsjetnik se može zakazati tek kada odabrana utakmica ima potvrđeno vrijeme početka.","Eine Erinnerung ist erst mit bestätigter Anstoßzeit möglich.","El recordatorio se programa cuando el partido tiene hora confirmada.","Le rappel est programmé quand l’heure du match est confirmée."),11,subText,false));
        }
        LinearLayout actions=hrow();
        Button reschedule=outline("↻ "+t2("Reschedule","Ponovno zakaži","Neu planen","Reprogramar","Reprogrammer"));reschedule.setOnClickListener(v->{syncMatchRemindersAsync();toast(t2("Reminders are being updated","Podsjetnici se ažuriraju","Erinnerungen werden aktualisiert","Los recordatorios se están actualizando","Mise à jour des rappels"));});actions.addView(reschedule,new LinearLayout.LayoutParams(0,dp(52),1));
        Button test=outline("✓ "+t2("Test","Test","Test","Prueba","Test"));test.setOnClickListener(v->{if(!favoriteNotifications){toast(t2("Enable reminders first","Prvo uključi podsjetnike","Aktiviere zuerst Erinnerungen","Activa primero los recordatorios","Active d’abord les rappels"));return;}if(!notificationPermissionGranted()){requestNotificationPermission();return;}if(MatchReminderScheduler.showTestNotification(this))toast(t2("Test notification sent","Testna obavijest poslana","Testbenachrichtigung gesendet","Notificación de prueba enviada","Notification de test envoyée"));});LinearLayout.LayoutParams testLp=new LinearLayout.LayoutParams(0,dp(52),1);testLp.setMargins(dp(7),0,0,0);actions.addView(test,testLp);timing.addView(actions);

        LinearLayout alerts=card();alerts.addView(label("⚡ "+t2("What needs your attention","Što ti je važno sada","Was jetzt wichtig ist","Lo importante ahora","Ce qui compte maintenant"),21,text,true));
        if(!favoriteNotifications){
            addBriefEmpty(alerts,t2("Reminders are turned off. Your favorites and match data remain saved.","Podsjetnici su isključeni. Favoriti i podaci o utakmicama ostaju spremljeni.","Erinnerungen sind deaktiviert. Favoriten und Spieldaten bleiben gespeichert.","Los recordatorios están desactivados. Tus favoritos y datos siguen guardados.","Les rappels sont désactivés. Tes favoris et données restent enregistrés."));
        }else{
            LinkedHashSet<String> shown=new LinkedHashSet<String>();int count=0;
            for(Match match:data.matches)if(matchMatchesPersonalTeams(match)&&matchIsLive(match)&&shown.add(favoriteMatchIdentityKey(match))){addNotificationAlert(alerts,"🔴",t2("Live now","Uživo sada","Jetzt live","En vivo ahora","En direct"),match);count++;}
            ArrayList<Match> today=personalMatchesToday();for(Match match:today)if(matchIsUpcoming(match)&&shown.add(favoriteMatchIdentityKey(match))){addNotificationAlert(alerts,"📅",t2("Match today","Utakmica danas","Spiel heute","Partido hoy","Match aujourd’hui"),match);count++;}
            Match next=nextPersonalMatch();if(next!=null&&matchWithinHours(next,48)&&shown.add(favoriteMatchIdentityKey(next))){addNotificationAlert(alerts,"⏳",t2("Coming within 48 hours","Počinje unutar 48 sati","Beginnt in 48 Stunden","Empieza en 48 horas","Commence sous 48 heures"),next);count++;}
            for(Match match:recentPersonalResults(4))if(resultWithinHours(match,24)&&shown.add(favoriteMatchIdentityKey(match))){addNotificationAlert(alerts,"✅",t2("Final result","Konačni rezultat","Endergebnis","Resultado final","Résultat final"),match);count++;}
            if(count==0)addBriefEmpty(alerts,t2("There are no current alerts for your selected clubs or national team.","Trenutačno nema obavijesti za odabrane klubove ili reprezentaciju.","Derzeit keine Hinweise für deine Auswahl.","No hay avisos actuales para tus selecciones.","Aucune alerte actuelle pour tes sélections."));
        }

        LinearLayout delivery=card();delivery.addView(label("🛡️ "+t2("Reliable delivery","Pouzdana isporuka","Zuverlässige Zustellung","Entrega fiable","Diffusion fiable"),20,text,true));
        delivery.addView(label(t2("Reminders are scheduled directly on this phone and restored after a restart or app update. Android can delay them slightly during aggressive battery saving. Goal alerts will be added only with a separately tested background service.","Podsjetnici se zakazuju izravno na ovom telefonu i vraćaju nakon ponovnog pokretanja ili ažuriranja aplikacije. Android ih može malo odgoditi pri jakoj štednji baterije. Obavijesti o golovima dodat ćemo tek uz posebno testiran pozadinski sustav.","Erinnerungen werden direkt auf diesem Telefon geplant und nach Neustart oder Update wiederhergestellt. Starke Akkusparmodi können sie leicht verzögern. Tor-Hinweise folgen erst mit einem separat getesteten Hintergrunddienst.","Los recordatorios se programan en este teléfono y se restauran tras reiniciar o actualizar. El ahorro de batería puede retrasarlos un poco. Los avisos de gol llegarán solo con un servicio probado.","Les rappels sont programmés sur ce téléphone et restaurés après redémarrage ou mise à jour. L’économie de batterie peut les retarder légèrement. Les alertes de but viendront avec un service testé."),13,subText,false));
    }

    void showTransferCenter(){
        clear(t2("Transfer center","Transfer centar","Transferzentrum","Centro de fichajes","Centre des transferts"),t2("Official deals, loans and rumours","Službeni transferi, posudbe i glasine","Offizielle Deals, Leihen und Gerüchte","Operaciones, cesiones y rumores","Transferts, prêts et rumeurs"),"More");
        String[][] rows={{"✅","Official","New signing added to the followed-club watchlist."},{"🔄","Rumour","Midfielder linked with a summer move."},{"📤","Outgoing","Loan option being monitored."},{"🧭","Scout watch","Three targets match the club profile."}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+t2(r[1],r[1].equals("Official")?"Službeno":r[1].equals("Rumour")?"Glasina":r[1].equals("Outgoing")?"Odlazak":"Praćenje skauta",r[1],r[1],r[1]),21,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showInjuryCenter(){
        clear(t2("Injuries & suspensions","Ozljede i suspenzije","Verletzungen & Sperren","Lesiones y sanciones","Blessures et suspensions"),favoriteClub,"More");
        LinearLayout summary=card(); summary.addView(kpiRow(t2("Injured","Ozlijeđeni","Verletzt","Lesionados","Blessés"),"2",t2("Doubtful","Upitni","Fraglich","Dudosos","Incertain"),"1",t2("Suspended","Suspendirani","Gesperrt","Sancionados","Suspendus"),"0",false));
        String[][] rows={{"🩹","First-team forward",t2("Expected return: 12 days","Povratak: 12 dana","Rückkehr: 12 Tage","Regreso: 12 días","Retour : 12 jours")},{"⚠️","Central midfielder",t2("Late fitness test","Kasni test spremnosti","Später Fitnesstest","Prueba física tardía","Test physique tardif")}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+r[1],20,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showAiDailySummary(){
        clear("Football Fun AI+",t2("Your personalized football summary","Tvoj personalizirani nogometni sažetak","Deine personalisierte Fußball-Zusammenfassung","Tu resumen personalizado","Ton résumé personnalisé"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(17,48,90),Color.rgb(84,32,142),dp(24))); hero.addView(label("🤖 "+t2("Today in your football","Danas u tvom nogometu","Heute in deinem Fußball","Hoy en tu fútbol","Aujourd'hui dans ton football"),24,Color.WHITE,true));
        hero.addView(label("• "+favoriteClub+" "+t2("remains your top priority.","ostaje tvoj glavni prioritet.","bleibt deine Top-Priorität.","sigue siendo tu prioridad.","reste ta priorité.")+"\n• "+myTeam+" "+t2("alerts are enabled.","obavijesti su uključene.","Benachrichtigungen sind aktiv.","tiene alertas activadas.","a les alertes activées.")+"\n• "+primaryFollowedCompetition()+" "+t2("is ready for the next round.","spreman je za sljedeće kolo.","ist bereit für die nächste Runde.","está listo para la próxima jornada.","est prêt pour la prochaine journée."),16,Color.WHITE,false));
        LinearLayout chance=card(); chance.addView(label("📊 "+t2("AI match probability","AI procjena utakmice","KI-Spielwahrscheinlichkeit","Probabilidad IA","Probabilité IA"),22,text,true)); chance.addView(kpiRow(favoriteClub,"62%",t2("Draw","Neriješeno","Unentschieden","Empate","Nul"),"24%",t2("Opponent","Protivnik","Gegner","Rival","Adversaire"),"14%",false)); chance.addView(label(t2("Based on saved form and available app data. Not betting advice.","Na temelju spremljene forme i dostupnih podataka. Nije savjet za klađenje.","Basierend auf gespeicherter Form. Keine Wettberatung.","Basado en la forma guardada. No es consejo de apuestas.","Basé sur la forme enregistrée. Pas un conseil de pari."),13,subText,false));
    }

    void showSmartTeamComparison(){
        clear(t2("Smart team comparison","Pametna usporedba timova","Intelligenter Teamvergleich","Comparación inteligente","Comparaison intelligente"),t2("Form, absences, value and history","Forma, izostanci, vrijednost i povijest","Form, Ausfälle, Wert und Historie","Forma, bajas, valor e historial","Forme, absences, valeur et historique"),"More");
        LinearLayout c=card(); c.addView(label(favoriteClub+"  VS  "+t2("Next opponent","Sljedeći protivnik","Nächster Gegner","Próximo rival","Prochain adversaire"),23,text,true)); c.addView(kpiRow(t2("Form","Forma","Form","Forma","Forme"),"W W D W L",t2("Squad value","Vrijednost","Kaderwert","Valor","Valeur"),"€92M",t2("AI edge","AI prednost","KI-Vorteil","Ventaja IA","Avantage IA"),"62%",false));
        LinearLayout h=card(); h.addView(label("📚 "+t2("Head-to-head","Međusobni omjer","Direkter Vergleich","Cara a cara","Face-à-face"),22,text,true)); h.addView(label(t2("Last 5: 3 wins • 1 draw • 1 loss","Zadnjih 5: 3 pobjede • 1 remi • 1 poraz","Letzte 5: 3 Siege • 1 Remis • 1 Niederlage","Últimos 5: 3 victorias • 1 empate • 1 derrota","5 derniers : 3 victoires • 1 nul • 1 défaite"),16,subText,false));
    }

    void showFootballCalendar(){
        clear(t2("Football calendar","Nogometni kalendar","Fußballkalender","Calendario de fútbol","Calendrier football"),t2("Your clubs and teams by date","Tvoji klubovi i reprezentacije po datumima","Deine Klubs und Teams nach Datum","Tus clubes y selecciones por fecha","Tes clubs et équipes par date"),"More");
        Calendar now=Calendar.getInstance(); String[] days={"MON","TUE","WED","THU","FRI","SAT","SUN"};
        LinearLayout month=card(); month.addView(label(new SimpleDateFormat("MMMM yyyy",homeLocale()).format(now.getTime()),24,text,true));
        LinearLayout head=hrow(); for(String d:days){TextView t=label(d,11,subText,true);t.setGravity(Gravity.CENTER);head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));} month.addView(head);
        for(int r=0;r<5;r++){LinearLayout week=hrow();for(int i=0;i<7;i++){int n=r*7+i+1;TextView d=chip(String.valueOf(n));d.setGravity(Gravity.CENTER);if(n==10||n==14||n==18)d.setText("⚽\n"+n);week.addView(d,new LinearLayout.LayoutParams(0,dp(58),1));}month.addView(week);} 
        LinearLayout upcoming=card(); upcoming.addView(label("📅 "+t2("Upcoming for you","Uskoro za tebe","Demnächst für dich","Próximamente para ti","À venir pour toi"),22,text,true)); Match m=nextFavoriteMatch(); if(m!=null)addHomeMatchRow(upcoming,m,true);
    }

    void showFanJourney(){
        clear(t2("Fan journey","Navijački put","Fan-Reise","Camino del aficionado","Parcours de fan"),t2("Your verified activity overview","Pregled tvoje potvrđene aktivnosti","Übersicht deiner bestätigten Aktivität","Resumen de tu actividad verificada","Aperçu de ton activité vérifiée"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("🏅 "+profileName,25,Color.WHITE,true));
        hero.addView(label(t2("Your journey grows from activity recorded in Football Fun.","Tvoj navijački put raste iz aktivnosti zabilježene u Football Funu.","Deine Fan-Reise wächst mit der in Football Fun erfassten Aktivität.","Tu camino de aficionado crece con la actividad registrada en Football Fun.","Ton parcours de fan évolue avec l’activité enregistrée dans Football Fun."),15,Color.WHITE,false));
        hero.addView(kpiRow(t2("Matches","Utakmice","Spiele","Partidos","Matchs"),String.valueOf(displayPlayedCount()),t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),String.valueOf(favoriteClubs.size()+favoriteNationalTeams.size()),t2("Leagues","Lige","Ligen","Ligas","Ligues"),String.valueOf(followedCompetitions.size()),true));
        LinearLayout info=card();
        info.addView(label("🏆 "+t2("Achievements","Postignuća","Erfolge","Logros","Succès"),20,text,true));
        info.addView(label(t2("Verified achievements and streaks will appear here when enough real activity is available. Football Fun does not show simulated progress.","Potvrđena postignuća i nizovi pojavit će se ovdje kada bude dostupno dovoljno stvarne aktivnosti. Football Fun ne prikazuje simulirani napredak.","Bestätigte Erfolge und Serien erscheinen hier, sobald genügend echte Aktivität vorliegt. Football Fun zeigt keinen simulierten Fortschritt.","Los logros y rachas verificados aparecerán aquí cuando haya suficiente actividad real. Football Fun no muestra progreso simulado.","Les succès et séries vérifiés apparaîtront ici lorsqu’il y aura suffisamment d’activité réelle. Football Fun n’affiche pas de progression simulée."),14,subText,false));
    }


    void showMore(){
        clear(tr("More"),t2("Settings, data and support","Postavke, podaci i podrška","Einstellungen, Daten und Hilfe","Ajustes, datos y soporte","Réglages, données et assistance"),"More");
        LinearLayout settings=card();settings.addView(label("⚙️ "+t2("Quick settings","Brze postavke","Schnelleinstellungen","Ajustes rápidos","Réglages rapides"),21,text,true));settings.addView(label("🌍 "+tr("Language"),14,subText,true));
        LinearLayout langs=hrow();for(String l:new String[]{"EN","HR","DE","ES","FR"}){TextView cc=chip(l);if(l.equals(lang)){cc.setTextColor(Color.WHITE);cc.setBackground(gradient(RED_DARK,RED,dp(18)));}cc.setOnClickListener(v->{lang=((TextView)v).getText().toString();userPreferences.saveLanguage(lang);invalidateCompetitionCaches();prewarmActiveCompetitionAsync();syncMatchRemindersAsync();redraw();});langs.addView(cc,new LinearLayout.LayoutParams(0,dp(40),1));}settings.addView(langs);
        Button reminders=hasProAccess()?outline("🔔 "+t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match")):lockedProButton(t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"),t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"));reminders.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Match reminders","Podsjetnici za utakmice","Spielerinnerungen","Recordatorios de partidos","Rappels de match"));return;}showNotificationCenter();});settings.addView(reminders);
        Button mode=hasProAccess()?outline(darkMode?t2("☀️ Light theme","☀️ Svijetla tema","☀️ Helles Design","☀️ Tema claro","☀️ Thème clair"):t2("🌙 Dark theme","🌙 Tamna tema","🌙 Dunkles Design","🌙 Tema oscuro","🌙 Thème sombre")):lockedProButton(t2("Themes","Teme","Designs","Temas","Thèmes"),t2("Theme personalization","Personalizacija teme","Design-Personalisierung","Personalización del tema","Personnalisation du thème"));mode.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Theme personalization","Personalizacija teme","Design-Personalisierung","Personalización del tema","Personnalisation du thème"));return;}darkMode=!darkMode;userPreferences.saveDarkMode(darkMode);redraw();});settings.addView(mode);

        LinearLayout access=card();access.addView(label("⚽ "+t2("Football access","Nogometni sadržaj","Fußballzugang","Acceso al fútbol","Accès football"),21,text,true));
        Button players=outline("👥 "+t2("Players","Igrači","Spieler","Jugadores","Joueurs"));players.setOnClickListener(v->showPlayersHub());access.addView(players);
        Button search=outline("🔎 "+t2("Global search","Globalna pretraga","Globale Suche","Búsqueda global","Recherche globale"));search.setOnClickListener(v->openGlobalSearch());access.addView(search);

        LinearLayout personal=card();personal.addView(label("⭐ "+t2("Personalization","Personalizacija","Personalisierung","Personalización","Personnalisation"),21,text,true));
        LinearLayout row1=hrow();Button fav=hasProAccess()?outline(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris")):lockedProButton(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),t2("Favorites and following","Favoriti i praćenje","Favoriten und Folgen","Favoritos y seguimiento","Favoris et suivi"));fav.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Favorites and following","Favoriti i praćenje","Favoriten und Folgen","Favoritos y seguimiento","Favoris et suivi"));return;}showFavorites();});Button team=hasProAccess()?outline(tr("My Team")):lockedProButton(tr("My Team"),t2("National team personalization","Personalizacija reprezentacije","Nationalteam-Personalisierung","Personalización de selección","Personnalisation de l’équipe"));team.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("National team personalization","Personalizacija reprezentacije","Nationalteam-Personalisierung","Personalización de selección","Personnalisation de l’équipe"));return;}showMyTeam();});row1.addView(fav,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams r1g=new LinearLayout.LayoutParams(0,dp(52),1);r1g.setMargins(dp(8),0,0,0);row1.addView(team,r1g);personal.addView(row1);
        LinearLayout row2=hrow();Button profile=hasProAccess()?outline("👤 "+t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil")):lockedProButton(t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil"),t2("Personal profile","Osobni profil","Persönliches Profil","Perfil personal","Profil personnel"));profile.setOnClickListener(v->{if(!hasProAccess()){showPremium(t2("Personal profile","Osobni profil","Persönliches Profil","Perfil personal","Profil personnel"));return;}showProfile();});Button premium=outline("💎 Football Fun Pro");premium.setOnClickListener(v->showPremium());row2.addView(profile,new LinearLayout.LayoutParams(0,dp(52),1));LinearLayout.LayoutParams r2g=new LinearLayout.LayoutParams(0,dp(52),1);r2g.setMargins(dp(8),0,0,0);row2.addView(premium,r2g);personal.addView(row2);

        LinearLayout dataCard=card();dataCard.addView(label("↻ "+t2("Data center","Centar podataka","Datenzentrale","Centro de datos","Centre de données"),21,text,true));dataCard.addView(label("● "+t2("Connected and ready","Povezano i spremno","Verbunden und bereit","Conectado y listo","Connecté et prêt"),14,GREEN,true));dataCard.addView(label(dataFreshnessLabel(),12,subText,false));dataCard.addView(label("Football data provided by the Football-Data.org API",12,text,true));Button refresh=outline("↻  "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"));refresh.setOnClickListener(v->refreshOnlineSafe(true));dataCard.addView(refresh);

        LinearLayout help=card();help.addView(label("💬 "+t2("Help and information","Pomoć i informacije","Hilfe und Informationen","Ayuda e información","Aide et informations"),21,text,true));LinearLayout h1=hrow();Button support=outline(t2("Support","Podrška","Hilfe","Soporte","Assistance"));support.setOnClickListener(v->openSupportEmail("Football Fun support"));Button about=outline(t2("About","O aplikaciji","Über","Acerca de","À propos"));about.setOnClickListener(v->showAboutApp());h1.addView(support,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams hg=new LinearLayout.LayoutParams(0,dp(46),1);hg.setMargins(dp(8),0,0,0);h1.addView(about,hg);help.addView(h1);LinearLayout h2=hrow();Button privacy=outline(t2("Privacy","Privatnost","Datenschutz","Privacidad","Confidentialité"));privacy.setOnClickListener(v->showPrivacyPolicy());Button terms=outline(t2("Terms","Uvjeti","Bedingungen","Términos","Conditions"));terms.setOnClickListener(v->showTermsOfUse());h2.addView(privacy,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams h2g=new LinearLayout.LayoutParams(0,dp(46),1);h2g.setMargins(dp(8),0,0,0);h2.addView(terms,h2g);help.addView(h2);
        if(isPrivacyOptionsRequired()){Button adPrivacy=outline("🛡️ "+t2("Ad privacy choices","Postavke privatnosti oglasa","Datenschutz für Werbung","Privacidad de anuncios","Confidentialité des annonces"));adPrivacy.setOnClickListener(v->showAdPrivacyOptions());help.addView(adPrivacy);}
        LinearLayout version=card();version.setPadding(dp(14),dp(11),dp(14),dp(11));LinearLayout vr=hrow();vr.addView(label("Football Fun",15,text,true),new LinearLayout.LayoutParams(0,-2,1));vr.addView(label("v"+APP_VERSION+" • "+APP_BUILD_CODE,13,RED,true));version.addView(vr);version.addView(label(t2("Independent football information app.","Neovisna aplikacija za nogometne informacije.","Unabhängige Fußball-Informationsapp.","Aplicación independiente de información futbolística.","Application indépendante d’information football."),12,subText,false));
    }


    void showTermsOfUse(){
        clear(t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),"Football Fun","More");
        LinearLayout c=card();c.addView(label("📄 "+t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),25,text,true));
        c.addView(label(t2("Football Fun provides football information for personal, non-commercial use. Fixtures, scores, statuses, player and competition data can be delayed, incomplete or corrected by their source.","Football Fun pruža nogometne informacije za osobnu i nekomercijalnu uporabu. Raspored, rezultati, statusi te podaci o igračima i natjecanjima mogu kasniti, biti nepotpuni ili ih izvor može ispraviti.","Football Fun bietet Fußballinformationen für die persönliche, nicht kommerzielle Nutzung. Daten können verspätet, unvollständig oder korrigiert sein.","Football Fun ofrece información de fútbol para uso personal y no comercial. Los datos pueden retrasarse, estar incompletos o corregirse.","Football Fun fournit des informations football pour un usage personnel et non commercial. Les données peuvent être retardées, incomplètes ou corrigées."),15,subText,false));
        c.addView(label(t2("The app does not provide betting advice, gambling, live video or official broadcast content. Decisions made from app information are your responsibility.","Aplikacija ne daje savjete za klađenje, ne nudi igre na sreću, video prijenos uživo ni službeni televizijski sadržaj. Za odluke donesene na temelju informacija iz aplikacije odgovara korisnik.","Die App bietet keine Wettberatung, Glücksspiele, Live-Videos oder offiziellen Übertragungen. Entscheidungen liegen in deiner Verantwortung.","La app no ofrece consejos de apuestas, juegos de azar, vídeo en directo ni retransmisiones oficiales. Las decisiones son responsabilidad del usuario.","L’application ne fournit aucun conseil de pari, jeu d’argent, vidéo en direct ni diffusion officielle. Les décisions restent sous ta responsabilité."),15,subText,false));
        LinearLayout pro=card();pro.addView(label("💎 Football Fun Pro",22,RED,true));
        pro.addView(label(t2("Free access includes competition selection, match fixtures and results, match details, the player directory and player profiles. Pro features require an active purchase after Google Play Billing is enabled.","Besplatan pristup uključuje odabir natjecanja, raspored i rezultate utakmica, detalje utakmica, imenik igrača i profile igrača. Pro funkcije zahtijevat će aktivnu kupnju nakon povezivanja Google Play naplate.","Kostenlos sind Wettbewerbsauswahl, Spielpläne und Ergebnisse, Spieldetails, Spielerverzeichnis und Spielerprofile. Pro erfordert nach Aktivierung von Google Play Billing einen aktiven Kauf.","El acceso gratuito incluye competiciones, calendarios y resultados, detalles de partidos, directorio y perfiles de jugadores. Pro requerirá una compra activa mediante Google Play.","L’accès gratuit comprend compétitions, calendriers et résultats, détails des matchs, annuaire et profils des joueurs. Pro nécessitera un achat actif via Google Play."),14,subText,false));
        pro.addView(label(t2("Until the purchase system is activated, no payment is taken.","Dok se sustav kupnje ne aktivira, naplata se ne izvršava.","Bis das Kaufsystem aktiviert ist, erfolgt keine Zahlung.","Hasta activar el sistema de compra, no se realiza ningún cobro.","Tant que le système d’achat n’est pas activé, aucun paiement n’est effectué."),14,text,true));
        LinearLayout rights=card();rights.addView(label("⚖️ "+t2("Third-party rights","Prava trećih strana","Rechte Dritter","Derechos de terceros","Droits de tiers"),22,text,true));
        rights.addView(label(t2("Competition, club and player names, badges and trademarks belong to their respective owners. Football Fun is independent and does not claim ownership or official endorsement.","Nazivi natjecanja, klubova i igrača, grbovi i žigovi pripadaju njihovim vlasnicima. Football Fun je neovisan i ne polaže prava vlasništva niti tvrdi da ima službenu podršku.","Namen, Wappen und Marken gehören ihren Eigentümern. Football Fun ist unabhängig und beansprucht weder Eigentum noch offizielle Unterstützung.","Los nombres, escudos y marcas pertenecen a sus propietarios. Football Fun es independiente y no reclama propiedad ni respaldo oficial.","Les noms, écussons et marques appartiennent à leurs propriétaires. Football Fun est indépendante et ne revendique ni propriété ni approbation officielle."),14,subText,false));
    }

    void openSupportEmail(String subject){
        try{
            Intent email=new Intent(Intent.ACTION_SENDTO);
            email.setData(Uri.parse("mailto:"));
            email.putExtra(Intent.EXTRA_SUBJECT,subject+" • v"+APP_VERSION);
            startActivity(Intent.createChooser(email,t2("Send email","Pošalji e-mail","E-Mail senden","Enviar correo","Envoyer un e-mail")));
        }catch(Exception e){
            toast(t2("No email app is available.","Nije pronađena aplikacija za e-mail.","Keine E-Mail-App verfügbar.","No hay una app de correo disponible.","Aucune application e-mail disponible."));
        }
    }

    String safeTeam(String value){
        if(value==null||value.trim().isEmpty()||value.equalsIgnoreCase("null")) return t2("To be decided","Još nije poznato","Noch offen","Por definir","À déterminer");
        return value.trim();
    }

    void addCompactResultRow(LinearLayout parent,Match m){
        LinearLayout row=hrow(); row.setPadding(dp(10),dp(8),dp(10),dp(8)); row.setBackground(round(chipBg,dp(14),0));
        TextView teams=label(flag(m.home)+" "+safeTeam(m.home)+"  "+m.homeGoals+" : "+m.awayGoals+"  "+flag(m.away)+" "+safeTeam(m.away),14,text,true);
        row.addView(teams,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatchDetails(m));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(3),0,dp(3)); parent.addView(row,lp);
    }

    void addHomeSearchShortcut(){
        Button search=outline("🔎 "+t2("Search clubs, players and competitions","Pretraži klubove, igrače i natjecanja","Clubs, Spieler und Wettbewerbe suchen","Buscar clubes, jugadores y competiciones","Rechercher clubs, joueurs et compétitions"));
        search.setOnClickListener(v->openGlobalSearch());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(50));lp.setMargins(0,0,0,dp(12));content.addView(search,lp);
    }

    void openGlobalSearch(){
        globalSearchOriginScreen="More".equals(currentScreen)?"More":"Home";
        globalSearchQuery="";
        showGlobalSearch();
    }

    void showClubCenterFromGlobalSearch(String club){
        currentClubOriginScreen="GlobalSearch";
        currentClubOriginCompetition="";
        showClubCenterTab(club,"overview");
    }

    void showCompetitionHubFromGlobalSearch(String competition,String region){
        currentCompetitionOriginScreen="GlobalSearch";
        showCompetitionHub(competition,region);
    }

    void showGlobalSearch(){
        clear(t2("Search","Pretraga","Suche","Buscar","Recherche"),t2("Clubs • players • competitions","Klubovi • igrači • natjecanja","Klubs • Spieler • Wettbewerbe","Clubes • jugadores • competiciones","Clubs • joueurs • compétitions"),"GlobalSearch");
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(52,24,96),Color.rgb(220,34,104),dp(24)));
        hero.addView(label("🔎 "+t2("Find your football","Pronađi svoj nogomet","Finde deinen Fußball","Encuentra tu fútbol","Trouve ton football"),24,Color.WHITE,true));
        hero.addView(label(t2("Open a club, player or competition in seconds.","Otvori klub, igrača ili natjecanje u nekoliko sekundi.","Öffne Klub, Spieler oder Wettbewerb in Sekunden.","Abre un club, jugador o competición en segundos.","Ouvre un club, joueur ou une compétition en quelques secondes."),14,Color.WHITE,false));

        LinearLayout searchCard=card();
        EditText q=new EditText(this);q.setHint(t2("Search by name, league or country","Traži po nazivu, ligi ili državi","Nach Name, Liga oder Land suchen","Buscar por nombre, liga o país","Rechercher par nom, ligue ou pays"));q.setSingleLine(true);q.setTextColor(text);q.setHintTextColor(subText);q.setBackground(round(chipBg,dp(16),1));q.setPadding(dp(15),0,dp(15),0);q.setText(globalSearchQuery);q.setSelection(q.getText().length());searchCard.addView(q,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout results=card();
        Runnable refresh=()->{globalSearchQuery=q.getText().toString();renderGlobalSearchResults(results,globalSearchQuery);};
        q.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){refresh.run();}public void afterTextChanged(Editable e){}});
        refresh.run();
    }

    void renderGlobalSearchResults(LinearLayout results,String raw){
        results.removeAllViews();
        String term=raw==null?"":raw.trim().toLowerCase(homeLocale());
        results.addView(label("🔎 "+(term.length()==0?t2("Suggested","Preporučeno","Empfohlen","Sugerido","Suggéré"):t2("Results","Rezultati","Ergebnisse","Resultados","Résultats")),22,text,true));
        int total=0;

        ArrayList<ClubProfile> clubs=availableClubProfiles();
        int clubCount=0;
        LinkedHashSet<String> renderedClubNames=new LinkedHashSet<>();
        for(ClubProfile club:clubs){
            String canonicalName=ClubIdentityRegistry.canonicalName(club.name);
            String canonicalDisplay=displayTeamName(canonicalName);
            String dedupeKey=teamKey(canonicalName);
            if(renderedClubNames.contains(dedupeKey))continue;
            ClubProfile authoritative=ClubIdentityRegistry.resolve(canonicalName);
            ClubProfile displayProfile=authoritative!=null?authoritative:club;
            String hay=(club.name+" "+canonicalName+" "+club.competition+" "+club.country+" "+canonicalDisplay).toLowerCase(homeLocale());
            if(term.length()>0&&!hay.contains(term))continue;
            if(term.length()==0&&!isFavoriteClubName(canonicalName)&&clubCount>=3)continue;
            final String clubName=canonicalName;
            LinearLayout row=hrow();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(9),dp(10),dp(9));row.setBackground(round(chipBg,dp(16),1));
            row.addView(homeTeamVisual(clubName,dp(48),false),new LinearLayout.LayoutParams(dp(48),dp(48)));
            LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setPadding(dp(10),0,0,0);TextView name=label(displayTeamName(clubName),15,text,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);copy.addView(name);copy.addView(label(clubCompetitionLabel(displayProfile),11,subText,false));row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            TextView star=centerLabel(isFavoriteClubName(clubName)?"★":"☆",20,isFavoriteClubName(clubName)?GOLD:subText,true);star.setOnClickListener(v->{toggleFavoriteClub(clubName);renderGlobalSearchResults(results,raw);});row.addView(star,new LinearLayout.LayoutParams(dp(44),dp(44)));row.setOnClickListener(v->showClubCenterFromGlobalSearch(clubName));applyPressFeedback(row);results.addView(row,new LinearLayout.LayoutParams(-1,-2));
            renderedClubNames.add(dedupeKey);clubCount++;total++;if(clubCount>=6)break;
        }

        int playerCount=0;
        for(PlayerRecord player:playerIndex.values()){
            String hay=(player.name+" "+player.club+" "+player.position+" "+player.nationality).toLowerCase(homeLocale());
            if(term.length()==0||!hay.contains(term))continue;
            final PlayerRecord selected=player;Button b=outline("👤 "+player.name+"  •  "+displayTeamName(player.club));b.setSingleLine(true);b.setEllipsize(android.text.TextUtils.TruncateAt.END);b.setOnClickListener(v->showPlayerCenter(selected));results.addView(b);playerCount++;total++;if(playerCount>=5)break;
        }

        String[][] comps={{"World Cup 2026","International"},{"UEFA European Championship","International"},{"UEFA Champions League","Europe"},{"UEFA Europa League","Europe"},{"Premier League","England"},{"Championship","England"},{"La Liga","Spain"},{"Bundesliga","Germany"},{"Serie A","Italy"},{"Ligue 1","France"},{"Eredivisie","Netherlands"},{"Primeira Liga","Portugal"},{"Brasileirão Série A","Brazil"},{"HNL","Croatia"}};
        int compCount=0;
        for(String[] comp:comps){String display=displayCompetitionName(comp[0]);String hay=(comp[0]+" "+display+" "+comp[1]).toLowerCase(homeLocale());if(term.length()>0&&!hay.contains(term))continue;if(term.length()==0&&!followedCompetitions.contains(comp[0])&&compCount>=3)continue;final String n=comp[0],r=comp[1];Button b=outline(competitionIcon(n)+" "+display);b.setOnClickListener(v->showCompetitionHubFromGlobalSearch(n,r));results.addView(b);compCount++;total++;if(compCount>=5)break;}

        if(total==0){results.addView(centerLabel("⚽",34,text,true));results.addView(centerLabel(t2("Nothing found","Nema rezultata","Nichts gefunden","No se encontraron resultados","Aucun résultat"),19,text,true));results.addView(centerLabel(t2("Try a club, competition, country or player name.","Pokušaj naziv kluba, natjecanja, države ili igrača.","Versuche Klub, Wettbewerb, Land oder Spieler.","Prueba un club, competición, país o jugador.","Essaie un club, une compétition, un pays ou un joueur."),13,subText,false));}
    }

    String clubCompetitionLabel(ClubProfile club){
        String competition=club==null?"":displayCompetitionName(club.competition);String country=club==null?"":club.country;
        if(competition.length()>0&&country.length()>0)return clubCountryFlag(club.name)+" "+competition+" • "+country;
        if(competition.length()>0)return competition;return country;
    }

    void showProfile(){
        if(!requirePro(t2("Personal profile","Osobni profil","Persönliches Profil","Perfil personal","Profil personnel")))return;
        clear(t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil"),t2("Your football identity","Tvoj nogometni identitet","Deine Fußballidentität","Tu identidad futbolística","Ton identité football"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("👤 "+profileName,27,Color.WHITE,true)); hero.addView(label(flag(profileCountry)+" "+profileCountry,17,Color.WHITE,false));
        hero.addView(kpiRow(t2("Viewed","Pogledano","Angesehen","Vistos","Vus"),String.valueOf(displayPlayedCount()),t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),String.valueOf(favoriteClubs.size()),t2("Following","Pratiš","Gefolgt","Siguiendo","Suivis"),String.valueOf(followedCompetitions.size()),true));
        LinearLayout form=card();
        EditText name=new EditText(this); name.setText(profileName); name.setHint(t2("Display name","Ime profila","Anzeigename","Nombre visible","Nom affiché")); name.setTextColor(text); name.setBackground(round(chipBg,dp(16),0)); name.setPadding(dp(14),0,dp(14),0); form.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        Spinner country=spinner(data.teams,profileCountry); form.addView(country);
        Button save=btn(t2("Save profile","Spremi profil","Profil speichern","Guardar perfil","Enregistrer le profil")); save.setOnClickListener(v->{profileName=name.getText().toString().trim(); if(profileName.isEmpty())profileName="Football Fan"; profileCountry=country.getSelectedItem().toString(); userPreferences.saveProfile(profileName,profileCountry); toast(t2("Profile saved","Profil spremljen","Profil gespeichert","Perfil guardado","Profil enregistré")); showProfile();}); form.addView(save);
        LinearLayout achievements=card(); achievements.addView(label("🏅 "+t2("Your progress","Tvoj napredak","Dein Fortschritt","Tu progreso","Ta progression"),22,text,true)); achievements.addView(label("✓ "+t2("Profile created","Profil kreiran","Profil erstellt","Perfil creado","Profil créé")+"\n✓ "+t2("Favorite selected","Favorit odabran","Favorit gewählt","Favorito elegido","Favori choisi")+"\n✓ "+t2("Competition followed","Natjecanje praćeno","Wettbewerb verfolgt","Competición seguida","Compétition suivie"),16,subText,false));
    }

    void showOfflineCenter(){
        clear(t2("Offline & sync","Offline i sinkronizacija","Offline & Sync","Offline y sincronización","Hors ligne et synchro"),t2("Always keep your football available","Tvoj nogomet uvijek dostupan","Dein Fußball immer verfügbar","Tu fútbol siempre disponible","Ton football toujours disponible"),"More");
        LinearLayout status=card(); status.addView(label("📡 "+t2("Connection status","Status veze","Verbindungsstatus","Estado de conexión","État de connexion"),22,text,true)); status.addView(label(onlineStatus+"\n"+dataFreshnessLabel(),15,subText,false));
        Button sync=btn("↻ "+t2("Sync now","Sinkroniziraj sada","Jetzt synchronisieren","Sincronizar ahora","Synchroniser maintenant")); sync.setOnClickListener(v->refreshOnlineSafe(true)); status.addView(sync);
        LinearLayout offline=card(); offline.addView(label("📦 "+t2("Offline mode","Offline način","Offline-Modus","Modo sin conexión","Mode hors ligne"),22,text,true)); offline.addView(label(t2("The latest matches, favorites and settings stay available without internet.","Zadnje utakmice, favoriti i postavke ostaju dostupni bez interneta.","Letzte Spiele, Favoriten und Einstellungen bleiben offline verfügbar.","Los últimos partidos, favoritos y ajustes quedan disponibles sin internet.","Les derniers matchs, favoris et réglages restent disponibles hors ligne."),15,subText,false));
        Button backup=outline(t2("Export local backup","Izvezi lokalnu kopiju","Lokales Backup exportieren","Exportar copia local","Exporter la sauvegarde locale")); backup.setOnClickListener(v->showBackupExport()); offline.addView(backup);
    }


    String premiumOriginForCurrentScreen(){
        if("Premium".equals(currentScreen))return premiumOriginNav;
        if("Matches".equals(currentScreen)||"MatchDetails".equals(currentScreen))return "Matches";
        if("Leagues".equals(currentScreen)||"CompetitionHub".equals(currentScreen)||"CompetitionRounds".equals(currentScreen)||"CompetitionResults".equals(currentScreen)||"CompetitionStandings".equals(currentScreen)||"CompetitionParticipants".equals(currentScreen))return "Leagues";
        if("Favorites".equals(currentScreen))return "Favorites";
        if("ClubCenter".equals(currentScreen))return currentClubOriginCompetition.isEmpty()?"Favorites":"Leagues";
        if("PlayerCenter".equals(currentScreen))return playerBottomNavTarget();
        if("Home".equals(currentScreen)||"DailyBrief".equals(currentScreen))return "Home";
        return "More";
    }

    boolean validPremiumOrigin(String origin){
        return "Home".equals(origin)||"Matches".equals(origin)||"Leagues".equals(origin)||"Favorites".equals(origin)||"More".equals(origin);
    }

    void showPremium(){showPremium("",premiumOriginForCurrentScreen());}

    void openGooglePlaySubscriptions(){
        try{
            Intent intent=new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/account/subscriptions?package="+getPackageName()));
            startActivity(intent);
        }catch(Exception ignored){
            toast(t2("Google Play subscriptions are not available right now.","Google Play pretplate trenutačno nisu dostupne.","Google Play-Abonnements sind derzeit nicht verfügbar.","Las suscripciones de Google Play no están disponibles ahora.","Les abonnements Google Play ne sont pas disponibles actuellement."));
        }
    }

    void showPremium(String requestedFeature){showPremium(requestedFeature,premiumOriginForCurrentScreen());}

    void showPremium(String requestedFeature,String originNav){
        String previousScreen=currentScreen;
        premiumRequestedFeature=requestedFeature==null?"":requestedFeature;
        premiumOriginNav=validPremiumOrigin(originNav)?originNav:"More";
        if(!"Premium".equals(previousScreen))premiumReturnScreen=previousScreen;
        clear("Football Fun Pro",t2("Choose how you follow football","Odaberi kako pratiš nogomet","Wähle, wie du Fußball verfolgst","Elige cómo sigues el fútbol","Choisis comment tu suis le football"),"Premium");

        if(requestedFeature!=null&&!requestedFeature.trim().isEmpty()){
            LinearLayout requested=card();
            requested.setBackground(gradient(Color.rgb(53,24,105),Color.rgb(235,31,86),dp(22)));
            requested.addView(label("💎 "+requestedFeature,22,Color.WHITE,true));
            requested.addView(label(t2("This is planned as a Football Fun Pro benefit.","Ovo je planirano kao pogodnost Football Fun Pro pretplate.","Dies ist als Vorteil von Football Fun Pro geplant.","Esto está previsto como ventaja de Football Fun Pro.","Ceci est prévu comme avantage de Football Fun Pro."),14,Color.WHITE,false));
        }

        LinearLayout hero=card();
        hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("💎 Football Fun Pro",29,Color.WHITE,true));
        hero.addView(label(t2("Follow football without limits.","Prati nogomet bez ograničenja.","Fußball ohne Grenzen verfolgen.","Sigue el fútbol sin límites.","Suis le football sans limites."),20,Color.WHITE,true));
        hero.addView(label(t2("Free covers the essential football experience. Pro unlocks the personal football center, following, advanced reminders and an ad-free experience.","Besplatna verzija pokriva osnovno praćenje nogometa. Pro otključava osobni nogometni centar, praćenje, napredne podsjetnike i iskustvo bez oglasa.","Free deckt das grundlegende Fußballerlebnis ab. Pro schaltet das persönliche Fußballzentrum, Folgen, erweiterte Erinnerungen und ein werbefreies Erlebnis frei.","La versión gratuita cubre lo esencial. Pro desbloquea el centro personal, seguimiento, recordatorios avanzados y una experiencia sin anuncios.","La version gratuite couvre l’essentiel. Pro débloque le centre personnel, le suivi, les rappels avancés et une expérience sans publicité."),14,Color.WHITE,false));
        if(proEntitlement!=null&&proEntitlement.isQaUnlocked()){
            hero.addView(label("🧪 "+t2("QA mode: all Pro features are unlocked for development.","QA način: sve Pro funkcije otključane su za razvoj.","QA-Modus: Alle Pro-Funktionen sind für die Entwicklung freigeschaltet.","Modo QA: todas las funciones Pro están desbloqueadas para desarrollo.","Mode QA : toutes les fonctions Pro sont déverrouillées pour le développement."),13,Color.rgb(235,220,120),true));
        }else if(hasProAccess()){
            hero.addView(label("✓ "+t2("Pro is active","Pro je aktivan","Pro ist aktiv","Pro está activo","Pro est actif"),16,GREEN,true));
        }

        LinearLayout plans=card();
        plans.addView(label("💳 "+t2("Subscriptions","Pretplate","Abonnements","Suscripciones","Abonnements"),21,text,true));

        LinearLayout monthly=new LinearLayout(this);monthly.setOrientation(LinearLayout.VERTICAL);monthly.setPadding(dp(14),dp(12),dp(14),dp(12));monthly.setBackground(round(chipBg,dp(18),1));
        monthly.addView(label(t2("Monthly","Mjesečno","Monatlich","Mensual","Mensuel"),17,text,true));
        String monthlyPrice=(proEntitlement!=null&&proEntitlement.isQaUnlocked())
                ? ProEntitlementManager.MONTHLY_PRICE_FALLBACK
                : (billingManager!=null?billingManager.monthlyPrice():ProEntitlementManager.MONTHLY_PRICE_FALLBACK);
        monthly.addView(label(monthlyPrice+" / "+t2("month","mj.","Monat","mes","mois"),22,RED,true));
        boolean trialVisible=(proEntitlement!=null&&proEntitlement.isQaUnlocked())
                || (billingManager!=null&&billingManager.monthlyTrialAvailable());
        if(trialVisible){
            monthly.addView(label("🎁 "+t2("7 days free, then the monthly subscription","7 dana besplatno, zatim mjesečna pretplata","7 Tage kostenlos, danach Monatsabo","7 días gratis, luego suscripción mensual","7 jours gratuits, puis abonnement mensuel"),13,GREEN,true));
        }
        monthly.setOnClickListener(v->{if(billingManager!=null)billingManager.launchMonthly(this);});
        plans.addView(monthly,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout yearly=new LinearLayout(this);yearly.setOrientation(LinearLayout.VERTICAL);yearly.setPadding(dp(14),dp(12),dp(14),dp(12));yearly.setBackground(gradient(Color.rgb(46,27,88),Color.rgb(118,42,154),dp(18)));
        LinearLayout.LayoutParams ylp=new LinearLayout.LayoutParams(-1,-2);ylp.setMargins(0,dp(8),0,0);
        yearly.addView(label("⭐ "+t2("Best value","Najbolja vrijednost","Bester Wert","Mejor valor","Meilleur choix"),15,Color.rgb(245,220,90),true));
        yearly.addView(label(t2("Yearly","Godišnje","Jährlich","Anual","Annuel"),17,Color.WHITE,true));
        String yearlyPrice=(proEntitlement!=null&&proEntitlement.isQaUnlocked())
                ? ProEntitlementManager.YEARLY_PRICE_FALLBACK
                : (billingManager!=null?billingManager.yearlyPrice():ProEntitlementManager.YEARLY_PRICE_FALLBACK);
        yearly.addView(label(yearlyPrice+" / "+t2("year","god.","Jahr","año","an"),22,Color.WHITE,true));
        yearly.setOnClickListener(v->{if(billingManager!=null)billingManager.launchYearly(this);});
        yearly.addView(label(t2("About 37% less than paying monthly for 12 months.","Oko 37% manje od 12 mjesečnih uplata.","Etwa 37 % günstiger als 12 Monatszahlungen.","Aproximadamente un 37 % menos que 12 pagos mensuales.","Environ 37 % de moins que 12 paiements mensuels."),12,Color.WHITE,false));
        plans.addView(yearly,ylp);

        LinearLayout free=card();
        free.addView(label("⚽ "+t2("Free includes","Besplatno uključuje","Free enthält","Gratis incluye","Gratuit inclut"),21,text,true));
        free.addView(label("✓ "+t2("Fixtures, results, live matches and match details","Raspored, rezultate, utakmice uživo i detalje utakmica","Spielpläne, Ergebnisse, Live-Spiele und Spieldetails","Calendarios, resultados, partidos en vivo y detalles","Calendriers, résultats, matchs en direct et détails"),15,text,true));
        free.addView(label("✓ "+t2("Competition schedules and results, player profiles and global search","Rasporede i rezultate natjecanja, profile igrača i globalnu pretragu","Wettbewerbspläne und Ergebnisse, Spielerprofile und globale Suche","Calendarios y resultados de competiciones, perfiles y búsqueda global","Calendriers et résultats des compétitions, profils et recherche globale"),15,text,true));
        free.addView(label("✓ "+t2("Supported by ads","Podržano oglasima","Durch Werbung unterstützt","Con publicidad","Avec publicité"),15,text,true));

        LinearLayout pro=card();
        pro.addView(label("💎 "+t2("Pro adds","Pro dodaje","Pro ergänzt","Pro añade","Pro ajoute"),21,RED,true));
        pro.addView(label("✓ "+t2("Favorites, followed clubs, competitions and matches","Favorite te praćenje klubova, natjecanja i utakmica","Favoriten sowie verfolgte Klubs, Wettbewerbe und Spiele","Favoritos y seguimiento de clubes, competiciones y partidos","Favoris et suivi des clubs, compétitions et matchs"),15,text,true));
        pro.addView(label("✓ "+t2("Personalized Home, club centers, tables and advanced reminders","Personaliziranu Početnu, centre klubova, tablice i napredne podsjetnike","Personalisierte Startseite, Klubzentren, Tabellen und erweiterte Erinnerungen","Inicio personalizado, centros de clubes, tablas y recordatorios avanzados","Accueil personnalisé, centres de clubs, classements et rappels avancés"),15,text,true));
        pro.addView(label("✓ "+t2("Advanced football insights and future Pro features","Napredne nogometne uvide i buduće Pro funkcije","Erweiterte Fußball-Einblicke und zukünftige Pro-Funktionen","Información avanzada y futuras funciones Pro","Analyses avancées et futures fonctions Pro"),15,text,true));
        pro.addView(label("✓ "+t2("No banner or interstitial ads","Bez banner i međuprostornih oglasa","Keine Banner- oder Vollbildwerbung","Sin banners ni anuncios intersticiales","Sans bannières ni publicités interstitielles"),15,text,true));

        boolean billingReady=billingManager!=null&&billingManager.isReady();
        pro.addView(label((billingReady?"✓ ":"○ ")+(billingReady?t2("Google Play Billing connected","Google Play Billing povezan","Google Play Billing verbunden","Google Play Billing conectado","Google Play Billing connecté"):t2("Waiting for Google Play Billing","Čeka se Google Play Billing","Warten auf Google Play Billing","Esperando Google Play Billing","En attente de Google Play Billing")),13,billingReady?GREEN:subText,true));

        Button restore=outline("↻ "+t2("Restore purchase","Vrati kupnju","Kauf wiederherstellen","Restaurar compra","Restaurer l’achat"));
        restore.setOnClickListener(v->{if(billingManager!=null)billingManager.restorePurchases();});
        pro.addView(restore);

        Button manage=outline("⚙ "+t2("Manage subscription","Upravljaj pretplatom","Abo verwalten","Gestionar suscripción","Gérer l’abonnement"));
        manage.setOnClickListener(v->openGooglePlaySubscriptions());
        pro.addView(manage);

        pro.addView(label(t2(
                "Subscriptions renew automatically unless cancelled in Google Play. Google Play shows the final localized price, billing period and any eligible offer before purchase.",
                "Pretplate se automatski obnavljaju dok ih ne otkažeš u Google Playu. Google Play prije kupnje prikazuje konačnu lokaliziranu cijenu, razdoblje naplate i dostupnu ponudu.",
                "Abonnements verlängern sich automatisch, sofern sie nicht in Google Play gekündigt werden. Google Play zeigt vor dem Kauf den endgültigen lokalen Preis, Abrechnungszeitraum und verfügbare Angebote.",
                "Las suscripciones se renuevan automáticamente salvo que se cancelen en Google Play. Google Play muestra antes de la compra el precio final localizado, el período de facturación y las ofertas disponibles.",
                "Les abonnements se renouvellent automatiquement sauf annulation dans Google Play. Google Play affiche avant l’achat le prix local final, la période de facturation et les offres disponibles."),12,subText,false));

        pro.addView(label(t2("Prices are loaded from Google Play. Debug/QA builds remain unlocked and use test ads; public builds use real entitlement and production ads.","Cijene se učitavaju iz Google Playa. Debug/QA buildovi ostaju otključani i koriste testne oglase; javni build koristi stvarnu pretplatu i produkcijske oglase.","Preise werden aus Google Play geladen. Debug-/QA-Builds bleiben entsperrt und verwenden Testanzeigen; öffentliche Builds verwenden echte Berechtigungen und Produktionsanzeigen.","Los precios se cargan desde Google Play. Los builds Debug/QA permanecen desbloqueados y usan anuncios de prueba; los builds públicos usan derechos reales y anuncios de producción.","Les prix sont chargés depuis Google Play. Les builds Debug/QA restent déverrouillés et utilisent des annonces test ; les builds publics utilisent les droits réels et les annonces de production."),12,subText,false));
    }
    void showStats(){clear(tr("Statistics"),"Advanced insights","More");LinearLayout c=card();c.addView(label("📊 "+tr("Statistics"),25,text,true));c.addView(kpiRow("Played",""+displayPlayedCount(),"Goals",""+displayTotalGoals(),"Progress",displayProgressPercent()+"%",false));c.addView(label("Average goals: "+data.avgGoals(),18,subText,false));c.addView(label("Best attack: "+data.bestAttack(),18,RED,true));c.addView(label("Highest scoring group: "+data.bestGroup(),18,GREEN,true));}
    void sharePrediction(){shareText("⚽ Football Fun\n\n"+tr("My Team")+": "+flag(myTeam)+" "+myTeam+"\nChampion pick: "+topInline(1)+"\nTop 4: "+topInline(4)+"\nProgress: "+displayProgressPercent()+"%\n\nFootball Fun");}
    void shareText(String msg){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(send,t2("Share","Podijeli","Teilen","Compartir","Partager")));hideSystemBars();}
    
    void showPlayStoreChecklist() {
        clear("Play Store", tr("Launch readiness checklist"), "More");
        LinearLayout c = card();
        c.addView(label("🚀 Play Store Launch Checklist", 24, text, true));
        c.addView(label("Status: almost ready for private/internal testing.", 15, subText, false));
        c.addView(label("✅ Offline tournament simulator\n✅ All 48 teams loaded\n✅ Group tables\n✅ My Team hub\n✅ Croatia Road to Final\n✅ Multi-language menu\n✅ Dark/Light mode\n✅ Share Prediction\n✅ Premium positioning", 15, subText, false));
        LinearLayout todo = card();
        todo.addView(label("Before public release", 22, RED, true));
        todo.addView(label("1. Verify every official fixture date and venue.\n2. Do not use FIFA logo or official crests.\n3. Add real app icon and screenshots.\n4. Prepare privacy policy.\n5. Test on at least 3 phones.\n6. Build release AAB for Play Console.", 15, subText, false));
    }

    void showCroatiaRoad() {
        clear(myTeam + " Road", "Group "+groupOfTeam(myTeam)+" and path to final", "More");
        LinearLayout hero = card();
        hero.setBackground(gradient(RED_DARK, RED, dp(24)));
        hero.addView(label(flag(myTeam) + " " + myTeam + " Road to Final", 25, Color.WHITE, true));
        hero.addView(label(groupLineFor(myTeam), 16, Color.WHITE, false));
        LinearLayout g = card();
        g.addView(label("Group "+groupOfTeam(myTeam)+" matches", 22, text, true));
        for (Match m : data.matches) {
            if (m.group.equals(groupOfTeam(myTeam)) || m.home.equals(myTeam) || m.away.equals(myTeam)) {
                g.addView(label(displayLocalDateTime(m.date) + " • " + flag(m.home) + " " + m.home + " vs " + flag(m.away) + " " + m.away, 14, subText, false));
            }
        }
        LinearLayout road = card();
        road.addView(label("Projected path", 22, text, true));
        road.addView(label("Group "+groupOfTeam(myTeam)+" → Round of 32 → Round of 16 → Quarter-final → Semi-final → Final", 16, GREEN, true));
        road.addView(label("This is the emotional hook for Croatian users, while the app stays global for every fan.", 14, subText, false));
    }

    void showWorldCupFacts() {
        clear("Facts", "Tournament quick facts", "More");
        String[] facts = {
            "48 teams • 12 groups • 104 matches",
            "Top 2 from each group qualify",
            "Best 8 third-placed teams qualify",
            "Knockout starts with Round of 32",
            "Host countries: USA, Mexico and Canada",
            "App works offline after installation"
        };
        for (String f : facts) {
            LinearLayout c = card();
            c.addView(label("⚽ " + f, 19, text, true));
        }
    }

    void showPrivacyInfo() {
        showPrivacyPolicy();
    }

void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    String flag(String t){
        if(t==null)return "🏳";
        String clean=t.trim();
        String n=clean.toLowerCase()
                .replace("&","and")
                .replace("-"," ")
                .replace(".","")
                .replace(",","")
                .replace("  "," ");

        // Exact/variant fixes for countries whose API names differ from local names.
        // Do not shorten display names; this only decides which flag to show.
        if(n.equals("bih") || n.contains("bosnia")) return "🇧🇦";
        if(n.equals("sco") || n.contains("scotland")) return "🏴󠁧󠁢󠁳󠁣󠁴󠁿";
        if(n.equals("cod") || n.equals("drc") || n.contains("dr congo") || n.contains("congo dr") || n.contains("democratic republic of congo") || n.contains("democratic republic of the congo")) return "🇨🇩";

        String[][] f={
            {"Croatia","🇭🇷"},{"Brazil","🇧🇷"},{"Germany","🇩🇪"},{"Argentina","🇦🇷"},{"France","🇫🇷"},{"Spain","🇪🇸"},{"Portugal","🇵🇹"},{"England","🇬🇧"},{"Netherlands","🇳🇱"},{"Belgium","🇧🇪"},
            {"Mexico","🇲🇽"},{"USA","🇺🇸"},{"United States","🇺🇸"},{"Canada","🇨🇦"},{"Japan","🇯🇵"},{"Korea Republic","🇰🇷"},{"South Korea","🇰🇷"},{"South Africa","🇿🇦"},{"Czechia","🇨🇿"},{"Bosnia and Herzegovina","🇧🇦"},
            {"Qatar","🇶🇦"},{"Switzerland","🇨🇭"},{"Morocco","🇲🇦"},{"Haiti","🇭🇹"},{"Scotland","🏴󠁧󠁢󠁳󠁣󠁴󠁿"},{"Paraguay","🇵🇾"},{"Australia","🇦🇺"},{"Turkey","🇹🇷"},{"Curacao","🇨🇼"},{"Curaçao","🇨🇼"},
            {"Ivory Coast","🇨🇮"},{"Cote d'Ivoire","🇨🇮"},{"Ecuador","🇪🇨"},{"Sweden","🇸🇪"},{"Tunisia","🇹🇳"},{"Egypt","🇪🇬"},{"Iran","🇮🇷"},{"New Zealand","🇳🇿"},{"Cape Verde","🇨🇻"},{"Cape Verde Islands","🇨🇻"},{"Saudi Arabia","🇸🇦"},
            {"Uruguay","🇺🇾"},{"Senegal","🇸🇳"},{"Iraq","🇮🇶"},{"Norway","🇳🇴"},{"Algeria","🇩🇿"},{"Austria","🇦🇹"},{"Jordan","🇯🇴"},{"DR Congo","🇨🇩"},{"Uzbekistan","🇺🇿"},{"Colombia","🇨🇴"},{"Ghana","🇬🇭"},{"Panama","🇵🇦"}
        };
        for(String[] x:f)if(clean.equals(x[0]))return x[1];
        return "🏳";
    }
    Drawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(radius);return g;}
    Drawable round(int color,int radius,int sw){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(sw>0)g.setStroke(sw,stroke);return g;}
    int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}


    String liveLabelFromJson(String status, String minute){
        if(status==null) status="";
        if(minute==null) minute="";
        String s=status.trim().toUpperCase(Locale.US);
        String m=minute.trim().replace("'", "");
        boolean live=s.equals("LIVE") || s.equals("1H") || s.equals("2H") ||
                s.equals("IN_PROGRESS") || s.equals("IN PROGRESS") ||
                s.equals("INPLAY") || s.equals("IN PLAY");
        if(live){
            if(m.length()>0) return "🔴 LIVE "+m+"'";
            return "🔴 LIVE";
        }
        if(s.equals("HT")) return "🟠 HT";
        if(s.equals("FT") || s.equals("FINISHED") || s.equals("FULLTIME") || s.equals("FULL TIME")) return "✅ "+t2("FT","KRAJ","ENDE","FINAL","FIN");
        if(s.equals("UPCOMING") || s.equals("SCHEDULED") || s.equals("TIMED") || s.equals("NOT_STARTED") || s.equals("NOT STARTED")) return "📅";
        return "";
    }


    boolean onlineMatchIsFinished(String status){ return MatchStatus.isFinished(status); }


    String tournamentInfoLine(){
        return "🌍 Teams: 48  •  Groups: 12  •  Matches: 104";
    }

}