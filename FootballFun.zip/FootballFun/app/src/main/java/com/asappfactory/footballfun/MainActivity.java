package com.asappfactory.footballfun;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.SharedPreferences;
import android.net.Uri;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import java.io.*;
import java.net.*;
import org.json.*;

public class MainActivity extends Activity {
    static final boolean ENABLE_PLAYER_DATA_MODULES = false; // hidden until the higher API plan is activated
    static final boolean ENABLE_CARDS_LINEUPS_MODULES = true; // future feature flag for cards, lineups and player details
    static final String APP_VERSION = BuildConfig.VERSION_NAME;
    static final int APP_BUILD_CODE = BuildConfig.VERSION_CODE;
    static final int TOURNAMENT_TOTAL_MATCHES = 104;
    final int RED=Color.rgb(255,48,94), RED_DARK=Color.rgb(139,23,77), GOLD=Color.rgb(247,199,75), GREEN=Color.rgb(35,207,145), BLUE=Color.rgb(92,118,255);
    final int PURPLE=Color.rgb(115,67,255), PURPLE_DARK=Color.rgb(53,28,108), SURFACE=Color.rgb(18,21,31);
    int bg, cardBg, text, subText, navBg, chipBg, stroke;
    LinearLayout root, content, bottom;
    TextView title, subtitle;
    SharedPreferences prefs;
    Data data;
    Handler handler=new Handler();
    boolean darkMode;
    String lang="EN", currentScreen="Home", myTeam="Croatia", favoriteClub="Dinamo Zagreb", profileName="Football Fan", profileCountry="Croatia", matchFilter="", groupFilter="All", matchStatusFilter="All", competitionFilter="All";
    Set<String> followedCompetitions=new LinkedHashSet<String>();
    Set<String> favoriteClubs=new LinkedHashSet<String>();
    boolean favoriteNotifications=true;
    TextView onlineStatusView;
    TextView onlineLastUpdateView;
    String onlineStatus="🟢 Ready for live data";
    boolean onlineRefreshInProgress=false;
    Runnable autoOnlineRefreshRunnable;
    Runnable liveMatchDetailsRefreshRunnable;
    String openMatchHome="", openMatchAway="", openMatchDate="";
    int openMatchApiId=-1;

    public void onCreate(Bundle b){
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        prefs=getSharedPreferences("footballfun",0);
        darkMode=prefs.getBoolean("darkMode",true);
        lang=prefs.getString("lang","EN");
        myTeam=prefs.getString("team","Croatia");
        favoriteClub=prefs.getString("favoriteClub","Dinamo Zagreb");
        profileName=prefs.getString("profileName","Football Fan");
        profileCountry=prefs.getString("profileCountry","Croatia");
        favoriteClubs=new LinkedHashSet<String>(prefs.getStringSet("favoriteClubs",new LinkedHashSet<String>(Arrays.asList(favoriteClub))));
        if(favoriteClubs.isEmpty()) favoriteClubs.add(favoriteClub);
        followedCompetitions=new LinkedHashSet<String>(prefs.getStringSet("followedCompetitions",new LinkedHashSet<String>(Arrays.asList("UEFA Champions League","HNL","World Cup 2026"))));
        favoriteNotifications=prefs.getBoolean("favoriteNotifications",true);
        data=new Data(this);
        restoreCachedOnlineData();
        applyTheme();
        build();
        showHome();
        refreshOnlineSafe(false);
        startAutoOnlineRefresh();
    }

    public void onWindowFocusChanged(boolean hasFocus){
        super.onWindowFocusChanged(hasFocus);
        if(hasFocus) hideSystemBars();
    }

    @Override
    protected void onDestroy(){
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            if(liveMatchDetailsRefreshRunnable!=null) handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        super.onDestroy();
    }

    void startAutoOnlineRefresh(){
        try{
            if(autoOnlineRefreshRunnable!=null) handler.removeCallbacks(autoOnlineRefreshRunnable);
            autoOnlineRefreshRunnable=new Runnable(){ public void run(){
                try{
                    refreshOnlineSafe(false);
                    handler.postDelayed(this, 15*60*1000);
                }catch(Exception ignored){
                    handler.postDelayed(this, 15*60*1000);
                }
            }};
            handler.postDelayed(autoOnlineRefreshRunnable, 15*60*1000);
        }catch(Exception ignored){}
    }

    void hideSystemBars(){
        try{
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN|
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }catch(Exception e){}
    }

    void applyTheme(){
        bg=darkMode?Color.rgb(7,9,15):Color.rgb(246,247,250);
        cardBg=darkMode?Color.rgb(18,22,33):Color.WHITE;
        text=darkMode?Color.rgb(248,249,252):Color.rgb(20,24,32);
        subText=darkMode?Color.rgb(160,169,187):Color.rgb(92,99,112);
        navBg=darkMode?Color.rgb(11,13,21):Color.WHITE;
        chipBg=darkMode?Color.rgb(28,33,46):Color.rgb(238,241,246);
        stroke=darkMode?Color.rgb(43,50,68):Color.rgb(220,225,233);
    }

    String tr(String key){
        String en=key, hr=key, de=key, es=key, fr=key;
        if(key.equals("Home")){hr="Početna";de="Start";es="Inicio";fr="Accueil";}
        else if(key.equals("Matches")){hr="Utakmice";de="Spiele";es="Partidos";fr="Matchs";}
        else if(key.equals("Groups")){hr="Skupine";de="Gruppen";es="Grupos";fr="Groupes";}
        else if(key.equals("Predict")){hr="Prognoza";de="Tipp";es="Predicción";fr="Prono";}
        else if(key.equals("More")){hr="Više";de="Mehr";es="Más";fr="Plus";}
        else if(key.equals("My Team")){hr="Moja reprezentacija";de="Mein Team";es="Mi equipo";fr="Mon équipe";}
        else if(key.equals("Start Simulator")){hr="Pokreni simulator";de="Simulator starten";es="Iniciar simulador";fr="Démarrer";}
        else if(key.equals("Team Hub")){hr="Centar reprezentacije";de="Team-Zentrale";es="Centro equipo";fr="Hub équipe";}
        else if(key.equals("Share Poster")){hr="Podijeli poster";de="Poster teilen";es="Compartir póster";fr="Partager poster";}
        else if(key.equals("Smart Match Center")){hr="Pametni centar utakmica";de="Match-Zentrale";es="Centro de partidos";fr="Centre matchs";}
        else if(key.equals("Search team, group or host city")){hr="Traži reprezentaciju, skupinu ili grad";de="Team, Gruppe oder Stadt suchen";es="Buscar equipo, grupo o ciudad";fr="Chercher équipe, groupe ou ville";}
        else if(key.equals("Apply Search")){hr="Primijeni pretragu";de="Suchen";es="Buscar";fr="Rechercher";}
        else if(key.equals("Save Result")){hr="Spremi rezultat";de="Ergebnis speichern";es="Guardar resultado";fr="Enregistrer";}
        else if(key.equals("Prediction Studio")){hr="Studio prognoze";de="Prognose-Studio";es="Estudio de predicción";fr="Studio prédiction";}
        else if(key.equals("Enter Scores")){hr="Upiši rezultate";de="Ergebnisse eingeben";es="Introducir marcadores";fr="Saisir scores";}
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Dream Final")){hr="Finale snova";de="Traumfinale";es="Final soñado";fr="Finale rêvée";}
        else if(key.equals("Reset Scores")){hr="Resetiraj rezultate";de="Zurücksetzen";es="Reiniciar";fr="Réinitialiser";}
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Austragungsorte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Statistics")){hr="Statistika";de="Statistiken";es="Estadísticas";fr="Statistiques";}
        else if(key.equals("Premium")){hr="Premium";de="Premium";es="Premium";fr="Premium";}
        else if(key.equals("Switch to Light Mode")){hr="Prebaci na svijetli način";de="Hellmodus";es="Modo claro";fr="Mode clair";}
        else if(key.equals("Switch to Dark Mode")){hr="Prebaci na tamni način";de="Dunkelmodus";es="Modo oscuro";fr="Mode sombre";}
        else if(key.equals("Language")){hr="Jezik";de="Sprache";es="Idioma";fr="Langue";}
        else if(key.equals(myTeam + " Road to Final")){hr="Hrvatska put do finala";de="Kroatien Weg ins Finale";es="Croacia camino a la final";fr="Croatie route finale";}
        else if(key.equals("Free vs Pro")){hr="Besplatno vs Pro";de="Gratis vs Pro";es="Gratis vs Pro";fr="Gratuit vs Pro";}
        else if(key.equals("Open")){hr="Otvori";de="Öffnen";es="Abrir";fr="Ouvrir";}
        
        else if(key.equals("Visual Bracket")){hr="Vizualni kostur";de="Turnierbaum";es="Cuadro visual";fr="Tableau visuel";}
        else if(key.equals("Golden Boot")){hr="Zlatna kopačka";de="Goldener Schuh";es="Bota de Oro";fr="Soulier d'Or";}
        else if(key.equals("MVP Prediction")){hr="MVP prognoza";de="MVP Prognose";es="Predicción MVP";fr="Prédiction MVP";}
        else if(key.equals("Compare Teams")){hr="Usporedi timove";de="Teams vergleichen";es="Comparar equipos";fr="Comparer équipes";}
        else if(key.equals("Export Backup")){hr="Izvoz kopije";de="Backup exportieren";es="Exportar copia";fr="Exporter sauvegarde";}
        else if(key.equals("PDF Poster Info")){hr="PDF poster info";de="PDF Poster Info";es="Info póster PDF";fr="Info poster PDF";}
        else if(key.equals("World Cup Quiz")){hr="SP kviz";de="WM Quiz";es="Quiz Mundial";fr="Quiz Coupe du Monde";}
        else if(key.equals("Stadium Guide")){hr="Vodič stadiona";de="Stadionführer";es="Guía de estadios";fr="Guide des stades";}
        else if(key.equals("City Guide Pro")){hr="Vodič gradova Pro";de="Städteführer Pro";es="Guía de ciudades Pro";fr="Guide des villes Pro";}
        else if(key.equals("Achievements")){hr="Postignuća";de="Erfolge";es="Logros";fr="Succès";}
        else if(key.equals("Tournament tree preview")){hr="Pregled turnirskog stabla";de="Vorschau Turnierbaum";es="Vista del cuadro";fr="Aperçu du tableau";}
        else if(key.equals("Golden Boot simulation")){hr="Simulacija zlatne kopačke";de="Goldener Schuh Simulation";es="Simulación Bota de Oro";fr="Simulation Soulier d'Or";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Team vs Team")){hr="Tim protiv tima";de="Team gegen Team";es="Equipo contra equipo";fr="Équipe contre équipe";}
        else if(key.equals("Export / Import prediction")){hr="Izvoz / uvoz prognoze";de="Prognose export/import";es="Exportar / importar predicción";fr="Exporter / importer pronostic";}
        else if(key.equals("Printable prediction poster")){hr="Poster prognoze za print";de="Druckbares Prognoseposter";es="Póster imprimible";fr="Poster imprimable";}
        else if(key.equals("Fan challenge")){hr="Navijački izazov";de="Fan Herausforderung";es="Reto de fans";fr="Défi des fans";}
        else if(key.equals("Host stadium notes")){hr="Bilješke o stadionima";de="Stadion Notizen";es="Notas de estadios";fr="Notes stades";}
        else if(key.equals("Fan travel notes")){hr="Navijačke putne bilješke";de="Fan Reisehinweise";es="Notas de viaje";fr="Notes voyage fans";}
        else if(key.equals("Badges and milestones")){hr="Značke i postignuća";de="Abzeichen und Meilensteine";es="Insignias e hitos";fr="Badges et étapes";}
        else if(key.equals("Launch readiness checklist")){hr="Popis spremnosti za objavu";de="Checkliste Veröffentlichung";es="Lista de lanzamiento";fr="Liste de lancement";}
        else if(key.equals("Privacy")){hr="Privatnost";de="Datenschutz";es="Privacidad";fr="Confidentialité";}
        else if(key.equals("Legal safety")){hr="Pravna sigurnost";de="Rechtliche Sicherheit";es="Seguridad legal";fr="Sécurité juridique";}

        
        else if(key.equals("Host Cities Pro")){hr="Gradovi domaćini Pro";de="Gastgeberstädte Pro";es="Ciudades sede Pro";fr="Villes hôtes Pro";}
        else if(key.equals("Team Hub Pro")){hr="Centar reprezentacije Pro";de="Team-Zentrale Pro";es="Centro equipo Pro";fr="Hub équipe Pro";}
        else if(key.equals("Onboarding Preview")){hr="Uvodni ekran";de="Einführung";es="Introducción";fr="Introduction";}
        else if(key.equals("Poster Export Plan")){hr="Plan izvoza postera";de="Poster-Export Plan";es="Plan exportar póster";fr="Plan export poster";}
        else if(key.equals("Tournament Rules")){hr="Pravila turnira";de="Turnierregeln";es="Reglas torneo";fr="Règles tournoi";}
        else if(key.equals("Monetization Plan")){hr="Plan zarade";de="Monetarisierung";es="Monetización";fr="Monétisation";}

        
        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("Players")){hr="Igrači";de="Spieler";es="Jugadores";fr="Joueurs";}
        else if(key.equals("Top scorers prediction")){hr="Prognoza najboljih strijelaca";de="Torschützen-Prognose";es="Predicción de goleadores";fr="Pronostic buteurs";}
        else if(key.equals("Player of the tournament")){hr="Igrač turnira";de="Spieler des Turniers";es="Jugador del torneo";fr="Joueur du tournoi";}
        else if(key.equals("Star watch")){hr="Zvijezde turnira";de="Stars im Blick";es="Estrellas a seguir";fr="Stars à suivre";}
        else if(key.equals("Shortlist")){hr="🏆 MVP Power Ranking";de="Auswahlliste";es="Lista corta";fr="Liste courte";}
        else if(key.equals("goals")){hr="golova";de="Tore";es="goles";fr="buts";}
        else if(key.equals("Privacy / Legal")){hr="Privatnost / Pravno";de="Datenschutz / Rechtliches";es="Privacidad / Legal";fr="Confidentialité / Légal";}

        
        else if(key.equals("About App")){hr="O aplikaciji";de="Über die App";es="Acerca de la app";fr="À propos";}
        else if(key.equals("Privacy Policy")){hr="Pravila privatnosti";de="Datenschutzerklärung";es="Política de privacidad";fr="Politique de confidentialité";}
        else if(key.equals("App version")){hr="Verzija aplikacije";de="App-Version";es="Versión de la app";fr="Version de l'app";}
        else if(key.equals("Independent fan-made app")){hr="Nezavisna navijačka aplikacija";de="Unabhängige Fan-App";es="Aplicación independiente de fans";fr="Application indépendante de fans";}
        else if(key.equals("No login. No account. No personal profile.")){hr="Bez prijave. Bez računa. Bez osobnog profila.";de="Kein Login. Kein Konto. Kein persönliches Profil.";es="Sin inicio de sesión. Sin cuenta. Sin perfil personal.";fr="Pas de connexion. Pas de compte. Pas de profil personnel.";}
        else if(key.equals("Data is stored only on this device.")){hr="Podaci se spremaju samo na ovom uređaju.";de="Daten werden nur auf diesem Gerät gespeichert.";es="Los datos se guardan solo en este dispositivo.";fr="Les données sont stockées uniquement sur cet appareil.";}
        else if(key.equals("Scores, language, theme and selected team are saved locally.")){hr="Prognoze, jezik, tema i odabrana reprezentacija spremaju se lokalno na uređaju.";de="Prognosen, Sprache, Design und ausgewähltes Team werden lokal auf dem Gerät gespeichert.";es="Predicciones, idioma, tema y equipo elegido se guardan localmente en el dispositivo.";fr="Pronostics, langue, thème et équipe choisie sont enregistrés localement sur l’appareil.";}
        else if(key.equals("This app is not affiliated with FIFA.")){en="This app is not affiliated with, endorsed by, or sponsored by FIFA.";hr="Ova aplikacija nije povezana, odobrena niti sponzorirana od strane FIFA-e.";de="Diese App ist nicht mit FIFA verbunden, von FIFA genehmigt oder gesponsert.";es="Esta aplicación no está afiliada, aprobada ni patrocinada por la FIFA.";fr="Cette application n'est pas affiliée, approuvée ni sponsorisée par la FIFA.";}
        else if(key.equals("Independent fan app subtitle")){en="Independent app for following the 2026 World Cup.";hr="Neovisna aplikacija za praćenje Svjetskog prvenstva 2026.";de="Unabhängige App zur Verfolgung der Weltmeisterschaft 2026.";es="Aplicación independiente para seguir la Copa Mundial 2026.";fr="Application indépendante pour suivre la Coupe du Monde 2026.";}
        else if(key.equals("About feature line")){en="Live data • Groups • Predictions • Knockout stage • My Team • Share Poster";hr="Live podaci • Skupine • Prognoze • Nokaut faza • Moja reprezentacija • Poster za dijeljenje";de="Live-Daten • Gruppen • Prognosen • K.-o.-Runde • Mein Team • Poster teilen";es="Datos en vivo • Grupos • Predicciones • Eliminatorias • Mi equipo • Póster para compartir";fr="Données en direct • Groupes • Pronostics • Phase finale • Mon équipe • Poster à partager";}
        else if(key.equals("Legal")){hr="Pravno";de="Rechtliches";es="Legal";fr="Mentions légales";}
        else if(key.equals("Legal notice detail")){en="This app uses independent data sources and does not include official FIFA logos, official team crests, player photos or live streaming.";hr="Aplikacija koristi neovisne izvore podataka i ne sadrži službene FIFA logotipe, službene grbove reprezentacija, fotografije igrača ni prijenos uživo.";de="Diese App verwendet unabhängige Datenquellen und enthält keine offiziellen FIFA-Logos, keine offiziellen Teamwappen, keine Spielerfotos und kein Live-Streaming.";es="La aplicación utiliza fuentes de datos independientes y no incluye logotipos oficiales de FIFA, escudos oficiales de selecciones, fotos de jugadores ni transmisión en vivo.";fr="L'application utilise des sources de données indépendantes et ne contient aucun logo officiel de la FIFA, aucun écusson officiel d'équipe, aucune photo de joueur et aucun streaming en direct.";}
        else if(key.equals("Privacy info text")){en="World Cup Fan 2026 stores your selected team, language, theme and personal predictions on this device. Online results are loaded only to display match data inside the app. There is no login, user account or personal profile.";hr="World Cup Fan 2026 sprema odabranu reprezentaciju, jezik, temu i korisničke prognoze na ovom uređaju. Online rezultati se dohvaćaju samo za prikaz podataka u aplikaciji. Nema prijave, korisničkog računa ni osobnog profila.";de="World Cup Fan 2026 speichert das ausgewählte Team, die Sprache, das Design und deine Prognosen auf diesem Gerät. Online-Ergebnisse werden nur zur Anzeige in der App geladen. Keine Anmeldung, kein Konto und kein persönliches Profil.";es="World Cup Fan 2026 guarda el equipo elegido, el idioma, el tema y tus predicciones en este dispositivo. Los resultados en línea se cargan solo para mostrarlos en la aplicación. Sin inicio de sesión, sin cuenta y sin perfil personal.";fr="World Cup Fan 2026 enregistre l'équipe choisie, la langue, le thème et tes pronostics sur cet appareil. Les résultats en ligne sont chargés uniquement pour l'affichage dans l'application. Pas de connexion, pas de compte et pas de profil personnel.";}
        else if(key.equals("Legal safety text")){en="Independent fan app. No official FIFA logos, official team crests, player photos, live streaming, betting or gambling.";hr="Neovisna navijačka aplikacija. Nema službeni FIFA logotip, službene grbove, fotografije igrača, prijenos uživo, klađenje ni igre na sreću.";de="Unabhängige Fan-App. Keine offiziellen FIFA-Logos, keine offiziellen Wappen, keine Spielerfotos, kein Live-Streaming, keine Wetten und kein Glücksspiel.";es="Aplicación independiente de fans. Sin logotipos oficiales de FIFA, escudos oficiales, fotos de jugadores, transmisión en vivo, apuestas ni juegos de azar.";fr="Application indépendante de fans. Aucun logo officiel de la FIFA, aucun écusson officiel, aucune photo de joueur, aucun streaming en direct, aucun pari ni jeu d'argent.";}
        else if(key.equals("No betting streaming media")){hr="Aplikacija ne nudi klađenje, prijenos uživo ni službeni turnirski medijski sadržaj.";de="Die App bietet keine Wetten, kein Live-Streaming und keine offiziellen Turniermedien.";es="La aplicación no ofrece apuestas, transmisión en vivo ni contenido multimedia oficial del torneo.";fr="L'application ne propose aucun pari, aucun streaming en direct et aucun contenu média officiel du tournoi.";}

        
        else if(key.equals("Pro Bracket")){hr="Pro kostur";de="Pro-Turnierbaum";es="Cuadro Pro";fr="Tableau Pro";}
        else if(key.equals("Round of 32")){hr="Šesnaestina finala";de="Runde der 32";es="Dieciseisavos";fr="Seizièmes de finale";}
        else if(key.equals("Round of 16")){hr="Osmina finala";de="Achtelfinale";es="Octavos de final";fr="Huitièmes de finale";}
        else if(key.equals("Quarter-finals")){hr="Četvrtfinale";de="Viertelfinale";es="Cuartos de final";fr="Quarts de finale";}
        else if(key.equals("Semi-finals")){hr="Polufinale";de="Halbfinale";es="Semifinales";fr="Demi-finales";}
        else if(key.equals("Final")){hr="Finale";de="Finale";es="Final";fr="Finale";}
        else if(key.equals("Projected path from your group results.")){hr="Kostur prema upisanim rezultatima skupina.";de="Turnierweg nach deinen Gruppenergebnissen.";es="Camino según tus resultados de grupo.";fr="Parcours selon tes résultats de groupe.";}
        
        else if(key.equals("Tournament is live")){hr="Prvenstvo je u tijeku";de="Das Turnier läuft";es="El torneo está en marcha";fr="Le tournoi est en cours";}
        else if(key.equals("Day 1 of the World Cup")){hr="Dan 1 Svjetskog prvenstva";de="Tag 1 der Weltmeisterschaft";es="Día 1 del Mundial";fr="Jour 1 de la Coupe du Monde";}
        else if(key.equals("Global Edition")){hr="Globalno izdanje";de="Globale Ausgabe";es="Edición global";fr="Édition mondiale";}
        else if(key.equals("Progress")){hr="Napredak";de="Fortschritt";es="Progreso";fr="Progression";}
        else if(key.equals("Played")){hr="Odigrano";de="Gespielt";es="Jugados";fr="Joués";}
        else if(key.equals("Goals")){hr="Golovi";de="Tore";es="Goles";fr="Buts";}
        else if(key.equals("Road to Final")){hr="Put do finala";de="Weg ins Finale";es="Camino a la final";fr="Route vers la finale";}
        else if(key.equals("Scores to tables")){hr="Upiši rezultate, provjeri skupine i podijeli poster.";de="Tippe Ergebnisse ein, prüfe Gruppen und teile dein Poster.";es="Introduce resultados, revisa grupos y comparte tu póster.";fr="Entre les scores, vérifie les groupes et partage ton poster.";}
        else if(key.equals("Winner")){hr="Pobjednik";de="Sieger";es="Ganador";fr="Vainqueur";}
        else if(key.equals("Not selected")){hr="nije odabran";de="nicht gewählt";es="no seleccionado";fr="non choisi";}
        else if(key.equals("Question")){hr="Pitanje";de="Frage";es="Pregunta";fr="Question";}
        else if(key.equals("Score")){hr="Bodovi";de="Punkte";es="Puntuación";fr="Score";}
        else if(key.equals("Correct")){hr="Točno";de="Richtig";es="Correcto";fr="Correct";}
        else if(key.equals("Wrong")){hr="Netočno";de="Falsch";es="Incorrecto";fr="Incorrect";}
        else if(key.equals("Try again")){hr="Pokušaj ponovno";de="Erneut versuchen";es="Intentar de nuevo";fr="Réessayer";}

        else if(key.equals("Host Cities")){hr="Gradovi domaćini";de="Gastgeberstädte";es="Ciudades sede";fr="Villes hôtes";}
        else if(key.equals("16 host cities")){hr="16 gradova domaćina";de="16 Gastgeberstädte";es="16 ciudades sede";fr="16 villes hôtes";}
        else if(key.equals("Country")){hr="Država";de="Land";es="País";fr="Pays";}
        else if(key.equals("Capacity")){hr="Kapacitet";de="Kapazität";es="Capacidad";fr="Capacité";}
        else if(key.equals("Matches count")){hr="Broj utakmica";de="Anzahl Spiele";es="Número de partidos";fr="Nombre de matchs";}

        if(lang.equals("HR")) return hr; if(lang.equals("DE")) return de; if(lang.equals("ES")) return es; if(lang.equals("FR")) return fr; return en;
    }

    void build(){
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        setContentView(root);
        hideSystemBars();

        LinearLayout header=new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(20),dp(12),dp(20),dp(8));
        header.setBackground(gradient(Color.rgb(20,22,38),PURPLE_DARK,0));
        header.setElevation(dp(5));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(96)));
        title=label("Football Fun",25,Color.WHITE,true);
        title.setLetterSpacing(0.01f);
        title.setGravity(Gravity.CENTER);
        subtitle=label("Version "+APP_VERSION+"  •  "+lang,13,Color.rgb(225,229,238),false);
        subtitle.setGravity(Gravity.CENTER);
        header.addView(title,new LinearLayout.LayoutParams(-1,0,1));
        header.addView(subtitle,new LinearLayout.LayoutParams(-1,-2));

        ScrollView sv=new ScrollView(this);
        content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14),dp(12),dp(14),dp(96));
        sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        bottom=new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setPadding(dp(8),dp(7),dp(8),dp(7));
        bottom.setBackgroundColor(navBg);
        bottom.setElevation(dp(12));
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(76)));
        nav("🏠","Home"); nav("⚽","Matches"); nav("🏆","Leagues"); nav("⭐","Favorites"); nav("☰","More");
    }

    void nav(String icon,String name){
        boolean selected=currentScreen.equals(name)||(currentScreen.equals("MatchDetails")&&name.equals("Matches"))||(currentScreen.equals("Predict")&&name.equals("Predict"));
        TextView b=label(icon+"\n"+tr(name),selected?12:11,selected?Color.WHITE:subText,true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(selected?gradient(PURPLE_DARK,RED,dp(20)):round(Color.TRANSPARENT,dp(20),0));
        if(selected){ b.setElevation(dp(4)); b.setScaleX(1.04f); b.setScaleY(1.04f); }
        b.setOnClickListener(v->{ if(name.equals("Home"))showHome(); else if(name.equals("Matches"))showMatches(); else if(name.equals("Leagues"))showLeagues(); else if(name.equals("Favorites"))showFavorites(); else showMore(); });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-1,1); lp.setMargins(dp(3),0,dp(3),0);
        bottom.addView(b,lp);
    }

    void redraw(){
        applyTheme();
        build();
        if(currentScreen.equals("Home"))showHome();
        else if(currentScreen.equals("Matches"))showMatches();
        else if(currentScreen.equals("MatchDetails")){
            Match open=findOpenMatchDetails();
            if(open!=null)showMatchDetails(open); else showMatches();
        }
        else if(currentScreen.equals("Leagues"))showLeagues();
        else if(currentScreen.equals("Favorites"))showFavorites();
        else showMore();
    }

    TextView label(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(dp(1),1.10f);t.setLetterSpacing(sp>=20?0.01f:0f);t.setPadding(dp(3),dp(5),dp(3),dp(5));if(bold)t.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(14);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(18),dp(11),dp(18),dp(11));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(gradient(PURPLE_DARK,RED,dp(18)));b.setElevation(dp(4));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.98f).scaleY(.98f).setDuration(80).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();}return false;});return b;}
    Button outline(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setTextColor(text);b.setAllCaps(false);b.setMinHeight(dp(48));b.setPadding(dp(15),dp(10),dp(15),dp(10));b.setTypeface(Typeface.DEFAULT_BOLD);b.setBackground(round(chipBg,dp(18),1));b.setStateListAnimator(null);b.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().alpha(.78f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().alpha(1f).setDuration(90).start();}return false;});return b;}
    TextView chip(String s){TextView t=label(s,13,text,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(13),dp(10),dp(13),dp(10));t.setBackground(round(chipBg,dp(18),1));return t;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(19),dp(18),dp(19),dp(18));l.setBackground(round(cardBg,dp(22),1));l.setElevation(dp(3));l.setClipToOutline(true);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(16));content.addView(l,lp);return l;}
    LinearLayout hrow(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    void clear(String h,String s,String key){
        if(!"MatchDetails".equals(key)) stopLiveMatchDetailsRefresh();
        currentScreen=key;
        title.setText(h);
        subtitle.setText(s);
        content.removeAllViews();
        content.setAlpha(0f);
        content.setTranslationY(dp(8));
        content.animate().alpha(1f).translationY(0f).setDuration(180).start();
        hideSystemBars();
    }

    String t2(String en,String hr,String de,String es,String fr){if(lang.equals("HR"))return hr;if(lang.equals("DE"))return de;if(lang.equals("ES"))return es;if(lang.equals("FR"))return fr;return en;}
    String lastUpdateLabel(String last){
        if(last!=null && last.trim().length()>0){
            String local=displayLocalDateTime(last);
            return t2("🕒 Last update: "+local,"🕒 Zadnje ažuriranje: "+local,"🕒 Letzte Aktualisierung: "+local,"🕒 Última actualización: "+local,"🕒 Dernière mise à jour : "+local);
        }
        return t2("🕒 Last update: not yet refreshed","🕒 Još nije ažurirano","🕒 Noch nicht aktualisiert","🕒 Aún no actualizado","🕒 Pas encore actualisé");
    }

void showHome(){
        clear("Football Fun","","Home");
        title.setGravity(Gravity.CENTER);
        subtitle.setVisibility(View.GONE);

        String club=primaryFavoriteClub();
        String league=clubLeague(club);
        String country=clubCountry(club);
        String countryFlag=clubCountryFlag(club);

        // Premium hero — selected favourite club stays the visual identity.
        LinearLayout hero=new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18),dp(16),dp(18),dp(17));
        hero.setBackground(gradient(Color.rgb(28,4,18),Color.rgb(205,0,54),dp(24)));
        hero.setElevation(dp(8));
        LinearLayout.LayoutParams heroLp=new LinearLayout.LayoutParams(-1,-2);
        heroLp.setMargins(0,0,0,dp(16));
        content.addView(hero,heroLp);

        LinearLayout heroTop=hrow();
        LinearLayout heroText=new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        TextView eyebrow=label(t2("MY CLUB","MOJ KLUB","MEIN KLUB","MI CLUB","MON CLUB"),13,Color.rgb(210,214,224),true);
        heroText.addView(eyebrow);
        TextView clubName=label(twoLineClubName(club),33,Color.WHITE,true);
        clubName.setLineSpacing(0,0.94f);
        clubName.setMaxLines(2);
        heroText.addView(clubName);
        heroText.addView(label("❤️  "+countryFlag+" "+country+"  •  "+league,15,Color.WHITE,true));
        heroTop.addView(heroText,new LinearLayout.LayoutParams(0,-2,1));
        View favouriteVisual=homeTeamVisual(club,dp(148),true);
        favouriteVisual.setElevation(dp(7));
        heroTop.addView(favouriteVisual,new LinearLayout.LayoutParams(dp(148),dp(148)));
        hero.addView(heroTop);

        String[] formLetters=recentForm(club,5);
        LinearLayout form=hrow();
        for(String letter:formLetters){
            int color=letter.equals("W")?Color.rgb(18,190,83):letter.equals("L")?Color.rgb(238,41,75):letter.equals("D")?Color.rgb(69,78,96):Color.rgb(45,50,63);
            TextView f=label(letter,14,Color.WHITE,true);
            f.setGravity(Gravity.CENTER);
            f.setBackground(round(color,dp(22),0));
            LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(dp(42),dp(42));
            flp.setMargins(dp(3),dp(7),dp(8),dp(9));
            form.addView(f,flp);
        }
        hero.addView(form);

        Match next=nextMatchForTeam(club);
        String nextOwner=club;
        if(next==null){
            next=nextMatchForTeam(myTeam);
            nextOwner=myTeam;
        }

        LinearLayout nextPanel=new LinearLayout(this);
        nextPanel.setOrientation(LinearLayout.VERTICAL);
        nextPanel.setPadding(dp(14),dp(11),dp(14),dp(13));
        nextPanel.setBackground(round(Color.rgb(8,12,22),dp(19),1));
        String nextTitle=t2("NEXT MATCH","SLJEDEĆA UTAKMICA","NÄCHSTES SPIEL","PRÓXIMO PARTIDO","PROCHAIN MATCH");
        if(next!=null && !sameTeam(nextOwner,club)) nextTitle+=" • "+nextOwner;
        nextPanel.addView(label(nextTitle,12,Color.rgb(174,183,201),true));
        if(next!=null){
            final Match selectedNext=next;
            LinearLayout matchup=hrow();
            matchup.setGravity(Gravity.CENTER);
            matchup.addView(dynamicTeamBlock(next.home,72),new LinearLayout.LayoutParams(0,-2,1));
            LinearLayout clock=new LinearLayout(this); clock.setOrientation(LinearLayout.VERTICAL); clock.setGravity(Gravity.CENTER);
            clock.addView(centerLabel(homeDateLabel(next),12,Color.rgb(184,191,205),false));
            TextView kickoff=centerLabel(homeCenterValue(next),matchIsLive(next)||matchIsFinished(next)?27:31,Color.WHITE,true);
            kickoff.setSingleLine(true);
            clock.addView(kickoff);
            clock.addView(centerLabel(homeCenterStatus(next),15,matchIsLive(next)?RED:Color.rgb(184,191,205),true));
            matchup.addView(clock,new LinearLayout.LayoutParams(dp(104),-2));
            matchup.addView(dynamicTeamBlock(next.away,72),new LinearLayout.LayoutParams(0,-2,1));
            matchup.setOnClickListener(v->showMatchDetails(selectedNext));
            nextPanel.addView(matchup);
        }else{
            nextPanel.addView(label(t2("No upcoming match is available from the current data source.","Trenutačni izvor podataka nema dostupnu sljedeću utakmicu.","Die aktuelle Datenquelle enthält kein nächstes Spiel.","La fuente actual no tiene un próximo partido disponible.","La source actuelle ne contient aucun prochain match."),15,Color.rgb(184,191,205),false));
        }
        hero.addView(nextPanel);

        // Today's matches now come only from the connected data source.
        LinearLayout matches=homeCard();
        LinearLayout sectionHead=hrow();
        TextView todayTitle=label(t2("TODAY'S MATCHES","DANAŠNJE UTAKMICE","HEUTIGE SPIELE","PARTIDOS DE HOY","MATCHS DU JOUR"),17,text,true);
        todayTitle.setMaxLines(2);
        todayTitle.setLineSpacing(0,0.94f);
        sectionHead.addView(todayTitle,new LinearLayout.LayoutParams(0,-2,1));
        TextView seeAll=label(t2("View all  ›","Pogledaj sve  ›","Alle anzeigen  ›","Ver todo  ›","Tout voir  ›"),14,RED,true);
        seeAll.setOnClickListener(v->{matchStatusFilter="Today";showMatches();});
        sectionHead.addView(seeAll);
        matches.addView(sectionHead);
        ArrayList<Match> today=todaysMatches();
        if(today.isEmpty()){
            TextView none=label(t2("No matches are scheduled for today.","Danas nema zakazanih utakmica.","Für heute sind keine Spiele angesetzt.","No hay partidos programados para hoy.","Aucun match n'est prévu aujourd'hui."),15,subText,false);
            none.setPadding(dp(4),dp(16),dp(4),dp(8));
            matches.addView(none);
        }else{
            for(int i=0;i<Math.min(3,today.size());i++) addDynamicHomeMatch(matches,today.get(i));
            if(today.size()>3) matches.addView(label("+"+(today.size()-3)+" "+t2("more matches","još utakmica","weitere Spiele","partidos más","matchs supplémentaires"),13,subText,false));
        }

        // Favourite club competition metadata; no fabricated table or result is shown here.
        LinearLayout leagueCard=homeCard();
        LinearLayout leagueHead=hrow();
        leagueHead.addView(label(t2("MY LEAGUE","MOJA LIGA","MEINE LIGA","MI LIGA","MA LIGUE"),14,subText,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView tableLink=label(t2("Open competition  ›","Otvori natjecanje  ›","Wettbewerb öffnen  ›","Abrir competición  ›","Ouvrir la compétition  ›"),14,RED,true);
        final String selectedLeague=league;
        final String selectedCountry=country;
        tableLink.setOnClickListener(v->showFavoriteLeagueStatus(selectedLeague,selectedCountry,club));
        leagueHead.addView(tableLink);
        leagueCard.addView(leagueHead);
        LinearLayout leagueRow=hrow(); leagueRow.setPadding(0,dp(8),0,0);
        View leagueBadge=leagueVisual(league,countryFlag,92);
        leagueRow.addView(leagueBadge,new LinearLayout.LayoutParams(dp(92),dp(92)));
        LinearLayout leagueCopy=new LinearLayout(this); leagueCopy.setOrientation(LinearLayout.VERTICAL); leagueCopy.setPadding(dp(14),0,0,0);
        leagueCopy.addView(label(league,24,text,true));
        leagueCopy.addView(label(countryFlag+"  "+country,15,subText,false));
        leagueCopy.addView(label(t2("Favourite club: ","Omiljeni klub: ","Lieblingsklub: ","Club favorito: ","Club favori : ")+club,13,subText,false));
        leagueRow.addView(leagueCopy,new LinearLayout.LayoutParams(0,-2,1));
        TextView bars=centerLabel("▂▅█",19,Color.WHITE,true); bars.setBackground(round(Color.rgb(66,10,88),dp(25),1));
        leagueRow.addView(bars,new LinearLayout.LayoutParams(dp(54),dp(54)));
        leagueRow.setOnClickListener(v->showFavoriteLeagueStatus(selectedLeague,selectedCountry,club));
        leagueCard.addView(leagueRow);
    }

    void showFavoriteLeagueStatus(String league,String country,String club){
        clear(league,country,"Leagues");
        LinearLayout hero=card();
        hero.setBackground(gradient(RED_DARK,RED,dp(24)));
        hero.addView(label("🏆 "+league,26,Color.WHITE,true));
        hero.addView(label(clubCountryFlag(club)+" "+club,19,Color.WHITE,true));
        hero.addView(label(t2("Favourite club competition","Natjecanje omiljenog kluba","Wettbewerb des Lieblingsklubs","Competición del club favorito","Compétition du club favori"),14,Color.WHITE,false));

        LinearLayout status=card();
        status.addView(label("🌐 "+t2("Verified data source","Provjereni izvor podataka","Verifizierte Datenquelle","Fuente de datos verificada","Source de données vérifiée"),22,text,true));
        if(competitionUsesFootballData(league)){
            status.addView(label(t2(
                    "Matches, results, live statuses and standings for this competition come from football-data.org. Football Fun displays only data that the connected source has actually published.",
                    "Utakmice, rezultati, statusi uživo i tablica za ovo natjecanje dolaze s football-data.org. Football Fun prikazuje samo podatke koje je povezani izvor stvarno objavio.",
                    "Spiele, Ergebnisse, Live-Status und Tabelle dieses Wettbewerbs stammen von football-data.org. Football Fun zeigt nur tatsächlich veröffentlichte Daten.",
                    "Los partidos, resultados, estados en vivo y la clasificación provienen de football-data.org. Football Fun muestra solo datos realmente publicados.",
                    "Les matchs, résultats, statuts en direct et le classement proviennent de football-data.org. Football Fun n’affiche que les données réellement publiées."),15,subText,false));
            Button matches=btn("⚽ "+t2("Open competition matches","Otvori utakmice natjecanja","Wettbewerbsspiele öffnen","Abrir partidos de la competición","Ouvrir les matchs de la compétition"));
            matches.setOnClickListener(v->{competitionFilter=league;matchStatusFilter="All";showMatches();});
            status.addView(matches);
            Button standings=outline("📊 "+t2("Open verified standings","Otvori provjerenu tablicu","Verifizierte Tabelle öffnen","Abrir clasificación verificada","Ouvrir le classement vérifié"));
            standings.setOnClickListener(v->showLeagueStandings(league));
            status.addView(standings);
        }else{
            status.addView(label(t2(
                    "HNL stays in Football Fun. Its fixtures, results and standings will use a separate reliable source; no placeholder table is shown.",
                    "HNL ostaje u Football Funu. Raspored, rezultati i tablica koristit će poseban pouzdan izvor; ne prikazujemo izmišljenu tablicu.",
                    "Die HNL bleibt in Football Fun. Spielplan, Ergebnisse und Tabelle erhalten eine eigene zuverlässige Quelle; keine Platzhalter-Tabelle wird gezeigt.",
                    "HNL permanece en Football Fun. Tendrá una fuente fiable propia para calendario, resultados y tabla; no se muestra una tabla inventada.",
                    "La HNL reste dans Football Fun. Une source fiable distincte fournira calendrier, résultats et classement; aucun faux classement n’est affiché."),15,subText,false));
            Button pending=outline("🇭🇷 "+t2("HNL source in preparation","HNL izvor u pripremi","HNL-Quelle in Vorbereitung","Fuente HNL en preparación","Source HNL en préparation"));
            pending.setEnabled(false);
            status.addView(pending);
        }
        Button competitions=outline(t2("View all competitions","Pogledaj sva natjecanja","Alle Wettbewerbe anzeigen","Ver todas las competiciones","Voir toutes les compétitions"));
        competitions.setOnClickListener(v->showLeagues());
        status.addView(competitions);
    }


    String primaryFavoriteClub(){
        if(favoriteClub!=null && favoriteClub.trim().length()>0) return favoriteClub.trim();
        if(favoriteClubs!=null && !favoriteClubs.isEmpty()) return favoriteClubs.iterator().next();
        return "Dinamo Zagreb";
    }

    String twoLineClubName(String name){
        if(name==null) return "Football Club";
        String n=name.trim();
        if(n.length()<=12) return n;
        int split=n.lastIndexOf(' ');
        if(split>3) return n.substring(0,split)+"\n"+n.substring(split+1);
        return n;
    }

    String clubLogoResource(String club,boolean hero){
        String k=teamKey(club);
        if(k.equals("dinamozagreb")||k.equals("dinamo")) return hero?"logo_dinamo":"logo_dinamo_match";
        if(k.equals("hajduksplit")||k.equals("hajduk")) return hero?"logo_hajduk_hero":"logo_hajduk_match";
        if(k.equals("realmadrid")) return hero?"logo_real_madrid_hero":"logo_real_madrid";
        if(k.equals("bayernmunich")||k.equals("bayernmunchen")||k.equals("bayern")) return hero?"logo_bayern_hero":"logo_bayern";
        if(k.equals("liverpool")) return hero?"logo_liverpool_hero":"logo_liverpool";
        if(k.equals("arsenal")) return hero?"logo_arsenal_hero":"logo_arsenal";
        if(k.equals("barcelona")||k.equals("fcbarcelona")) return hero?"logo_barcelona_hero":"logo_barcelona";
        if(k.equals("atleticomadrid")||k.equals("atletico")) return hero?"logo_atletico_hero":"logo_atletico";
        return "";
    }

    String clubLeague(String club){
        String k=teamKey(club);
        if(k.contains("dinamo")||k.contains("hajduk")||k.equals("rijeka")||k.equals("osijek")) return "HNL";
        if(k.equals("realmadrid")||k.contains("barcelona")||k.contains("atletico")) return "La Liga";
        if(k.contains("manchestercity")||k.equals("liverpool")||k.equals("arsenal")) return "Premier League";
        if(k.contains("bayern")||k.contains("borussiadortmund")) return "Bundesliga";
        if(k.equals("inter")||k.equals("intermilan")||k.equals("milan")||k.equals("acmilan")||k.equals("juventus")) return "Serie A";
        if(k.contains("parissaintgermain")||k.equals("psg")) return "Ligue 1";
        return t2("Club competition","Klupsko natjecanje","Klubwettbewerb","Competición de clubes","Compétition de clubs");
    }

    String clubCountry(String club){
        String league=clubLeague(club);
        if(league.equals("HNL")) return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(league.equals("La Liga")) return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(league.equals("Premier League")) return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(league.equals("Bundesliga")) return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(league.equals("Serie A")) return t2("Italy","Italija","Italien","Italia","Italie");
        if(league.equals("Ligue 1")) return t2("France","Francuska","Frankreich","Francia","France");
        return t2("Europe","Europa","Europa","Europa","Europe");
    }

    String clubCountryFlag(String club){
        String league=clubLeague(club);
        if(league.equals("HNL")) return "🇭🇷";
        if(league.equals("La Liga")) return "🇪🇸";
        if(league.equals("Premier League")) return "🇬🇧";
        if(league.equals("Bundesliga")) return "🇩🇪";
        if(league.equals("Serie A")) return "🇮🇹";
        if(league.equals("Ligue 1")) return "🇫🇷";
        return "⚽";
    }

    View leagueVisual(String league,String fallbackFlag,int size){
        if("Premier League".equals(league)) return homeLogo("logo_premier_league",dp(size));
        TextView badge=centerLabel(fallbackFlag,44,Color.WHITE,true);
        badge.setBackground(round(Color.rgb(28,33,46),dp(24),1));
        return badge;
    }

    View homeTeamVisual(String team,int sizePx,boolean hero){
        String logo=clubLogoResource(team,hero);
        if(logo.length()>0) return homeLogo(logo,sizePx);
        String symbol=flag(team);
        if(symbol.equals("🏳")) symbol="⚽";
        TextView badge=centerLabel(symbol,hero?58:38,Color.WHITE,true);
        badge.setGravity(Gravity.CENTER);
        return badge;
    }

    LinearLayout dynamicTeamBlock(String team,int sizeDp){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(sizeDp),false);
        visual.setElevation(dp(5));
        box.addView(visual,new LinearLayout.LayoutParams(dp(sizeDp),dp(sizeDp)));
        TextView n=centerLabel(shortName(team),14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    LinearLayout dynamicCompactTeamBlock(String team){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        View visual=homeTeamVisual(team,dp(52),false);
        visual.setElevation(dp(4));
        box.addView(visual,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView teamName=centerLabel(shortName(team),12,text,true);
        teamName.setMaxLines(2);
        teamName.setMinLines(2);
        teamName.setEllipsize(null);
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(2),dp(3),dp(2),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(40)));
        return box;
    }

    void addDynamicHomeMatch(LinearLayout parent,Match m){
        final Match selected=m;
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(12),dp(10),dp(12));
        row.setBackground(round(Color.rgb(16,21,33),dp(19),1));
        row.setElevation(dp(2));
        row.addView(dynamicCompactTeamBlock(m.home),new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        String badgeText=matchIsLive(m)?t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT"):matchIsFinished(m)?"FT":homeTimeLabel(m);
        TextView b=centerLabel(badgeText,11,Color.WHITE,true);
        b.setPadding(dp(8),dp(3),dp(8),dp(3));
        b.setBackground(round(matchIsLive(m)?Color.rgb(240,18,75):Color.rgb(66,74,92),dp(9),0));
        mid.addView(b,new LinearLayout.LayoutParams(dp(86),dp(26)));
        String center=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" - "+m.awayGoals:"VS";
        TextView scoreView=centerLabel(center,center.equals("VS")?23:30,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        mid.addView(scoreView);
        if(matchIsLive(m) && m.minute!=null && m.minute.trim().length()>0) mid.addView(centerLabel(m.minute.replace("'","")+"′",12,RED,true));
        row.addView(mid,new LinearLayout.LayoutParams(dp(94),-2));
        row.addView(dynamicCompactTeamBlock(m.away),new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatchDetails(selected));
        row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(11),0,0);
        parent.addView(row,lp);
    }

    boolean dataContainsTeam(String team){
        if(team==null) return false;
        for(Match m:data.matches) if(sameTeam(m.home,team)||sameTeam(m.away,team)) return true;
        return false;
    }

    Date localMatchDate(Match m){
        if(m==null || m.date==null) return null;
        String d=displayLocalDateTime(m.date).trim();
        try{
            if(d.length()>=16) return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(d.substring(0,16));
            if(d.length()>=10) return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(d.substring(0,10));
        }catch(Exception ignored){}
        return null;
    }

    String localDateKey(Match m){
        Date d=localMatchDate(m);
        return d==null?"":new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d);
    }

    boolean matchIsLive(Match m){ return m!=null && isLiveStatus(m.status); }
    boolean matchIsFinished(Match m){
        if(m==null) return false;
        if(matchIsLive(m)) return false;
        if(isFinishedStatus(m.status) && m.status!=null && m.status.trim().length()>0) return m.homeGoals>=0&&m.awayGoals>=0;
        return m.homeGoals>=0&&m.awayGoals>=0;
    }
    boolean matchIsUpcoming(Match m){ return m!=null && !matchIsLive(m) && !matchIsFinished(m); }

    boolean matchIsToday(Match m){
        String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        return today.equals(localDateKey(m));
    }

    boolean matchIsTomorrow(Match m){
        Calendar c=Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,1);
        String tomorrow=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());
        return tomorrow.equals(localDateKey(m));
    }

    ArrayList<Match> todaysMatches(){
        ArrayList<Match> out=new ArrayList<>();
        for(Match m:data.matches) if(matchIsToday(m)) out.add(m);
        Collections.sort(out,(a,b)->{
            Date da=localMatchDate(a), db=localMatchDate(b);
            if(da==null&&db==null)return 0; if(da==null)return 1; if(db==null)return -1; return da.compareTo(db);
        });
        return out;
    }

    Match nextMatchForTeam(String team){
        if(team==null || team.trim().length()==0) return null;
        Match best=null;
        Date bestDate=null;
        long now=System.currentTimeMillis();
        for(Match m:data.matches){
            if(!sameTeam(m.home,team)&&!sameTeam(m.away,team)) continue;
            if(matchIsLive(m)) return m;
            if(!matchIsUpcoming(m)) continue;
            Date d=localMatchDate(m);
            if(d==null || d.getTime()<now-2*60*60*1000L) continue;
            if(best==null || bestDate==null || d.before(bestDate)){best=m;bestDate=d;}
        }
        return best;
    }

    String[] recentForm(String team,int count){
        ArrayList<Match> finished=new ArrayList<>();
        for(Match m:data.matches) if(matchIsFinished(m)&&(sameTeam(m.home,team)||sameTeam(m.away,team))) finished.add(m);
        Collections.sort(finished,(a,b)->{
            Date da=localMatchDate(a),db=localMatchDate(b);
            if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);
        });
        String[] out=new String[count];
        Arrays.fill(out,"–");
        for(int i=0;i<Math.min(count,finished.size());i++){
            Match m=finished.get(i);
            int own=sameTeam(m.home,team)?m.homeGoals:m.awayGoals;
            int opp=sameTeam(m.home,team)?m.awayGoals:m.homeGoals;
            out[count-1-i]=own>opp?"W":own<opp?"L":"D";
        }
        return out;
    }


    String recentFormDisplay(String team){
        String[] f=recentForm(team,5);
        return f[0]+" • "+f[1]+" • "+f[2]+" • "+f[3]+" • "+f[4];
    }

    String homeDateLabel(Match m){
        Date d=localMatchDate(m);
        if(d==null) return t2("Date TBA","Datum naknadno","Datum offen","Fecha pendiente","Date à confirmer");
        return new SimpleDateFormat("EEE, dd.MM.",homeLocale()).format(d);
    }

    String homeTimeLabel(Match m){
        Date d=localMatchDate(m);
        if(d==null || m.date==null || displayLocalDateTime(m.date).length()<16) return t2("TBA","Naknadno","Offen","Pendiente","À confirmer");
        return new SimpleDateFormat("HH:mm",Locale.US).format(d);
    }

    Locale homeLocale(){
        if(lang.equals("HR"))return new Locale("hr","HR");
        if(lang.equals("DE"))return Locale.GERMANY;
        if(lang.equals("ES"))return new Locale("es","ES");
        if(lang.equals("FR"))return Locale.FRANCE;
        return Locale.ENGLISH;
    }

    String homeCenterValue(Match m){
        if(m.homeGoals>=0&&m.awayGoals>=0) return m.homeGoals+" - "+m.awayGoals;
        return homeTimeLabel(m);
    }

    String homeCenterStatus(Match m){
        if(m==null) return "VS";
        String status=m.status==null?"":m.status.trim().toUpperCase(Locale.US).replace(' ','_');
        String minute=(m.minute==null?"":m.minute.trim().replace("'","").replace("′", ""));
        if(status.equals("PAUSED")||status.equals("HALF_TIME")||status.equals("HT"))
            return t2("HALF-TIME","POLUVRIJEME","HALBZEIT","DESCANSO","MI-TEMPS");
        if(status.equals("EXTRA_TIME"))
            return t2("EXTRA TIME","PRODUŽECI","VERLÄNGERUNG","PRÓRROGA","PROLONGATION")+(minute.length()>0?" "+minute+"′":"");
        if(status.equals("PENALTY_SHOOTOUT")||status.equals("PENALTIES"))
            return t2("PENALTIES","JEDANAESTERCI","ELFMETERSCHIESSEN","PENALES","TIRS AU BUT");
        if(matchIsLive(m))
            return (minute.length()>0)?t2("LIVE ","UŽIVO ","LIVE ","EN VIVO ","DIRECT ")+minute+"′":t2("LIVE","UŽIVO","LIVE","EN VIVO","DIRECT");
        if(matchIsFinished(m))
            return t2("FULL TIME","ZAVRŠENO","BEENDET","FINALIZADO","TERMINÉ");
        return "VS";
    }

    LinearLayout homeCard(){
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(15),dp(16),dp(15));
        l.setBackground(round(Color.rgb(12,16,26),dp(23),1)); l.setElevation(dp(5));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(16)); content.addView(l,lp); return l;
    }

    ImageView homeLogo(String name,int size){
        ImageView iv=new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); iv.setAdjustViewBounds(true);
        int id=getResources().getIdentifier(name,"drawable",getPackageName()); if(id!=0) iv.setImageResource(id);
        iv.setPadding(dp(2),dp(2),dp(2),dp(2)); return iv;
    }

    TextView centerLabel(String s,int sp,int color,boolean bold){ TextView t=label(s,sp,color,bold); t.setGravity(Gravity.CENTER); return t; }

    LinearLayout teamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(72));
        crest.setElevation(dp(5));
        box.addView(crest,new LinearLayout.LayoutParams(dp(72),dp(72)));
        TextView n=centerLabel(name,14,Color.WHITE,true);
        n.setMaxLines(2);
        n.setMinLines(2);
        n.setEllipsize(null);
        n.setLineSpacing(0,0.92f);
        n.setPadding(dp(2),dp(2),dp(2),0);
        box.addView(n,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }

    void addPremiumMatch(LinearLayout parent,String leftLogo,String leftName,String score,String rightName,String rightLogo,String badge,String minute){
        LinearLayout row=hrow();
        row.setPadding(dp(10),dp(12),dp(10),dp(12));
        row.setBackground(round(Color.rgb(16,21,33),dp(19),1));
        row.setElevation(dp(2));

        LinearLayout leftTeam=compactTeamBlock(leftLogo,leftName);
        row.addView(leftTeam,new LinearLayout.LayoutParams(0,-2,1));

        LinearLayout mid=new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        if(badge!=null&&!badge.isEmpty()){
            TextView b=centerLabel(badge,11,Color.WHITE,true);
            b.setPadding(dp(12),dp(3),dp(12),dp(3));
            b.setBackground(round(badge.equals("LIVE")?Color.rgb(240,18,75):Color.rgb(66,74,92),dp(9),0));
            b.setElevation(dp(3));
            mid.addView(b,new LinearLayout.LayoutParams(dp(86),dp(26)));
        }
        TextView scoreView=centerLabel(score,30,Color.WHITE,true);
        scoreView.setLetterSpacing(0.04f);
        mid.addView(scoreView);
        if(minute!=null&&!minute.isEmpty())mid.addView(centerLabel(minute,12,subText,false));
        row.addView(mid,new LinearLayout.LayoutParams(dp(94),-2));

        LinearLayout rightTeam=compactTeamBlock(rightLogo,rightName);
        row.addView(rightTeam,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatches());
        row.setOnTouchListener((v,e)->{if(e.getAction()==0){v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();}else if(e.getAction()==1||e.getAction()==3){v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();}return false;});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(11),0,0);
        parent.addView(row,lp);
    }

    LinearLayout compactTeamBlock(String logo,String name){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        ImageView crest=homeLogo(logo,dp(52));
        crest.setElevation(dp(4));
        box.addView(crest,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView teamName=centerLabel(name,12,text,true);
        teamName.setMaxLines(2);
        teamName.setMinLines(2);
        teamName.setEllipsize(null);
        teamName.setLineSpacing(0,0.92f);
        teamName.setPadding(dp(2),dp(3),dp(2),0);
        box.addView(teamName,new LinearLayout.LayoutParams(-1,dp(40)));
        return box;
    }


    int realLiveCount(){ int c=0; for(Match m:data.matches) if(matchIsLive(m)) c++; return c; }
    Match firstLiveMatch(){ for(Match m:data.matches) if(matchIsLive(m)) return m; return null; }
    String primaryFollowedCompetition(){ if(followedCompetitions!=null&&!followedCompetitions.isEmpty())return followedCompetitions.iterator().next(); return "HNL"; }
    String competitionTeams(String c){
        if(c.equals("HNL"))return "10";
        if(c.equals("UEFA Champions League"))return "36";
        if(c.equals("World Cup 2026"))return "48";
        if(c.equals("UEFA European Championship"))return "24";
        if(c.equals("Championship"))return "24";
        if(c.equals("Bundesliga")||c.equals("Ligue 1")||c.equals("Eredivisie")||c.equals("Primeira Liga"))return "18";
        return "20";
    }
    String competitionApiCode(String c){
        if(c.equals("World Cup 2026"))return "WC";
        if(c.equals("UEFA European Championship"))return "EC";
        if(c.equals("UEFA Champions League"))return "CL";
        if(c.equals("Premier League"))return "PL";
        if(c.equals("Championship"))return "ELC";
        if(c.equals("La Liga"))return "PD";
        if(c.equals("Bundesliga"))return "BL1";
        if(c.equals("Serie A"))return "SA";
        if(c.equals("Ligue 1"))return "FL1";
        if(c.equals("Eredivisie"))return "DED";
        if(c.equals("Primeira Liga"))return "PPL";
        if(c.equals("Brasileirão Série A"))return "BSA";
        return "HNL";
    }
    boolean competitionUsesFootballData(String c){return !c.equals("HNL");}
    boolean isNationalCompetition(String c){return c.equals("World Cup 2026")||c.equals("UEFA European Championship");}
    String competitionRound(String c){ if(isNationalCompetition(c))return t2("Tournament","Turnir","Turnier","Torneo","Tournoi"); return t2("League season","Ligaška sezona","Ligasaison","Temporada de liga","Saison de ligue"); }
    String competitionRegion(String c){
        if(c.equals("HNL"))return t2("Croatia","Hrvatska","Kroatien","Croacia","Croatie");
        if(c.equals("Premier League")||c.equals("Championship"))return t2("England","Engleska","England","Inglaterra","Angleterre");
        if(c.equals("La Liga"))return t2("Spain","Španjolska","Spanien","España","Espagne");
        if(c.equals("Serie A"))return t2("Italy","Italija","Italien","Italia","Italie");
        if(c.equals("Bundesliga"))return t2("Germany","Njemačka","Deutschland","Alemania","Allemagne");
        if(c.equals("Ligue 1"))return t2("France","Francuska","Frankreich","Francia","France");
        if(c.equals("Eredivisie"))return t2("Netherlands","Nizozemska","Niederlande","Países Bajos","Pays-Bas");
        if(c.equals("Primeira Liga"))return t2("Portugal","Portugal","Portugal","Portugal","Portugal");
        if(c.equals("Brasileirão Série A"))return t2("Brazil","Brazil","Brasilien","Brasil","Brésil");
        if(isNationalCompetition(c))return t2("International","Međunarodno","International","Internacional","International");
        return t2("Europe","Europa","Europa","Europa","Europe");
    }
    String competitionMeta(String c){ return competitionRegion(c)+"  •  "+competitionTeams(c)+" "+t2(isNationalCompetition(c)?"teams":"clubs",isNationalCompetition(c)?"reprezentacija":"klubova",isNationalCompetition(c)?"Teams":"Klubs",isNationalCompetition(c)?"selecciones":"clubes",isNationalCompetition(c)?"équipes":"clubs")+"  •  "+(competitionUsesFootballData(c)?"football-data.org "+competitionApiCode(c):t2("Dedicated HNL source","Poseban HNL izvor","Eigene HNL-Quelle","Fuente HNL dedicada","Source HNL dédiée")); }
    boolean matchBelongsToCompetition(Match m,String selected){
        if(selected==null||selected.equals("All"))return true;
        String raw=(m.competition==null?"":m.competition).toLowerCase(Locale.US);
        String name=selected.toLowerCase(Locale.US);
        String code=competitionApiCode(selected).toLowerCase(Locale.US);
        if(raw.equals(code)||raw.contains(name))return true;
        if(selected.equals("World Cup 2026"))return raw.contains("world cup")||raw.equals("wc");
        if(selected.equals("UEFA European Championship"))return raw.contains("european championship")||raw.contains("euro")||raw.equals("ec");
        if(selected.equals("La Liga"))return raw.contains("primera division")||raw.contains("primera división")||raw.equals("pd");
        if(selected.equals("Brasileirão Série A"))return raw.contains("brasileiro")||raw.contains("brazil")||raw.equals("bsa");
        return false;
    }
    Match lastFavoriteResult(){
        String preferred=dataContainsTeam(primaryFavoriteClub())?primaryFavoriteClub():myTeam;
        ArrayList<Match> found=new ArrayList<>();
        for(Match m:data.matches) if(matchIsFinished(m)&&(sameTeam(m.home,preferred)||sameTeam(m.away,preferred))) found.add(m);
        Collections.sort(found,(a,b)->{Date da=localMatchDate(a),db=localMatchDate(b);if(da==null&&db==null)return 0;if(da==null)return 1;if(db==null)return -1;return db.compareTo(da);});
        return found.isEmpty()?null:found.get(0);
    }
    void addResultRow(LinearLayout parent,Match m){ LinearLayout row=hrow(); row.setPadding(dp(10),dp(10),dp(10),dp(10)); row.setBackground(round(chipBg,dp(16),0)); TextView left=label(flag(m.home)+" "+safeTeam(m.home),15,text,true); TextView score=label(m.homeGoals+" : "+m.awayGoals,18,RED,true); TextView right=label(flag(m.away)+" "+safeTeam(m.away),15,text,true); right.setGravity(Gravity.RIGHT); row.addView(left,new LinearLayout.LayoutParams(0,-2,1)); row.addView(score); row.addView(right,new LinearLayout.LayoutParams(0,-2,1)); parent.addView(row); }

    void addHomeMatchRow(LinearLayout parent,Match m,boolean highlight){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(dp(12),dp(10),dp(12),dp(10));
        row.setBackground(round(highlight?Color.argb(46,255,48,94):chipBg,dp(18),highlight?1:0));
        TextView meta=label(displayLocalDateTime(m.date)+(m.venue!=null&&m.venue.length()>0?" • "+m.venue:""),12,subText,true); row.addView(meta);
        LinearLayout teams=hrow();
        String homeName=safeTeam(m.home), awayName=safeTeam(m.away);
        TextView left=label(flag(homeName)+" "+homeName,15,text,true); TextView right=label(flag(awayName)+" "+awayName,15,text,true); right.setGravity(Gravity.RIGHT);
        teams.addView(left,new LinearLayout.LayoutParams(0,-2,1)); TextView versus=label("VS",12,Color.WHITE,true); versus.setGravity(Gravity.CENTER); versus.setPadding(dp(9),dp(4),dp(9),dp(4)); versus.setBackground(gradient(PURPLE_DARK,RED,dp(12))); teams.addView(versus); teams.addView(right,new LinearLayout.LayoutParams(0,-2,1)); row.addView(teams);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(5),0,dp(5)); parent.addView(row,lp);
    }

    int favoriteCoverageScore(){
        int score=20;
        if(myTeam!=null&&!myTeam.trim().isEmpty())score+=25;
        if(favoriteClubs!=null&&!favoriteClubs.isEmpty())score+=30;
        if(followedCompetitions!=null&&!followedCompetitions.isEmpty())score+=25;
        return Math.min(100,score);
    }


    int homeLiveCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsLive(m)) c++;
        return c;
    }

    boolean isFinalStageLabel(String s){
        if(s==null)return false;
        String x=s.toLowerCase(Locale.US);
        return x.contains("final") || x.contains("round") || x.contains("group") || x.contains("stadium") || x.contains("arena");
    }

    int homeTodayCount(){
        int c=0;
        for(Match m:data.matches) if(matchIsToday(m)) c++;
        return c;
    }

    Match nextFavoriteMatch(){
        Match clubMatch=nextMatchForTeam(primaryFavoriteClub());
        return clubMatch!=null?clubMatch:nextMatchForTeam(myTeam);
    }

    LinearLayout pathPreview(String team){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(0,dp(6),0,dp(8));
        String[] rounds={"Round of 32","Round of 16","Quarter-final","Semi-final","Final"};
        String[] steps={
            "✅ Group "+groupOfTeam(team),
            (hasWonStage(team,"Round of 32")?"✅ ":"⬜ ")+"Round of 32",
            (hasWonStage(team,"Round of 16")?"✅ ":"⬜ ")+"Round of 16",
            (hasWonStage(team,"Quarter-final")?"✅ ":"⬜ ")+"Quarter-final",
            (hasWonStage(team,"Semi-final")?"✅ ":"⬜ ")+"Semi-final",
            (hasWonStage(team,"Final")?"🏆 ":"🏆 ")+"Final"
        };
        for(String s:steps)p.addView(label("   "+s,15,subText,false));
        return p;
    }

    LinearLayout kpiRow(String a,String av,String b,String bv,String c,String cv,boolean light){
        LinearLayout r=hrow();r.setPadding(0,dp(10),0,0);
        r.addView(kpi(a,av,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(b,bv,light),new LinearLayout.LayoutParams(0,dp(72),1));r.addView(kpi(c,cv,light),new LinearLayout.LayoutParams(0,dp(72),1));return r;
    }
    LinearLayout kpi(String n,String v,boolean light){LinearLayout k=new LinearLayout(this);k.setOrientation(LinearLayout.VERTICAL);k.setGravity(Gravity.CENTER);k.setPadding(dp(4),dp(4),dp(4),dp(4));k.setBackground(round(light?Color.argb(45,255,255,255):chipBg,dp(18),0));TextView val=label(v,22,light?Color.WHITE:RED,true);val.setGravity(Gravity.CENTER);TextView name=label(n,11,light?Color.WHITE:subText,false);name.setGravity(Gravity.CENTER);k.addView(val);k.addView(name);return k;}
    String daysTo(String date){try{Date d=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).parse(date);long diff=d.getTime()-System.currentTimeMillis();return String.valueOf(Math.max(0,diff/86400000));}catch(Exception e){return "0";}}

    void showLeagues(){
        clear(t2("Leagues & competitions","Lige i natjecanja","Ligen & Wettbewerbe","Ligas y competiciones","Ligues et compétitions"),t2("Only competitions available through your connected sources","Samo natjecanja dostupna kroz povezane izvore","Nur Wettbewerbe aus verbundenen Quellen","Solo competiciones de fuentes conectadas","Uniquement les compétitions des sources connectées"),"Leagues");
        LinearLayout summary=card();
        summary.addView(label("🏆 "+t2("Your competitions","Tvoja natjecanja","Deine Wettbewerbe","Tus competiciones","Tes compétitions"),22,text,true));
        summary.addView(label(followedCompetitionText(),15,subText,false));
        summary.addView(label("🌐 football-data.org  •  12  "+t2("available competitions","dostupnih natjecanja","verfügbare Wettbewerbe","competiciones disponibles","compétitions disponibles")+"\n📊 "+t2("Verified standings synchronize gradually within the API limit","Provjerene tablice sinkroniziraju se postupno unutar API ograničenja","Verifizierte Tabellen werden schrittweise innerhalb des API-Limits synchronisiert","Las clasificaciones verificadas se sincronizan gradualmente dentro del límite API","Les classements vérifiés se synchronisent progressivement dans la limite API")+"\n🇭🇷 HNL  •  "+t2("kept in the app; dedicated source will be connected","ostaje u aplikaciji; spojit će se poseban izvor","bleibt in der App; eigene Quelle folgt","permanece en la app; se conectará una fuente propia","reste dans l’application; une source dédiée sera connectée"),14,subText,false));

        addCompetitionSection(t2("Club competitions","Klupska natjecanja","Klubwettbewerbe","Competiciones de clubes","Compétitions de clubs"),new String[][]{
            {"⭐","UEFA Champions League"},{"🏴","Premier League"},{"🏴","Championship"},{"🇪🇸","La Liga"},{"🇩🇪","Bundesliga"},{"🇮🇹","Serie A"},{"🇫🇷","Ligue 1"},{"🇳🇱","Eredivisie"},{"🇵🇹","Primeira Liga"},{"🇧🇷","Brasileirão Série A"},{"🇭🇷","HNL"}
        });
        addCompetitionSection(t2("National-team competitions","Reprezentativna natjecanja","Nationalmannschaftswettbewerbe","Competiciones de selecciones","Compétitions de sélections"),new String[][]{
            {"🌍","World Cup 2026"},{"🇪🇺","UEFA European Championship"}
        });
    }

    void addCompetitionSection(String sectionTitle,String[][] comps){
        LinearLayout head=card();
        head.setPadding(dp(16),dp(12),dp(16),dp(12));
        head.addView(label(sectionTitle,20,text,true));
        for(String[] x:comps)addCompetitionCard(x[0],x[1]);
    }

    void addCompetitionCard(String icon,String competitionName){
        String region=competitionRegion(competitionName);
        LinearLayout c=card();
        c.addView(label(icon+" "+competitionName,22,text,true));
        c.addView(label(region+"  •  "+competitionTeams(competitionName)+" "+t2(isNationalCompetition(competitionName)?"teams":"clubs",isNationalCompetition(competitionName)?"reprezentacija":"klubova",isNationalCompetition(competitionName)?"Teams":"Klubs",isNationalCompetition(competitionName)?"selecciones":"clubes",isNationalCompetition(competitionName)?"équipes":"clubs"),15,subText,false));
        boolean connected=competitionUsesFootballData(competitionName);
        String sourceText=connected?"football-data.org  •  "+competitionApiCode(competitionName):t2("HNL source will be connected separately","HNL izvor spojit će se zasebno","HNL-Quelle wird separat verbunden","La fuente HNL se conectará por separado","La source HNL sera connectée séparément");
        c.addView(label((connected?"🟢 ":"🟡 ")+sourceText,13,connected?GREEN:Color.rgb(244,184,64),true));
        final String cn=competitionName, rg=region;
        boolean followed=followedCompetitions.contains(cn);
        LinearLayout actions=hrow();
        Button open=outline(t2("Open","Otvori","Öffnen","Abrir","Ouvrir"));
        open.setOnClickListener(v->showCompetitionHub(cn,rg));
        Button follow=btn(followed?t2("Following ✓","Pratim ✓","Gefolgt ✓","Siguiendo ✓","Suivi ✓"):t2("Follow","Prati","Folgen","Seguir","Suivre"));
        follow.setOnClickListener(v->{if(followedCompetitions.contains(cn))followedCompetitions.remove(cn);else followedCompetitions.add(cn);prefs.edit().putStringSet("followedCompetitions",new LinkedHashSet<String>(followedCompetitions)).apply();showLeagues();});
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(56),1));
        actions.addView(follow,new LinearLayout.LayoutParams(0,dp(56),1));
        c.addView(actions);
    }

    void showCompetitionHub(String competitionName,String region){
        clear(competitionName,region+"  •  "+competitionApiCode(competitionName),"Leagues");
        boolean connected=competitionUsesFootballData(competitionName);
        LinearLayout hero=card(); hero.setBackground(gradient(RED_DARK,RED,dp(24)));
        hero.addView(label("🏆 "+competitionName,25,Color.WHITE,true));
        hero.addView(label(t2("Competition hub","Centar natjecanja","Wettbewerbszentrale","Centro de competición","Centre de compétition"),15,Color.WHITE,false));
        hero.addView(kpiRow(t2("Following","Praćenje","Gefolgt","Siguiendo","Suivi"),followedCompetitions.contains(competitionName)?"ON":"OFF",t2("Source","Izvor","Quelle","Fuente","Source"),connected?"football-data.org":"HNL",t2("Status","Status","Status","Estado","Statut"),connected?"CONNECTED":"PREPARING",true));

        LinearLayout source=card();
        if(connected){
            source.addView(label("🟢 "+t2("API competition available","API natjecanje dostupno","API-Wettbewerb verfügbar","Competición API disponible","Compétition API disponible"),22,text,true));
            source.addView(label(t2("This competition is included in your football-data.org package. Fixtures, results, live statuses and standings will use API code ","Ovo natjecanje uključeno je u tvoj football-data.org paket. Raspored, rezultati, statusi uživo i tablica koristit će API kod ","Dieser Wettbewerb ist in deinem football-data.org-Paket enthalten. Spielplan, Ergebnisse, Live-Status und Tabelle verwenden den API-Code ","Esta competición está incluida en tu paquete football-data.org. Calendario, resultados, estados en vivo y tabla usarán el código API ","Cette compétition est incluse dans ton forfait football-data.org. Calendrier, résultats, statuts en direct et classement utiliseront le code API ")+competitionApiCode(competitionName)+".",15,subText,false));
            Button matches=btn("⚽ "+t2("Open competition matches","Otvori utakmice natjecanja","Wettbewerbsspiele öffnen","Abrir partidos de la competición","Ouvrir les matchs de la compétition"));
            matches.setOnClickListener(v->{competitionFilter=competitionName;matchStatusFilter="All";matchFilter="";showMatches();});
            source.addView(matches);
            Button standings=outline("📊 "+t2("Open verified standings","Otvori provjerenu tablicu","Verifizierte Tabelle öffnen","Abrir clasificación verificada","Ouvrir le classement vérifié"));
            standings.setOnClickListener(v->showLeagueStandings(competitionName));
            source.addView(standings);
            if(competitionName.equals("World Cup 2026")){
                Button groups=outline("🌍 "+t2("Open World Cup groups","Otvori skupine Svjetskog prvenstva","WM-Gruppen öffnen","Abrir grupos del Mundial","Ouvrir les groupes de la Coupe du monde"));
                groups.setOnClickListener(v->showGroups()); source.addView(groups);
            }
        }else{
            source.addView(label("🟡 "+t2("HNL remains available","HNL ostaje dostupan","HNL bleibt verfügbar","HNL sigue disponible","La HNL reste disponible"),22,text,true));
            source.addView(label(t2("HNL will not be removed. A separate reliable source will be connected for fixtures, results, live statuses and the table. Until then, Football Fun will not show invented HNL data.","HNL se ne uklanja. Za raspored, rezultate, statuse uživo i tablicu spojit će se poseban pouzdan izvor. Do tada Football Fun neće prikazivati izmišljene HNL podatke.","Die HNL wird nicht entfernt. Für Spielplan, Ergebnisse, Live-Status und Tabelle wird eine eigene zuverlässige Quelle verbunden. Bis dahin zeigt Football Fun keine erfundenen HNL-Daten.","HNL no se eliminará. Se conectará una fuente fiable separada para calendario, resultados, estados en vivo y tabla. Hasta entonces Football Fun no mostrará datos HNL inventados.","La HNL ne sera pas supprimée. Une source fiable distincte sera connectée pour le calendrier, les résultats, les statuts en direct et le classement. D’ici là, Football Fun n’affichera aucune donnée HNL inventée."),15,subText,false));
            Button pending=outline("🇭🇷 "+t2("HNL source in preparation","HNL izvor u pripremi","HNL-Quelle in Vorbereitung","Fuente HNL en preparación","Source HNL en préparation"));
            pending.setEnabled(false); source.addView(pending);
        }

        LinearLayout notify=card(); notify.addView(label("🔔 "+t2("Competition alerts","Obavijesti natjecanja","Wettbewerbshinweise","Alertas de competición","Alertes de compétition"),22,text,true));
        Button toggle=btn(followedCompetitions.contains(competitionName)?t2("Following ✓","Pratim ✓","Gefolgt ✓","Siguiendo ✓","Suivi ✓"):t2("Follow competition","Prati natjecanje","Wettbewerb folgen","Seguir competición","Suivre la compétition"));
        toggle.setOnClickListener(v->{ if(followedCompetitions.contains(competitionName)) followedCompetitions.remove(competitionName); else followedCompetitions.add(competitionName); prefs.edit().putStringSet("followedCompetitions",new LinkedHashSet<String>(followedCompetitions)).apply(); showCompetitionHub(competitionName,region); }); notify.addView(toggle);
    }

    JSONObject cachedOnlineRoot(){
        try{
            String raw=prefs.getString("online_rawJson","");
            if(raw==null||raw.trim().length()==0)return null;
            return new JSONObject(raw);
        }catch(Exception ignored){return null;}
    }

    JSONObject verifiedStandingsEntry(String competitionName){
        JSONObject root=cachedOnlineRoot();
        if(root==null)return null;
        JSONObject all=root.optJSONObject("standings");
        if(all==null)return null;
        JSONObject entry=all.optJSONObject(competitionApiCode(competitionName));
        if(entry==null)return null;
        JSONArray tables=entry.optJSONArray("standings");
        return tables!=null&&tables.length()>0?entry:null;
    }

    boolean hasVerifiedStandings(String competitionName){return verifiedStandingsEntry(competitionName)!=null;}

    void showLeagueStandings(String competitionName){
        clear(competitionName,t2("Verified standings","Provjerena tablica","Verifizierte Tabelle","Clasificación verificada","Classement vérifié"),"Leagues");

        LinearLayout source=card();
        source.addView(label("🛡️ "+t2("Verified data only","Samo provjereni podaci","Nur verifizierte Daten","Solo datos verificados","Données vérifiées uniquement"),22,text,true));
        source.addView(label(t2(
                "Football Fun never fills missing positions or statistics with demo values.",
                "Football Fun nikada ne popunjava nedostajuća mjesta ili statistiku demonstracijskim vrijednostima.",
                "Football Fun füllt fehlende Plätze oder Statistiken niemals mit Demo-Werten.",
                "Football Fun nunca rellena posiciones o estadísticas faltantes con valores de demostración.",
                "Football Fun ne remplit jamais les données manquantes avec des valeurs de démonstration."),15,subText,false));

        JSONObject entry=verifiedStandingsEntry(competitionName);
        if(entry==null){
            LinearLayout empty=card();
            if(competitionUsesFootballData(competitionName)){
                empty.addView(label("📊 "+t2("Standings are being synchronized","Tablica se sinkronizira","Tabelle wird synchronisiert","La clasificación se está sincronizando","Le classement se synchronise"),23,text,true));
                empty.addView(label(t2(
                        "The updater refreshes a small number of competition tables per run to respect the API request limit. Refresh the data again later; no invented table will be shown while waiting.",
                        "Updater pri svakom pokretanju osvježava manji broj tablica kako bi poštovao ograničenje API zahtjeva. Ponovno osvježi podatke kasnije; dok čekamo, neće se prikazivati izmišljena tablica.",
                        "Der Updater aktualisiert pro Lauf nur wenige Tabellen, um das API-Limit einzuhalten. Aktualisiere später erneut; währenddessen wird keine erfundene Tabelle angezeigt.",
                        "El actualizador refresca pocas tablas por ejecución para respetar el límite de la API. Actualiza de nuevo más tarde; no se mostrará una tabla inventada.",
                        "La mise à jour actualise peu de classements par exécution afin de respecter la limite API. Réessaie plus tard; aucun faux classement ne sera affiché."),15,subText,false));
                Button refresh=btn("🔄 "+t2("Refresh data","Osvježi podatke","Daten aktualisieren","Actualizar datos","Actualiser les données"));
                refresh.setOnClickListener(v->refreshOnlineSafe(true));
                empty.addView(refresh);
            }else{
                empty.addView(label("🇭🇷 "+t2("HNL source in preparation","HNL izvor u pripremi","HNL-Quelle in Vorbereitung","Fuente HNL en preparación","Source HNL en préparation"),23,text,true));
                empty.addView(label(t2("A separate reliable HNL source will supply this table.","Ovu tablicu dostavit će poseban pouzdan HNL izvor.","Eine eigene zuverlässige HNL-Quelle wird diese Tabelle liefern.","Una fuente HNL fiable separada proporcionará esta tabla.","Une source HNL fiable distincte fournira ce classement."),15,subText,false));
            }
            return;
        }

        String updated=entry.optString("updatedAt",prefs.getString("online_lastUpdate",""));
        JSONObject season=entry.optJSONObject("season");
        int matchday=season==null?0:season.optInt("currentMatchday",0);
        source.addView(label("football-data.org  •  "+competitionApiCode(competitionName)+(matchday>0?"  •  "+t2("Matchday ","Kolo ","Spieltag ","Jornada ","Journée ")+matchday:"")+"\n"+lastUpdateLabel(updated),13,subText,false));

        JSONArray standings=entry.optJSONArray("standings");
        boolean rendered=false;
        for(int i=0;i<standings.length();i++){
            JSONObject standing=standings.optJSONObject(i);
            if(standing==null)continue;
            String type=standing.optString("type","");
            if(type.length()>0&&!type.equalsIgnoreCase("TOTAL"))continue;
            JSONArray table=standing.optJSONArray("table");
            if(table==null||table.length()==0)continue;
            rendered=true;
            String group=standing.optString("group","");
            String stage=normalizeStage(standing.optString("stage",""));
            LinearLayout tableCard=card();
            String heading=(group!=null&&group.trim().length()>0)?group.replace('_',' '):(stage.length()>0?stage:t2("Overall table","Ukupna tablica","Gesamttabelle","Tabla general","Classement général"));
            tableCard.addView(label("🏆 "+heading,21,text,true));
            tableCard.addView(verifiedStandingHeader());
            for(int j=0;j<table.length();j++){
                JSONObject row=table.optJSONObject(j);
                if(row!=null)tableCard.addView(verifiedStandingRow(row));
            }
        }

        if(!rendered){
            LinearLayout empty=card();
            empty.addView(label(t2("The source returned no overall table for this competition.","Izvor nije vratio ukupnu tablicu za ovo natjecanje.","Die Quelle lieferte keine Gesamttabelle für diesen Wettbewerb.","La fuente no devolvió una tabla general para esta competición.","La source n’a fourni aucun classement général pour cette compétition."),15,subText,false));
        }
    }

    LinearLayout verifiedStandingHeader(){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(8),dp(6),dp(8));
        row.setBackground(round(chipBg,dp(12),0));
        row.addView(standingCell("#",11,subText,true,dp(30),0));
        row.addView(standingCell(t2("TEAM","KLUB","TEAM","EQUIPO","ÉQUIPE"),11,subText,true,0,1));
        row.addView(standingCell("P",11,subText,true,dp(34),0));
        row.addView(standingCell("GD",11,subText,true,dp(42),0));
        row.addView(standingCell("PTS",11,subText,true,dp(44),0));
        return row;
    }

    LinearLayout verifiedStandingRow(JSONObject item){
        LinearLayout row=hrow();
        row.setPadding(dp(6),dp(9),dp(6),dp(9));
        JSONObject team=item.optJSONObject("team");
        String teamName=team==null?"":team.optString("shortName",team.optString("name",team.optString("tla","")));
        boolean favourite=sameTeam(teamName,primaryFavoriteClub());
        if(favourite)row.setBackground(round(Color.argb(42,255,48,94),dp(12),1));
        row.addView(standingCell(String.valueOf(item.optInt("position",0)),13,favourite?RED:subText,true,dp(30),0));
        row.addView(standingCell(teamName,14,text,favourite,0,1));
        row.addView(standingCell(String.valueOf(item.optInt("playedGames",0)),13,text,false,dp(34),0));
        int gd=item.optInt("goalDifference",0);
        row.addView(standingCell((gd>0?"+":"")+gd,13,gd>0?GREEN:(gd<0?RED:subText),true,dp(42),0));
        row.addView(standingCell(String.valueOf(item.optInt("points",0)),14,text,true,dp(44),0));
        return row;
    }

    TextView standingCell(String value,int sp,int color,boolean bold,int widthDp,int weight){
        TextView view=label(value,sp,color,bold);
        view.setGravity(widthDp>0?Gravity.CENTER:Gravity.LEFT|Gravity.CENTER_VERTICAL);
        view.setSingleLine(true);
        view.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp=weight>0?new LinearLayout.LayoutParams(0,dp(38),weight):new LinearLayout.LayoutParams(widthDp,dp(38));
        view.setLayoutParams(lp);
        return view;
    }

    void showLeagueStats(String competitionName){
        clear(competitionName,t2("Verified competition statistics","Provjerena statistika natjecanja","Verifizierte Wettbewerbsstatistik","Estadísticas verificadas","Statistiques vérifiées"),"Leagues");
        LinearLayout c=card();
        c.addView(label("🛡️ "+t2("No placeholder statistics","Bez izmišljene statistike","Keine Platzhalter-Statistik","Sin estadísticas inventadas","Aucune statistique fictive"),23,text,true));
        c.addView(label(t2("Top scorers, assists and trends will appear only after the connected source publishes them.","Najbolji strijelci, asistencije i trendovi pojavit će se tek kada ih povezani izvor objavi.","Torschützen, Assists und Trends erscheinen erst, wenn die verbundene Quelle sie veröffentlicht.","Goleadores, asistencias y tendencias aparecerán solo cuando la fuente conectada los publique.","Buteurs, passes décisives et tendances apparaîtront uniquement lorsque la source les publiera."),15,subText,false));
    }

    String followedCompetitionText(){
        if(followedCompetitions==null || followedCompetitions.isEmpty()) return t2("No competitions followed yet","Još ne pratiš nijedno natjecanje","Noch keine Wettbewerbe gefolgt","Aún no sigues competiciones","Aucune compétition suivie");
        StringBuilder b=new StringBuilder();
        for(String c:followedCompetitions){if(b.length()>0)b.append("  •  ");b.append(c);}
        return b.toString();
    }

    String favoriteClubText(){
        if(favoriteClubs==null || favoriteClubs.isEmpty()) return favoriteClub;
        StringBuilder b=new StringBuilder(); int i=0;
        for(String c:favoriteClubs){ if(i>0)b.append(" • "); b.append(c); i++; if(i>=3){ if(favoriteClubs.size()>3)b.append(" +").append(favoriteClubs.size()-3); break; } }
        return b.toString();
    }

    void showFavorites(){
        clear(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),t2("Your club and national team","Tvoj klub i reprezentacija","Dein Klub und Nationalteam","Tu club y selección","Ton club et ton équipe nationale"),"Favorites");
        LinearLayout current=card(); current.setBackground(gradient(RED_DARK,RED,dp(24)));
        current.addView(label("⭐ "+favoriteClubText(),24,Color.WHITE,true));
        current.addView(label(flag(myTeam)+" "+myTeam,19,Color.WHITE,true));
        current.addView(label(t2("Match reminders and personalized news will use these favorites.","Podsjetnici za utakmice i personalizirane vijesti koristit će ove favorite.","Spielerinnerungen und personalisierte Nachrichten nutzen diese Favoriten.","Los recordatorios y noticias usarán estos favoritos.","Les rappels et actualités utiliseront ces favoris."),14,Color.WHITE,false));
        LinearLayout overview=card(); overview.addView(label("📈 "+t2("Favorite overview","Pregled favorita","Favoritenübersicht","Resumen de favoritos","Aperçu des favoris"),22,text,true));
        String overviewTeam=dataContainsTeam(primaryFavoriteClub())?primaryFavoriteClub():myTeam;
        overview.addView(label("🔥 "+t2("Form","Forma","Form","Forma","Forme")+" • "+overviewTeam+":  "+recentFormDisplay(overviewTeam),18,text,true));
        Match favLast=lastFavoriteResult(); if(favLast!=null){overview.addView(label("✅ "+t2("Last match","Zadnja utakmica","Letztes Spiel","Último partido","Dernier match"),14,subText,true));addResultRow(overview,favLast);}
        Match favNext=nextFavoriteMatch(); if(favNext!=null){overview.addView(label("📅 "+t2("Next match","Sljedeća utakmica","Nächstes Spiel","Próximo partido","Prochain match"),14,subText,true));addHomeMatchRow(overview,favNext,false);}

        LinearLayout notificationCard=card();
        notificationCard.addView(label("🔔 "+t2("Favorite notifications","Obavijesti za favorite","Favoriten-Benachrichtigungen","Notificaciones de favoritos","Notifications des favoris"),22,text,true));
        notificationCard.addView(label(favoriteNotifications?t2("Enabled","Uključene","Aktiviert","Activadas","Activées"):t2("Disabled","Isključene","Deaktiviert","Desactivadas","Désactivées"),15,subText,false));
        Button toggleNotifications=btn(favoriteNotifications?t2("Turn off","Isključi","Ausschalten","Desactivar","Désactiver"):t2("Turn on","Uključi","Einschalten","Activar","Activer"));
        toggleNotifications.setOnClickListener(v->{favoriteNotifications=!favoriteNotifications;prefs.edit().putBoolean("favoriteNotifications",favoriteNotifications).apply();showFavorites();});
        notificationCard.addView(toggleNotifications);

        LinearLayout clubCard=card(); clubCard.addView(label("🏟️ "+t2("Favorite clubs","Omiljeni klubovi","Lieblingsklubs","Clubes favoritos","Clubs favoris"),22,text,true));
        clubCard.addView(label(t2("Tap clubs to add or remove them. Your first club is the primary favorite.","Dodirni klub za dodavanje ili uklanjanje. Prvi klub je glavni favorit.","Tippe auf Klubs, um sie hinzuzufügen oder zu entfernen. Der erste Klub ist dein Hauptfavorit.","Toca clubes para añadirlos o quitarlos. El primero es tu favorito principal.","Touchez les clubs pour les ajouter ou les retirer. Le premier est votre favori principal."),14,subText,false));
        String[] clubs={"Dinamo Zagreb","Hajduk Split","Rijeka","Osijek","Real Madrid","Barcelona","Manchester City","Liverpool","Arsenal","Bayern Munich","Borussia Dortmund","Inter","Milan","Juventus","Paris Saint-Germain"};
        for(String clubName:clubs){
            final String cn=clubName; boolean selected=favoriteClubs.contains(cn);
            Button clubButton=selected?btn("✓ "+cn):outline("＋ "+cn);
            clubButton.setOnClickListener(v->{
                if(favoriteClubs.contains(cn)){ if(favoriteClubs.size()>1) favoriteClubs.remove(cn); } else favoriteClubs.add(cn);
                favoriteClub=favoriteClubs.iterator().next();
                prefs.edit().putStringSet("favoriteClubs",new LinkedHashSet<String>(favoriteClubs)).putString("favoriteClub",favoriteClub).apply();
                showFavorites();
            });
            clubCard.addView(clubButton);
        }

        LinearLayout teamCard=card(); teamCard.addView(label("🌍 "+tr("My Team"),22,text,true));
        Spinner team=spinner(data.teams,myTeam); teamCard.addView(team);
        Button saveTeam=btn(t2("Save national team","Spremi reprezentaciju","Nationalteam speichern","Guardar selección","Enregistrer l'équipe"));
        saveTeam.setOnClickListener(v->{myTeam=team.getSelectedItem().toString();prefs.edit().putString("team",myTeam).apply();toast(t2("National team saved","Reprezentacija spremljena","Nationalteam gespeichert","Selección guardada","Équipe enregistrée"));showFavorites();}); teamCard.addView(saveTeam);
    }

    void showMatches(){
        String matchTitle=competitionFilter.equals("All")?tr("Matches"):competitionFilter;
        String matchSubtitle=competitionFilter.equals("All")?tr("Smart Match Center"):t2("Competition matches","Utakmice natjecanja","Wettbewerbsspiele","Partidos de la competición","Matchs de la compétition");
        clear(matchTitle,matchSubtitle,"Matches");
        addOnlineCard();
        if(!competitionFilter.equals("All")){
            LinearLayout active=card();
            active.addView(label("🏆 "+competitionFilter,20,text,true));
            active.addView(label("API: "+competitionApiCode(competitionFilter)+"  •  "+competitionRegion(competitionFilter),14,subText,false));
            Button clearCompetition=outline(t2("Show all competitions","Prikaži sva natjecanja","Alle Wettbewerbe anzeigen","Mostrar todas las competiciones","Afficher toutes les compétitions"));
            clearCompetition.setOnClickListener(v->{competitionFilter="All";showMatches();});
            active.addView(clearCompetition);
        }
        LinearLayout filters=card(); filters.addView(label("⚡ "+t2("Quick filters","Brzi filteri","Schnellfilter","Filtros rápidos","Filtres rapides"),22,text,true));
        LinearLayout statusRow=hrow();
        statusRow.setWeightSum(5.10f);
        String[] statusKeys={"All","Live","Today","Tomorrow","Finished"};
        float[] statusWeights={0.85f,0.95f,0.95f,0.90f,1.45f};
        for(int i=0;i<statusKeys.length;i++){
            final String st=statusKeys[i];
            final String value=st;
            String title=t2(st,st.equals("All")?"Sve":st.equals("Live")?"Uživo":st.equals("Today")?"Danas":st.equals("Tomorrow")?"Sutra":"Završeno",st,st,st);
            TextView ch=label(title,11,text,true);
            ch.setGravity(Gravity.CENTER);
            ch.setSingleLine(true);
            ch.setPadding(dp(2),0,dp(2),0);
            ch.setBackground(round(chipBg,dp(18),1));
            if(st.equals(matchStatusFilter)){ch.setTextColor(Color.WHITE);ch.setBackground(gradient(RED_DARK,RED,dp(18)));}
            ch.setOnClickListener(v->{matchStatusFilter=value;showMatches();});
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(44),statusWeights[i]);
            cp.setMargins(dp(1),0,dp(1),0);
            statusRow.addView(ch,cp);
        }
        filters.addView(statusRow);
        EditText search=new EditText(this); search.setHint(tr("Search team, group or host city")); search.setText(matchFilter); search.setSingleLine(true); search.setTextColor(text); search.setHintTextColor(subText); search.setPadding(dp(14),0,dp(14),0); search.setBackground(round(chipBg,dp(16),0)); filters.addView(search,new LinearLayout.LayoutParams(-1,dp(54)));
        Button go=btn(tr("Apply Search")); go.setOnClickListener(v->{matchFilter=search.getText().toString();showMatches();}); filters.addView(go);

        String f=matchFilter.toLowerCase(Locale.US).trim(); int shown=0;
        for(Match m:data.matches){
            if(!matchBelongsToCompetition(m,competitionFilter))continue;
            if(!groupFilter.equals("All")&&!m.group.equals(groupFilter))continue;
            String hay=(m.group+" "+m.home+" "+m.away+" "+m.venue+" "+m.competition).toLowerCase(Locale.US); if(f.length()>0&&!hay.contains(f))continue;
            if(matchStatusFilter.equals("Finished")&&!matchIsFinished(m))continue;
            if(matchStatusFilter.equals("Live")&&!matchIsLive(m))continue;
            if(matchStatusFilter.equals("Today")&&!matchIsToday(m))continue;
            if(matchStatusFilter.equals("Tomorrow")&&!matchIsTomorrow(m))continue;
            shown++; matchCard(m);
        }
        if(shown==0){LinearLayout n=card();n.addView(label(t2("No matches found","Nema pronađenih utakmica","Keine Spiele gefunden","No se encontraron partidos","Aucun match trouvé"),21,text,true));n.addView(label(t2("Try another filter or search.","Pokušaj drugi filter ili pretragu.","Versuche einen anderen Filter.","Prueba otro filtro.","Essayez un autre filtre."),15,subText,false));}
    }

    void addGroupChip(LinearLayout row,String g,EditText search){TextView ch=chip(g);boolean sel=g.equals(groupFilter);ch.setTextColor(sel?Color.WHITE:text);if(sel)ch.setBackground(gradient(RED_DARK,RED,dp(18)));ch.setOnClickListener(v->{groupFilter=g;matchFilter=search.getText().toString();showMatches();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(2),dp(5),dp(2),dp(1));row.addView(ch,lp);}
    void matchCard(Match m){
        LinearLayout c=card();
        String shownDate=displayLocalDateTime(m.date);
        String phase=stageLabel(m);
        String venueText=(m.venue!=null && !m.venue.equals(phase) && !m.venue.equals("Group stage"))?m.venue:"";
        String status=(matchIsLive(m)||matchIsFinished(m))?homeCenterStatus(m):"";
        String meta=(status.length()>0?status+" • ":"")+(phase.length()>0?phase+" • ":"")+shownDate+(venueText.length()>0?" • "+venueText:"");
        c.addView(label(meta,12,matchIsLive(m)?RED:subText,true));
        LinearLayout teams=hrow();
        TextView left=label(flag(m.home)+"\n"+shortName(m.home),15,text,true);left.setGravity(Gravity.CENTER);
        String scoreText=(m.homeGoals>=0&&m.awayGoals>=0)?display(m.homeGoals)+" : "+display(m.awayGoals):"VS";
        TextView score=label(scoreText,scoreText.equals("VS")?24:30,RED,true);score.setGravity(Gravity.CENTER);
        TextView right=label(flag(m.away)+"\n"+shortName(m.away),15,text,true);right.setGravity(Gravity.CENTER);
        teams.addView(left,new LinearLayout.LayoutParams(0,dp(80),1));teams.addView(score,new LinearLayout.LayoutParams(0,dp(80),1));teams.addView(right,new LinearLayout.LayoutParams(0,dp(80),1));c.addView(teams);

        c.setClickable(true); c.setOnClickListener(v->showMatchDetails(m));
        TextView open=label(t2("Tap for match details","Dodirni za detalje utakmice","Für Spieldetails tippen","Toca para detalles","Touchez pour les détails"),12,RED,true); open.setGravity(Gravity.RIGHT); c.addView(open);
    }

    void showMatchDetails(Match m){
        if(m==null){showMatches();return;}
        rememberOpenMatch(m);
        clear(shortName(m.home)+" - "+shortName(m.away),stageLabel(m),"MatchDetails");
        LinearLayout hero=card(); hero.setBackground(gradient(RED_DARK,RED,dp(24)));
        String result=(m.homeGoals>=0&&m.awayGoals>=0)?m.homeGoals+" : "+m.awayGoals:"VS";
        hero.addView(label(flag(m.home)+" "+m.home+"   "+result+"   "+flag(m.away)+" "+m.away,22,Color.WHITE,true));

        ArrayList<String> metaParts=new ArrayList<>();
        if(matchIsLive(m)||matchIsFinished(m)) metaParts.add(homeCenterStatus(m));
        metaParts.add(displayLocalDateTime(m.date));
        String phase=stageLabel(m); if(phase.length()>0) metaParts.add(phase);
        if(m.actualVenue!=null && m.actualVenue.trim().length()>0) metaParts.add(m.actualVenue.trim());
        if(m.attendance>0) metaParts.add(t2("Attendance","Gledatelja","Zuschauer","Asistencia","Affluence")+": "+m.attendance);
        hero.addView(label(joinParts(metaParts," • "),14,Color.WHITE,false));
        if(m.refereeText!=null && m.refereeText.length()>0) hero.addView(label("🧑‍⚖️ "+m.refereeText,13,Color.WHITE,false));
        if(matchIsLive(m)) hero.addView(label("↻ "+t2("Auto-refresh every 60 seconds","Automatsko osvježavanje svakih 60 sekundi","Automatische Aktualisierung alle 60 Sekunden","Actualización automática cada 60 segundos","Actualisation automatique toutes les 60 secondes"),12,Color.WHITE,true));

        LinearLayout events=card();
        events.addView(label("⚡ "+t2("Match events","Događaji utakmice","Spielereignisse","Eventos del partido","Événements du match"),22,text,true));
        if(m.eventsText!=null && m.eventsText.trim().length()>0){
            events.addView(label(m.eventsText,15,text,false));
        }else{
            String empty=matchIsLive(m)
                    ?t2("The provider has not published goal, card or substitution details yet. Refresh again shortly.","Izvor još nije objavio detalje golova, kartona ili zamjena. Osvježi ponovno za nekoliko minuta.","Der Anbieter hat noch keine Tor-, Karten- oder Wechseldetails veröffentlicht.","El proveedor aún no ha publicado goles, tarjetas o cambios.","La source n’a pas encore publié les buts, cartons ou remplacements.")
                    :t2("Events will appear when supplied by the provider.","Događaji će se prikazati kada ih dostavi izvor podataka.","Ereignisse erscheinen, sobald sie geliefert werden.","Los eventos aparecerán cuando estén disponibles.","Les événements apparaîtront dès qu’ils seront disponibles.");
            events.addView(label(empty,15,subText,false));
        }

        LinearLayout stats=card();
        stats.addView(label("📊 "+t2("Match statistics","Statistika utakmice","Spielstatistik","Estadísticas del partido","Statistiques du match"),22,text,true));
        if(m.statsText!=null && m.statsText.trim().length()>0){
            stats.addView(label(m.statsText,15,text,false));
        }else{
            stats.addView(label(t2("Verified statistics are not available from the provider yet.","Provjerena statistika još nije dostupna od izvora podataka.","Verifizierte Statistiken sind noch nicht verfügbar.","Las estadísticas verificadas aún no están disponibles.","Les statistiques vérifiées ne sont pas encore disponibles."),15,subText,false));
        }

        LinearLayout lineups=card();
        lineups.addView(label("👕 "+t2("Lineups","Sastavi","Aufstellungen","Alineaciones","Compositions"),22,text,true));
        boolean hasLineups=(m.homeLineupText!=null&&m.homeLineupText.length()>0)||(m.awayLineupText!=null&&m.awayLineupText.length()>0);
        if(hasLineups){
            if(m.homeLineupText!=null&&m.homeLineupText.length()>0){
                lineups.addView(label(flag(m.home)+" "+m.home+(m.homeFormation.length()>0?" • "+m.homeFormation:""),17,RED,true));
                lineups.addView(label(m.homeLineupText,14,text,false));
            }
            if(m.awayLineupText!=null&&m.awayLineupText.length()>0){
                lineups.addView(label("\n"+flag(m.away)+" "+m.away+(m.awayFormation.length()>0?" • "+m.awayFormation:""),17,RED,true));
                lineups.addView(label(m.awayLineupText,14,text,false));
            }
        }else{
            lineups.addView(label(t2("Starting XI and bench have not been published yet.","Početnih 11 i klupa još nisu objavljeni.","Startelf und Bank wurden noch nicht veröffentlicht.","Los onces y suplentes aún no se han publicado.","Les titulaires et remplaçants ne sont pas encore publiés."),15,subText,false));
        }
        if(matchIsUpcoming(m)){
            Button remind=btn("🔔 "+t2("Set match reminder","Postavi podsjetnik","Spielerinnerung setzen","Crear recordatorio","Créer un rappel"));
            remind.setOnClickListener(v->toast(t2("Reminder saved","Podsjetnik spremljen","Erinnerung gespeichert","Recordatorio guardado","Rappel enregistré")));
            lineups.addView(remind);
        }

        LinearLayout form=card(); form.addView(label("📈 "+t2("Recent form","Nedavna forma","Aktuelle Form","Forma reciente","Forme récente"),22,text,true));
        form.addView(label(flag(m.home)+" "+safeTeam(m.home)+"   "+recentFormDisplay(m.home)+"\n"+flag(m.away)+" "+safeTeam(m.away)+"   "+recentFormDisplay(m.away),16,subText,false));
        LinearLayout h2h=card(); h2h.addView(label("🤝 "+t2("Head to head","Međusobni susreti","Direkter Vergleich","Enfrentamientos","Face-à-face"),22,text,true));
        h2h.addView(label(t2("Previous meetings will be added from the match head-to-head endpoint.","Prethodni međusobni susreti dodat će se iz posebnog head-to-head izvora.","Frühere Duelle werden über den Head-to-Head-Endpunkt ergänzt.","Los enfrentamientos previos se añadirán desde el endpoint head-to-head.","Les confrontations précédentes seront ajoutées depuis la source face-à-face."),15,subText,false));
        startLiveMatchDetailsRefresh(m);
    }

    String joinParts(List<String> parts,String separator){
        StringBuilder sb=new StringBuilder();
        for(String part:parts){
            if(part==null||part.trim().length()==0)continue;
            if(sb.length()>0)sb.append(separator);
            sb.append(part.trim());
        }
        return sb.toString();
    }

    void populateMatchDetails(Match m,JSONObject o){
        if(m==null||o==null)return;
        m.apiId=o.optInt("id",m.apiId);
        m.actualVenue=o.optString("venue",m.actualVenue==null?"":m.actualVenue);
        m.attendance=o.optInt("attendance",m.attendance);
        JSONObject homeObj=o.optJSONObject("homeTeam");
        JSONObject awayObj=o.optJSONObject("awayTeam");
        if(homeObj!=null){
            m.homeFormation=homeObj.optString("formation","");
            m.homeLineupText=formatLineup(homeObj);
        }
        if(awayObj!=null){
            m.awayFormation=awayObj.optString("formation","");
            m.awayLineupText=formatLineup(awayObj);
        }
        m.eventsText=formatMatchEvents(o);
        m.statsText=formatMatchStatistics(homeObj,awayObj,m.home,m.away);
        m.refereeText=formatReferees(o.optJSONArray("referees"));
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject half=score.optJSONObject("halfTime");
            if(half!=null && !half.isNull("home") && !half.isNull("away")) m.halfTimeScore=half.optInt("home")+" : "+half.optInt("away");
        }
        m.detailsAvailable=(m.eventsText.length()>0||m.statsText.length()>0||m.homeLineupText.length()>0||m.awayLineupText.length()>0||m.refereeText.length()>0);
    }

    String formatLineup(JSONObject team){
        if(team==null)return "";
        JSONArray lineup=team.optJSONArray("lineup");
        JSONArray bench=team.optJSONArray("bench");
        StringBuilder sb=new StringBuilder();
        appendPlayers(sb,lineup,t2("Starting XI","Početnih 11","Startelf","Once inicial","Onze de départ"));
        appendPlayers(sb,bench,t2("Bench","Klupa","Bank","Suplentes","Remplaçants"));
        return sb.toString().trim();
    }

    void appendPlayers(StringBuilder sb,JSONArray players,String heading){
        if(players==null||players.length()==0)return;
        if(sb.length()>0)sb.append("\n\n");
        sb.append(heading).append("\n");
        for(int i=0;i<players.length();i++){
            JSONObject p=players.optJSONObject(i); if(p==null)continue;
            int number=p.optInt("shirtNumber",-1);
            String name=p.optString("name","");
            String position=p.optString("position","");
            if(number>0)sb.append(number).append(". ");
            sb.append(name);
            if(position.length()>0)sb.append(" — ").append(position);
            if(i<players.length()-1)sb.append("\n");
        }
    }

    String formatMatchEvents(JSONObject match){
        ArrayList<DetailEvent> all=new ArrayList<>();
        JSONArray goals=match.optJSONArray("goals");
        if(goals!=null)for(int i=0;i<goals.length();i++){
            JSONObject g=goals.optJSONObject(i); if(g==null)continue;
            int minute=g.optInt("minute",0), injury=g.optInt("injuryTime",0);
            JSONObject scorer=g.optJSONObject("scorer"), assist=g.optJSONObject("assist"), team=g.optJSONObject("team");
            String text="⚽ "+minuteLabel(minute,injury)+" "+objectName(scorer);
            if(assist!=null&&objectName(assist).length()>0)text+=" ("+t2("assist","asistencija","Vorlage","asistencia","passe")+": "+objectName(assist)+")";
            if(team!=null&&objectName(team).length()>0)text+=" • "+objectName(team);
            all.add(new DetailEvent(minute,text));
        }
        JSONArray bookings=match.optJSONArray("bookings");
        if(bookings!=null)for(int i=0;i<bookings.length();i++){
            JSONObject b=bookings.optJSONObject(i); if(b==null)continue;
            int minute=b.optInt("minute",0);
            String card=b.optString("card","").toUpperCase(Locale.US);
            String icon=card.contains("RED")?"🟥":"🟨";
            String text=icon+" "+minuteLabel(minute,0)+" "+objectName(b.optJSONObject("player"));
            String team=objectName(b.optJSONObject("team")); if(team.length()>0)text+=" • "+team;
            all.add(new DetailEvent(minute,text));
        }
        JSONArray substitutions=match.optJSONArray("substitutions");
        if(substitutions!=null)for(int i=0;i<substitutions.length();i++){
            JSONObject sub=substitutions.optJSONObject(i); if(sub==null)continue;
            int minute=sub.optInt("minute",0);
            String text="🔄 "+minuteLabel(minute,0)+" "+objectName(sub.optJSONObject("playerIn"))+" ↔ "+objectName(sub.optJSONObject("playerOut"));
            String team=objectName(sub.optJSONObject("team")); if(team.length()>0)text+=" • "+team;
            all.add(new DetailEvent(minute,text));
        }
        Collections.sort(all,(a,b)->a.minute-b.minute);
        StringBuilder sb=new StringBuilder();
        for(DetailEvent e:all){if(sb.length()>0)sb.append("\n");sb.append(e.text);}
        return sb.toString();
    }

    String minuteLabel(int minute,int injury){
        if(injury>0)return minute+"+"+injury+"′";
        return minute>0?minute+"′":"";
    }

    String objectName(JSONObject o){return o==null?"":o.optString("name",o.optString("shortName",""));}

    String formatMatchStatistics(JSONObject homeObj,JSONObject awayObj,String home,String away){
        if(homeObj==null||awayObj==null)return "";
        JSONObject hs=homeObj.optJSONObject("statistics"), as=awayObj.optJSONObject("statistics");
        if(hs==null||as==null)return "";
        StringBuilder sb=new StringBuilder();
        sb.append(flag(home)).append(" ").append(shortName(home)).append("     ").append(flag(away)).append(" ").append(shortName(away));
        appendStat(sb,hs,as,"ball_possession",t2("Possession","Posjed","Ballbesitz","Posesión","Possession"),"%");
        appendStat(sb,hs,as,"shots",t2("Shots","Udarci","Schüsse","Tiros","Tirs"),"");
        appendStat(sb,hs,as,"shots_on_goal",t2("Shots on target","U okvir","Schüsse aufs Tor","A puerta","Cadrés"),"");
        appendStat(sb,hs,as,"corner_kicks",t2("Corners","Korneri","Ecken","Córners","Corners"),"");
        appendStat(sb,hs,as,"offsides",t2("Offsides","Zaleđa","Abseits","Fueras de juego","Hors-jeu"),"");
        appendStat(sb,hs,as,"fouls",t2("Fouls","Prekršaji","Fouls","Faltas","Fautes"),"");
        appendStat(sb,hs,as,"saves",t2("Saves","Obrane","Paraden","Paradas","Arrêts"),"");
        appendStat(sb,hs,as,"yellow_cards",t2("Yellow cards","Žuti kartoni","Gelbe Karten","Amarillas","Cartons jaunes"),"");
        appendStat(sb,hs,as,"red_cards",t2("Red cards","Crveni kartoni","Rote Karten","Rojas","Cartons rouges"),"");
        return sb.toString();
    }

    void appendStat(StringBuilder sb,JSONObject home,JSONObject away,String key,String label,String suffix){
        if(!home.has(key)&&!away.has(key))return;
        String h=home.isNull(key)?"-":home.optString(key,"-");
        String a=away.isNull(key)?"-":away.optString(key,"-");
        if(suffix.length()>0){if(!h.equals("-"))h+=suffix;if(!a.equals("-"))a+=suffix;}
        sb.append("\n").append(h).append("   ").append(label).append("   ").append(a);
    }

    String formatReferees(JSONArray refs){
        if(refs==null)return "";
        for(int i=0;i<refs.length();i++){
            JSONObject r=refs.optJSONObject(i); if(r==null)continue;
            String type=r.optString("type","");
            if(type.equals("REFEREE")||type.equals("MAIN_REFEREE"))return r.optString("name","");
        }
        return "";
    }

    int change(int v,int d){if(v<0)v=0;v+=d;if(v<0)v=0;return v;} String display(int v){return v>=0?""+v:"-";}
    TextView scoreLabel(int v){TextView t=label(display(v),21,text,true);t.setGravity(Gravity.CENTER);t.setBackground(round(chipBg,dp(14),0));return t;} String shortName(String s){return s;}

    void showGroups(){
        clear(tr("Groups"),"P/W/D/L/GD/Pts","Groups");
        addOnlineCard();
        Map<String,List<TeamRow>> map=data.standings();
        for(String g:data.groups){LinearLayout c=card();c.addView(label("Group "+g,23,RED,true));c.addView(tableRow("#","Team","P","W","D","L","GD","Pts",true,subText));List<TeamRow> rows=map.get(g);for(int i=0;i<rows.size();i++){TeamRow r=rows.get(i);int col=i<2?GREEN:(i==2?GOLD:subText);c.addView(tableRow((i+1)+"",flag(r.team)+" "+r.team,r.p+"",r.w+"",r.d+"",r.l+"",(r.gf-r.ga)+"",r.pts+"",false,col));}}
        LinearLayout third=card();third.addView(label("🥉 Best third-placed teams",22,text,true));List<TeamRow> th=data.bestThirds();for(int i=0;i<th.size();i++){TeamRow r=th.get(i);third.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,i<8?GREEN:subText,false));}
    }
    LinearLayout tableRow(String pos,String team,String p,String w,String d,String l,String gd,String pts,boolean bold,int color){LinearLayout r=hrow();r.setPadding(0,dp(4),0,dp(4));r.addView(cell(pos,.45f,bold,color));r.addView(cell(team,2.4f,bold,color));r.addView(cell(p,.55f,bold,color));r.addView(cell(w,.55f,bold,color));r.addView(cell(d,.55f,bold,color));r.addView(cell(l,.55f,bold,color));r.addView(cell(gd,.7f,bold,color));r.addView(cell(pts,.8f,true,color));return r;}
    TextView cell(String s,float w,boolean bold,int color){TextView t=label(s,12,color,bold);t.setGravity(Gravity.CENTER_VERTICAL);t.setSingleLine(true);t.setTextSize(s.length()>14?10:12);t.setLayoutParams(new LinearLayout.LayoutParams(0,dp(34),w));return t;}

    
    String groupLineFor(String team) {
        if (team == null) return "";
        for (String g : data.groups) {
            ArrayList<String> names = new ArrayList<>();
            for (Match m : data.matches) {
                if (m.group.equals(g)) {
                    if (!names.contains(m.home)) names.add(m.home);
                    if (!names.contains(m.away)) names.add(m.away);
                }
            }
            if (names.contains(team)) {
                String line = "Group " + g + ": ";
                for (int i=0; i<names.size(); i++) {
                    if (i>0) line += ", ";
                    line += names.get(i);
                }
                return line;
            }
        }
        return "";
    }

    String groupOfTeam(String team) {
        if (team == null) return "";
        for (Match m : data.matches) {
            if ((m.home.equals(team) || m.away.equals(team)) && isGroupLetter(m.group)) return m.group;
        }
        return "";
    }

    boolean isGroupLetter(String g){
        return g!=null && g.length()==1 && g.compareTo("A")>=0 && g.compareTo("L")<=0;
    }

    String stageLabel(Match m){
        if(m==null) return "";
        if(isGroupLetter(m.group)) return "Group "+m.group;
        return normalizeStage(m.venue);
    }

    String normalizeStage(String raw){
        if(raw==null) return "";
        String x=raw.trim();
        if(x.length()==0 || x.equalsIgnoreCase("null") || x.equals("?")) return "";
        String u=x.replace("-","_").replace(" ","_").toUpperCase(Locale.US);
        if(u.equals("GROUP") || u.equals("GROUP_STAGE") || u.equals("REGULAR_SEASON")) return "";
        if(u.contains("ROUND_OF_32") || u.contains("LAST_32") || u.contains("R32")) return "Round of 32";
        if(u.contains("ROUND_OF_16") || u.contains("LAST_16") || u.contains("R16")) return "Round of 16";
        if(u.contains("QUARTER")) return "Quarter-final";
        if(u.contains("SEMI")) return "Semi-final";
        if(u.contains("FINAL")) return "Final";
        if(x.toLowerCase(Locale.US).startsWith("round of 32")) return "Round of 32";
        if(x.toLowerCase(Locale.US).startsWith("round of 16")) return "Round of 16";
        return x;
    }

    boolean hasWonStage(String team,String stage){
        if(team==null || stage==null) return false;
        for(Match m:data.matches){
            if(!stage.equals(stageLabel(m))) continue;
            if(!matchIsFinished(m)) continue;
            if(sameTeam(m.home,team) && m.homeGoals>m.awayGoals) return true;
            if(sameTeam(m.away,team) && m.awayGoals>m.homeGoals) return true;
        }
        return false;
    }


    void addOnlineCard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online update",23,text,true));
        onlineStatusView=label(onlineStatus,14,subText,false);
        c.addView(onlineStatusView);
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0){
            onlineLastUpdateView=label(lastUpdateLabel(last),13,subText,false);
        }else{
            onlineLastUpdateView=label(lastUpdateLabel(""),13,subText,false);
        }
        c.addView(onlineLastUpdateView);
        Button r=outline(t2("🔄 Refresh Live Data","🔄 Osvježi podatke","🔄 Live-Daten aktualisieren","🔄 Actualizar datos","🔄 Actualiser les données"));
        r.setOnClickListener(v->refreshOnlineSafe(true));
        c.addView(r);
    }
    void addFinishedMatchesCard(){
        addOnlineMatchCenterCard(false);
    }

    void addOnlineMatchCenterCard(boolean compact){
        String live=prefs.getString("online_liveMatches","");
        String jsonUpcoming=prefs.getString("online_upcomingMatches","");
        LinearLayout c=card();
        c.addView(label("⚽ Online match center",23,text,true));
        int liveCount=lineCount(live);
        int finished=displayPlayedCount();
        int upcoming=displayUpcomingCount();
        c.addView(label("🔴 Live: "+liveCount+"   ✅ Finished: "+finished+"   📅 Upcoming: "+upcoming,14,subText,false));

        if(live!=null && live.trim().length()>0){
            c.addView(label("🔴 Live matches",18,RED,true));
            c.addView(label(limitLines(live, compact?3:10),15,subText,false));
        }

        c.addView(label("✅ Finished matches",18,RED,true));
        String onlineFinished=prefs.getString("online_finishedMatches","");
        if(onlineFinished!=null && onlineFinished.trim().length()>0){
            c.addView(label(limitLines(onlineFinished, compact?8:9999),15,subText,false));
            int fc=lineCount(onlineFinished);
            if(compact && fc>8)c.addView(label("+"+(fc-8)+" more finished matches",14,subText,false));
        }else{
            int count=0;
            for(Match m:data.matches){
                if(matchIsFinished(m)){
                    count++;
                    if(!compact || count<=8)c.addView(label(flag(m.home)+" "+m.home+" "+m.homeGoals+" - "+m.awayGoals+" "+flag(m.away)+" "+m.away+" • Group "+m.group,14,subText,false));
                }
            }
            if(count==0)c.addView(label("No finished matches yet.",15,subText,false));
            else if(compact && count>8)c.addView(label("+"+(count-8)+" more finished matches",14,subText,false));
        }

        c.addView(label("📅 Upcoming matches",18,RED,true));
        if(jsonUpcoming!=null && jsonUpcoming.trim().length()>0){
            c.addView(label(limitLines(jsonUpcoming, compact?4:8),15,subText,false));
        }else{
            int shown=0;
            for(Match m:data.matches){
                if(matchIsUpcoming(m)){
                    shown++;
                    if(!compact || shown<=5)c.addView(label(displayLocalDateTime(m.date)+" • Group "+m.group+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away,14,subText,false));
                }
            }
            if(shown==0)c.addView(label("No upcoming matches.",15,subText,false));
            else if(compact && shown>5)c.addView(label("+"+(shown-5)+" more upcoming matches",14,subText,false));
        }
    }

    void addHomeOnlineDashboard(){
        LinearLayout c=card();
        c.addView(label("🌐 Online dashboard",23,text,true));
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        int live=lineCount(prefs.getString("online_liveMatches",""));
        c.addView(kpiRow("Live",""+live,"Finished",""+displayPlayedCount(),"Upcoming",""+displayUpcomingCount(),false));
        if(ENABLE_PLAYER_DATA_MODULES){
            String topScorer=firstRankingLine(gb,t2("Scorer stats coming soon","Statistika strijelaca uskoro","Torschützenstatistik folgt","Estadística de goleadores pronto","Statistiques buteurs bientôt"));
            String topMvp=firstRankingLine(mv,t2("MVP ranking coming soon","MVP poredak uskoro","MVP-Rangliste folgt","Ranking MVP pronto","Classement MVP bientôt"));
            c.addView(label("🥇 "+topScorer,15,subText,false));
            c.addView(label("⭐ "+topMvp,15,subText,false));
        }else{
            c.addView(label(t2("Live matches, results and tables are active.","Rezultati, utakmice i tablice su online.","Live-Spiele, Ergebnisse und Tabellen sind aktiv.","Partidos, resultados y tablas en vivo activos.","Matchs, résultats et tableaux en direct actifs."),15,subText,false));
        }
        String last=prefs.getString("online_lastUpdate","");
        if(last!=null && last.trim().length()>0)c.addView(label(lastUpdateLabel(last),13,subText,false));
    }

    int countUpcoming(){int c=0;for(Match m:data.matches)if(matchIsUpcoming(m))c++;return c;}
    int lineCount(String s){if(s==null || s.trim().length()==0)return 0;return s.split("\\n").length;}
    String firstRankingLine(String s,String fallback){if(s==null || s.trim().length()==0)return fallback;String[] lines=s.split("\\n");if(lines.length==0)return fallback;String first=lines[0].trim();first=first.replaceFirst("^\\d+\\.\\s*","");return first.length()>0?first:fallback;}
    int displayPlayedCount(){int v=prefs.getInt("online_playedCount",-1);return v>=0?v:data.playedCount();}
    int displayTotalGoals(){int v=prefs.getInt("online_totalGoals",-1);return v>=0?v:data.totalGoals();}
    int displayUpcomingCount(){int v=prefs.getInt("online_upcomingCount",-1);return v>=0?v:countUpcoming();}
    int displayTotalMatches(){int v=prefs.getInt("online_totalMatches",TOURNAMENT_TOTAL_MATCHES);return v>0?v:TOURNAMENT_TOTAL_MATCHES;}
    int displayProgressPercent(){return (int)Math.round(displayPlayedCount()*100.0/displayTotalMatches());}

    int onlineTotalMatches(JSONObject root){
        if(root==null) return TOURNAMENT_TOTAL_MATCHES;
        JSONObject rs=root.optJSONObject("resultSet");
        if(rs!=null && rs.optInt("count",0)>0) return rs.optInt("count",TOURNAMENT_TOTAL_MATCHES);
        JSONArray arr=root.optJSONArray("matches");
        if(arr!=null && arr.length()>72) return arr.length();
        return TOURNAMENT_TOTAL_MATCHES;
    }
    int onlineFinishedCount(JSONObject root){
        if(root==null) return 0;
        JSONObject rs=root.optJSONObject("resultSet");
        if(rs!=null && rs.optInt("played",0)>0) return rs.optInt("played",0);
        JSONArray fin=root.optJSONArray("finished");
        if(fin!=null) return fin.length();
        JSONArray arr=root.optJSONArray("matches");
        int c=0;
        if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null && isFinishedStatus(o.optString("status","")) && jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0)c++;}
        return c;
    }
    int onlineUpcomingCount(JSONObject root){
        if(root==null) return -1;
        JSONArray up=root.optJSONArray("upcoming");
        if(up!=null) return up.length();
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) return -1;
        int c=0;
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); if(o!=null && isUpcomingStatus(o.optString("status","")))c++;}
        return c;
    }
    int onlineTotalGoals(JSONObject root){
        if(root==null) return 0;
        JSONArray arr=root.optJSONArray("matches");
        if(arr==null) arr=root.optJSONArray("finished");
        int g=0;
        if(arr!=null) for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i); int h=jsonHomeGoals(o), a=jsonAwayGoals(o); if(h>=0 && a>=0 && isFinishedStatus(o.optString("status",""))) g+=h+a;}
        return g;
    }

    String limitLines(String s,int max){if(s==null)return "";String[] lines=s.split("\\n");StringBuilder sb=new StringBuilder();for(int i=0;i<lines.length && i<max;i++){if(i>0)sb.append("\n");sb.append(lines[i]);}if(lines.length>max)sb.append("\n+").append(lines.length-max).append(" more");return sb.toString();}

    void addOnlineRankingsPreview(){
        String gb=prefs.getString("online_goldenBoot","");
        String mv=prefs.getString("online_mvp","");
        if((gb==null || gb.trim().length()==0) && (mv==null || mv.trim().length()==0)) return;
        LinearLayout c=card();
        c.addView(label("🌐 Online rankings",23,text,true));
        if(gb!=null && gb.trim().length()>0){
            c.addView(label("🥇 "+tr("Golden Boot"),18,RED,true));
            c.addView(label(gb,15,subText,false));
        }
        if(mv!=null && mv.trim().length()>0){
            c.addView(label("⭐ "+tr("MVP Prediction"),18,RED,true));
            c.addView(label(mv,15,subText,false));
        }
    }


    void restoreCachedOnlineData(){
        String cached=prefs.getString("online_rawJson","");
        if(cached==null || cached.trim().length()==0) return;
        try{
            applyOnlineJson(cached);
            onlineStatus="🟢 Cached data loaded";
        }catch(Exception ignored){}
    }


    void refreshOnlineSafe(){
        refreshOnlineSafe(true);
    }

    void refreshOnlineSafe(final boolean showToast){
        if(onlineRefreshInProgress) return;
        onlineRefreshInProgress=true;
        onlineStatus="Refreshing online data...";
        if(onlineStatusView!=null) onlineStatusView.setText(onlineStatus);
        new Thread(new Runnable(){ public void run(){
            String result;
            String last="";
            try{
                String json=downloadFirstOnlineJson();
                if(json==null || json.trim().length()==0) throw new Exception("Empty online file");
                int applied=applyOnlineJson(json);
                last=prefs.getString("online_lastUpdate","");
                result="🟢 Connected • data updated";
            }catch(Exception e){
                result="Online data unavailable • "+safeMsg(e);
            }
            final String msg=result;
            final String lastText=last;
            runOnUiThread(new Runnable(){ public void run(){
                onlineRefreshInProgress=false;
                onlineStatus=msg;
                if(onlineStatusView!=null) onlineStatusView.setText(msg);
                if(onlineLastUpdateView!=null){
                    String lu=prefs.getString("online_lastUpdate",lastText);
                    onlineLastUpdateView.setText(lastUpdateLabel(lu));
                }
                if(showToast) toast(msg);
                if(msg.startsWith("🟢 Connected")){
                    if(currentScreen.equals("Home")) showHome();
                    else if(currentScreen.equals("MatchDetails")){
                        Match refreshed=findOpenMatchDetails();
                        if(refreshed!=null) showMatchDetails(refreshed); else showMatches();
                    }
                    else if(currentScreen.equals("Matches")) showMatches();
                    else if(currentScreen.equals("Groups")) showGroups();
                    else if(currentScreen.equals("More")) {
                        /* Keep current More sub-screen stable; online rankings update when opened again. */
                    }
                }
            }});
        }}).start();
    }


    void rememberOpenMatch(Match m){
        if(m==null)return;
        openMatchApiId=m.apiId;
        openMatchHome=m.home==null?"":m.home;
        openMatchAway=m.away==null?"":m.away;
        openMatchDate=m.date==null?"":m.date;
    }

    Match findOpenMatchDetails(){
        if(data==null||data.matches==null)return null;
        for(Match m:data.matches){
            if(openMatchApiId>0 && m.apiId==openMatchApiId)return m;
        }
        for(Match m:data.matches){
            boolean samePair=(sameTeam(m.home,openMatchHome)&&sameTeam(m.away,openMatchAway))||(sameTeam(m.home,openMatchAway)&&sameTeam(m.away,openMatchHome));
            if(!samePair)continue;
            if(openMatchDate.length()==0||m.date==null||m.date.equals(openMatchDate)||m.date.startsWith(openMatchDate.length()>=10?openMatchDate.substring(0,10):openMatchDate))return m;
        }
        return null;
    }

    void stopLiveMatchDetailsRefresh(){
        try{
            if(liveMatchDetailsRefreshRunnable!=null)handler.removeCallbacks(liveMatchDetailsRefreshRunnable);
        }catch(Exception ignored){}
        liveMatchDetailsRefreshRunnable=null;
    }

    void startLiveMatchDetailsRefresh(Match m){
        stopLiveMatchDetailsRefresh();
        if(m==null||!matchIsLive(m)||!"MatchDetails".equals(currentScreen))return;
        rememberOpenMatch(m);
        liveMatchDetailsRefreshRunnable=new Runnable(){ public void run(){
            if(!"MatchDetails".equals(currentScreen))return;
            Match open=findOpenMatchDetails();
            if(open==null){showMatches();return;}
            if(!matchIsLive(open)){showMatchDetails(open);return;}
            refreshOnlineSafe(false);
            handler.postDelayed(this,60*1000L);
        }};
        handler.postDelayed(liveMatchDetailsRefreshRunnable,60*1000L);
    }

    String safeMsg(Exception e){
        if(e==null || e.getMessage()==null) return "check connection";
        String s=e.getMessage();
        return s.length()>70?s.substring(0,70):s;
    }

    String downloadFirstOnlineJson() throws Exception{
        String[] urls={
                "https://raw.githubusercontent.com/alensekula-ship-it/worldcup-live-updater/main/live-results.json",
                "https://raw.githubusercontent.com/alensekula-ship-it/worldcup-live-data/main/live-results.json",
                "https://alensekula-ship-it.github.io/worldcup-live-data/live-results.json",
                "https://raw.githubusercontent.com/alensekula-ship-it/WorldCupFan2026/main/live-results.json",
                "https://alensekula-ship-it.github.io/WorldCupFan2026/live-results.json"
        };
        Exception last=null;
        for(String u:urls){
            try{
                String separator=u.contains("?")?"&":"?";
                String txt=downloadText(u+separator+"t="+System.currentTimeMillis());
                if(txt!=null && txt.trim().length()>0) return txt;
            }catch(Exception e){
                last=e;
            }
        }
        if(last!=null) throw last;
        throw new Exception("No online source");
    }

    String downloadText(String urlStr) throws Exception{
        HttpURLConnection con=null;
        BufferedReader br=null;
        try{
            URL url=new URL(urlStr);
            con=(HttpURLConnection)url.openConnection();
            con.setConnectTimeout(7000);
            con.setReadTimeout(7000);
            con.setRequestMethod("GET");
            con.setRequestProperty("Accept","application/json");
            con.setRequestProperty("Cache-Control","no-cache, no-store, must-revalidate");
            con.setRequestProperty("Pragma","no-cache");
            int code=con.getResponseCode();
            if(code<200 || code>=300) throw new Exception("HTTP "+code);
            br=new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8"));
            StringBuilder sb=new StringBuilder();
            String line;
            while((line=br.readLine())!=null) sb.append(line);
            return sb.toString();
        }finally{
            try{ if(br!=null) br.close(); }catch(Exception ignored){}
            if(con!=null) con.disconnect();
        }
    }

    String teamKey(String s){
        if(s==null) return "";
        String k=s.toLowerCase(Locale.US).replace("č","c").replace("ć","c").replace("š","s").replace("ž","z").replace("đ","d");
        k=k.replace("côte d’ivoire","ivorycoast").replace("côte d'ivoire","ivorycoast").replace("cote d’ivoire","ivorycoast").replace("cote d'ivoire","ivorycoast");
        k=k.replace("curaçao","curacao").replace("united states","usa").replace("u.s.a.","usa").replace("u.s.a","usa");
        k=k.replace("south korea","korearepublic").replace("republic of korea","korearepublic");
        k=k.replace("cape verde islands","capeverde").replace("capeverdeislands","capeverde");
        k=k.replace("democratic republic of congo","drcongo").replace("d r congo","drcongo").replace("congo dr","drcongo").replace("drc","drcongo");
        k=k.replace("bosnia & herzegovina","bosniaherzegovina").replace("bosnia and herzegovina","bosniaherzegovina").replace("bosnia-herzegovina","bosniaherzegovina").replace("bosnia herzegovina","bosniaherzegovina");
        return k.replaceAll("[^a-z0-9]","");
    }
    boolean sameTeam(String a,String b){
        String x=teamKey(a), y=teamKey(b);
        if(x.equals(y)) return true;
        if((x.equals("ivorycoast")&&y.equals("cotedivoire"))||(y.equals("ivorycoast")&&x.equals("cotedivoire"))) return true;
        if((x.equals("korearepublic")&&y.equals("korea"))||(y.equals("korearepublic")&&x.equals("korea"))) return true;
        if((x.equals("bosniaherzegovina")&&y.equals("bosniaandherzegovina"))||(y.equals("bosniaherzegovina")&&x.equals("bosniaandherzegovina"))) return true;
        return false;
    }

    boolean isLiveStatus(String st){
        if(st==null) return false;
        String s=st.toLowerCase(Locale.US);
        return s.contains("live") || s.contains("in_progress") || s.contains("in progress") || s.contains("in_play") || s.contains("inplay") || s.contains("in play") || s.equals("paused") || s.equals("half_time") || s.equals("extra_time") || s.equals("penalty_shootout") || s.equals("1h") || s.equals("2h") || s.equals("ht");
    }

    boolean isFinishedStatus(String st){
        if(st==null) return false;
        String s=st.toLowerCase(Locale.US);
        return s.length()==0 || s.contains("finished") || s.equals("ft") || s.contains("final") || s.contains("full") || s.equals("awarded");
    }

    boolean isUpcomingStatus(String st){
        if(st==null) return false;
        String s=st.toLowerCase(Locale.US);
        return s.contains("upcoming") || s.contains("scheduled") || s.contains("timed") || s.contains("not_started") || s.contains("not started");
    }

    String nowStamp(){
        return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());
    }

    int applyOnlineJson(String json) throws Exception{
        JSONObject root=new JSONObject(json);
        int applied=0;
        JSONArray arr=root.optJSONArray("matches");
        JSONArray finishedArr=root.optJSONArray("finished");

        // v13.44: one source of truth. When football-data.org returns the full
        // competition match list, rebuild the in-app match list from that JSON.
        // This prevents the simulator/predict screens from showing old local APK
        // fixtures while the online match center shows fresh data.
        if(arr!=null && arr.length()>0){
            applied += rebuildMatchesFromOnlineArray(arr);
        }else{
            if(finishedArr!=null) applied+=applyResultsFromArray(finishedArr, true);
        }
        if(applied>0)data.save();
        String live=formatMatchFeed(root.optJSONArray("live"));
        String upcoming=formatMatchFeed(root.optJSONArray("upcoming"));
        if(arr!=null){
            StringBuilder liveSb=new StringBuilder();
            StringBuilder upSb=new StringBuilder();
            for(int i=0;i<arr.length();i++){
                JSONObject o=arr.optJSONObject(i);
                if(o==null) continue;
                String st=o.optString("status","").toLowerCase(Locale.US);
                boolean hasScore=jsonHomeGoals(o)>=0 && jsonAwayGoals(o)>=0;
                if(isLiveStatus(st)){ if(liveSb.length()>0)liveSb.append("\n"); liveSb.append(formatOneMatch(o,false)); }
                else if((isUpcomingStatus(st)) && !hasScore){ if(upSb.length()>0)upSb.append("\n"); upSb.append(formatOneMatch(o,true)); }
            }
            if(live.length()==0)live=liveSb.toString();
            if(upcoming.length()==0)upcoming=upSb.toString();
        }
        String finishedFeed=formatMatchFeed(root.optJSONArray("finished"));
        int onlinePlayed=onlineFinishedCount(root);
        int onlineGoals=onlineTotalGoals(root);
        int onlineUpcoming=onlineUpcomingCount(root);
        int onlineTotal=onlineTotalMatches(root);
        if(onlinePlayed<=0) onlinePlayed=data.playedCount();
        if(onlineGoals<=0) onlineGoals=data.totalGoals();
        if(onlineUpcoming<0) onlineUpcoming=countUpcoming();
        String updated=root.optString("lastUpdate",root.optString("updated",""));
        if(updated==null || updated.trim().length()==0) updated=nowStamp();
        prefs.edit()
            .putString("online_lastUpdate",updated)
            .putString("online_rawJson",json)
            .putString("online_finishedMatches",finishedFeed)
            .putInt("online_playedCount",onlinePlayed)
            .putInt("online_totalGoals",onlineGoals)
            .putInt("online_upcomingCount",onlineUpcoming)
            .putInt("online_totalMatches",onlineTotal)
            .putString("online_goldenBoot",formatRanking(root.optJSONArray("goldenBoot"),"goals"))
            .putString("online_mvp",formatRanking(root.optJSONArray("mvp")!=null?root.optJSONArray("mvp"):root.optJSONArray("mvpRanking"),"points"))
            .putString("online_liveMatches",live)
            .putString("online_upcomingMatches",upcoming)
            .apply();
        return applied;
    }


    int rebuildMatchesFromOnlineArray(JSONArray arr){
        if(arr==null || arr.length()==0) return 0;
        ArrayList<Match> fresh=new ArrayList<>();
        LinkedHashSet<String> freshTeams=new LinkedHashSet<>();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0 || away.length()==0) continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0) stage="Group stage";

            Match m=new Match(jsonGroup, home, away, jsonDate, stage);
            m.status=o.optString("status","");
            m.minute=o.optString("minute",o.optString("matchMinute",""));
            m.competition=competitionNameFromJson(o);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=m.status.toLowerCase(Locale.US);
            // Only official live/finished matches get scores. Scheduled matches stay blank.
            if(hg>=0 && ag>=0 && (isFinishedStatus(st) || isLiveStatus(st))){
                m.homeGoals=hg;
                m.awayGoals=ag;
            }else{
                m.homeGoals=-1;
                m.awayGoals=-1;
            }
            populateMatchDetails(m,o);
            fresh.add(m);
            freshTeams.add(home);
            freshTeams.add(away);
        }
        if(fresh.size()==0) return 0;
        data.matches.clear();
        data.matches.addAll(fresh);
        data.teams.clear();
        data.teams.addAll(freshTeams);
        Collections.sort(data.teams);
        return fresh.size();
    }


    int syncMatchesFromArray(JSONArray arr){
        if(arr==null) return 0;
        int changed=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            if(home.length()==0 || away.length()==0) continue;

            String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
            if(jsonGroup.length()==0) jsonGroup=groupOfTeam(home);
            String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
            String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
            if(stage.length()==0) stage="Group stage";

            Match target=null;
            for(Match m:data.matches){
                if((sameTeam(m.home,home)&&sameTeam(m.away,away)) || (sameTeam(m.home,away)&&sameTeam(m.away,home))){
                    target=m;
                    break;
                }
            }

            if(target==null){
                target=new Match(jsonGroup,home,away,jsonDate,stage);
                data.matches.add(target);
                changed++;
            }else{
                if(jsonGroup.length()==1 && !target.group.equals(jsonGroup)){target.group=jsonGroup; changed++;}
                if(stage.length()>0 && !target.venue.equals(stage)){target.venue=stage; changed++;}
                if(jsonDate.length()>=10 && !target.date.equals(jsonDate)){target.date=jsonDate; changed++;}
            }

            target.status=o.optString("status",target.status);
            target.minute=o.optString("minute",o.optString("matchMinute",target.minute));
            target.competition=competitionNameFromJson(o);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=target.status.toLowerCase(Locale.US);
            if(hg>=0 && ag>=0 && (isFinishedStatus(st)||isLiveStatus(st))){
                if(sameTeam(target.home,home)){
                    if(target.homeGoals!=hg || target.awayGoals!=ag){target.homeGoals=hg; target.awayGoals=ag; changed++;}
                }else{
                    if(target.homeGoals!=ag || target.awayGoals!=hg){target.homeGoals=ag; target.awayGoals=hg; changed++;}
                }
            }
            populateMatchDetails(target,o);
        }
        return changed;
    }

    int applyResultsFromArray(JSONArray arr, boolean forceFinished){
        if(arr==null) return 0;
        int applied=0;
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String home=teamNameFromJson(o,true);
            String away=teamNameFromJson(o,false);
            int hg=jsonHomeGoals(o);
            int ag=jsonAwayGoals(o);
            String st=o.optString("status","").toLowerCase(Locale.US);
            boolean finalResult = forceFinished || isFinishedStatus(st);
            if(home.length()==0 || away.length()==0 || hg<0 || ag<0 || !finalResult) continue;
            boolean found=false;
            for(Match m:data.matches){
                if((sameTeam(m.home,home)&&sameTeam(m.away,away)) || (sameTeam(m.home,away)&&sameTeam(m.away,home))){
                    if(sameTeam(m.home,home)){m.homeGoals=hg;m.awayGoals=ag;}else{m.homeGoals=ag;m.awayGoals=hg;}
                    String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                    if(jsonGroup.length()==1) m.group=jsonGroup;
                    String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                    if(stage.length()==0) stage="Group stage";
                    if(stage.length()>0) m.venue=stage;
                    String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                    if(jsonDate.length()>=10) m.date=jsonDate;
                    m.status=o.optString("status","FINISHED");
                    m.minute=o.optString("minute",o.optString("matchMinute",""));
                    m.competition=competitionNameFromJson(o);
                    populateMatchDetails(m,o);
                    found=true;
                    applied++;
                    break;
                }
            }
            if(!found){
                String jsonGroup=cleanGroup(o.optString("group",o.optString("stage","")));
                String jsonDate=cleanDate(o.optString("date",o.optString("time",o.optString("utcDate",""))));
                String stage=normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName","Group stage"))));
                if(stage.length()==0) stage="Group stage";
                Match extra=new Match(jsonGroup,home,away,jsonDate,stage);
                extra.status=o.optString("status","FINISHED");
                extra.minute=o.optString("minute",o.optString("matchMinute",""));
                extra.competition=competitionNameFromJson(o);
                extra.homeGoals=hg;
                extra.awayGoals=ag;
                populateMatchDetails(extra,o);
                data.matches.add(extra);
                applied++;
            }
        }
        return applied;
    }

    String teamNameFromJson(JSONObject o, boolean home){
        String a=home?o.optString("home",""):o.optString("away","");
        if(a.length()>0) return a;
        JSONObject obj=home?o.optJSONObject("homeTeam"):o.optJSONObject("awayTeam");
        if(obj!=null){
            a=obj.optString("name",obj.optString("shortName",obj.optString("tla","")));
            if(a.length()>0) return a;
        }
        a=home?o.optString("homeTeam",""):o.optString("awayTeam","");
        if(a.length()>0 && !a.trim().startsWith("{")) return a;
        a=home?o.optString("home_name",""):o.optString("away_name","");
        if(a.length()>0) return a;
        return "";
    }


    String competitionNameFromJson(JSONObject o){
        if(o==null) return "";
        String c=o.optString("competitionName",o.optString("competition",""));
        if(c!=null && c.length()>0 && !c.trim().startsWith("{")) return c;
        JSONObject competition=o.optJSONObject("competition");
        if(competition!=null) return competition.optString("name",competition.optString("code",""));
        return "";
    }


    int jsonHomeGoals(JSONObject o){
        if(o==null) return -1;
        if(o.has("homeGoals")) return o.optInt("homeGoals",-1);
        if(o.has("homeScore")) return o.optInt("homeScore",-1);
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject ft=score.optJSONObject("fullTime");
            if(ft!=null && !ft.isNull("home")) return ft.optInt("home",-1);
            JSONObject rt=score.optJSONObject("regularTime");
            if(rt!=null && !rt.isNull("home")) return rt.optInt("home",-1);
        }
        return -1;
    }

    int jsonAwayGoals(JSONObject o){
        if(o==null) return -1;
        if(o.has("awayGoals")) return o.optInt("awayGoals",-1);
        if(o.has("awayScore")) return o.optInt("awayScore",-1);
        JSONObject score=o.optJSONObject("score");
        if(score!=null){
            JSONObject ft=score.optJSONObject("fullTime");
            if(ft!=null && !ft.isNull("away")) return ft.optInt("away",-1);
            JSONObject rt=score.optJSONObject("regularTime");
            if(rt!=null && !rt.isNull("away")) return rt.optInt("away",-1);
        }
        return -1;
    }

    String cleanGroup(String g){
        if(g==null) return "";
        g=g.trim();
        if(g.length()==0 || g.equalsIgnoreCase("null") || g.equals("?")) return "";
        if(g.startsWith("GROUP_")) g=g.substring(6);
        if(g.startsWith("Group ")) g=g.substring(6);
        if(g.equals("GROUP_STAGE") || g.equalsIgnoreCase("Group stage")) return "";
        return isGroupLetter(g)?g:"";
    }

    String cleanDate(String d){
        if(d==null) return "";
        d=d.trim();
        if(d.length()==0) return "";
        // API utcDate example: 2026-06-26T19:00:00Z -> 2026-06-26 19:00 UTC
        if(d.contains("T")){
            try{
                String x=d.replace("T"," ").replace("Z","");
                if(x.length()>=16) return x.substring(0,16)+" UTC";
            }catch(Exception ignored){}
        }
        return d;
    }

    String tournamentDateLine(){
        String last=prefs.getString("online_lastUpdate","");
        String local=displayLocalDateTime(last);
        String date=(local!=null && local.length()>=10)?local.substring(0,10):"";
        if(date.length()==0) date=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
        try{
            Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);
            String pretty=new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(d);
            return t2("Live data • updated "+pretty, "Podaci uživo • ažurirano "+pretty, "Live-Daten • aktualisiert "+pretty, "Datos en vivo • actualizado "+pretty, "Données en direct • mis à jour "+pretty);
        }catch(Exception e){
            return t2("Live tournament data", "Podaci prvenstva uživo", "Live-Turnierdaten", "Datos del torneo en vivo", "Données du tournoi en direct");
        }
    }

    String formatMatchFeed(JSONArray arr){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            if(sb.length()>0) sb.append("\n");
            sb.append(formatOneMatch(o,false));
        }
        return sb.toString();
    }

    String formatOneMatch(JSONObject o, boolean noScore){
        String home=teamNameFromJson(o,true);
        String away=teamNameFromJson(o,false);
        String group=cleanGroup(o.optString("group",o.optString("stage","")));
        String date=displayLocalDateTime(cleanDate(o.optString("date",o.optString("time",o.optString("utcDate","")))));
        String status=o.optString("status","");
        String minute=o.optString("minute",o.optString("matchMinute",""));
        int hg=jsonHomeGoals(o);
        int ag=jsonAwayGoals(o);
        String st=status.toLowerCase(Locale.US);
        boolean live=isLiveStatus(st);
        StringBuilder sb=new StringBuilder();

        if(live) sb.append(liveLabelFromJson(status, minute));
        else if(isFinishedStatus(st)) sb.append("✅ FT");
        else if(noScore || isUpcomingStatus(st)) sb.append("📅");

        if(!live && minute!=null && minute.trim().length()>0){
            if(sb.length()>0) sb.append(" ");
            sb.append(minute.trim());
        }
        if(date.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(date);
        }
        String phase=group.length()>0?("Group "+group):normalizeStage(o.optString("stage",o.optString("round",o.optString("stageName",""))));
        if(phase.length()>0){
            if(sb.length()>0) sb.append(" • ");
            sb.append(phase);
        }
        if(sb.length()>0) sb.append(" • ");
        sb.append(flag(home)).append(" ").append(home);
        if(!noScore && hg>=0 && ag>=0) sb.append(" ").append(hg).append(" - ").append(ag).append(" ");
        else sb.append(" vs ");
        sb.append(flag(away)).append(" ").append(away);
        return sb.toString();
    }


    String formatRanking(JSONArray arr,String valueKey){
        if(arr==null || arr.length()==0) return "";
        StringBuilder sb=new StringBuilder();
        boolean isMvp=valueKey!=null && valueKey.equals("points");
        String[] medal={"🥇 ","🥈 ","🥉 ","4️⃣ ","5️⃣ "};
        for(int i=0;i<arr.length() && i<5;i++){
            JSONObject o=arr.optJSONObject(i);
            if(o==null) continue;
            String name=o.optString("name",o.optString("player",""));
            String team=o.optString("team","");
            String value=o.has(valueKey)?String.valueOf(o.opt(valueKey)):"";
            if(name.length()==0) continue;
            if(isMvp){
                sb.append(medal[i]).append(name);
            }else{
                sb.append(i+1).append(". ").append(name);
            }
            if(team.length()>0) sb.append(" • ").append(flag(team)).append(" ").append(team);
            if(value.length()>0) sb.append(" • ").append(value);
            if(valueKey.equals("goals") && value.length()>0) sb.append(" goals");
            if(valueKey.equals("points") && value.length()>0) sb.append(" pts");
            sb.append("\n");
        }
        return sb.toString().trim();
    }

void showPredictor(){
        clear(tr("Predict"),tr("Prediction Studio"),"Predict");
        LinearLayout c=card();c.addView(label("🔮 "+tr("Prediction Studio"),25,text,true));c.addView(label("Scores → tables → best thirds → bracket → champion → share poster.",15,subText,false));
        Button s=btn(tr("Enter Scores"));s.setOnClickListener(v->showMatches());c.addView(s);Button br=btn(tr("Pro Bracket"));br.setOnClickListener(v->showKnockout());c.addView(br);Button poster=btn(tr("Share Poster"));poster.setOnClickListener(v->showPoster());c.addView(poster);Button df=btn(tr("Dream Final"));df.setOnClickListener(v->showDreamFinal());c.addView(df);
        LinearLayout q=card();q.addView(label("✅ Qualified teams preview",22,text,true));List<TeamRow> qual=data.qualified();for(int i=0;i<Math.min(qual.size(),16);i++){TeamRow r=qual.get(i);q.addView(label((i+1)+". "+flag(r.team)+" "+r.team+" • Group "+r.group+" • "+r.pts+" pts",14,subText,false));}
    }

    String bracketTeam(ArrayList<String> q,int index){if(q==null||q.size()==0)return "TBD";return q.get(index%q.size());}


    ArrayList<String[]> bracketPairs(){
        ArrayList<String> q=new ArrayList<>();
        for(TeamRow r:data.qualified())q.add(r.team);
        if(q.size()<32){
            for(String t:data.teams){ if(!q.contains(t)) q.add(t); if(q.size()>=32)break; }
        }
        ArrayList<String[]> pairs=new ArrayList<>();
        for(int i=0;i<16;i++)pairs.add(new String[]{bracketTeam(q,i*2),bracketTeam(q,i*2+1)});
        return pairs;
    }
    void addBracketPair(LinearLayout parent,String a,String b,boolean withPlaceholder){
        LinearLayout box=inner(parent);
        box.addView(label(flag(a)+" "+a,16,text,true));
        if(withPlaceholder)box.addView(label("        "+tr("Winner")+": —",14,subText,false));
        else box.addView(label("        │",12,subText,false));
        box.addView(label(flag(b)+" "+b,16,text,true));
    }
    void addVisualPair(LinearLayout parent,String a,String b){
        LinearLayout box=inner(parent);
        box.addView(label("┌ "+flag(a)+" "+a,16,text,false));
        box.addView(label("├─ VS",16,subText,false));
        box.addView(label("└ "+flag(b)+" "+b,16,text,false));
    }
void showKnockout(){
        clear(tr("Pro Bracket"),tr("Round of 32")+" → "+tr("Final"),"Predict");
        LinearLayout intro=card();
        intro.setBackground(gradient(RED_DARK,RED,dp(24)));
        intro.addView(label("🏆 "+tr("Pro Bracket"),26,Color.WHITE,true));
        intro.addView(label(tr("Projected path from your group results."),15,Color.WHITE,false));
        LinearLayout c=card();
        c.addView(label(tr("Round of 32"),23,RED,true));
        for(String[] p:bracketPairs())addBracketPair(c,p[0],p[1],true);
    }
    LinearLayout inner(LinearLayout p){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(12),dp(10),dp(12),dp(10));l.setBackground(round(chipBg,dp(18),0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(8),0,dp(8));p.addView(l,lp);return l;}
    String winner(String a,String b){if(a.equals(myTeam))return a;if(b.equals(myTeam))return b;return a.compareTo(b)<=0?a:b;}

    void showPoster(){
        clear(tr("Share Poster"),"Social prediction card","Predict");
        LinearLayout p=card();p.setBackground(gradient(RED_DARK,RED,dp(24)));p.addView(label("WORLD CUP FAN 2026",25,Color.WHITE,true));p.addView(label("MY TOURNAMENT PREDICTION",17,Color.WHITE,false));p.addView(label(flag(myTeam)+" "+tr("My Team")+": "+myTeam,22,Color.WHITE,true));List<TeamRow> q=data.qualified();String champ=q.size()>0?q.get(0).team:myTeam;p.addView(label("🏆 Champion: "+flag(champ)+" "+champ,25,GOLD,true));p.addView(label("Top 4\n"+topLines(4),16,Color.WHITE,false));p.addView(label("Made with World Cup Fan 2026",13,Color.WHITE,false));Button share=btn(tr("Share Poster"));share.setOnClickListener(v->sharePrediction());p.addView(share);
    }
    String topLines(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++)s+=(i+1)+". "+flag(q.get(i).team)+" "+q.get(i).team+"\n";return s.length()==0?"TBD":s;}
    String topInline(int n){List<TeamRow> q=data.qualified();String s="";for(int i=0;i<Math.min(n,q.size());i++){if(i>0)s+=" • ";s+=flag(q.get(i).team)+" "+q.get(i).team;}return s.length()==0?"TBD":s;}

    void showDreamFinal(){clear(tr("Dream Final"),"Build a fan final","Predict");LinearLayout c=card();c.addView(label("🏆 "+tr("Dream Final"),25,text,true));Spinner left=spinner(data.teams,myTeam), right=spinner(data.teams,"Brazil");c.addView(label("Finalist 1",13,subText,true));c.addView(left);c.addView(label("Finalist 2",13,subText,true));c.addView(right);Button share=btn(tr("Share Poster"));share.setOnClickListener(v->{String a=left.getSelectedItem().toString(),b=right.getSelectedItem().toString();shareText("🏆 Dream Final 2026\n\n"+flag(a)+" "+a+" vs "+flag(b)+" "+b+"\n\nFootball Fun");});c.addView(share);}
    Spinner spinner(ArrayList<String> items,String sel){Spinner sp=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);sp.setAdapter(ad);int pos=items.indexOf(sel);if(pos>=0)sp.setSelection(pos);return sp;}

    void showMyTeam(){
        clear(tr("My Team"),"Team hub","More");
        LinearLayout c=card();
        c.addView(label(flag(myTeam)+" "+myTeam,28,RED,true));
        Spinner sp=spinner(data.teams,myTeam);
        c.addView(sp);
        Button save=btn("Save");
        save.setOnClickListener(v->{myTeam = sp.getSelectedItem().toString(); prefs.edit().putString("team", myTeam).apply(); toast("My Team saved"); showHome();});
        c.addView(save);

        LinearLayout path=card();
        path.addView(label("Road to Final",22,text,true));
        path.addView(pathPreview(myTeam));

        LinearLayout m=card();
        m.addView(label("⚽ "+tr("Matches"),22,text,true));
        int shown=0;
        for(Match ma:data.matches){
            if(sameTeam(ma.home,myTeam)||sameTeam(ma.away,myTeam)){
                m.addView(label(myTeamMatchLine(ma),14,subText,false));
                shown++;
            }
        }
        if(shown==0)m.addView(label("No matches found for "+myTeam,14,subText,false));
    }

    String myTeamMatchLine(Match ma){
        String date=myTeamDisplayDate(ma.date);
        String score=(ma.homeGoals>=0 && ma.awayGoals>=0)?(" "+ma.homeGoals+" - "+ma.awayGoals+" "):" vs ";
        String status=(ma.homeGoals>=0 && ma.awayGoals>=0)?"✅ FT • ":"📅 ";
        StringBuilder sb=new StringBuilder();
        sb.append(status);
        if(date.length()>0)sb.append(date).append(" • ");
        String phase=stageLabel(ma);
        if(phase.length()>0)sb.append(phase).append(" • ");
        sb.append(flag(ma.home)).append(" ").append(ma.home).append(score).append(flag(ma.away)).append(" ").append(ma.away);
        return sb.toString();
    }

    String myTeamDisplayDate(String raw){
        if(raw==null)return "";
        String d=raw.trim();
        if(d.length()==0)return "";
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC");
        d=d.replace("UTC","").trim();
        if(d.length()<16)return d;
        return displayLocalDateTime(raw);
    }

    String displayLocalDateTime(String raw){
        if(raw==null)return "";
        String d=raw.trim();
        if(d.length()==0)return "";
        if(d.contains("T"))d=cleanDate(d);
        boolean hasUtc=d.toUpperCase(Locale.US).contains("UTC") || d.endsWith("Z");
        d=d.replace("UTC","").replace("Z","").trim();
        if(d.length()<16)return d;
        // football-data.org returns UTC. Show match times in the phone's local timezone.
        // Local fallback schedules are already stored in local display time, so do not shift them.
        if(!hasUtc)return d;
        try{
            SimpleDateFormat in=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
            in.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date parsed=in.parse(d.substring(0,16));
            SimpleDateFormat out=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);
            out.setTimeZone(TimeZone.getDefault());
            return out.format(parsed);
        }catch(Exception ignored){
            return d;
        }
    }
    void showCities(){clear(tr("Host Cities"),"USA • Mexico • Canada","More");String[][] cities={{"🇲🇽 Mexico City","Opening match energy and historic football culture."},{"🇨🇦 Toronto","Canada showcase city."},{"🇺🇸 Los Angeles","Entertainment capital and massive fan base."},{"🇺🇸 New York/New Jersey","Final atmosphere and huge global audience."},{"🇺🇸 Dallas","Huge stadium, huge matches."},{"🇺🇸 Miami","Latin football culture."},{"🇨🇦 Vancouver","West coast Canadian host."},{"🇺🇸 Atlanta","Modern stadium and fan festival city."},{"🇺🇸 Houston","International city."},{"🇺🇸 Kansas City","American soccer heartland."},{"🇺🇸 Boston","Historic sports city."},{"🇺🇸 Seattle","Strong supporter culture."}};for(String[] ci:cities){LinearLayout c=card();c.addView(label(ci[0],22,text,true));c.addView(label(ci[1],15,subText,false));}}

    
    void showVisualBracket(){
        clear(tr("Visual Bracket"),tr("Tournament tree preview"),"More");
        LinearLayout c=card();
        c.addView(label("🏆 "+tr("Round of 32"),24,RED,true));
        for(String[] p:bracketPairs())addVisualPair(c,p[0],p[1]);
    }

    String projectedWinner(String a, String b) {
        if (a.equals(myTeam)) return a;
        if (b.equals(myTeam)) return b;
        int aa = teamPower(a), bb = teamPower(b);
        if (aa == bb) return a.compareTo(b) <= 0 ? a : b;
        return aa > bb ? a : b;
    }

    int teamPower(String t) {
        String elite = "Brazil Argentina France England Spain Germany Portugal Netherlands Belgium Croatia";
        String strong = "Uruguay Colombia Morocco Switzerland Denmark USA Mexico Japan Senegal";
        if (elite.contains(t)) return 90;
        if (strong.contains(t)) return 78;
        return 65;
    }

    void showScorers(){
        clear(tr("Golden Boot"),tr("Top scorers prediction"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.addView(label("🏆 Top Scorers 2026",25,text,true));
        c.addView(label(scorersIntro(),15,subText,false));
        String gb=prefs.getString("online_goldenBoot","");
        if(gb!=null && gb.trim().length()>0){
            c.addView(label(gb,15,subText,false));
            return;
        }
        String[][] scorers={
            {"Kylian Mbappé","France","7"},
            {"Harry Kane","England","6"},
            {"Lionel Messi","Argentina","5"},
            {"Vinícius Jr","Brazil","5"},
            {"Cristiano Ronaldo","Portugal","4"},
            {"Luka Modrić","Croatia","3"},
            {"Erling Haaland","Norway","3"},
            {"Mohamed Salah","Egypt","3"}
        };
        for(int i=0;i<scorers.length;i++){
            String[] s=scorers[i];
            c.addView(label((i+1)+". "+s[0]+" • "+flag(s[1])+" "+s[1]+" • "+s[2]+" "+tr("goals"),15,i<3?RED:subText,i<3));
        }
    }

    void showMvp(){
        clear(tr("MVP Prediction"),tr("Player of the tournament"),"More");
        addOnlineCard();
        LinearLayout c=card();
        c.setBackground(gradient(RED_DARK,RED,dp(24)));
        c.addView(label("⭐ "+tr("MVP Prediction"),26,Color.WHITE,true));
        c.addView(label(flag(myTeam)+" "+myTeam+" MVP Candidate",23,GOLD,true));
        c.addView(label(mvpIntro(),15,Color.WHITE,false));
        LinearLayout list=card();
        list.addView(label("🏆 MVP Power Ranking",22,text,true));
        String mv=prefs.getString("online_mvp","");
        if(mv!=null && mv.trim().length()>0){
            list.addView(label(mv,15,subText,false));
        }else{
            list.addView(label("🥇 "+flag(myTeam)+" "+myTeam+" Leader\n🥈 🇫🇷 France Star\n🥉 🇧🇷 Brazil Star\n4️⃣ 🇬🇧 England Star\n5️⃣ 🇦🇷 Argentina Star",15,subText,false));
        }
    }

    void showCompareTeams() {
        clear(tr("Compare Teams"), tr("Team vs Team"), "More");
        LinearLayout c = card();
        c.addView(label("⚔️ " + tr("Compare Teams"), 25, text, true));
        Spinner a = spinner(data.teams, myTeam);
        Spinner b = spinner(data.teams, "Brazil");
        c.addView(label("Team A", 13, subText, true)); c.addView(a);
        c.addView(label("Team B", 13, subText, true)); c.addView(b);
        Button compare = btn(tr("Compare Teams"));
        compare.setOnClickListener(v -> {
            String ta = a.getSelectedItem().toString();
            String tb = b.getSelectedItem().toString();
            showCompareResult(ta, tb);
        });
        c.addView(compare);
    }

    void showCompareResult(String a, String b) {
        clear("Compare", a + " vs " + b, "More");
        LinearLayout c = card();
        c.addView(label(flag(a) + " " + a + " vs " + flag(b) + " " + b, 22, text, true));
        int pa = teamPower(a), pb = teamPower(b);
        c.addView(label(a + " power: " + pa, 17, pa>=pb?GREEN:subText, true));
        c.addView(label(b + " power: " + pb, 17, pb>=pa?GREEN:subText, true));
        String pick = projectedWinner(a,b);
        c.addView(label("Projected winner: " + flag(pick) + " " + pick, 20, RED, true));
    }

    void showBackupExport() {
        clear(tr("Export Backup"), tr("Export / Import prediction"), "More");
        LinearLayout c = card();
        c.addView(label("💾 " + tr("Export Backup"), 24, text, true));
        c.addView(label("Export code lets fans save or send their prediction. Import can be added later when we move the app from MVP to full account-free backup.", 15, subText, false));
        Button export = btn("Share Backup Code");
        export.setOnClickListener(v -> shareText(buildBackupCode()));
        c.addView(export);
    }

    String buildBackupCode() {
        String code = "WCF2026|" + myTeam + "|" + displayPlayedCount() + "|" + displayTotalGoals() + "|" + displayProgressPercent();
        return "My World Cup Fan 2026 backup code:\n\n" + code + "\n\nSave this text for later.";
    }

    void showPdfPosterInfo() {
        clear(tr("PDF Poster Info"), tr("Printable prediction poster"), "More");
        LinearLayout c = card();
        c.addView(label("🖨️ " + tr("PDF Poster Info"), 24, text, true));
        c.addView(label("The app already has the poster layout. Next technical step is Android PDF export. For now, Share Poster creates a clean shareable prediction text/card.", 15, subText, false));
        Button open = btn("Open Share Poster");
        open.setOnClickListener(v -> showPoster());
        c.addView(open);
    }

    void showQuiz() {
        clear(tr("World Cup Quiz"), tr("Fan challenge"), "More");
        LinearLayout c = card();
        c.addView(label("🧠 " + tr("World Cup Quiz"), 25, text, true));
        final int[] score = new int[]{0};
        final int[] answered = new int[]{0};
        TextView scoreView = label(tr("Score") + ": 0/5", 18, RED, true);
        c.addView(scoreView);
        String[][] qa = {
            {"How many teams play in 2026?","48","32","36","40"},
            {"How many groups are there?","12","8","10","16"},
            {"How many teams are in each group?","4","3","5","6"},
            {"Which group is Croatia in?","L","A","D","H"},
            {"How many third-placed teams go through?","8","4","6","12"}
        };
        for (String[] q : qa) {
            LinearLayout box = inner(c);
            box.addView(label("❓ " + q[0], 16, text, true));
            ArrayList<String> opts = new ArrayList<>();
            opts.add(q[1]); opts.add(q[2]); opts.add(q[3]); opts.add(q[4]);
            Collections.shuffle(opts);
            final boolean[] done = new boolean[]{false};
            TextView result = label("", 14, subText, true);
            for(String opt:opts){
                Button b=outline(opt);
                b.setOnClickListener(v->{
                    if(done[0])return;
                    done[0]=true; answered[0]++;
                    if(((Button)v).getText().toString().equals(q[1])){score[0]++; result.setText("✅ "+tr("Correct")); result.setTextColor(GREEN);} 
                    else {result.setText("❌ "+tr("Wrong")+" • "+q[1]); result.setTextColor(RED);} 
                    scoreView.setText(tr("Score")+": "+score[0]+"/5");
                });
                box.addView(b);
            }
            box.addView(result);
        }
        Button again=btn(tr("Try again")); again.setOnClickListener(v->showQuiz()); c.addView(again);
    }

    void showStadiumGuide() {
        clear(tr("Stadium Guide"), tr("Host stadium notes"), "More");
        String[][] stadiums = {
            {"Azteca Stadium","Mexico City • iconic opening venue"},
            {"MetLife Stadium","New York/New Jersey • final-level stadium"},
            {"AT&T Stadium","Dallas • huge capacity"},
            {"SoFi Stadium","Los Angeles • modern showpiece"},
            {"Hard Rock Stadium","Miami • global fan city"},
            {"BC Place","Vancouver • Canadian west coast"}
        };
        for (String[] s : stadiums) {
            LinearLayout c = card();
            c.addView(label("🏟️ " + s[0], 22, text, true));
            c.addView(label(s[1], 15, subText, false));
        }
    }

    void showCityGuidePro() {
        clear(tr("City Guide Pro"), tr("Fan travel notes"), "More");
        String[][] cities = {
            {"Mexico City","Opening energy, football history, altitude factor."},
            {"Los Angeles","Entertainment, big stadium, global fan base."},
            {"New York/New Jersey","Final atmosphere and media center."},
            {"Dallas","Massive stadium and high-scoring indoor-style matches."},
            {"Miami","Latin football culture and beach city vibe."},
            {"Toronto","Canada showcase and multicultural fan base."}
        };
        for (String[] city : cities) {
            LinearLayout c = card();
            c.addView(label("🌎 " + city[0], 22, text, true));
            c.addView(label(city[1], 15, subText, false));
        }
    }

    void showAchievements() {
        clear(tr("Achievements"), tr("Badges and milestones"), "More");
        LinearLayout c = card();
        c.addView(label("🏅 " + tr("Achievements"), 25, text, true));
        int played = displayPlayedCount();
        c.addView(label((played>=1?"✅":"⬜") + " First Prediction", 17, played>=1?GREEN:subText, true));
        c.addView(label((played>=10?"✅":"⬜") + " Group Stage Analyst", 17, played>=10?GREEN:subText, true));
        c.addView(label((played>=24?"✅":"⬜") + " Tournament Expert", 17, played>=24?GREEN:subText, true));
        c.addView(label((displayProgressPercent()>=100?"✅":"⬜") + " Prediction Master", 17, displayProgressPercent()>=100?GOLD:subText, true));
        c.addView(label("My Team badge: " + flag(myTeam) + " " + myTeam + " Fan", 17, RED, true));
    }


    void showHostCityDetails(){
        clear(tr("Host Cities"),tr("16 host cities"),"More");
        String[][] cities={
            {"🇺🇸 Atlanta","Atlanta Stadium","United States","71,000","8","Modern host city, huge airport hub and strong sports culture.","Moderan grad domaćin, veliki zračni čvor i jaka sportska kultura.","Moderner Gastgeber, großer Flughafen-Hub und starke Sportkultur.","Ciudad moderna, gran aeropuerto y fuerte cultura deportiva.","Ville moderne, grand hub aérien et forte culture sportive."},
            {"🇺🇸 Boston","Boston Stadium","United States","65,000","7","Historic sports market with passionate East Coast fans.","Povijesni sportski grad s vatrenim navijačima istočne obale.","Historischer Sportmarkt mit leidenschaftlichen Fans der Ostküste.","Ciudad deportiva histórica con aficionados apasionados.","Marché sportif historique avec fans passionnés."},
            {"🇨🇦 Toronto","Toronto Stadium","Canada","45,000","6","Canada's biggest city and a multicultural football hub.","Najveći kanadski grad i multikulturalno nogometno središte.","Kanadas größte Stadt und multikulturelles Fußballzentrum.","La ciudad más grande de Canadá y centro multicultural del fútbol.","Plus grande ville du Canada et hub football multiculturel."},
            {"🇺🇸 Dallas","Dallas Stadium","United States","80,000","9","One of the biggest venues of the tournament.","Jedan od najvećih stadiona turnira.","Eine der größten Spielstätten des Turniers.","Una de las sedes más grandes del torneo.","L'une des plus grandes enceintes du tournoi."},
            {"🇲🇽 Guadalajara","Guadalajara Stadium","Mexico","49,000","4","Classic Mexican football city with deep local culture.","Klasični meksički nogometni grad s jakom lokalnom kulturom.","Klassische mexikanische Fußballstadt mit tiefer lokaler Kultur.","Ciudad clásica del fútbol mexicano con gran cultura local.","Ville classique du football mexicain avec forte culture locale."},
            {"🇺🇸 Houston","Houston Stadium","United States","72,000","7","Diverse global city with strong Latin football energy.","Raznolik globalni grad s jakom latino nogometnom energijom.","Vielfältige Weltstadt mit starker lateinamerikanischer Fußballenergie.","Ciudad global diversa con fuerte energía futbolera latina.","Ville mondiale diverse avec forte énergie football latino."},
            {"🇺🇸 Kansas City","Kansas City Stadium","United States","76,000","6","Known for loud crowds and supporter culture.","Poznat po glasnim navijačima i jakoj navijačkoj kulturi.","Bekannt für laute Fans und starke Supporter-Kultur.","Conocida por su afición ruidosa y cultura de seguidores.","Connue pour ses foules bruyantes et sa culture supporters."},
            {"🇺🇸 Los Angeles","Los Angeles Stadium","United States","70,000","8","Entertainment capital and premium stadium destination.","Prijestolnica zabave i premium stadionska destinacija.","Entertainment-Hauptstadt und Premium-Stadionziel.","Capital del entretenimiento y sede premium.","Capitale du divertissement et destination stade premium."},
            {"🇺🇸 Miami","Miami Stadium","United States","65,000","7","Beach city, Latin football culture and fan travel appeal.","Grad plaža, latino nogometne kulture i velika navijačka destinacija.","Strandstadt mit lateinamerikanischer Fußballkultur.","Ciudad de playa, cultura latina y gran atractivo para fans.","Ville de plage, culture football latino et forte attractivité fans."},
            {"🇲🇽 Mexico City","Mexico City Stadium","Mexico","87,000","5","Opening-match atmosphere and iconic football history.","Atmosfera utakmice otvaranja i legendarna nogometna povijest.","Eröffnungsspiel-Atmosphäre und ikonische Fußballgeschichte.","Ambiente inaugural e historia futbolística icónica.","Ambiance d'ouverture et histoire football iconique."},
            {"🇲🇽 Monterrey","Monterrey Stadium","Mexico","53,000","4","Modern stadium and intense football culture.","Moderan stadion i intenzivna nogometna kultura.","Modernes Stadion und intensive Fußballkultur.","Estadio moderno y cultura futbolera intensa.","Stade moderne et culture football intense."},
            {"🇺🇸 New York/New Jersey","New York/New Jersey Stadium","United States","82,500","8","Global media capital and final-stage atmosphere.","Globalna medijska prijestolnica i atmosfera završnice.","Globale Medienhauptstadt und Final-Atmosphäre.","Capital mediática global y ambiente de final.","Capitale médiatique mondiale et ambiance de finale."},
            {"🇺🇸 Philadelphia","Philadelphia Stadium","United States","69,000","6","Historic city with passionate sports fans.","Povijesni grad s vrlo strastvenim sportskim navijačima.","Historische Stadt mit leidenschaftlichen Sportfans.","Ciudad histórica con aficionados deportivos intensos.","Ville historique avec fans de sport passionnés."},
            {"🇺🇸 San Francisco Bay Area","Bay Area Stadium","United States","68,500","6","Tech-region host with strong tourism appeal.","Domaćin iz tehnološke regije s velikim turističkim potencijalom.","Tech-Region mit starker touristischer Anziehung.","Región tecnológica con gran atractivo turístico.","Région tech avec fort attrait touristique."},
            {"🇺🇸 Seattle","Seattle Stadium","United States","69,000","6","One of the strongest U.S. soccer cultures.","Jedna od najjačih nogometnih kultura u SAD-u.","Eine der stärksten Fußballkulturen der USA.","Una de las culturas futboleras más fuertes de EE.UU.","Une des plus fortes cultures soccer des États-Unis."},
            {"🇨🇦 Vancouver","Vancouver Stadium","Canada","54,500","7","Beautiful west-coast host city with tourism appeal.","Prekrasan grad domaćin na zapadnoj obali s jakim turizmom.","Schöne Gastgeberstadt an der Westküste mit Tourismus-Reiz.","Hermosa ciudad de la costa oeste con atractivo turístico.","Belle ville hôte de la côte ouest avec attrait touristique."}
        };
        for(String[] x:cities){
            LinearLayout c=card();
            c.addView(label(x[0],23,text,true));
            c.addView(label("🏟️ "+x[1],16,RED,true));
            c.addView(label(tr("Country")+": "+x[2]+"  •  "+tr("Capacity")+": "+x[3]+"  •  "+tr("Matches count")+": "+x[4],14,subText,false));
            c.addView(label(cityDesc(x[5],x[6],x[7],x[8],x[9]),15,subText,false));
        }
    }

    void showTeamHubPro() {
        clear("Team Hub Pro", "Detailed national team view", "More");
        LinearLayout top=card();
        top.addView(label(flag(myTeam)+" "+myTeam,30,RED,true));
        top.addView(label("Group "+groupOfTeam(myTeam)+" • saved My Team • Road to Final ready",16,subText,false));
        top.addView(label("Power rating: "+teamPower(myTeam)+"/100",18,GREEN,true));
        LinearLayout games=card();
        games.addView(label("⚽ Matches",23,text,true));
        for(Match m:data.matches){
            if(m.home.equals(myTeam)||m.away.equals(myTeam)){
                games.addView(label(displayLocalDateTime(m.date)+" • "+flag(m.home)+" "+m.home+" vs "+flag(m.away)+" "+m.away+" • "+m.venue,14,subText,false));
            }
        }
        LinearLayout notes=card();
        notes.addView(label("🔎 Fan notes",22,text,true));
        notes.addView(label("Use this screen later for squad, coach, form, star player and qualification story. It is now ready as the Team Hub base.",15,subText,false));
    }

    void showOnboardingPreview() {
        clear("Onboarding", "First launch preview", "More");
        LinearLayout a=card(); a.setBackground(gradient(RED_DARK, RED, dp(24)));
        a.addView(label("1/3  Pick your team",24,Color.WHITE,true));
        a.addView(label("Choose your national team and follow the road to the final.",16,Color.WHITE,false));
        LinearLayout b=card(); b.addView(label("2/3  Predict results",24,text,true));
        b.addView(label("Enter scores, calculate standings and build the knockout path.",16,subText,false));
        LinearLayout c=card(); c.addView(label("3/3  Share your poster",24,text,true));
        c.addView(label("Create a fan prediction and share it with friends before every matchday.",16,subText,false));
    }

    void showShareImagePlan() {
        clear("Poster Export", "Image/PDF export plan", "More");
        LinearLayout c=card();
        c.addView(label("🖼️ Share Poster Pro",24,text,true));
        c.addView(label("Current version shares prediction text/card. Next native step is PNG generation from the poster view, then PDF export for printable brackets.",15,subText,false));
        Button open=btn("Open Share Poster"); open.setOnClickListener(v->showPoster()); c.addView(open);
        LinearLayout roadmap=card();
        roadmap.addView(label("Export roadmap",22,RED,true));
        roadmap.addView(label("1. Poster preview\n2. Render as bitmap\n3. Save PNG\n4. Android share sheet\n5. PDF bracket export",15,subText,false));
    }

    void showKnockoutRules() {
        clear("Tournament Rules", "48-team format explained", "More");
        LinearLayout c=card();
        c.addView(label("📘 2026 format",24,text,true));
        c.addView(label("48 teams play in 12 groups of four. The top two teams from each group advance, plus the eight best third-placed teams. The knockout stage starts with a Round of 32.",16,subText,false));
        LinearLayout r=card();
        r.addView(label("App logic",22,RED,true));
        r.addView(label("The app calculates group tables from your scores, ranks third-placed teams and builds a predicted knockout path.",15,subText,false));
    }

    void showMonetizationPlan() {
        clear("Monetization", "Free vs Pro plan", "More");
        LinearLayout c=card(); c.setBackground(gradient(RED_DARK, RED, dp(24)));
        c.addView(label("💎 Pro plan",28,Color.WHITE,true));
        c.addView(label("Suggested: Free app + Pro unlock (€1.99–€4.99).",17,GOLD,true));
        c.addView(label("Free: scores, tables, basic prediction.\nPro: multiple predictions, poster export, PDF bracket, custom tournaments, achievements, no ads.",16,Color.WHITE,false));
        LinearLayout n=card();
        n.addView(label("Commercial focus",22,text,true));
        n.addView(label("The strongest paid feature is shareable prediction content: fans want to show their champion, final, bracket and team path.",15,subText,false));
    }


    String cityDesc(String en, String hr, String de, String es, String fr){
        if(lang.equals("HR"))return hr;
        if(lang.equals("DE"))return de;
        if(lang.equals("ES"))return es;
        if(lang.equals("FR"))return fr;
        return en;
    }
    String playerIntro(){
        if(lang.equals("HR"))return "Centar za Zlatnu kopačku, MVP prognozu i glavne zvijezde turnira.";
        if(lang.equals("DE"))return "Bereich für Goldener Schuh, MVP-Prognose und Turnierstars.";
        if(lang.equals("ES"))return "Sección para Bota de Oro, predicción MVP y estrellas del torneo.";
        if(lang.equals("FR"))return "Section Soulier d'Or, pronostic MVP et stars du tournoi.";
        return "Players hub for Golden Boot, MVP prediction and star-player watch.";
    }
    String scorersIntro(){
        if(lang.equals("HR"))return "Navijačka prognoza najboljih strijelaca. Kasnije se može povezati sa stvarnom statistikom utakmica.";
        if(lang.equals("DE"))return "Fan-Prognose der besten Torschützen. Später kann sie mit echten Spielstatistiken verbunden werden.";
        if(lang.equals("ES"))return "Predicción de goleadores para fans. Luego se puede conectar con estadísticas reales.";
        if(lang.equals("FR"))return "Pronostic des meilleurs buteurs. Plus tard, il pourra être relié aux vraies statistiques.";
        return "Fan prediction list for top scorers. Later this can be connected to real match statistics.";
    }
    String mvpIntro(){
        if(lang.equals("HR"))return "MVP prognoza prati tvoju odabranu reprezentaciju i trenutni navijački kostur.";
        if(lang.equals("DE"))return "Die MVP-Prognose folgt deinem gewählten Team und deinem aktuellen Turnierbaum.";
        if(lang.equals("ES"))return "La predicción MVP sigue tu selección elegida y tu cuadro actual.";
        if(lang.equals("FR"))return "Le pronostic MVP suit ton équipe choisie et ton tableau actuel.";
        return "MVP prediction follows your selected team and current fan bracket.";
    }

void showPlayersHub(){
        if(!ENABLE_PLAYER_DATA_MODULES){
            clear(tr("Players"),tr("Premium"),"More");
            LinearLayout locked=card();
            locked.addView(label("🔒 "+tr("Players"),24,text,true));
            locked.addView(label(t2("Player details, cards, line-ups and scorer tables are prepared in code, but hidden until the higher API plan is activated.","Detalji igrača, kartoni, sastavi i strijelci su pripremljeni u kodu, ali su sakriveni dok se ne aktivira veći API paket.","Spielerdetails, Karten, Aufstellungen und Torschützen sind im Code vorbereitet, aber bis zum höheren API-Paket ausgeblendet.","Detalles de jugadores, tarjetas, alineaciones y goleadores están preparados en el código, pero ocultos hasta activar el plan API superior.","Détails joueurs, cartons, compositions et buteurs sont prêts dans le code, mais masqués jusqu'au forfait API supérieur."),15,subText,false));
            return;
        }
        clear(tr("Players"),tr("Golden Boot"),"More");
        LinearLayout c=card();
        c.addView(label("⚽ "+tr("Players"),24,text,true));
        c.addView(label(playerIntro(),15,subText,false));
        Button scorers=btn(tr("Golden Boot")); scorers.setOnClickListener(v->showScorers()); c.addView(scorers);
        Button mvp=btn(tr("MVP Prediction")); mvp.setOnClickListener(v->showMvp()); c.addView(mvp);
        LinearLayout stars=card();
        stars.addView(label("⭐ "+tr("Star watch"),22,text,true));
        stars.addView(label("France • Mbappé\nArgentina • Messi\nEngland • Kane\nPortugal • Ronaldo\nBrazil • Vinícius Jr\nCroatia • Modrić\nNorway • Haaland\nEgypt • Salah",15,subText,false));
    }

    void showAboutApp(){
        clear(tr("About App"), tr("Independent fan app subtitle"), "More");
        LinearLayout c=card();
        c.addView(label("⚽ World Cup Fan 2026",26,text,true));
        c.addView(label(tr("Independent fan app subtitle"),18,RED,true));
        c.addView(label(tr("App version")+": "+APP_VERSION,16,subText,false));
        c.addView(label(tr("About feature line"),15,subText,false));
        LinearLayout tools=card(); tools.addView(label("🧰 "+t2("App tools","Alati aplikacije","App-Werkzeuge","Herramientas","Outils"),22,text,true));
        Button backup=outline(t2("Backup favorites","Sigurnosna kopija favorita","Favoriten sichern","Copia de favoritos","Sauvegarder les favoris")); backup.setOnClickListener(v->shareText("Football Fun backup: "+favoriteClubText()+" | "+followedCompetitionText())); tools.addView(backup);
        Button feedback=outline(t2("Send feedback","Pošalji povratnu informaciju","Feedback senden","Enviar comentarios","Envoyer un avis")); feedback.setOnClickListener(v->shareText("Football Fun feedback")); tools.addView(feedback);
        Button rate=outline(t2("Rate Football Fun","Ocijeni Football Fun","Football Fun bewerten","Valorar Football Fun","Noter Football Fun")); rate.setOnClickListener(v->toast(t2("Store rating opens after public release.","Ocjenjivanje se otvara nakon javne objave.","Bewertung nach Veröffentlichung.","La valoración se abrirá tras el lanzamiento.","La notation sera disponible après publication."))); tools.addView(rate);

        LinearLayout l=card();
        l.addView(label(tr("Legal"),22,text,true));
        l.addView(label(tr("This app is not affiliated with FIFA."),15,subText,false));
        l.addView(label(tr("Legal notice detail"),15,subText,false));
    }

    void showPrivacyPolicy(){
        clear(tr("Privacy Policy"), tr("No login. No account. No personal profile."), "More");
        LinearLayout c=card();
        c.addView(label("🔒 "+tr("Privacy Policy"),26,text,true));
        c.addView(label(tr("No login. No account. No personal profile."),16,subText,false));
        c.addView(label(tr("Data is stored only on this device."),16,subText,false));
        c.addView(label(tr("Scores, language, theme and selected team are saved locally."),16,subText,false));
        LinearLayout legal=card();
        legal.addView(label(tr("Legal safety"),22,RED,true));
        legal.addView(label(tr("This app is not affiliated with FIFA."),15,subText,false));
        legal.addView(label(tr("No betting streaming media"),15,subText,false));
    }

    void showDailyBrief(){
        clear(t2("Your football day","Tvoj nogometni dan","Dein Fußballtag","Tu día de fútbol","Ta journée football"),t2("Everything important, in one place","Sve važno na jednom mjestu","Alles Wichtige an einem Ort","Todo lo importante en un lugar","Tout l'essentiel au même endroit"),"Home");
        LinearLayout c=card(); c.addView(label("🔥 "+favoriteClub,24,text,true)); c.addView(label(t2("Your club is the first priority in this briefing.","Tvoj klub je prvi prioritet ovog sažetka.","Dein Klub hat in diesem Briefing Priorität.","Tu club es la prioridad de este resumen.","Ton club est la priorité de ce brief."),15,subText,false));
        Match n=nextFavoriteMatch(); if(n!=null)addHomeMatchRow(c,n,true);
        LinearLayout rep=card(); rep.addView(label(flag(myTeam)+" "+myTeam,22,text,true)); rep.addView(label(t2("National team watch is active. Line-up and match alerts are prepared.","Praćenje reprezentacije je aktivno. Spremne su obavijesti za sastav i utakmicu.","Nationalteam-Tracking ist aktiv.","Seguimiento de selección activo.","Suivi de la sélection actif."),15,subText,false));
        LinearLayout league=card(); league.addView(label("🏆 "+primaryFollowedCompetition(),22,text,true)); league.addView(label(competitionMeta(primaryFollowedCompetition()),15,subText,false));
    }

    void showTransferCenter(){
        clear(t2("Transfer center","Transfer centar","Transferzentrum","Centro de fichajes","Centre des transferts"),t2("Official deals, loans and rumours","Službeni transferi, posudbe i glasine","Offizielle Deals, Leihen und Gerüchte","Operaciones, cesiones y rumores","Transferts, prêts et rumeurs"),"More");
        String[][] rows={{"✅","Official","New signing added to the followed-club watchlist."},{"🔄","Rumour","Midfielder linked with a summer move."},{"📤","Outgoing","Loan option being monitored."},{"🧭","Scout watch","Three targets match the club profile."}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+t2(r[1],r[1].equals("Official")?"Službeno":r[1].equals("Rumour")?"Glasina":r[1].equals("Outgoing")?"Odlazak":"Praćenje skauta",r[1],r[1],r[1]),21,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showInjuryCenter(){
        clear(t2("Injuries & suspensions","Ozljede i suspenzije","Verletzungen & Sperren","Lesiones y sanciones","Blessures et suspensions"),favoriteClub,"More");
        LinearLayout summary=card(); summary.addView(kpiRow(t2("Injured","Ozlijeđeni","Verletzt","Lesionados","Blessés"),"2",t2("Doubtful","Upitni","Fraglich","Dudosos","Incertain"),"1",t2("Suspended","Suspendirani","Gesperrt","Sancionados","Suspendus"),"0",false));
        String[][] rows={{"🩹","First-team forward",t2("Expected return: 12 days","Povratak: 12 dana","Rückkehr: 12 Tage","Regreso: 12 días","Retour : 12 jours")},{"⚠️","Central midfielder",t2("Late fitness test","Kasni test spremnosti","Später Fitnesstest","Prueba física tardía","Test physique tardif")}};
        for(String[] r:rows){LinearLayout c=card();c.addView(label(r[0]+" "+r[1],20,text,true));c.addView(label(r[2],15,subText,false));}
    }

    void showAiDailySummary(){
        clear("Football Fun AI+",t2("Your personalized football summary","Tvoj personalizirani nogometni sažetak","Deine personalisierte Fußball-Zusammenfassung","Tu resumen personalizado","Ton résumé personnalisé"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(17,48,90),Color.rgb(84,32,142),dp(24))); hero.addView(label("🤖 "+t2("Today in your football","Danas u tvom nogometu","Heute in deinem Fußball","Hoy en tu fútbol","Aujourd'hui dans ton football"),24,Color.WHITE,true));
        hero.addView(label("• "+favoriteClub+" "+t2("remains your top priority.","ostaje tvoj glavni prioritet.","bleibt deine Top-Priorität.","sigue siendo tu prioridad.","reste ta priorité.")+"\n• "+myTeam+" "+t2("alerts are enabled.","obavijesti su uključene.","Benachrichtigungen sind aktiv.","tiene alertas activadas.","a les alertes activées.")+"\n• "+primaryFollowedCompetition()+" "+t2("is ready for the next round.","spreman je za sljedeće kolo.","ist bereit für die nächste Runde.","está listo para la próxima jornada.","est prêt pour la prochaine journée."),16,Color.WHITE,false));
        LinearLayout chance=card(); chance.addView(label("📊 "+t2("AI match probability","AI procjena utakmice","KI-Spielwahrscheinlichkeit","Probabilidad IA","Probabilité IA"),22,text,true)); chance.addView(kpiRow(favoriteClub,"62%",t2("Draw","Neriješeno","Unentschieden","Empate","Nul"),"24%",t2("Opponent","Protivnik","Gegner","Rival","Adversaire"),"14%",false)); chance.addView(label(t2("Based on saved form and available app data. Not betting advice.","Na temelju spremljene forme i dostupnih podataka. Nije savjet za klađenje.","Basierend auf gespeicherter Form. Keine Wettberatung.","Basado en la forma guardada. No es consejo de apuestas.","Basé sur la forme enregistrée. Pas un conseil de pari."),13,subText,false));
    }

    void showSmartTeamComparison(){
        clear(t2("Smart team comparison","Pametna usporedba timova","Intelligenter Teamvergleich","Comparación inteligente","Comparaison intelligente"),t2("Form, absences, value and history","Forma, izostanci, vrijednost i povijest","Form, Ausfälle, Wert und Historie","Forma, bajas, valor e historial","Forme, absences, valeur et historique"),"More");
        LinearLayout c=card(); c.addView(label(favoriteClub+"  VS  "+t2("Next opponent","Sljedeći protivnik","Nächster Gegner","Próximo rival","Prochain adversaire"),23,text,true)); c.addView(kpiRow(t2("Form","Forma","Form","Forma","Forme"),"W W D W L",t2("Squad value","Vrijednost","Kaderwert","Valor","Valeur"),"€92M",t2("AI edge","AI prednost","KI-Vorteil","Ventaja IA","Avantage IA"),"62%",false));
        LinearLayout h=card(); h.addView(label("📚 "+t2("Head-to-head","Međusobni omjer","Direkter Vergleich","Cara a cara","Face-à-face"),22,text,true)); h.addView(label(t2("Last 5: 3 wins • 1 draw • 1 loss","Zadnjih 5: 3 pobjede • 1 remi • 1 poraz","Letzte 5: 3 Siege • 1 Remis • 1 Niederlage","Últimos 5: 3 victorias • 1 empate • 1 derrota","5 derniers : 3 victoires • 1 nul • 1 défaite"),16,subText,false));
    }

    void showFootballCalendar(){
        clear(t2("Football calendar","Nogometni kalendar","Fußballkalender","Calendario de fútbol","Calendrier football"),t2("Your clubs and teams by date","Tvoji klubovi i reprezentacije po datumima","Deine Klubs und Teams nach Datum","Tus clubes y selecciones por fecha","Tes clubs et équipes par date"),"More");
        Calendar now=Calendar.getInstance(); String[] days={"MON","TUE","WED","THU","FRI","SAT","SUN"};
        LinearLayout month=card(); month.addView(label(new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(now.getTime()),24,text,true));
        LinearLayout head=hrow(); for(String d:days){TextView t=label(d,11,subText,true);t.setGravity(Gravity.CENTER);head.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));} month.addView(head);
        for(int r=0;r<5;r++){LinearLayout week=hrow();for(int i=0;i<7;i++){int n=r*7+i+1;TextView d=chip(String.valueOf(n));d.setGravity(Gravity.CENTER);if(n==10||n==14||n==18)d.setText("⚽\n"+n);week.addView(d,new LinearLayout.LayoutParams(0,dp(58),1));}month.addView(week);} 
        LinearLayout upcoming=card(); upcoming.addView(label("📅 "+t2("Upcoming for you","Uskoro za tebe","Demnächst für dich","Próximamente para ti","À venir pour toi"),22,text,true)); Match m=nextFavoriteMatch(); if(m!=null)addHomeMatchRow(upcoming,m,true);
    }

    void showFanJourney(){
        clear(t2("Fan journey","Navijački put","Fan-Reise","Camino del aficionado","Parcours de fan"),t2("Profile, streaks and achievements","Profil, nizovi i postignuća","Profil, Serien und Erfolge","Perfil, rachas y logros","Profil, séries et succès"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24))); hero.addView(label("🏅 "+profileName,25,Color.WHITE,true)); hero.addView(label("🔥 12 "+t2("day streak","dana u nizu","Tage Serie","días de racha","jours de série"),18,Color.WHITE,true)); hero.addView(kpiRow(t2("Matches","Utakmice","Spiele","Partidos","Matchs"),String.valueOf(displayPlayedCount()),t2("Predictions","Prognoze","Tipps","Pronósticos","Pronostics"),"84",t2("Leagues","Lige","Ligen","Ligas","Ligues"),String.valueOf(followedCompetitions.size()),true));
        String[] badges={"🏆 "+t2("First competition followed","Prvo praćeno natjecanje","Erster Wettbewerb","Primera competición","Première compétition"),"💯 "+t2("100 match explorer","Istraživač 100 utakmica","100-Spiele-Entdecker","Explorador de 100 partidos","Explorateur de 100 matchs"),"🎯 "+t2("Prediction specialist","Specijalist prognoza","Prognose-Spezialist","Especialista en pronósticos","Spécialiste des pronostics"),"👑 "+t2("Fan of the year progress","Napredak prema navijaču godine","Fan-des-Jahres-Fortschritt","Progreso fan del año","Progression fan de l'année")};
        for(String b:badges){LinearLayout c=card();c.addView(label(b,19,text,true));c.addView(label("████████░░ 80%",15,RED,true));}
    }

void showMore(){
        clear(tr("More"),t2("Settings and support","Postavke i podrška","Einstellungen und Hilfe","Ajustes y soporte","Réglages et assistance"),"More");

        LinearLayout settings=card();
        settings.addView(label("⚙️ "+t2("Settings","Postavke","Einstellungen","Ajustes","Réglages"),23,text,true));

        settings.addView(label("🌍 "+tr("Language"),17,subText,true));
        LinearLayout langs=hrow();
        for(String l:new String[]{"EN","HR","DE","ES","FR"}){
            TextView cc=chip(l);
            if(l.equals(lang)){ cc.setTextColor(Color.WHITE); cc.setBackground(gradient(RED_DARK,RED,dp(18))); }
            cc.setOnClickListener(v->{ lang=((TextView)v).getText().toString(); prefs.edit().putString("lang",lang).apply(); redraw(); });
            langs.addView(cc,new LinearLayout.LayoutParams(0,dp(44),1));
        }
        settings.addView(langs);

        Switch notifySwitch=new Switch(this);
        notifySwitch.setText("🔔 "+t2("Match notifications","Obavijesti za utakmice","Spielbenachrichtigungen","Notificaciones de partidos","Notifications de matchs"));
        notifySwitch.setTextColor(text); notifySwitch.setChecked(prefs.getBoolean("notifications",true));
        notifySwitch.setOnCheckedChangeListener((buttonView,isChecked)->prefs.edit().putBoolean("notifications",isChecked).apply());
        settings.addView(notifySwitch);

        Button mode=btn(darkMode?t2("Switch to light theme","Uključi svijetlu temu","Zum hellen Design","Cambiar a tema claro","Passer au thème clair"):t2("Switch to dark theme","Uključi tamnu temu","Zum dunklen Design","Cambiar a tema oscuro","Passer au thème sombre"));
        mode.setOnClickListener(v->{ darkMode=!darkMode; prefs.edit().putBoolean("darkMode",darkMode).apply(); redraw(); });
        settings.addView(mode);

        LinearLayout account=card();
        account.addView(label("⭐ "+t2("Personalization","Personalizacija","Personalisierung","Personalización","Personnalisation"),23,text,true));
        Button favoritesBtn=outline(t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris")); favoritesBtn.setOnClickListener(v->showFavorites()); account.addView(favoritesBtn);
        Button myTeamBtn=outline(tr("My Team")); myTeamBtn.setOnClickListener(v->showMyTeam()); account.addView(myTeamBtn);
        Button profileBtn=outline("👤 "+t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil")); profileBtn.setOnClickListener(v->showProfile()); account.addView(profileBtn);

        LinearLayout premium=card();
        premium.setBackground(gradient(PURPLE_DARK,Color.rgb(174,34,118),dp(24)));
        premium.addView(label("💎 Football Fun PRO",24,Color.WHITE,true));
        premium.addView(label(t2("No ads and extra convenience — without hiding basic football information.","Bez oglasa i dodatna praktičnost — bez zaključavanja osnovnih nogometnih informacija.","Keine Werbung und mehr Komfort – ohne grundlegende Fußballinfos zu sperren.","Sin anuncios y más comodidad, sin bloquear la información básica.","Sans publicité et plus de confort, sans bloquer les informations essentielles."),15,Color.WHITE,false));
        Button premiumBtn=btn(tr("Premium")); premiumBtn.setOnClickListener(v->showPremium()); premium.addView(premiumBtn);

        LinearLayout info=card();
        info.addView(label("ℹ️ "+t2("Information","Informacije","Informationen","Información","Informations"),23,text,true));
        Button aboutBtn=outline("📱 "+tr("About App")); aboutBtn.setOnClickListener(v->showAboutApp()); info.addView(aboutBtn);
        Button privacyBtn=outline("🔒 "+tr("Privacy Policy")); privacyBtn.setOnClickListener(v->showPrivacyPolicy()); info.addView(privacyBtn);
        Button termsBtn=outline("📄 "+t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation")); termsBtn.setOnClickListener(v->showTermsOfUse()); info.addView(termsBtn);

        LinearLayout support=card();
        support.addView(label("💬 "+t2("Support","Podrška","Hilfe","Soporte","Assistance"),23,text,true));
        support.addView(label(t2("Questions, ideas or a problem? Send us a message.","Pitanje, prijedlog ili problem? Pošalji nam poruku.","Frage, Idee oder Problem? Schreib uns.","¿Pregunta, idea o problema? Escríbenos.","Une question, une idée ou un problème ? Écris-nous."),15,subText,false));
        Button contactBtn=outline("✉️ "+t2("Contact support","Kontaktiraj podršku","Support kontaktieren","Contactar soporte","Contacter l’assistance")); contactBtn.setOnClickListener(v->openSupportEmail("Football Fun support")); support.addView(contactBtn);
        Button reportBtn=outline("🐞 "+t2("Report a problem","Prijavi problem","Problem melden","Informar de un problema","Signaler un problème")); reportBtn.setOnClickListener(v->openSupportEmail("Football Fun problem report")); support.addView(reportBtn);
        Button ideaBtn=outline("💡 "+t2("Send a suggestion","Pošalji prijedlog","Vorschlag senden","Enviar sugerencia","Envoyer une suggestion")); ideaBtn.setOnClickListener(v->openSupportEmail("Football Fun suggestion")); support.addView(ideaBtn);

        LinearLayout version=card();
        version.addView(label("v"+APP_VERSION+" • Build "+APP_BUILD_CODE,18,RED,true));
        version.addView(label(t2("Fast, personal and focused on the football you follow.","Brza, osobna i usmjerena na nogomet koji pratiš.","Schnell, persönlich und auf deinen Fußball fokussiert.","Rápida, personal y centrada en tu fútbol.","Rapide, personnelle et centrée sur ton football."),15,subText,false));
    }

    void showTermsOfUse(){
        clear(t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),"Football Fun","More");
        LinearLayout c=card();
        c.addView(label("📄 "+t2("Terms of use","Uvjeti korištenja","Nutzungsbedingungen","Términos de uso","Conditions d’utilisation"),24,text,true));
        c.addView(label(t2(
            "Football Fun provides football information for personal use. Match data may be delayed or corrected. The app does not provide betting advice. By using the app, you agree to use its content responsibly.",
            "Football Fun pruža nogometne informacije za osobnu upotrebu. Podaci o utakmicama mogu kasniti ili biti naknadno ispravljeni. Aplikacija ne daje savjete za klađenje. Korištenjem aplikacije prihvaćaš odgovorno koristiti njezin sadržaj.",
            "Football Fun stellt Fußballinformationen zur persönlichen Nutzung bereit. Spieldaten können verzögert oder korrigiert werden. Die App bietet keine Wettberatung.",
            "Football Fun ofrece información futbolística para uso personal. Los datos pueden retrasarse o corregirse. La app no ofrece consejos de apuestas.",
            "Football Fun fournit des informations footballistiques à usage personnel. Les données peuvent être retardées ou corrigées. L’application ne fournit aucun conseil de pari."),16,subText,false));
    }

    void openSupportEmail(String subject){
        try{
            Intent email=new Intent(Intent.ACTION_SENDTO);
            email.setData(Uri.parse("mailto:"));
            email.putExtra(Intent.EXTRA_SUBJECT,subject+" • v"+APP_VERSION);
            startActivity(Intent.createChooser(email,t2("Send email","Pošalji e-mail","E-Mail senden","Enviar correo","Envoyer un e-mail")));
        }catch(Exception e){
            toast(t2("No email app is available.","Nije pronađena aplikacija za e-mail.","Keine E-Mail-App verfügbar.","No hay una app de correo disponible.","Aucune application e-mail disponible."));
        }
    }

    String safeTeam(String value){
        if(value==null||value.trim().isEmpty()||value.equalsIgnoreCase("null")) return t2("To be decided","Još nije poznato","Noch offen","Por definir","À déterminer");
        return value.trim();
    }

    void addCompactResultRow(LinearLayout parent,Match m){
        LinearLayout row=hrow(); row.setPadding(dp(10),dp(8),dp(10),dp(8)); row.setBackground(round(chipBg,dp(14),0));
        TextView teams=label(flag(m.home)+" "+safeTeam(m.home)+"  "+m.homeGoals+" : "+m.awayGoals+"  "+flag(m.away)+" "+safeTeam(m.away),14,text,true);
        row.addView(teams,new LinearLayout.LayoutParams(0,-2,1));
        row.setOnClickListener(v->showMatchDetails(m));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,dp(4),0,dp(4)); parent.addView(row,lp);
    }

    void showGlobalSearch(){
        clear(t2("Global search","Globalna pretraga","Globale Suche","Búsqueda global","Recherche globale"),t2("Teams • players • competitions • cities","Klubovi • igrači • natjecanja • gradovi","Teams • Spieler • Wettbewerbe • Städte","Equipos • jugadores • competiciones • ciudades","Équipes • joueurs • compétitions • villes"),"More");
        LinearLayout c=card();
        EditText q=new EditText(this); q.setHint(t2("Type a name","Upiši naziv","Namen eingeben","Escribe un nombre","Saisir un nom")); q.setSingleLine(true); q.setTextColor(text); q.setHintTextColor(subText); q.setBackground(round(chipBg,dp(16),0)); q.setPadding(dp(14),0,dp(14),0); c.addView(q,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout results=card(); results.addView(label("🔎 "+t2("Search results","Rezultati pretrage","Suchergebnisse","Resultados","Résultats"),22,text,true));
        Button run=btn(t2("Search everything","Pretraži sve","Alles durchsuchen","Buscar todo","Tout rechercher"));
        run.setOnClickListener(v->{
            results.removeAllViews(); results.addView(label("🔎 "+t2("Search results","Rezultati pretrage","Suchergebnisse","Resultados","Résultats"),22,text,true));
            String term=q.getText().toString().trim().toLowerCase(Locale.US); int count=0;
            for(String team:data.teams) if(term.length()==0||team.toLowerCase(Locale.US).contains(term)){ Button b=outline(flag(team)+" "+team); final String selected=team; b.setOnClickListener(x->{myTeam=selected;prefs.edit().putString("team",myTeam).apply();showMyTeam();}); results.addView(b); if(++count>=8)break; }
            String[][] comps={{"World Cup 2026","International"},{"UEFA European Championship","International"},{"UEFA Champions League","Europe"},{"Premier League","England"},{"Championship","England"},{"La Liga","Spain"},{"Bundesliga","Germany"},{"Serie A","Italy"},{"Ligue 1","France"},{"Eredivisie","Netherlands"},{"Primeira Liga","Portugal"},{"Brasileirão Série A","Brazil"},{"HNL","Croatia"}};
            for(String[] comp:comps) if(term.length()>0&&comp[0].toLowerCase(Locale.US).contains(term)){ Button b=outline("🏆 "+comp[0]); final String n=comp[0],r=comp[1]; b.setOnClickListener(x->showCompetitionHub(n,r)); results.addView(b); }
            if(count==0&&term.length()>0) results.addView(label(t2("No team found. Try a league or country.","Nema pronađene momčadi. Pokušaj ligu ili državu.","Kein Team gefunden.","No se encontró equipo.","Aucune équipe trouvée."),15,subText,false));
        }); c.addView(run);
    }

    void showProfile(){
        clear(t2("My profile","Moj profil","Mein Profil","Mi perfil","Mon profil"),t2("Your football identity","Tvoj nogometni identitet","Deine Fußballidentität","Tu identidad futbolística","Ton identité football"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("👤 "+profileName,27,Color.WHITE,true)); hero.addView(label(flag(profileCountry)+" "+profileCountry,17,Color.WHITE,false));
        hero.addView(kpiRow(t2("Viewed","Pogledano","Angesehen","Vistos","Vus"),String.valueOf(displayPlayedCount()),t2("Favorites","Favoriti","Favoriten","Favoritos","Favoris"),String.valueOf(favoriteClubs.size()),t2("Following","Pratiš","Gefolgt","Siguiendo","Suivis"),String.valueOf(followedCompetitions.size()),true));
        LinearLayout form=card();
        EditText name=new EditText(this); name.setText(profileName); name.setHint(t2("Display name","Ime profila","Anzeigename","Nombre visible","Nom affiché")); name.setTextColor(text); name.setBackground(round(chipBg,dp(16),0)); name.setPadding(dp(14),0,dp(14),0); form.addView(name,new LinearLayout.LayoutParams(-1,dp(54)));
        Spinner country=spinner(data.teams,profileCountry); form.addView(country);
        Button save=btn(t2("Save profile","Spremi profil","Profil speichern","Guardar perfil","Enregistrer le profil")); save.setOnClickListener(v->{profileName=name.getText().toString().trim(); if(profileName.isEmpty())profileName="Football Fan"; profileCountry=country.getSelectedItem().toString(); prefs.edit().putString("profileName",profileName).putString("profileCountry",profileCountry).apply(); toast(t2("Profile saved","Profil spremljen","Profil gespeichert","Perfil guardado","Profil enregistré")); showProfile();}); form.addView(save);
        LinearLayout achievements=card(); achievements.addView(label("🏅 "+t2("Your progress","Tvoj napredak","Dein Fortschritt","Tu progreso","Ta progression"),22,text,true)); achievements.addView(label("✓ "+t2("Profile created","Profil kreiran","Profil erstellt","Perfil creado","Profil créé")+"\n✓ "+t2("Favorite selected","Favorit odabran","Favorit gewählt","Favorito elegido","Favori choisi")+"\n✓ "+t2("Competition followed","Natjecanje praćeno","Wettbewerb verfolgt","Competición seguida","Compétition suivie"),16,subText,false));
    }

    void showOfflineCenter(){
        clear(t2("Offline & sync","Offline i sinkronizacija","Offline & Sync","Offline y sincronización","Hors ligne et synchro"),t2("Always keep your football available","Tvoj nogomet uvijek dostupan","Dein Fußball immer verfügbar","Tu fútbol siempre disponible","Ton football toujours disponible"),"More");
        LinearLayout status=card(); status.addView(label("📡 "+t2("Connection status","Status veze","Verbindungsstatus","Estado de conexión","État de connexion"),22,text,true)); status.addView(label(onlineStatus+"\n"+t2("Last cached update","Zadnje spremljeno ažuriranje","Letztes Cache-Update","Última actualización guardada","Dernière mise à jour en cache")+": "+prefs.getString("onlineLastUpdate","—"),15,subText,false));
        Button sync=btn("↻ "+t2("Sync now","Sinkroniziraj sada","Jetzt synchronisieren","Sincronizar ahora","Synchroniser maintenant")); sync.setOnClickListener(v->refreshOnlineSafe(true)); status.addView(sync);
        LinearLayout offline=card(); offline.addView(label("📦 "+t2("Offline mode","Offline način","Offline-Modus","Modo sin conexión","Mode hors ligne"),22,text,true)); offline.addView(label(t2("The latest matches, favorites and settings stay available without internet.","Zadnje utakmice, favoriti i postavke ostaju dostupni bez interneta.","Letzte Spiele, Favoriten und Einstellungen bleiben offline verfügbar.","Los últimos partidos, favoritos y ajustes quedan disponibles sin internet.","Les derniers matchs, favoris et réglages restent disponibles hors ligne."),15,subText,false));
        Button backup=outline(t2("Export local backup","Izvezi lokalnu kopiju","Lokales Backup exportieren","Exportar copia local","Exporter la sauvegarde locale")); backup.setOnClickListener(v->showBackupExport()); offline.addView(backup);
    }

    void showPremium(){
        clear(tr("Premium"),tr("Free vs Pro"),"More");
        LinearLayout hero=card(); hero.setBackground(gradient(Color.rgb(54,24,96),Color.rgb(137,48,196),dp(24)));
        hero.addView(label("💎 Football Fun Pro",27,Color.WHITE,true));
        hero.addView(label(t2("Built for fans who follow football every day.","Za navijače koji nogomet prate svaki dan.","Für Fans, die Fußball jeden Tag verfolgen.","Para aficionados que siguen el fútbol cada día.","Pour les fans qui suivent le football chaque jour."),16,Color.WHITE,false));
        hero.addView(label("€1.99 / "+t2("month","mjesec","Monat","mes","mois"),22,GOLD,true));
        LinearLayout benefits=card(); benefits.addView(label("✓ "+t2("No advertising","Bez oglasa","Keine Werbung","Sin publicidad","Sans publicité"),18,text,true)); benefits.addView(label("✓ "+t2("Unlimited clubs and competitions","Neograničeni klubovi i natjecanja","Unbegrenzte Klubs und Wettbewerbe","Clubes y competiciones ilimitados","Clubs et compétitions illimités"),18,text,true)); benefits.addView(label("✓ "+t2("Advanced match alerts","Napredne obavijesti za utakmice","Erweiterte Spielhinweise","Alertas avanzadas","Alertes avancées"),18,text,true)); benefits.addView(label("✓ "+t2("Deeper statistics and trends","Detaljnija statistika i trendovi","Tiefere Statistiken und Trends","Estadísticas y tendencias detalladas","Statistiques et tendances détaillées"),18,text,true)); benefits.addView(label("✓ "+t2("Premium themes and widgets","Premium teme i widgeti","Premium-Themes und Widgets","Temas y widgets Premium","Thèmes et widgets Premium"),18,text,true));
        Button coming=btn(t2("Pro launch coming soon","Pro uskoro dolazi","Pro startet bald","Pro llegará pronto","Pro arrive bientôt")); coming.setOnClickListener(v->toast(t2("You will keep your favorites when Pro launches.","Favoriti će ostati spremljeni kada Pro bude pokrenut.","Deine Favoriten bleiben beim Pro-Start erhalten.","Tus favoritos se conservarán al lanzar Pro.","Tes favoris seront conservés au lancement de Pro."))); benefits.addView(coming);
    }
    void showStats(){clear(tr("Statistics"),"Advanced insights","More");LinearLayout c=card();c.addView(label("📊 "+tr("Statistics"),25,text,true));c.addView(kpiRow("Played",""+displayPlayedCount(),"Goals",""+displayTotalGoals(),"Progress",displayProgressPercent()+"%",false));c.addView(label("Average goals: "+data.avgGoals(),18,subText,false));c.addView(label("Best attack: "+data.bestAttack(),18,RED,true));c.addView(label("Highest scoring group: "+data.bestGroup(),18,GREEN,true));}
    void sharePrediction(){shareText("⚽ Football Fun\n\n"+tr("My Team")+": "+flag(myTeam)+" "+myTeam+"\nChampion pick: "+topInline(1)+"\nTop 4: "+topInline(4)+"\nProgress: "+displayProgressPercent()+"%\n\nFootball Fun");}
    void shareText(String msg){Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,msg);startActivity(Intent.createChooser(send,"Share"));hideSystemBars();}
    
    void showPlayStoreChecklist() {
        clear("Play Store", tr("Launch readiness checklist"), "More");
        LinearLayout c = card();
        c.addView(label("🚀 Play Store Launch Checklist", 24, text, true));
        c.addView(label("Status: almost ready for private/internal testing.", 15, subText, false));
        c.addView(label("✅ Offline tournament simulator\n✅ All 48 teams loaded\n✅ Group tables\n✅ My Team hub\n✅ Croatia Road to Final\n✅ Multi-language menu\n✅ Dark/Light mode\n✅ Share Prediction\n✅ Premium positioning", 15, subText, false));
        LinearLayout todo = card();
        todo.addView(label("Before public release", 22, RED, true));
        todo.addView(label("1. Verify every official fixture date and venue.\n2. Do not use FIFA logo or official crests.\n3. Add real app icon and screenshots.\n4. Prepare privacy policy.\n5. Test on at least 3 phones.\n6. Build release AAB for Play Console.", 15, subText, false));
    }

    void showCroatiaRoad() {
        clear(myTeam + " Road", "Group "+groupOfTeam(myTeam)+" and path to final", "More");
        LinearLayout hero = card();
        hero.setBackground(gradient(RED_DARK, RED, dp(24)));
        hero.addView(label(flag(myTeam) + " " + myTeam + " Road to Final", 25, Color.WHITE, true));
        hero.addView(label(groupLineFor(myTeam), 16, Color.WHITE, false));
        LinearLayout g = card();
        g.addView(label("Group "+groupOfTeam(myTeam)+" matches", 22, text, true));
        for (Match m : data.matches) {
            if (m.group.equals(groupOfTeam(myTeam)) || m.home.equals(myTeam) || m.away.equals(myTeam)) {
                g.addView(label(displayLocalDateTime(m.date) + " • " + flag(m.home) + " " + m.home + " vs " + flag(m.away) + " " + m.away, 14, subText, false));
            }
        }
        LinearLayout road = card();
        road.addView(label("Projected path", 22, text, true));
        road.addView(label("Group "+groupOfTeam(myTeam)+" → Round of 32 → Round of 16 → Quarter-final → Semi-final → Final", 16, GREEN, true));
        road.addView(label("This is the emotional hook for Croatian users, while the app stays global for every fan.", 14, subText, false));
    }

    void showWorldCupFacts() {
        clear("Facts", "Tournament quick facts", "More");
        String[] facts = {
            "48 teams • 12 groups • 104 matches",
            "Top 2 from each group qualify",
            "Best 8 third-placed teams qualify",
            "Knockout starts with Round of 32",
            "Host countries: USA, Mexico and Canada",
            "App works offline after installation"
        };
        for (String f : facts) {
            LinearLayout c = card();
            c.addView(label("⚽ " + f, 19, text, true));
        }
    }

    void showPrivacyInfo() {
        clear(tr("Privacy"), tr("Legal safety"), "More");
        LinearLayout c = card();
        c.addView(label("🔒 " + tr("Privacy"), 24, text, true));
        c.addView(label(tr("Privacy info text"), 15, subText, false));
        LinearLayout l = card();
        l.addView(label(tr("Legal safety"), 22, RED, true));
        l.addView(label(tr("Legal safety text"), 15, subText, false));
    }

void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    String flag(String t){
        if(t==null)return "🏳";
        String clean=t.trim();
        String n=clean.toLowerCase()
                .replace("&","and")
                .replace("-"," ")
                .replace(".","")
                .replace(",","")
                .replace("  "," ");

        // Exact/variant fixes for countries whose API names differ from local names.
        // Do not shorten display names; this only decides which flag to show.
        if(n.equals("bih") || n.contains("bosnia")) return "🇧🇦";
        if(n.equals("sco") || n.contains("scotland")) return "🏴󠁧󠁢󠁳󠁣󠁴󠁿";
        if(n.equals("cod") || n.equals("drc") || n.contains("dr congo") || n.contains("congo dr") || n.contains("democratic republic of congo") || n.contains("democratic republic of the congo")) return "🇨🇩";

        String[][] f={
            {"Croatia","🇭🇷"},{"Brazil","🇧🇷"},{"Germany","🇩🇪"},{"Argentina","🇦🇷"},{"France","🇫🇷"},{"Spain","🇪🇸"},{"Portugal","🇵🇹"},{"England","🇬🇧"},{"Netherlands","🇳🇱"},{"Belgium","🇧🇪"},
            {"Mexico","🇲🇽"},{"USA","🇺🇸"},{"United States","🇺🇸"},{"Canada","🇨🇦"},{"Japan","🇯🇵"},{"Korea Republic","🇰🇷"},{"South Korea","🇰🇷"},{"South Africa","🇿🇦"},{"Czechia","🇨🇿"},{"Bosnia and Herzegovina","🇧🇦"},
            {"Qatar","🇶🇦"},{"Switzerland","🇨🇭"},{"Morocco","🇲🇦"},{"Haiti","🇭🇹"},{"Scotland","🏴󠁧󠁢󠁳󠁣󠁴󠁿"},{"Paraguay","🇵🇾"},{"Australia","🇦🇺"},{"Turkey","🇹🇷"},{"Curacao","🇨🇼"},{"Curaçao","🇨🇼"},
            {"Ivory Coast","🇨🇮"},{"Cote d'Ivoire","🇨🇮"},{"Ecuador","🇪🇨"},{"Sweden","🇸🇪"},{"Tunisia","🇹🇳"},{"Egypt","🇪🇬"},{"Iran","🇮🇷"},{"New Zealand","🇳🇿"},{"Cape Verde","🇨🇻"},{"Cape Verde Islands","🇨🇻"},{"Saudi Arabia","🇸🇦"},
            {"Uruguay","🇺🇾"},{"Senegal","🇸🇳"},{"Iraq","🇮🇶"},{"Norway","🇳🇴"},{"Algeria","🇩🇿"},{"Austria","🇦🇹"},{"Jordan","🇯🇴"},{"DR Congo","🇨🇩"},{"Uzbekistan","🇺🇿"},{"Colombia","🇨🇴"},{"Ghana","🇬🇭"},{"Panama","🇵🇦"}
        };
        for(String[] x:f)if(clean.equals(x[0]))return x[1];
        return "🏳";
    }
    Drawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(radius);return g;}
    Drawable round(int color,int radius,int sw){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);if(sw>0)g.setStroke(sw,stroke);return g;}
    int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+0.5f);}

    static class DetailEvent{int minute;String text;DetailEvent(int m,String t){minute=m;text=t;}}
    static class Match{
        String group,home,away,date,venue,status="",minute="",competition="";
        String actualVenue="",eventsText="",statsText="",homeLineupText="",awayLineupText="",homeFormation="",awayFormation="",refereeText="",halfTimeScore="";
        int homeGoals=-1,awayGoals=-1,apiId=-1,attendance=-1;
        boolean detailsAvailable=false;
        Match(String g,String h,String a,String d,String v){group=g;home=h;away=a;date=d;venue=v;}
    }
    static class TeamRow{String group,team;int pts,gf,ga,w,d,l,p;TeamRow(String g,String t){group=g;team=t;}}
    class Data{
        String[] groups={"A","B","C","D","E","F","G","H","I","J","K","L"};ArrayList<String> teams=new ArrayList<>();ArrayList<Match> matches=new ArrayList<>();SharedPreferences sp;
        Data(Context c){sp=c.getSharedPreferences("scores",0);seed();load();}
        void seed(){
            String[][] g={{"Mexico","South Africa","Korea Republic","Czechia"},{"Canada","Bosnia and Herzegovina","Qatar","Switzerland"},{"Brazil","Morocco","Haiti","Scotland"},{"USA","Paraguay","Australia","Turkey"},{"Germany","Curacao","Ivory Coast","Ecuador"},{"Netherlands","Japan","Sweden","Tunisia"},{"Belgium","Egypt","Iran","New Zealand"},{"Spain","Cape Verde","Saudi Arabia","Uruguay"},{"France","Senegal","Iraq","Norway"},{"Argentina","Algeria","Austria","Jordan"},{"Portugal","DR Congo","Uzbekistan","Colombia"},{"England","Croatia","Ghana","Panama"}};
            for(String[] row:g)for(String t:row)teams.add(t);
            // Official match schedule entered from the Google/FIFA schedule screenshots supplied by the user.
            matches.add(new Match("A","Mexico","South Africa","2026-06-11","Group stage"));
            matches.add(new Match("A","Korea Republic","Czechia","2026-06-13","Group stage"));
            matches.add(new Match("B","Canada","Bosnia and Herzegovina","2026-06-13","Group stage"));
            matches.add(new Match("D","USA","Paraguay","2026-06-14","Group stage"));
            matches.add(new Match("B","Qatar","Switzerland","2026-06-14 21:00","Group stage"));
            matches.add(new Match("C","Brazil","Morocco","2026-06-15 00:00","Group stage"));
            matches.add(new Match("C","Haiti","Scotland","2026-06-15 03:00","Group stage"));
            matches.add(new Match("D","Australia","Turkey","2026-06-15 06:00","Group stage"));
            matches.add(new Match("E","Germany","Curacao","2026-06-15 19:00","Group stage"));
            matches.add(new Match("F","Netherlands","Japan","2026-06-15 22:00","Group stage"));
            matches.add(new Match("E","Ivory Coast","Ecuador","2026-06-15 01:00","Group stage"));
            matches.add(new Match("F","Sweden","Tunisia","2026-06-15 04:00","Group stage"));
            matches.add(new Match("H","Spain","Cape Verde","2026-06-15 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Egypt","2026-06-15 21:00","Group stage"));
            matches.add(new Match("H","Saudi Arabia","Uruguay","2026-06-16 00:00","Group stage"));
            matches.add(new Match("G","Iran","New Zealand","2026-06-16 03:00","Group stage"));
            matches.add(new Match("I","France","Senegal","2026-06-16 21:00","Group stage"));
            matches.add(new Match("I","Iraq","Norway","2026-06-17 00:00","Group stage"));
            matches.add(new Match("J","Argentina","Algeria","2026-06-17 03:00","Group stage"));
            matches.add(new Match("J","Austria","Jordan","2026-06-17 06:00","Group stage"));
            matches.add(new Match("K","Portugal","DR Congo","2026-06-17 19:00","Group stage"));
            matches.add(new Match("L","England","Croatia","2026-06-17 22:00","Group stage"));
            matches.add(new Match("L","Ghana","Panama","2026-06-18 01:00","Group stage"));
            matches.add(new Match("K","Uzbekistan","Colombia","2026-06-18 04:00","Group stage"));
            matches.add(new Match("A","Czechia","South Africa","2026-06-18 18:00","Group stage"));
            matches.add(new Match("B","Switzerland","Bosnia and Herzegovina","2026-06-18 21:00","Group stage"));
            matches.add(new Match("B","Canada","Qatar","2026-06-19 00:00","Group stage"));
            matches.add(new Match("A","Mexico","Korea Republic","2026-06-19 03:00","Group stage"));
            matches.add(new Match("D","USA","Australia","2026-06-19 21:00","Group stage"));
            matches.add(new Match("C","Scotland","Morocco","2026-06-20 00:00","Group stage"));
            matches.add(new Match("C","Brazil","Haiti","2026-06-20 02:30","Group stage"));
            matches.add(new Match("D","Turkey","Paraguay","2026-06-20 05:00","Group stage"));
            matches.add(new Match("F","Netherlands","Sweden","2026-06-20 19:00","Group stage"));
            matches.add(new Match("E","Germany","Ivory Coast","2026-06-20 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Curacao","2026-06-21 02:00","Group stage"));
            matches.add(new Match("F","Tunisia","Japan","2026-06-21 06:00","Group stage"));
            matches.add(new Match("H","Spain","Saudi Arabia","2026-06-21 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Iran","2026-06-21 21:00","Group stage"));
            matches.add(new Match("H","Uruguay","Cape Verde","2026-06-22 00:00","Group stage"));
            matches.add(new Match("G","New Zealand","Egypt","2026-06-22 03:00","Group stage"));
            matches.add(new Match("J","Argentina","Austria","2026-06-22 19:00","Group stage"));
            matches.add(new Match("I","France","Iraq","2026-06-22 23:00","Group stage"));
            matches.add(new Match("I","Norway","Senegal","2026-06-23 02:00","Group stage"));
            matches.add(new Match("J","Jordan","Algeria","2026-06-23 05:00","Group stage"));
            matches.add(new Match("K","Portugal","Uzbekistan","2026-06-23 19:00","Group stage"));
            matches.add(new Match("L","England","Ghana","2026-06-23 22:00","Group stage"));
            matches.add(new Match("L","Panama","Croatia","2026-06-24 01:00","Group stage"));
            matches.add(new Match("K","Colombia","DR Congo","2026-06-24 04:00","Group stage"));
            matches.add(new Match("B","Switzerland","Canada","2026-06-24 21:00","Group stage"));
            matches.add(new Match("B","Bosnia and Herzegovina","Qatar","2026-06-24 21:00","Group stage"));
            matches.add(new Match("C","Morocco","Haiti","2026-06-25 00:00","Group stage"));
            matches.add(new Match("C","Scotland","Brazil","2026-06-25 00:00","Group stage"));
            matches.add(new Match("A","South Africa","Korea Republic","2026-06-25 03:00","Group stage"));
            matches.add(new Match("A","Czechia","Mexico","2026-06-25 03:00","Group stage"));
            matches.add(new Match("E","Curacao","Ivory Coast","2026-06-25 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Germany","2026-06-25 22:00","Group stage"));
            matches.add(new Match("F","Tunisia","Netherlands","2026-06-26 01:00","Group stage"));
            matches.add(new Match("F","Japan","Sweden","2026-06-26 01:00","Group stage"));
            matches.add(new Match("D","Turkey","USA","2026-06-26 04:00","Group stage"));
            matches.add(new Match("D","Paraguay","Australia","2026-06-26 04:00","Group stage"));
            matches.add(new Match("I","Norway","France","2026-06-26 21:00","Group stage"));
            matches.add(new Match("I","Senegal","Iraq","2026-06-26 21:00","Group stage"));
            matches.add(new Match("H","Cape Verde","Saudi Arabia","2026-06-27 02:00","Group stage"));
            matches.add(new Match("H","Uruguay","Spain","2026-06-27 02:00","Group stage"));
            matches.add(new Match("G","New Zealand","Belgium","2026-06-27 05:00","Group stage"));
            matches.add(new Match("G","Egypt","Iran","2026-06-27 05:00","Group stage"));
            matches.add(new Match("L","Panama","England","2026-06-27 23:00","Group stage"));
            matches.add(new Match("L","Croatia","Ghana","2026-06-27 23:00","Group stage"));
            matches.add(new Match("K","Colombia","Portugal","2026-06-28 01:30","Group stage"));
            matches.add(new Match("K","DR Congo","Uzbekistan","2026-06-28 01:30","Group stage"));
            matches.add(new Match("J","Algeria","Austria","2026-06-28 04:00","Group stage"));
            matches.add(new Match("J","Jordan","Argentina","2026-06-28 04:00","Group stage"));
            Collections.sort(teams);
        }
        void load(){for(int i=0;i<matches.size();i++){matches.get(i).homeGoals=sp.getInt("h"+i,-1);matches.get(i).awayGoals=sp.getInt("a"+i,-1);}}
        void save(){SharedPreferences.Editor e=sp.edit();for(int i=0;i<matches.size();i++){e.putInt("h"+i,matches.get(i).homeGoals);e.putInt("a"+i,matches.get(i).awayGoals);}e.apply();}
        void reset(){sp.edit().clear().apply();for(Match m:matches){m.homeGoals=-1;m.awayGoals=-1;}}
        Map<String,List<TeamRow>> standings(){Map<String,List<TeamRow>> out=new LinkedHashMap<>();for(String gr:groups){Map<String,TeamRow> m=new LinkedHashMap<>();for(Match ma:matches)if(ma.group.equals(gr)){m.putIfAbsent(ma.home,new TeamRow(gr,ma.home));m.putIfAbsent(ma.away,new TeamRow(gr,ma.away));if(matchIsFinished(ma)){TeamRow h=m.get(ma.home),a=m.get(ma.away);h.p++;a.p++;h.gf+=ma.homeGoals;h.ga+=ma.awayGoals;a.gf+=ma.awayGoals;a.ga+=ma.homeGoals;if(ma.homeGoals>ma.awayGoals){h.w++;h.pts+=3;a.l++;}else if(ma.homeGoals<ma.awayGoals){a.w++;a.pts+=3;h.l++;}else{h.d++;a.d++;h.pts++;a.pts++;}}}ArrayList<TeamRow> list=new ArrayList<>(m.values());Collections.sort(list,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));out.put(gr,list);}return out;}
        List<TeamRow> bestThirds(){ArrayList<TeamRow> third=new ArrayList<>();for(List<TeamRow> l:standings().values())if(l.size()>2)third.add(l.get(2));Collections.sort(third,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));return third;}
        List<TeamRow> qualified(){ArrayList<TeamRow> q=new ArrayList<>();for(List<TeamRow> l:standings().values()){if(l.size()>0)q.add(l.get(0));if(l.size()>1)q.add(l.get(1));}List<TeamRow> th=bestThirds();for(int i=0;i<Math.min(8,th.size());i++)q.add(th.get(i));return q;}
        int playedCount(){int c=0;for(Match m:matches)if(matchIsFinished(m))c++;return c;}int totalGoals(){int g=0;for(Match m:matches)if(matchIsFinished(m))g+=m.homeGoals+m.awayGoals;return g;}String avgGoals(){return playedCount()==0?"0.00":String.format(Locale.US,"%.2f",totalGoals()*1.0/playedCount());}int progressPercent(){return(int)Math.round(playedCount()*100.0/matches.size());}String bestAttack(){Map<String,Integer> gf=new HashMap<>();for(Match m:matches)if(matchIsFinished(m)){gf.put(m.home,gf.getOrDefault(m.home,0)+m.homeGoals);gf.put(m.away,gf.getOrDefault(m.away,0)+m.awayGoals);}String best="TBD";int max=-1;for(String t:gf.keySet())if(gf.get(t)>max){max=gf.get(t);best=t;}return best+" ("+Math.max(0,max)+")";}String bestGroup(){Map<String,Integer> goals=new HashMap<>();for(Match m:matches)if(matchIsFinished(m))goals.put(m.group,goals.getOrDefault(m.group,0)+m.homeGoals+m.awayGoals);String best="TBD";int max=-1;for(String g:goals.keySet())if(goals.get(g)>max){max=goals.get(g);best=g;}return best+" ("+Math.max(0,max)+" goals)";}Match nextFor(String team){return nextMatchForTeam(team);}
    }

    String liveLabelFromJson(String status, String minute){
        if(status==null) status="";
        if(minute==null) minute="";
        String s=status.trim().toUpperCase(Locale.US);
        String m=minute.trim().replace("'", "");
        boolean live=s.equals("LIVE") || s.equals("1H") || s.equals("2H") ||
                s.equals("IN_PROGRESS") || s.equals("IN PROGRESS") ||
                s.equals("INPLAY") || s.equals("IN PLAY");
        if(live){
            if(m.length()>0) return "🔴 LIVE "+m+"'";
            return "🔴 LIVE";
        }
        if(s.equals("HT")) return "🟠 HT";
        if(s.equals("FT") || s.equals("FINISHED") || s.equals("FULLTIME") || s.equals("FULL TIME")) return "✅ FT";
        if(s.equals("UPCOMING") || s.equals("SCHEDULED") || s.equals("TIMED") || s.equals("NOT_STARTED") || s.equals("NOT STARTED")) return "📅";
        return "";
    }


    boolean onlineMatchIsFinished(String status){
        if(status==null || status.trim().length()==0)return true;
        status=status.trim().toUpperCase();
        return status.equals("FT") || status.equals("FINISHED");
    }


    String tournamentInfoLine(){
        return "🌍 Teams: 48  •  Groups: 12  •  Matches: 104";
    }

}
