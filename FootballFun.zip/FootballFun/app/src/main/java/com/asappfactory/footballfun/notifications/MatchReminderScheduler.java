package com.asappfactory.footballfun.notifications;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import com.asappfactory.footballfun.MainActivity;
import com.asappfactory.footballfun.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Local, account-free match reminders backed by AlarmManager.
 *
 * The scheduler deliberately uses inexact allow-while-idle alarms. They do not require the
 * special exact-alarm permission and are appropriate for normal match reminders. Android may
 * shift delivery slightly while the phone is in aggressive battery saving mode.
 */
public final class MatchReminderScheduler {
    public static final String CHANNEL_ID = "football_fun_match_reminders";
    static final String ACTION_REMINDER = "com.asappfactory.footballfun.MATCH_REMINDER";

    private static final String PREFS = "footballfun";
    private static final String KEY_STORED = "scheduled_match_reminders_v1";
    private static final String KEY_COUNT = "scheduled_match_reminder_count";
    private static final int MAX_REMINDERS = 60;

    private MatchReminderScheduler() {}

    public static final class Reminder {
        public final String id;
        public final String home;
        public final String away;
        public final String competition;
        public final long kickoffMillis;

        public Reminder(String id, String home, String away, String competition, long kickoffMillis) {
            this.id = safe(id);
            this.home = safe(home);
            this.away = safe(away);
            this.competition = safe(competition);
            this.kickoffMillis = kickoffMillis;
        }
    }

    public static final class ScheduledReminder {
        public final int requestCode;
        public final String id;
        public final String home;
        public final String away;
        public final String competition;
        public final long kickoffMillis;
        public final long triggerAtMillis;
        public final int leadMinutes;

        ScheduledReminder(int requestCode, String id, String home, String away, String competition,
                          long kickoffMillis, long triggerAtMillis, int leadMinutes) {
            this.requestCode = requestCode;
            this.id = safe(id);
            this.home = safe(home);
            this.away = safe(away);
            this.competition = safe(competition);
            this.kickoffMillis = kickoffMillis;
            this.triggerAtMillis = triggerAtMillis;
            this.leadMinutes = leadMinutes;
        }
    }

    public static boolean hasNotificationPermission(Context context) {
        return Build.VERSION.SDK_INT < 33
                || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static int replaceAll(
            Context context,
            List<Reminder> source,
            boolean enabled,
            int leadMinutes
    ) {
        Context app = context.getApplicationContext();
        cancelStored(app, false);
        if (!enabled) {
            clearStored(app);
            return 0;
        }

        ensureChannel(app);
        ArrayList<Reminder> reminders = new ArrayList<Reminder>();
        if (source != null) reminders.addAll(source);
        Collections.sort(reminders, new Comparator<Reminder>() {
            @Override public int compare(Reminder a, Reminder b) {
                return Long.compare(a.kickoffMillis, b.kickoffMillis);
            }
        });

        long now = System.currentTimeMillis();
        long maximumKickoff = now + 120L * 24L * 60L * 60L * 1000L;
        JSONArray stored = new JSONArray();
        Set<Integer> usedCodes = new HashSet<Integer>();
        int count = 0;

        for (Reminder reminder : reminders) {
            if (reminder == null || reminder.kickoffMillis <= now || reminder.kickoffMillis > maximumKickoff) continue;
            long triggerAt = reminder.kickoffMillis - Math.max(1, leadMinutes) * 60L * 1000L;
            if (triggerAt <= now + 5_000L) continue;

            int requestCode = stableRequestCode(reminder.id + "|" + reminder.kickoffMillis + "|" + leadMinutes);
            while (usedCodes.contains(requestCode)) requestCode = requestCode == Integer.MAX_VALUE ? 1 : requestCode + 1;
            usedCodes.add(requestCode);

            scheduleOne(app, requestCode, triggerAt, reminder, leadMinutes);
            try {
                JSONObject item = new JSONObject();
                item.put("requestCode", requestCode);
                item.put("triggerAt", triggerAt);
                item.put("kickoff", reminder.kickoffMillis);
                item.put("id", reminder.id);
                item.put("home", reminder.home);
                item.put("away", reminder.away);
                item.put("competition", reminder.competition);
                item.put("leadMinutes", leadMinutes);
                stored.put(item);
            } catch (Exception ignored) {}

            count++;
            if (count >= MAX_REMINDERS) break;
        }

        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_STORED, stored.toString())
                .putInt(KEY_COUNT, count)
                .apply();
        return count;
    }

    public static void rescheduleStored(Context context) {
        Context app = context.getApplicationContext();
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean("favoriteNotifications", true)) {
            cancelStored(app, true);
            return;
        }

        ensureChannel(app);
        String raw = prefs.getString(KEY_STORED, "");
        if (raw == null || raw.trim().length() == 0) return;
        long now = System.currentTimeMillis();
        int count = 0;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                long triggerAt = item.optLong("triggerAt", 0L);
                long kickoff = item.optLong("kickoff", 0L);
                if (triggerAt <= now + 5_000L || kickoff <= now) continue;
                int requestCode = item.optInt("requestCode", stableRequestCode(item.optString("id", "") + "|" + kickoff));
                int lead = item.optInt("leadMinutes", 60);
                Reminder reminder = new Reminder(
                        item.optString("id", ""),
                        item.optString("home", ""),
                        item.optString("away", ""),
                        item.optString("competition", ""),
                        kickoff
                );
                scheduleOne(app, requestCode, triggerAt, reminder, lead);
                count++;
            }
        } catch (Exception ignored) {}
        prefs.edit().putInt(KEY_COUNT, count).apply();
    }

    public static void cancelAll(Context context) {
        cancelStored(context.getApplicationContext(), true);
    }

    public static int scheduledCount(Context context) {
        return scheduledReminders(context).size();
    }

    public static List<ScheduledReminder> scheduledReminders(Context context) {
        Context app = context.getApplicationContext();
        String raw = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_STORED, "");
        ArrayList<ScheduledReminder> result = new ArrayList<ScheduledReminder>();
        long now = System.currentTimeMillis();
        if (raw == null || raw.trim().length() == 0) return result;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                long triggerAt = item.optLong("triggerAt", 0L);
                long kickoff = item.optLong("kickoff", 0L);
                if (triggerAt <= now || kickoff <= now) continue;
                result.add(new ScheduledReminder(
                        item.optInt("requestCode", -1),
                        item.optString("id", ""),
                        item.optString("home", ""),
                        item.optString("away", ""),
                        item.optString("competition", ""),
                        kickoff,
                        triggerAt,
                        item.optInt("leadMinutes", 60)
                ));
            }
        } catch (Exception ignored) {}
        Collections.sort(result, new Comparator<ScheduledReminder>() {
            @Override public int compare(ScheduledReminder a, ScheduledReminder b) {
                return Long.compare(a.triggerAtMillis, b.triggerAtMillis);
            }
        });
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_COUNT, result.size()).apply();
        return result;
    }

    public static boolean showTestNotification(Context context) {
        Context app = context.getApplicationContext();
        if (!hasNotificationPermission(app)) return false;
        ensureChannel(app);
        String language = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", "EN");
        String title;
        String body;
        if ("HR".equals(language)) {
            title = "Football Fun podsjetnik radi";
            body = "Dobivat ćeš podsjetnike za odabrane utakmice.";
        } else if ("DE".equals(language)) {
            title = "Football Fun Erinnerung funktioniert";
            body = "Du erhältst Erinnerungen für ausgewählte Spiele.";
        } else if ("ES".equals(language)) {
            title = "El recordatorio de Football Fun funciona";
            body = "Recibirás avisos de los partidos seleccionados.";
        } else if ("FR".equals(language)) {
            title = "Le rappel Football Fun fonctionne";
            body = "Tu recevras des rappels pour les matchs choisis.";
        } else {
            title = "Football Fun reminder works";
            body = "You will receive reminders for selected matches.";
        }
        postNotification(app, 5_250_001, title, body, true, "", "", 0L);
        return true;
    }

    static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel existing = manager.getNotificationChannel(CHANNEL_ID);
        if (existing != null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Match reminders",
                NotificationManager.IMPORTANCE_HIGH
        );
        channel.setDescription("Reminders for followed football matches");
        channel.enableVibration(true);
        manager.createNotificationChannel(channel);
    }

    static void postScheduledNotification(Context context, Intent intent) {
        if (!context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("favoriteNotifications", true)) return;
        if (!hasNotificationPermission(context)) return;

        String home = intent.getStringExtra("home");
        String away = intent.getStringExtra("away");
        String competition = intent.getStringExtra("competition");
        long kickoff = intent.getLongExtra("kickoff", 0L);
        int leadMinutes = intent.getIntExtra("leadMinutes", 60);
        int notificationId = intent.getIntExtra("notificationId", stableRequestCode(safe(home) + "|" + safe(away)));
        String language = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("lang", "EN");

        String title = safe(home) + " – " + safe(away);
        String leadText = localizedLead(language, leadMinutes);
        String body = competition == null || competition.trim().length() == 0
                ? leadText
                : leadText + " • " + competition.trim();
        postNotification(context, notificationId, title, body, false, home, away, kickoff);
        markDelivered(context, notificationId);
    }

    private static void scheduleOne(
            Context context,
            int requestCode,
            long triggerAt,
            Reminder reminder,
            int leadMinutes
    ) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        PendingIntent pendingIntent = reminderPendingIntent(context, requestCode, reminder, leadMinutes);
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent);
    }

    private static PendingIntent reminderPendingIntent(
            Context context,
            int requestCode,
            Reminder reminder,
            int leadMinutes
    ) {
        Intent intent = new Intent(context, MatchReminderReceiver.class);
        intent.setAction(ACTION_REMINDER);
        intent.putExtra("notificationId", requestCode);
        intent.putExtra("home", reminder.home);
        intent.putExtra("away", reminder.away);
        intent.putExtra("competition", reminder.competition);
        intent.putExtra("kickoff", reminder.kickoffMillis);
        intent.putExtra("leadMinutes", leadMinutes);
        return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static void cancelStored(Context context, boolean clear) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_STORED, "");
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null && raw != null && raw.trim().length() > 0) {
            try {
                JSONArray array = new JSONArray(raw);
                for (int i = 0; i < array.length(); i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item == null) continue;
                    int requestCode = item.optInt("requestCode", -1);
                    if (requestCode < 0) continue;
                    Intent intent = new Intent(context, MatchReminderReceiver.class);
                    intent.setAction(ACTION_REMINDER);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            context,
                            requestCode,
                            intent,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
                    );
                    if (pendingIntent != null) {
                        alarmManager.cancel(pendingIntent);
                        pendingIntent.cancel();
                    }
                }
            } catch (Exception ignored) {}
        }
        if (clear) clearStored(context);
    }

    private static void clearStored(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .remove(KEY_STORED)
                .putInt(KEY_COUNT, 0)
                .apply();
    }

    private static void markDelivered(Context context, int requestCode) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_STORED, "");
        if (raw == null || raw.trim().length() == 0) return;
        JSONArray remaining = new JSONArray();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null || item.optInt("requestCode", -1) == requestCode) continue;
                remaining.put(item);
            }
        } catch (Exception ignored) {
            return;
        }
        prefs.edit().putString(KEY_STORED, remaining.toString()).putInt(KEY_COUNT, remaining.length()).apply();
    }

    private static void postNotification(Context context, int notificationId, String title, String body, boolean test,
                                         String home, String away, long kickoff) {
        ensureChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (!test && safe(home).length() > 0 && safe(away).length() > 0) {
            open.putExtra("open_match_reminder", true);
            open.putExtra("reminder_home", safe(home));
            open.putExtra("reminder_away", safe(away));
            open.putExtra("reminder_kickoff", kickoff);
        } else {
            open.putExtra("open_notifications", true);
        }
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                notificationId,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setPriority(Notification.PRIORITY_HIGH)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (test) builder.setTicker(title);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) manager.notify(notificationId, builder.build());
    }

    private static String localizedLead(String language, int minutes) {
        if ("HR".equals(language)) {
            if (minutes >= 1440) return "Počinje sutra";
            if (minutes == 60) return "Počinje za 1 sat";
            return "Počinje za " + minutes + " min";
        }
        if ("DE".equals(language)) {
            if (minutes >= 1440) return "Beginnt morgen";
            if (minutes == 60) return "Beginnt in 1 Stunde";
            return "Beginnt in " + minutes + " Min.";
        }
        if ("ES".equals(language)) {
            if (minutes >= 1440) return "Empieza mañana";
            if (minutes == 60) return "Empieza en 1 hora";
            return "Empieza en " + minutes + " min";
        }
        if ("FR".equals(language)) {
            if (minutes >= 1440) return "Commence demain";
            if (minutes == 60) return "Commence dans 1 heure";
            return "Commence dans " + minutes + " min";
        }
        if (minutes >= 1440) return "Starts tomorrow";
        if (minutes == 60) return "Starts in 1 hour";
        return "Starts in " + minutes + " min";
    }

    private static int stableRequestCode(String value) {
        int hash = value == null ? 1 : value.hashCode();
        if (hash == Integer.MIN_VALUE) hash = 1;
        hash = Math.abs(hash);
        return hash == 0 ? 1 : hash;
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
