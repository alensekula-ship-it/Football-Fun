package com.asappfactory.footballfun.data;

import com.asappfactory.footballfun.model.ClubProfile;
import com.asappfactory.footballfun.model.Match;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Builds the available club directory from verified match data. */
public final class ClubCatalog {
    public static List<ClubProfile> build(List<Match> matches, Set<String> savedFavorites) {
        LinkedHashMap<String, ClubProfile> clubs = new LinkedHashMap<String, ClubProfile>();

        // Central verified club directory. Domestic identity always wins over a
        // continental competition context (for example Celtic must remain a
        // Scottish Premiership club even when opened from Champions League).
        for (ClubProfile verified : ClubIdentityRegistry.all()) add(clubs, verified);

        if (matches != null) {
            for (Match match : matches) {
                if (match == null) continue;
                String competition = normalizeCompetition(match.competition);
                CompetitionCatalog.Competition meta = CompetitionCatalog.get(competition);
                if (meta.nationalTeams) continue;
                if (competition.length() == 0) continue;
                addResolved(clubs, match.home, competition, meta.regionKey);
                addResolved(clubs, match.away, competition, meta.regionKey);
            }
        }

        if (savedFavorites != null) {
            for (String favorite : savedFavorites) {
                if (favorite == null || favorite.trim().length() == 0) continue;
                String key = ClubIdentityRegistry.key(ClubIdentityRegistry.canonicalName(favorite));
                if (!clubs.containsKey(key)) {
                    addResolved(clubs, favorite, "", "");
                }
            }
        }

        ArrayList<ClubProfile> result = new ArrayList<ClubProfile>(clubs.values());
        Collections.sort(result, new Comparator<ClubProfile>() {
            @Override public int compare(ClubProfile a, ClubProfile b) {
                int byCompetition = a.competition.compareToIgnoreCase(b.competition);
                if (byCompetition != 0) return byCompetition;
                return a.name.compareToIgnoreCase(b.name);
            }
        });
        return result;
    }

    public static ClubProfile find(List<ClubProfile> clubs, String name) {
        if (clubs == null || name == null) return null;
        String wanted = ClubIdentityRegistry.key(ClubIdentityRegistry.canonicalName(name));
        for (ClubProfile club : clubs) {
            if (ClubIdentityRegistry.key(ClubIdentityRegistry.canonicalName(club.name)).equals(wanted)) return club;
        }
        return null;
    }

    private static void addResolved(Map<String, ClubProfile> clubs, String name, String competition, String country) {
        ClubProfile verified = ClubIdentityRegistry.resolve(name);
        if (verified != null) { add(clubs, verified); return; }
        add(clubs, new ClubProfile(name, competition, country));
    }

    private static void add(Map<String, ClubProfile> clubs, ClubProfile club) {
        if (club == null || club.name.length() == 0) return;
        ClubProfile verified = ClubIdentityRegistry.resolve(club.name);
        ClubProfile candidate = verified != null ? verified : club;
        String clubKey = ClubIdentityRegistry.key(ClubIdentityRegistry.canonicalName(candidate.name));
        ClubProfile existing = clubs.get(clubKey);
        if (existing == null) { clubs.put(clubKey, candidate); return; }
        // A verified domestic identity is authoritative. Never replace it with
        // UEFA/continental context or a less complete runtime row.
        ClubProfile existingVerified = ClubIdentityRegistry.resolve(existing.name);
        if (existingVerified != null) { clubs.put(clubKey, existingVerified); return; }
        if (candidate.competition.length() > 0 && existing.competition.length() == 0) clubs.put(clubKey, candidate);
    }

    private static String normalizeCompetition(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        String upper = value.toUpperCase(Locale.US);
        if (upper.equals("PL") || upper.contains("PREMIER LEAGUE")) return "Premier League";
        if (upper.equals("ELC") || upper.contains("CHAMPIONSHIP")) return "Championship";
        if (upper.equals("PD") || upper.contains("PRIMERA DIVISION") || upper.contains("LA LIGA")) return "La Liga";
        if (upper.equals("BL1") || upper.contains("BUNDESLIGA")) return "Bundesliga";
        if (upper.equals("SA") || upper.equals("SERIE A")) return "Serie A";
        if (upper.equals("FL1") || upper.contains("LIGUE 1")) return "Ligue 1";
        if (upper.equals("DED") || upper.contains("EREDIVISIE")) return "Eredivisie";
        if (upper.equals("PPL") || upper.contains("PRIMEIRA")) return "Primeira Liga";
        if (upper.equals("BSA") || upper.contains("BRASILEIR")) return "Brasileirão Série A";
        if (upper.equals("CL") || upper.contains("CHAMPIONS LEAGUE")) return "UEFA Champions League";
        if (upper.equals("HNL") || upper.contains("HNL")) return "HNL";
        if (upper.equals("WC") || upper.contains("WORLD CUP")) return "World Cup 2026";
        if (upper.equals("EC") || upper.contains("EUROPEAN CHAMPIONSHIP")) return "UEFA European Championship";
        return value;
    }

    private static String key(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.US);
        return normalized.replaceAll("[^a-z0-9]", "");
    }

    private ClubCatalog() {}
}
