package com.asappfactory.footballfun.model;

/** Core match model shared by screens and data providers. */
public final class Match {
    public String group;
    public String home;
    public String away;
    public String date;
    public String venue;
    public String status = "";
    public String minute = "";
    public String competition = "";

    public String actualVenue = "";
    public String eventsText = "";
    public String statsText = "";
    public String homeLineupText = "";
    public String awayLineupText = "";
    public String homeFormation = "";
    public String awayFormation = "";
    public String refereeText = "";
    public String halfTimeScore = "";

    public int homeGoals = -1;
    public int awayGoals = -1;
    public int apiId = -1;
    public int attendance = -1;
    public boolean detailsAvailable = false;

    public Match(String group, String home, String away, String date, String venue) {
        this.group = group;
        this.home = home;
        this.away = away;
        this.date = date;
        this.venue = venue;
    }
}
