package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * Network boundary for Football Fun live data.
 *
 * The Android refresh path uses one authoritative GitHub payload. Any provider
 * aggregation belongs in the updater, keeping device refresh bounded and making
 * every screen consume the same central data snapshot.
 */
public final class LiveDataClient {
    private static final int PRIMARY_CONNECT_TIMEOUT_MS = 7000;
    private static final int PRIMARY_READ_TIMEOUT_MS = 20000;
    private static final int SUPPLEMENT_CONNECT_TIMEOUT_MS = 4500;
    private static final int SUPPLEMENT_READ_TIMEOUT_MS = 6500;
    private static final long LIVE_FRESHNESS_MS = 6L * 60L * 60L * 1000L;
    private static final long UPCOMING_EXPIRY_GRACE_MS = 6L * 60L * 60L * 1000L;
    private static final String STATUS_SOURCE_UPDATE_FIELD = "_ffStatusUpdatedAtMs";

    // One authoritative remote feed. Older mirrors intentionally are not merged here:
    // they can be stale or contain only the World Cup and previously caused a fresh
    // multi-competition payload to be diluted by unrelated legacy snapshots.
    private static final String PRIMARY_SOURCE =
            "https://raw.githubusercontent.com/alensekula-ship-it/worldcup-live-updater/main/live-results.json";

    public static final class DownloadResult {
        public final String json;
        public final String etag;
        public final boolean notModified;

        DownloadResult(String json, String etag, boolean notModified) {
            this.json = json == null ? "" : json;
            this.etag = etag == null ? "" : etag;
            this.notModified = notModified;
        }
    }

    private static final String ESPN_SCOREBOARD =
            "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?dates=";

    // Public, keyless ESPN competition feed. It includes Champions League
    // qualifying rounds that football-data.org may omit from its CL feed.
    private static final String ESPN_UCL_SCOREBOARD =
            "https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions_qual/scoreboard?dates=";

    /**
     * Applies every bundled verified competition fallback to any JSON payload.
     *
     * This is intentionally also used when restoring SharedPreferences cache:
     * users upgrading from an older build can otherwise keep an old cached feed
     * without the newly bundled fixtures until the next successful network sync.
     */
    /**
     * Applies only the authoritative bundled HNL schedule.
     * Used on every online refresh and on one-time cache migration so an older
     * persisted HNL row can never overwrite a newer verified HNL date/time.
     */
    public JSONObject parseAndMergeOfficialHnlFixtures(String json) throws Exception {
        if (json == null || json.trim().isEmpty()) json = "{}";
        JSONObject root = new JSONObject(json);
        // Build one master array from all feed families once, apply the verified
        // HNL replacement, then rebuild the derived state from that master. Build
        // 312 repeatedly serialized/reparsed the same multi-megabyte payload.
        consolidateAllFeedsIntoMaster(root);
        applyOfficialHnlSchedule(root);
        rebuildDerivedFeedsFromMaster(root);
        return root;
    }

    public String mergeOfficialHnlFixtures(String json) throws Exception {
        return parseAndMergeOfficialHnlFixtures(json).toString();
    }

    public String mergeBundledFixtures(String json) throws Exception {
        if (json == null || json.trim().isEmpty()) throw new Exception("Empty online file");
        JSONObject root = new JSONObject(json);
        // Normalize every raw/cache feed into one master array before any bundled
        // competition fallback inspects it. This guarantees that an event present
        // only in upcoming/live/finished cannot disappear simply because matches
        // was empty or incomplete in the first source/cache snapshot.
        enforceCentralMatchState(root);
        applyOfficialHnlSchedule(root);
        PremierLeague2627Data.mergeInto(root);
        Championship2627Data.mergeInto(root);
        LaLiga2627Data.mergeInto(root);
        Bundesliga2627Data.mergeInto(root);
        SerieA2627Data.mergeInto(root);
        Ligue12627Data.mergeInto(root);
        Eredivisie2627Data.mergeInto(root);
        PrimeiraLiga2627Data.mergeInto(root);
        Brasileirao2026Data.mergeInto(root);
        enforceCentralMatchState(root);
        return root.toString();
    }

    /**
     * Downloads the single authoritative GitHub payload. If the server confirms
     * that the caller already has the current ETag, no JSON is downloaded or
     * reparsed. No secondary network request is made from this refresh path.
     */
    public DownloadResult downloadLatest(String previousEtag) throws Exception {
        HttpResult primary = downloadHttp(
                PRIMARY_SOURCE, previousEtag, PRIMARY_CONNECT_TIMEOUT_MS, PRIMARY_READ_TIMEOUT_MS);

        if (primary.notModified) {
            return new DownloadResult("", primary.etag.length() > 0 ? primary.etag : previousEtag, true);
        }
        if (primary.body == null || primary.body.trim().isEmpty()) throw new Exception("Empty online file");

        // The GitHub updater is the single authoritative network source. Keep
        // refresh to one bounded request; parsing happens exactly once in the
        // central apply pipeline instead of parsing the same multi-MB JSON twice.
        return new DownloadResult(primary.body, primary.etag, false);
    }

    public String downloadLatest() throws Exception {
        DownloadResult result = downloadLatest("");
        return result.notModified ? "" : result.json;
    }

    /**
     * Final JSON-level invariant before the UI/cache sees any competition data:
     * FINISHED always carries a complete score; a final/played row without one is
     * NO_RESULT. The live/finished/upcoming feeds are rebuilt from the same state.
     */
    private void enforceCentralMatchState(JSONObject root) {
        if (root == null) return;
        try {
            consolidateAllFeedsIntoMaster(root);
            rebuildDerivedFeedsFromMaster(root);
        } catch (Exception ignored) {}
    }

    private void rebuildDerivedFeedsFromMaster(JSONObject root) {
        if (root == null) return;
        try {
            JSONArray matches = root.optJSONArray("matches");
            if (matches == null) return;

            long rootUpdate = rootUpdateTime(root);
            JSONArray live = new JSONArray();
            JSONArray finished = new JSONArray();
            JSONArray upcoming = new JSONArray();

            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.optJSONObject(i);
                if (match == null) continue;

                String status = normalizedStatus(match.optString("status", ""));

                // LIVE is inherently time-sensitive. A cached/first-source LIVE
                // row is accepted only when the status itself came from a source
                // updated within the freshness window. This closes the last path
                // by which an old LIVE snapshot could survive simply because a
                // newer unrelated source refreshed the root timestamp.
                if (isLiveStatus(status) &&
                        (!isFreshStatusUpdate(match, rootUpdate) || !isPlausibleLiveDate(match))) {
                    status = staleLiveFallbackStatus(match);
                    match.put("status", status);
                    removeScoreFields(match);
                }

                // A fixture cannot remain "upcoming" forever after kickoff. If the
                // provider has not supplied LIVE/FINISHED/postponed/cancelled state
                // after a generous grace period, expose it as NO_RESULT instead of
                // showing a historical fixture among future matches.
                if (isUpcomingStatus(status) && isExpiredUpcomingFixture(match)) {
                    status = "NO_RESULT";
                    match.put("status", status);
                    removeScoreFields(match);
                }

                int homeScore = scoreFrom(match, true);
                int awayScore = scoreFrom(match, false);
                boolean hasScore = homeScore >= 0 && awayScore >= 0;

                if (status.isEmpty()) status = hasScore ? "FINISHED" : "SCHEDULED";
                if (isFinishedStatus(status) && !hasScore) status = "NO_RESULT";
                else if (isResultUnavailableStatus(status) && hasScore) status = "FINISHED";

                match.put("status", status);

                boolean liveState = isLiveStatus(status);
                boolean finishedState = isFinishedStatus(status) && hasScore;
                if (!liveState && !finishedState) removeScoreFields(match);

                if (liveState) live.put(match);
                else if (finishedState) finished.put(match);
                else if (isUpcomingStatus(status)) upcoming.put(match);
            }

            root.put("live", live);
            root.put("finished", finished);
            root.put("upcoming", upcoming);
        } catch (Exception ignored) {}
    }

    /**
     * Builds the one authoritative match array from all four feed families.
     * Do this even for the first source and restored cache, not only while
     * merging later sources. Derived feeds are rebuilt afterwards.
     */
    private void consolidateAllFeedsIntoMaster(JSONObject root) throws Exception {
        if (root == null) return;
        JSONArray master = new JSONArray();
        Map<String, ArrayList<JSONObject>> index = new HashMap<>();
        long rootUpdate = rootUpdateTime(root);
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray rows = root.optJSONArray(feed);
            if (rows != null) mergeMatchArray(master, index, rows, rootUpdate);
        }
        root.put("matches", master);
    }

    private void stampIncomingFeedRows(JSONObject root, long sourceUpdate) {
        if (root == null || sourceUpdate <= 0L) return;
        String stamp = String.valueOf(sourceUpdate);
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray rows = root.optJSONArray(feed);
            if (rows == null) continue;
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null) continue;
                try { row.put(STATUS_SOURCE_UPDATE_FIELD, stamp); } catch (Exception ignored) {}
            }
        }
    }

    private long statusSourceUpdate(JSONObject match, long fallback) {
        if (match != null) {
            String raw = match.optString(STATUS_SOURCE_UPDATE_FIELD, "").trim();
            if (!raw.isEmpty()) {
                try {
                    long parsed = Long.parseLong(raw);
                    if (parsed > 0L) return parsed;
                } catch (Exception ignored) {}
                long parsedDate = parseDate(raw);
                if (parsedDate > 0L) return parsedDate;
            }
        }
        return fallback;
    }

    private boolean isFreshStatusUpdate(JSONObject match, long rootUpdate) {
        long updated = statusSourceUpdate(match, rootUpdate);
        return updated > 0L && Math.abs(System.currentTimeMillis() - updated) <= LIVE_FRESHNESS_MS;
    }

    private boolean isPlausibleLiveDate(JSONObject match) {
        long day = fixtureDay(match);
        if (day <= 0L) return true;
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.set(Calendar.HOUR_OF_DAY, 0);
        utc.set(Calendar.MINUTE, 0);
        utc.set(Calendar.SECOND, 0);
        utc.set(Calendar.MILLISECOND, 0);
        long gap = Math.abs(day - utc.getTimeInMillis());
        // Allow the adjacent UTC day for late-night matches/time-zone edges,
        // but reject a LIVE row attached to an old/future fixture date.
        return gap <= 24L * 60L * 60L * 1000L;
    }

    private String staleLiveFallbackStatus(JSONObject match) {
        return isExpiredUpcomingFixture(match) ? "NO_RESULT" : "SCHEDULED";
    }

    private boolean isExpiredUpcomingFixture(JSONObject match) {
        long kickoff = fixtureKickoffTime(match);
        if (kickoff <= 0L) return false;
        return System.currentTimeMillis() > kickoff + UPCOMING_EXPIRY_GRACE_MS;
    }

    private long fixtureKickoffTime(JSONObject match) {
        if (match == null) return 0L;
        String raw = match.optString("utcDate", match.optString("date", "")).trim();
        if (raw.isEmpty()) return 0L;
        long parsed = parseDate(raw);
        if (parsed <= 0L && raw.length() >= 10) parsed = parseDate(raw.substring(0, 10));
        if (parsed <= 0L) return 0L;
        // A date-only fixture has no verified kickoff time. Keep it upcoming for
        // the entire published day, then allow the same six-hour provider grace.
        if (raw.matches("\\d{4}-\\d{2}-\\d{2}")) {
            parsed += 24L * 60L * 60L * 1000L - 1L;
        }
        return parsed;
    }

    private boolean isResultUnavailableStatus(String status) {
        String value = normalizedStatus(status);
        return "NO_RESULT".equals(value) || "PLAYED_NO_SCORE".equals(value) ||
                "FINISHED_NO_SCORE".equals(value) || "RESULT_PENDING".equals(value) ||
                "UNCONFIRMED_RESULT".equals(value) || "RESULT_UNCONFIRMED".equals(value) ||
                "PLAYED".equals(value);
    }

    private boolean isAdministrativeStatus(String status) {
        String value = normalizedStatus(status);
        return value.startsWith("POSTPON") || value.startsWith("CANCEL") ||
                value.startsWith("SUSPEND") || "ABANDONED".equals(value);
    }

    private boolean isUpcomingStatus(String status) {
        String value = normalizedStatus(status);
        return "SCHEDULED".equals(value) || "TIMED".equals(value) ||
                "NOT_STARTED".equals(value) || "UPCOMING".equals(value) ||
                "TBD".equals(value) || "TBA".equals(value) || "NS".equals(value);
    }

    private void removeScoreFields(JSONObject match) {
        if (match == null) return;
        String[] keys = {"homeGoals", "awayGoals", "homeScore", "awayScore",
                "home_score", "away_score", "scoreHome", "scoreAway",
                "goalsHome", "goalsAway", "score", "scores", "result",
                "currentScore", "displayScore"};
        for (String key : keys) match.remove(key);
    }

    private void mergeFeed(JSONObject base, JSONObject incoming, long incomingUpdate) {
        try {
            consolidateAllFeedsIntoMaster(base);
            JSONArray baseMatches = base.optJSONArray("matches");
            if (baseMatches == null) {
                baseMatches = new JSONArray();
                base.put("matches", baseMatches);
            }
            Map<String, ArrayList<JSONObject>> byPair = indexMatches(baseMatches);

            mergeMatchArray(baseMatches, byPair, incoming.optJSONArray("matches"), incomingUpdate);
            mergeMatchArray(baseMatches, byPair, incoming.optJSONArray("upcoming"), incomingUpdate);
            mergeMatchArray(baseMatches, byPair, incoming.optJSONArray("live"), incomingUpdate);
            mergeMatchArray(baseMatches, byPair, incoming.optJSONArray("finished"), incomingUpdate);

            // Rebuild all derived feeds through the same invariant used at the
            // final network/cache boundary. This prevents an intermediate
            // FINISHED-without-score row from ever being treated as played.
            enforceCentralMatchState(base);
        } catch (Exception ignored) {}
    }

    private Map<String, ArrayList<JSONObject>> indexMatches(JSONArray matches) {
        Map<String, ArrayList<JSONObject>> result = new HashMap<>();
        if (matches == null) return result;
        for (int i = 0; i < matches.length(); i++) {
            JSONObject match = matches.optJSONObject(i);
            if (match == null) continue;
            String home = teamName(match, true);
            String away = teamName(match, false);
            if (home.isEmpty() || away.isEmpty()) continue;
            addToPairIndex(result, pairKey(home, away), match);
        }
        return result;
    }

    private void addToPairIndex(Map<String, ArrayList<JSONObject>> index,
                                String key, JSONObject match) {
        ArrayList<JSONObject> bucket = index.get(key);
        if (bucket == null) {
            bucket = new ArrayList<>();
            index.put(key, bucket);
        }
        bucket.add(match);
    }

    private void mergeMatchArray(JSONArray baseMatches, Map<String, ArrayList<JSONObject>> byPair,
                                 JSONArray candidates, long sourceUpdate) {
        if (candidates == null) return;
        for (int i = 0; i < candidates.length(); i++) {
            JSONObject candidate = candidates.optJSONObject(i);
            if (candidate == null) continue;
            String home = teamName(candidate, true);
            String away = teamName(candidate, false);
            if (home.isEmpty() || away.isEmpty()) continue;

            String directKey = pairKey(home, away);
            String reverseKey = pairKey(away, home);
            JSONObject target = bestFixtureMatch(byPair.get(directKey), candidate, false);
            boolean reversed = false;
            if (target == null) {
                target = bestFixtureMatch(byPair.get(reverseKey), candidate, true);
                reversed = target != null;
            }
            if (target == null) {
                try {
                    baseMatches.put(candidate);
                    addToPairIndex(byPair, directKey, candidate);
                } catch (Exception ignored) {}
                continue;
            }
            long effectiveSourceUpdate = statusSourceUpdate(candidate, sourceUpdate);
            mergeOneMatch(target, candidate, reversed, effectiveSourceUpdate);
        }
    }

    /**
     * A team pair alone is not a fixture identity: the same clubs can meet in
     * league, cup and European competition. Prefer competition + season +
     * round/date and never merge rows that explicitly belong to different
     * competitions or seasons.
     */
    private JSONObject bestFixtureMatch(ArrayList<JSONObject> bucket, JSONObject candidate,
                                        boolean reversed) {
        if (bucket == null || bucket.isEmpty() || candidate == null) return null;
        JSONObject best = null;
        int bestScore = Integer.MIN_VALUE;
        for (JSONObject target : bucket) {
            int score = fixtureCompatibilityScore(target, candidate, reversed);
            if (score > bestScore) {
                bestScore = score;
                best = target;
            }
        }
        return bestScore >= 0 ? best : null;
    }

    private int fixtureCompatibilityScore(JSONObject target, JSONObject candidate, boolean reversed) {
        if (target == null || candidate == null) return Integer.MIN_VALUE;

        String targetCompetition = competitionKey(target);
        String candidateCompetition = competitionKey(candidate);
        if (!targetCompetition.isEmpty() && !candidateCompetition.isEmpty() &&
                !targetCompetition.equals(candidateCompetition)) return Integer.MIN_VALUE;

        String targetSeason = seasonKey(target);
        String candidateSeason = seasonKey(candidate);
        if (!targetSeason.isEmpty() && !candidateSeason.isEmpty() &&
                !targetSeason.equals(candidateSeason)) return Integer.MIN_VALUE;

        int targetRound = fixtureRound(target);
        int candidateRound = fixtureRound(candidate);
        if (targetRound > 0 && candidateRound > 0 && targetRound != candidateRound)
            return Integer.MIN_VALUE;

        long targetDay = fixtureDay(target);
        long candidateDay = fixtureDay(candidate);
        long dayGap = (targetDay > 0L && candidateDay > 0L)
                ? Math.abs(targetDay - candidateDay) : -1L;

        if (reversed && !canMergeReversedFixture(target, candidate)) return Integer.MIN_VALUE;

        // If competition identity is missing on either side, require concrete
        // round/date agreement. This prevents an unlabelled feed from crossing
        // into another competition merely because the clubs have the same names.
        if (targetCompetition.isEmpty() || candidateCompetition.isEmpty()) {
            boolean sameRound = targetRound > 0 && candidateRound > 0 && targetRound == candidateRound;
            boolean closeDate = dayGap >= 0L && dayGap <= 7L * 24L * 60L * 60L * 1000L;
            if (!sameRound && !closeDate) return Integer.MIN_VALUE;
        }

        int score = 0;
        if (!targetCompetition.isEmpty() && targetCompetition.equals(candidateCompetition)) score += 1000;
        if (!targetSeason.isEmpty() && targetSeason.equals(candidateSeason)) score += 250;
        if (targetRound > 0 && targetRound == candidateRound) score += 500;
        if (dayGap == 0L) score += 400;
        else if (dayGap > 0L && dayGap <= 7L * 24L * 60L * 60L * 1000L) score += 100;
        if (!reversed) score += 50;
        return score;
    }

    private String competitionKey(JSONObject match) {
        if (match == null) return "";
        String code = match.optString("competitionCode", "").trim();
        JSONObject competition = match.optJSONObject("competition");
        if (code.isEmpty() && competition != null) code = competition.optString("code", "").trim();
        if (!code.isEmpty()) return normalizeIdentity(code);

        String name = match.optString("competitionName", "").trim();
        if (name.isEmpty() && competition != null) name = competition.optString("name", "").trim();
        if (name.isEmpty()) {
            Object raw = match.opt("competition");
            if (raw instanceof String) name = String.valueOf(raw).trim();
        }
        return normalizeCompetitionIdentity(name);
    }

    private String normalizeCompetitionIdentity(String raw) {
        String value = normalizeIdentity(raw);
        if (value.equals("premierleague") || value.equals("pl")) return "pl";
        if (value.equals("championship") || value.equals("eflchampionship") || value.equals("elc")) return "elc";
        if (value.equals("laliga") || value.equals("primeradivision") || value.equals("pd")) return "pd";
        if (value.equals("bundesliga") || value.equals("bl1")) return "bl1";
        if (value.equals("seriea") || value.equals("sa")) return "sa";
        if (value.equals("ligue1") || value.equals("fl1")) return "fl1";
        if (value.equals("eredivisie") || value.equals("ded")) return "ded";
        if (value.equals("primeiraliga") || value.equals("ppl")) return "ppl";
        if (value.contains("brasileirao") || value.contains("brasileiro") || value.equals("bsa")) return "bsa";
        if (value.contains("championsleague") || value.equals("cl")) return "cl";
        if (value.contains("worldcup") || value.equals("wc")) return "wc";
        if (value.contains("europeanchampionship") || value.equals("ec") || value.equals("euro")) return "ec";
        if (value.equals("hnl") || value.contains("hrvatskanogometnaliga")) return "hnl";
        return value;
    }

    private String seasonKey(JSONObject match) {
        if (match == null) return "";
        Object raw = match.opt("season");
        if (raw instanceof JSONObject) {
            JSONObject season = (JSONObject) raw;
            String start = season.optString("startDate", "").trim();
            if (start.length() >= 4 && start.substring(0, 4).matches("\\d{4}")) return start.substring(0, 4);
            String name = season.optString("name", "").trim();
            String year = firstFourDigitYear(name);
            if (!year.isEmpty()) return year;
        } else if (raw != null && raw != JSONObject.NULL) {
            String year = firstFourDigitYear(String.valueOf(raw));
            if (!year.isEmpty()) return year;
        }
        return "";
    }

    private String firstFourDigitYear(String raw) {
        if (raw == null) return "";
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(?:19|20)\\d{2}").matcher(raw);
        return matcher.find() ? matcher.group() : "";
    }

    private String normalizeIdentity(String raw) {
        if (raw == null) return "";
        return Normalizer.normalize(raw.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]", "");
    }

    private boolean canMergeReversedFixture(JSONObject target, JSONObject candidate) {
        if (target == null || candidate == null) return false;

        int targetRound = fixtureRound(target);
        int candidateRound = fixtureRound(candidate);
        if (targetRound > 0 && candidateRound > 0) {
            return targetRound == candidateRound;
        }

        long targetDay = fixtureDay(target);
        long candidateDay = fixtureDay(candidate);
        if (targetDay > 0L && candidateDay > 0L) {
            long gap = Math.abs(targetDay - candidateDay);
            return gap <= 7L * 24L * 60L * 60L * 1000L;
        }

        // Without round or date identity, a reversed home/away pair is
        // ambiguous (first leg vs return leg, cup vs league, etc.). Never guess.
        return false;
    }

    private int fixtureRound(JSONObject match) {
        if (match == null) return 0;
        int round = match.optInt("matchday", 0);
        if (round <= 0) round = match.optInt("roundNumber", 0);
        if (round <= 0) round = match.optInt("week", 0);
        return round;
    }

    private long fixtureDay(JSONObject match) {
        if (match == null) return 0L;
        String raw = match.optString("utcDate", match.optString("date", "")).trim();
        if (raw.length() < 10) return 0L;
        try {
            SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            parser.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date parsed = parser.parse(raw.substring(0, 10));
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void mergeOneMatch(JSONObject target, JSONObject candidate,
                               boolean reversed, long sourceUpdate) {
        try {
            String candidateStatus = normalizedStatus(candidate.optString("status", ""));
            String targetStatus = normalizedStatus(target.optString("status", ""));
            int homeScore = scoreFrom(candidate, true);
            int awayScore = scoreFrom(candidate, false);
            if (reversed) {
                int swap = homeScore; homeScore = awayScore; awayScore = swap;
            }

            long targetUpdate = statusSourceUpdate(target, 0L);
            boolean candidateNewEnough = sourceUpdate > 0L
                    ? targetUpdate <= 0L || sourceUpdate >= targetUpdate
                    : targetUpdate <= 0L;

            // A stale feed must never override newer official match state. LIVE is
            // additionally accepted only while the source timestamp is fresh.
            boolean sourceFresh = sourceUpdate > 0L &&
                    Math.abs(System.currentTimeMillis() - sourceUpdate) <= LIVE_FRESHNESS_MS;
            boolean candidateLive = isLiveStatus(candidateStatus);
            boolean candidateOfficial = isFinishedStatus(candidateStatus) ||
                    (candidateLive && sourceFresh && isPlausibleLiveDate(candidate));
            boolean candidateAdministrative = isResultUnavailableStatus(candidateStatus) ||
                    isAdministrativeStatus(candidateStatus);
            boolean targetOfficial = isFinishedStatus(targetStatus) || isLiveStatus(targetStatus);
            boolean safeNonLiveUpdate = !candidateLive && !targetOfficial;
            boolean replaceDynamicState = candidateNewEnough &&
                    (candidateOfficial || candidateAdministrative || safeNonLiveUpdate);

            if (replaceDynamicState) {
                if (candidateOfficial && homeScore >= 0 && awayScore >= 0) {
                    target.put("homeGoals", homeScore);
                    target.put("awayGoals", awayScore);
                    target.put("homeScore", homeScore);
                    target.put("awayScore", awayScore);
                } else if (isFinishedStatus(candidateStatus) || candidateAdministrative) {
                    // A newer FINISHED marker without a verified final score, or a
                    // postponed/cancelled/no-result state, must not inherit an older
                    // LIVE score and turn it into a false final result.
                    removeScoreFields(target);
                }
                if (!candidateStatus.isEmpty()) target.put("status", candidateStatus);
                if (sourceUpdate > 0L) target.put(STATUS_SOURCE_UPDATE_FIELD, String.valueOf(sourceUpdate));
                copyFirst(candidate, target, "minute", "matchMinute", "elapsed");

                // Dynamic event/score payloads follow the same source-age rule as
                // status so an older provider cannot overwrite newer match state.
                copyIfPresent(candidate, target, "score");
                copyIfPresent(candidate, target, "goals");
                copyIfPresent(candidate, target, "bookings");
                copyIfPresent(candidate, target, "substitutions");
                copyIfPresent(candidate, target, "events");
                copyIfPresent(candidate, target, "referees");
            }

            // Fixture metadata also follows source age: a newer feed may move a
            // kickoff or venue, while an older feed may only fill a missing value.
            if (candidateNewEnough) {
                copyIfPresent(candidate, target, "venue");
                copyIfPresent(candidate, target, "stage");
                copyIfPresent(candidate, target, "utcDate");
            } else {
                copyIfMissing(candidate, target, "venue");
                copyIfMissing(candidate, target, "stage");
                copyIfMissing(candidate, target, "utcDate");
            }
        } catch (Exception ignored) {}
    }

    private void copyFirst(JSONObject source, JSONObject target, String... keys) {
        for (String key : keys) {
            if (!source.has(key) || source.isNull(key)) continue;
            try { target.put("minute", source.opt(key)); } catch (Exception ignored) {}
            return;
        }
    }

    private void copyIfPresent(JSONObject source, JSONObject target, String key) {
        if (!source.has(key) || source.isNull(key)) return;
        try { target.put(key, source.opt(key)); } catch (Exception ignored) {}
    }

    private void copyIfMissing(JSONObject source, JSONObject target, String key) {
        if (!source.has(key) || source.isNull(key)) return;
        Object existing = target.opt(key);
        if (existing != null && existing != JSONObject.NULL && !String.valueOf(existing).trim().isEmpty()) return;
        try { target.put(key, source.opt(key)); } catch (Exception ignored) {}
    }

    private boolean isLiveStatus(String status) {
        return "LIVE".equals(status) || "IN_PLAY".equals(status) ||
                "PAUSED".equals(status) || "HALFTIME".equals(status) ||
                "EXTRA_TIME".equals(status) || "PENALTY_SHOOTOUT".equals(status);
    }

    private boolean isFinishedStatus(String status) {
        return "FINISHED".equals(status) || "FT".equals(status) ||
                "AFTER_EXTRA_TIME".equals(status) || "AFTER_PENALTIES".equals(status);
    }

    private String normalizedStatus(String status) {
        if (status == null) return "";
        String value = status.trim().toUpperCase(Locale.US).replace(' ', '_').replace('-', '_');
        if ("INPLAY".equals(value)) return "IN_PLAY";
        if ("HT".equals(value) || "HALF_TIME".equals(value)) return "PAUSED";
        if ("FULL_TIME".equals(value) || "ENDED".equals(value) || "FINAL".equals(value)) return "FINISHED";
        return value;
    }

    private int scoreFrom(JSONObject match, boolean home) {
        String status = normalizedStatus(match == null ? "" : match.optString("status", ""));
        return scoreFrom(match, home, isLiveStatus(status));
    }

    private int scoreFrom(JSONObject match, boolean home, boolean allowHalfTime) {
        if (match == null) return -1;
        String[] direct = home
                ? new String[]{"homeGoals", "homeScore", "home_score", "scoreHome"}
                : new String[]{"awayGoals", "awayScore", "away_score", "scoreAway"};
        for (String key : direct) {
            int value = parseScore(match.opt(key));
            if (value >= 0) return value;
        }
        JSONObject score = match.optJSONObject("score");
        if (score != null) {
            String side = home ? "home" : "away";
            String[] finalPeriods = {"fullTime", "regularTime", "extraTime", "penalties"};
            for (String period : finalPeriods) {
                JSONObject object = score.optJSONObject(period);
                int value = object == null ? -1 : parseScore(object.opt(side));
                if (value >= 0) return value;
            }
            int value = parseScore(score.opt(side));
            if (value >= 0) return value;
            // halfTime is a valid current score only while a match is live/paused;
            // it must never be accepted as a final result for FINISHED.
            if (allowHalfTime) {
                JSONObject halfTime = score.optJSONObject("halfTime");
                value = halfTime == null ? -1 : parseScore(halfTime.opt(side));
                if (value >= 0) return value;
            }
        }
        return -1;
    }

    private long rootUpdateTime(JSONObject root) {
        if (root == null) return 0L;
        String[] keys = {"generatedAt", "lastUpdate", "updated", "updatedAt"};
        long newest = 0L;
        for (String key : keys) {
            long parsed = parseDate(root.optString(key, ""));
            if (parsed > newest) newest = parsed;
        }
        return newest;
    }

    private long parseDate(String raw) {
        if (raw == null || raw.trim().isEmpty()) return 0L;
        String value = raw.trim();
        if (value.matches("\\d{10,13}")) {
            try {
                long numeric = Long.parseLong(value);
                return value.length() == 10 ? numeric * 1000L : numeric;
            } catch (Exception ignored) {}
        }
        String[] formats = {
                "yyyy-MM-dd HH:mm 'UTC'", "yyyy-MM-dd HH:mm",
                "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
                "yyyy-MM-dd"
        };
        for (String format : formats) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(format, Locale.US);
                parser.setLenient(false);
                parser.setTimeZone(TimeZone.getTimeZone("UTC"));
                java.text.ParsePosition position = new java.text.ParsePosition(0);
                Date parsed = parser.parse(value, position);
                if (parsed != null && position.getIndex() == value.length()) return parsed.getTime();
            } catch (Exception ignored) {}
        }
        return 0L;
    }


    /**
     * Adds every Champions League qualifying fixture returned by ESPN to the
     * central match array. This is deliberately done before the UI receives
     * data, so Home, Matches, Competitions and Favorites all see the same rows.
     */
    String enrichWithChampionsLeagueQualifiers(String primaryJson) {
        try {
            JSONObject root = new JSONObject(primaryJson);
            JSONArray matches = root.optJSONArray("matches");
            if (matches == null) {
                matches = new JSONArray();
                root.put("matches", matches);
            }
            JSONArray live = root.optJSONArray("live");
            if (live == null) { live = new JSONArray(); root.put("live", live); }
            JSONArray finished = root.optJSONArray("finished");
            if (finished == null) { finished = new JSONArray(); root.put("finished", finished); }
            JSONArray upcoming = root.optJSONArray("upcoming");
            if (upcoming == null) { upcoming = new JSONArray(); root.put("upcoming", upcoming); }

            Map<String, JSONObject> index = indexMatchesByPairAndDate(matches);
            String range = uclDateRange();
            String body = downloadText(ESPN_UCL_SCOREBOARD + range + "&limit=1000", SUPPLEMENT_CONNECT_TIMEOUT_MS, SUPPLEMENT_READ_TIMEOUT_MS);
            JSONObject scoreboard = new JSONObject(body);
            appendEspnUclEvents(scoreboard, matches, live, finished, upcoming, index);
            root.put("qualifyingProvider", "ESPN UEFA Champions League Qualifying");
            return root.toString();
        } catch (Exception ignored) {
            // The paid football-data.org/GitHub feed remains fully usable when
            // the supplemental source is temporarily unavailable.
            return primaryJson;
        }
    }

    private Map<String, JSONObject> indexMatchesByPairAndDate(JSONArray matches) {
        Map<String, JSONObject> result = new HashMap<>();
        for (int i = 0; i < matches.length(); i++) {
            JSONObject match = matches.optJSONObject(i);
            if (match == null || !"cl".equals(competitionKey(match))) continue;
            String home = teamName(match, true);
            String away = teamName(match, false);
            if (home.isEmpty() || away.isEmpty()) continue;
            result.put(competitionPairDateKey("cl", home, away,
                    match.optString("utcDate", match.optString("date", ""))), match);
        }
        return result;
    }

    private int appendEspnUclEvents(JSONObject scoreboard, JSONArray matches, JSONArray live,
                                    JSONArray finished, JSONArray upcoming,
                                    Map<String, JSONObject> index) throws Exception {
        JSONArray events = scoreboard.optJSONArray("events");
        if (events == null) return 0;
        int added = 0;
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            if (event == null) continue;
            JSONArray competitions = event.optJSONArray("competitions");
            JSONObject competition = competitions == null ? null : competitions.optJSONObject(0);
            JSONArray competitors = competition == null ? null : competition.optJSONArray("competitors");
            if (competitors == null) continue;

            JSONObject homeCompetitor = null, awayCompetitor = null;
            for (int c = 0; c < competitors.length(); c++) {
                JSONObject competitor = competitors.optJSONObject(c);
                if (competitor == null) continue;
                if ("home".equalsIgnoreCase(competitor.optString("homeAway"))) homeCompetitor = competitor;
                if ("away".equalsIgnoreCase(competitor.optString("homeAway"))) awayCompetitor = competitor;
            }
            if (homeCompetitor == null || awayCompetitor == null) continue;
            String home = espnTeamName(homeCompetitor);
            String away = espnTeamName(awayCompetitor);
            String utcDate = event.optString("date", competition == null ? "" : competition.optString("date", ""));
            if (home.isEmpty() || away.isEmpty() || utcDate.isEmpty()) continue;

            String key = competitionPairDateKey("cl", home, away, utcDate);
            JSONObject target = index.get(key);
            if (target == null) {
                target = new JSONObject();
                target.put("id", "espn-ucl-" + event.optString("id", String.valueOf(i)));
                target.put("home", home);
                target.put("away", away);
                target.put("homeTeam", espnTeamObject(homeCompetitor));
                target.put("awayTeam", espnTeamObject(awayCompetitor));
                target.put("competition", "UEFA Champions League");
                target.put("competitionCode", "CL");
                target.put("utcDate", utcDate);
                target.put("date", utcDate);
                target.put("stage", espnUclStage(event, competition, utcDate));
                target.put("group", "");
                target.put("dataProvider", "ESPN");
                matches.put(target);
                index.put(key, target);
                added++;
            }

            JSONObject status = event.optJSONObject("status");
            JSONObject type = status == null ? null : status.optJSONObject("type");
            String state = type == null ? "" : type.optString("state", "");
            boolean completed = type != null && type.optBoolean("completed", false);
            String normalized = completed ? "FINISHED" :
                    ("in".equalsIgnoreCase(state) ? "LIVE" : "SCHEDULED");
            target.put("status", normalized);
            target.put(STATUS_SOURCE_UPDATE_FIELD, String.valueOf(System.currentTimeMillis()));
            int hg = parseScore(homeCompetitor.opt("score"));
            int ag = parseScore(awayCompetitor.opt("score"));
            if (hg >= 0 && ag >= 0 && ("LIVE".equals(normalized) || "FINISHED".equals(normalized))) {
                target.put("homeGoals", hg); target.put("awayGoals", ag);
                target.put("homeScore", hg); target.put("awayScore", ag);
            }
            if (competition != null) {
                JSONObject venue = competition.optJSONObject("venue");
                if (venue != null) target.put("venue", venue.optString("fullName", ""));
            }
            if ("LIVE".equals(normalized)) replaceOrAppendByDate(live, target);
            else if ("FINISHED".equals(normalized)) replaceOrAppendByDate(finished, target);
            else replaceOrAppendByDate(upcoming, target);
        }
        return added;
    }

    private JSONObject espnTeamObject(JSONObject competitor) throws Exception {
        JSONObject source = competitor.optJSONObject("team");
        JSONObject out = new JSONObject();
        String name = espnTeamName(competitor);
        out.put("name", name);
        out.put("shortName", source == null ? name : source.optString("shortDisplayName", name));
        out.put("tla", source == null ? "" : source.optString("abbreviation", ""));
        if (source != null) {
            JSONArray logos = source.optJSONArray("logos");
            String crest = preferredRasterLogo(logos);
            if (crest.length() == 0) {
                String direct = source.optString("logo", source.optString("darkLogo", "")).trim();
                if (direct.startsWith("//")) direct = "https:" + direct;
                if (direct.startsWith("https://") && !direct.toLowerCase(Locale.US).contains(".svg")) crest = direct;
            }
            if (crest.length() == 0) {
                String teamId = source.optString("id", "").trim();
                if (teamId.length() > 0) {
                    // ESPN exposes a stable raster badge endpoint even when the
                    // scoreboard payload omits its logos array. This keeps small
                    // qualifier clubs from falling back to initials.
                    crest = "https://a.espncdn.com/i/teamlogos/soccer/500/" + teamId + ".png";
                }
            }
            if (crest.length() > 0) out.put("crest", crest);
        }
        return out;
    }

    private String preferredRasterLogo(JSONArray logos) {
        if (logos == null) return "";
        String fallback = "";
        for (int i = 0; i < logos.length(); i++) {
            JSONObject logo = logos.optJSONObject(i);
            if (logo == null) continue;
            String href = logo.optString("href", "").trim();
            if (href.startsWith("//")) href = "https:" + href;
            if (!href.startsWith("https://")) continue;
            String lower = href.toLowerCase(Locale.US);
            if (fallback.length() == 0) fallback = href;
            // BitmapFactory handles PNG/JPEG/WebP. Prefer these over an SVG
            // variant because SVG requires an additional renderer on Android.
            if (lower.contains(".png") || lower.contains(".jpg") ||
                    lower.contains(".jpeg") || lower.contains(".webp") ||
                    lower.contains("format=png")) return href;
        }
        return fallback;
    }

    private String espnUclStage(JSONObject event, JSONObject competition, String utcDate) {
        StringBuilder phase = new StringBuilder();
        StringBuilder notesText = new StringBuilder();
        JSONObject season = event.optJSONObject("season");
        if (season != null) {
            JSONObject type = season.optJSONObject("type");
            if (type != null) phase.append(type.optString("name", "")).append(' ');
            phase.append(season.optString("slug", "")).append(' ');
        }
        if (competition != null) {
            JSONArray notes = competition.optJSONArray("notes");
            if (notes != null) for (int i = 0; i < notes.length(); i++) {
                JSONObject note = notes.optJSONObject(i);
                if (note != null) notesText.append(note.optString("headline", "")).append(' ');
            }
        }

        // Round and leg are different concepts. ESPN headlines often contain
        // both, for example "Second Qualifying Round - 1st Leg". The old
        // parser saw "1st" first and incorrectly labelled that as 1. pretkolo.
        // ESPN moves the round label between season/type, competition/type,
        // week/round and note fields. Collect all of those small metadata
        // objects so "2nd Qualifying Round" is not lost when only the leg is
        // present in the visible headline.
        String metadata = collectQualifierMetadata(event) + " " + collectQualifierMetadata(competition);
        String phaseText = phase.toString().toLowerCase(Locale.US);
        String allText = (phase.toString() + " " + notesText + " " + metadata).toLowerCase(Locale.US);
        String round;
        if (containsRound(allText, "playoff", "play-off", "play off")) round = "Play-off";
        else if (containsRound(allText, "third qualifying", "third qualification", "3rd qualifying", "qualifying round 3")) round = "3. pretkolo";
        else if (containsRound(allText, "second qualifying", "second qualification", "2nd qualifying", "qualifying round 2")) round = "2. pretkolo";
        else if (containsRound(allText, "first qualifying", "first qualification", "1st qualifying", "qualifying round 1")) round = "1. pretkolo";
        else if (containsRound(phaseText, "third round", "round 3")) round = "3. pretkolo";
        else if (containsRound(phaseText, "second round", "round 2")) round = "2. pretkolo";
        else if (containsRound(phaseText, "first round", "round 1")) round = "1. pretkolo";
        else round = inferQualifierRoundFromDate(utcDate);

        String leg = qualifierLeg(notesText.toString());
        return leg.length() == 0 ? round : round + " • " + leg;
    }


    private String collectQualifierMetadata(JSONObject object) {
        if (object == null) return "";
        StringBuilder out = new StringBuilder();
        String[] keys = {"name", "shortName", "displayName", "description", "headline", "slug", "abbreviation"};
        for (String key : keys) {
            String value = object.optString(key, "").trim();
            if (value.length() > 0) out.append(value).append(' ');
        }
        String[] childKeys = {"type", "round", "week", "phase", "stage", "season"};
        for (String key : childKeys) {
            JSONObject child = object.optJSONObject(key);
            if (child == null) continue;
            for (String valueKey : keys) {
                String value = child.optString(valueKey, "").trim();
                if (value.length() > 0) out.append(value).append(' ');
            }
            int number = child.optInt("number", -1);
            if (number > 0) out.append("round ").append(number).append(' ');
        }
        return out.toString();
    }

    private boolean containsRound(String text, String... values) {
        if (text == null) return false;
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private String qualifierLeg(String raw) {
        String text = raw == null ? "" : raw.toLowerCase(Locale.US);
        if (text.contains("2nd leg") || text.contains("second leg") || text.contains("leg 2")) return "Uzvrat";
        if (text.contains("1st leg") || text.contains("first leg") || text.contains("leg 1")) return "Prva utakmica";
        return "";
    }


    /**
     * ESPN sometimes exposes only "Qualifying" plus the leg, without the
     * qualifying-round number. UEFA uses stable summer windows, so the date is
     * a safe final fallback after every metadata field has been checked.
     * This prevents cards from falling back to the vague "Kvalifikacije" label.
     */
    private String inferQualifierRoundFromDate(String utcDate) {
        if (utcDate == null || utcDate.length() < 10) return "Kvalifikacije";
        try {
            int month = Integer.parseInt(utcDate.substring(5, 7));
            int day = Integer.parseInt(utcDate.substring(8, 10));
            if (month == 6) return "Preliminarno kolo";
            if (month == 7) {
                if (day <= 17) return "1. pretkolo";
                return "2. pretkolo";
            }
            if (month == 8) {
                if (day <= 5) return "2. pretkolo";
                if (day <= 19) return "3. pretkolo";
                return "Play-off";
            }
        } catch (Exception ignored) { }
        return "Kvalifikacije";
    }

    private void replaceOrAppendByDate(JSONArray array, JSONObject candidate) throws Exception {
        String key = competitionPairDateKey(competitionKey(candidate),
                teamName(candidate, true), teamName(candidate, false),
                candidate.optString("utcDate", candidate.optString("date", "")));
        for (int i = 0; i < array.length(); i++) {
            JSONObject current = array.optJSONObject(i);
            if (current == null) continue;
            String currentKey = competitionPairDateKey(competitionKey(current),
                    teamName(current, true), teamName(current, false),
                    current.optString("utcDate", current.optString("date", "")));
            if (key.equals(currentKey)) return;
        }
        array.put(new JSONObject(candidate.toString()));
    }

    private String pairDateKey(String home, String away, String date) {
        String day = date == null ? "" : date.trim();
        if (day.length() >= 10) day = day.substring(0, 10);
        return pairKey(home, away) + "|" + day;
    }

    private String competitionPairDateKey(String competition, String home, String away, String date) {
        return (competition == null ? "" : competition) + "|" + pairDateKey(home, away, date);
    }

    private String uclDateRange() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar from = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        from.add(Calendar.DAY_OF_MONTH, -21);
        Calendar to = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        to.add(Calendar.DAY_OF_MONTH, 50);
        return format.format(from.getTime()) + "-" + format.format(to.getTime());
    }

    /** Package-visible for deterministic parser tests. */
    String enrichWithLiveScoreFallback(String primaryJson) {
        try {
            JSONObject root = new JSONObject(primaryJson);
            JSONArray matches = root.optJSONArray("matches");
            if (matches == null || matches.length() == 0) return primaryJson;

            Map<String, ArrayList<JSONObject>> primaryByPair = new HashMap<>();
            for (int i = 0; i < matches.length(); i++) {
                JSONObject match = matches.optJSONObject(i);
                if (match == null || !"wc".equals(competitionKey(match))) continue;
                String home = teamName(match, true);
                String away = teamName(match, false);
                if (!home.isEmpty() && !away.isEmpty()) {
                    addToPairIndex(primaryByPair, pairKey(home, away), match);
                }
            }
            if (primaryByPair.isEmpty()) return primaryJson;

            JSONArray mergedLive = root.optJSONArray("live");
            if (mergedLive == null) {
                mergedLive = new JSONArray();
                root.put("live", mergedLive);
            }

            int merged = 0;
            try {
                String espnBody = downloadText(
                        "https://site.api.espn.com/apis/site/v2/sports/soccer/fifa.world/scoreboard?limit=100",
                        SUPPLEMENT_CONNECT_TIMEOUT_MS, SUPPLEMENT_READ_TIMEOUT_MS);
                merged += mergeEspnScoreboard(new JSONObject(espnBody), primaryByPair, mergedLive);
            } catch (Exception ignored) {}
            if (merged == 0) {
                for (String date : utcDatesAroundToday()) {
                    try {
                        String espnBody = downloadText(ESPN_SCOREBOARD + date + "&limit=100", SUPPLEMENT_CONNECT_TIMEOUT_MS, SUPPLEMENT_READ_TIMEOUT_MS);
                        merged += mergeEspnScoreboard(new JSONObject(espnBody), primaryByPair, mergedLive);
                    } catch (Exception ignored) {
                        // Primary data must remain usable when the fallback is unavailable.
                    }
                }
            }
            return root.toString();
        } catch (Exception ignored) {
            return primaryJson;
        }
    }

    private JSONObject firstWorldCupTarget(ArrayList<JSONObject> bucket) {
        if (bucket == null) return null;
        for (JSONObject match : bucket) {
            if (match != null && "wc".equals(competitionKey(match))) return match;
        }
        return null;
    }

    private int mergeEspnScoreboard(JSONObject scoreboard,
                                    Map<String, ArrayList<JSONObject>> primaryByPair,
                                    JSONArray mergedLive) throws Exception {
        int mergedCount = 0;
        JSONArray events = scoreboard.optJSONArray("events");
        if (events == null) return 0;
        for (int i = 0; i < events.length(); i++) {
            JSONObject event = events.optJSONObject(i);
            if (event == null) continue;
            JSONArray competitions = event.optJSONArray("competitions");
            JSONObject competition = competitions == null ? null : competitions.optJSONObject(0);
            JSONArray competitors = competition == null ? null : competition.optJSONArray("competitors");
            if (competitors == null) continue;

            JSONObject homeCompetitor = null;
            JSONObject awayCompetitor = null;
            for (int c = 0; c < competitors.length(); c++) {
                JSONObject competitor = competitors.optJSONObject(c);
                if (competitor == null) continue;
                if ("home".equalsIgnoreCase(competitor.optString("homeAway"))) homeCompetitor = competitor;
                if ("away".equalsIgnoreCase(competitor.optString("homeAway"))) awayCompetitor = competitor;
            }
            if (homeCompetitor == null || awayCompetitor == null) continue;

            String home = espnTeamName(homeCompetitor);
            String away = espnTeamName(awayCompetitor);
            JSONObject target = firstWorldCupTarget(primaryByPair.get(pairKey(home, away)));
            boolean reversed = false;
            if (target == null) {
                target = firstWorldCupTarget(primaryByPair.get(pairKey(away, home)));
                reversed = target != null;
            }
            if (target == null) continue;

            JSONObject status = event.optJSONObject("status");
            JSONObject type = status == null ? null : status.optJSONObject("type");
            String state = type == null ? "" : type.optString("state", "");
            String detail = type == null ? "" : type.optString("shortDetail", type.optString("detail", ""));
            boolean completed = type != null && type.optBoolean("completed", false);
            String normalizedStatus = completed ? "FINISHED" :
                    ("in".equalsIgnoreCase(state) ? "LIVE" :
                            ("pre".equalsIgnoreCase(state) ? "SCHEDULED" : state.toUpperCase(Locale.US)));

            int homeScore = parseScore(homeCompetitor.opt("score"));
            int awayScore = parseScore(awayCompetitor.opt("score"));
            if (reversed) {
                int swap = homeScore;
                homeScore = awayScore;
                awayScore = swap;
            }

            // ESPN may publish 0-0 immediately at kickoff. Zero is a valid score.
            if (homeScore >= 0 && awayScore >= 0 && ("LIVE".equals(normalizedStatus) || "FINISHED".equals(normalizedStatus))) {
                target.put("homeGoals", homeScore);
                target.put("awayGoals", awayScore);
                target.put("homeScore", homeScore);
                target.put("awayScore", awayScore);
            }
            if (!normalizedStatus.isEmpty()) target.put("status", normalizedStatus);
            target.put(STATUS_SOURCE_UPDATE_FIELD, String.valueOf(System.currentTimeMillis()));
            String minute = extractMinute(detail);
            if (!minute.isEmpty()) target.put("minute", minute);
            target.put("liveProvider", "ESPN");

            if ("LIVE".equals(normalizedStatus)) {
                JSONObject liveCopy = new JSONObject(target.toString());
                replaceOrAppendLive(mergedLive, liveCopy);
            }
            mergedCount++;
        }
        return mergedCount;
    }

    private void replaceOrAppendLive(JSONArray live, JSONObject candidate) {
        String candidateKey = competitionPairDateKey(competitionKey(candidate),
                teamName(candidate, true), teamName(candidate, false),
                candidate.optString("utcDate", candidate.optString("date", "")));
        for (int i = 0; i < live.length(); i++) {
            JSONObject current = live.optJSONObject(i);
            if (current == null) continue;
            String currentKey = competitionPairDateKey(competitionKey(current),
                    teamName(current, true), teamName(current, false),
                    current.optString("utcDate", current.optString("date", "")));
            if (candidateKey.equals(currentKey)) {
                // JSONArray has no set on very old Android JSON implementations;
                // update the existing object in place instead.
                copyField(candidate, current, "status");
                copyField(candidate, current, "minute");
                copyField(candidate, current, "homeGoals");
                copyField(candidate, current, "awayGoals");
                copyField(candidate, current, "homeScore");
                copyField(candidate, current, "awayScore");
                copyField(candidate, current, "liveProvider");
                return;
            }
        }
        live.put(candidate);
    }

    private void copyField(JSONObject source, JSONObject target, String key) {
        if (!source.has(key)) return;
        try { target.put(key, source.opt(key)); } catch (Exception ignored) {}
    }

    private int parseScore(Object value) {
        if (value == null || value == JSONObject.NULL) return -1;
        if (value instanceof Number) return ((Number) value).intValue();
        try {
            String text = String.valueOf(value).trim();
            if (text.isEmpty() || "null".equalsIgnoreCase(text)) return -1;
            int dot = text.indexOf('.');
            if (dot > 0) text = text.substring(0, dot);
            return Integer.parseInt(text);
        } catch (Exception ignored) {
            return -1;
        }
    }

    private String extractMinute(String detail) {
        if (detail == null) return "";
        String cleaned = detail.replace("’", "'").trim();
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < cleaned.length(); i++) {
            char ch = cleaned.charAt(i);
            if (Character.isDigit(ch)) digits.append(ch);
            else if (digits.length() > 0) break;
        }
        return digits.toString();
    }

    private String espnTeamName(JSONObject competitor) {
        JSONObject team = competitor.optJSONObject("team");
        if (team == null) return "";
        String name = team.optString("displayName", "");
        if (name.isEmpty()) name = team.optString("shortDisplayName", "");
        if (name.isEmpty()) name = team.optString("name", "");
        if (name.isEmpty()) name = team.optString("abbreviation", "");
        return name;
    }

    private String teamName(JSONObject object, boolean home) {
        String direct = object.optString(home ? "home" : "away", "");
        if (!direct.isEmpty()) return direct;
        JSONObject team = object.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team != null) {
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (!name.isEmpty()) return name;
        }
        Object raw = object.opt(home ? "homeTeam" : "awayTeam");
        if (raw instanceof String) return String.valueOf(raw);
        return object.optString(home ? "home_name" : "away_name", "");
    }

    private String pairKey(String home, String away) {
        return teamKey(home) + "|" + teamKey(away);
    }

    private String teamKey(String name) {
        if (name == null) return "";
        String key = Normalizer.normalize(name.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]", "");
        if (key.equals("france") || key.equals("fra")) return "france";
        if (key.equals("england") || key.equals("eng")) return "england";
        if (key.equals("spain") || key.equals("esp")) return "spain";
        if (key.equals("argentina") || key.equals("arg")) return "argentina";
        if (key.equals("unitedstates") || key.equals("usa")) return "usa";
        if (key.equals("korearepublic") || key.equals("southkorea")) return "southkorea";
        return key;
    }

    private String[] utcDatesAroundToday() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        calendar.setTime(new Date());
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        String previous = format.format(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        String today = format.format(calendar.getTime());
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        String next = format.format(calendar.getTime());
        return new String[]{previous, today, next};
    }


    /**
     * Replaces every HNL row from generic/demo feeds with the verified
     * SuperSport HNL 2026/27 schedule published by HNS Semafor.
     *
     * The same rebuilt match objects are then consumed by Home, Matches,
     * Favorites and the HNL competition screen, so pairs and round numbers
     * cannot diverge between screens.
     */
    private void applyOfficialHnlSchedule(JSONObject root) {
        try {
            JSONArray official = officialHnlMatches();
            JSONArray matches = withoutHnl(root.optJSONArray("matches"));
            for (int i = 0; i < official.length(); i++) {
                matches.put(official.getJSONObject(i));
            }
            root.put("matches", matches);
            root.put("live", withoutHnl(root.optJSONArray("live")));
            root.put("finished", withoutHnl(root.optJSONArray("finished")));

            JSONArray upcoming = withoutHnl(root.optJSONArray("upcoming"));
            for (int i = 0; i < official.length(); i++) {
                upcoming.put(official.getJSONObject(i));
            }
            root.put("upcoming", upcoming);

            JSONObject sources = root.optJSONObject("sources");
            if (sources == null) {
                sources = new JSONObject();
                root.put("sources", sources);
            }
            JSONObject hnl = new JSONObject();
            hnl.put("status", "connected");
            hnl.put("provider", "HNS Semafor");
            hnl.put("season", "2026/27");
            hnl.put("matchCount", official.length());
            hnl.put("lastSuccessfulUpdate", "2026-08-13");
            sources.put("HNL", hnl);
        } catch (Exception ignored) {}
    }

    private JSONArray withoutHnl(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject match = source.optJSONObject(i);
            if (match == null || isHnlMatch(match)) continue;
            try { result.put(match); } catch (Exception ignored) {}
        }
        return result;
    }

    private boolean isHnlMatch(JSONObject match) {
        JSONObject competition = match.optJSONObject("competition");
        String value = competition == null
                ? match.optString("competition", match.optString("competitionCode", ""))
                : competition.optString("code", competition.optString("name", ""));
        String normalized = value == null ? "" : value.toUpperCase(Locale.US);
        return normalized.equals("HNL") || normalized.contains("SUPERSPORT HNL");
    }

    private JSONArray officialHnlMatches() {
        JSONArray result = new JSONArray();

        // SuperSport HNL 2026/27.
        //
        // Dates/venues are taken from the official HNS Semafor schedule.
        // Exact kickoff times are stored ONLY when they are currently published.
        // Unknown future kickoff times intentionally remain date-only.
        //
        // Published schedule checked 2026-08-13.

        // 1. kolo — completed/published exact kickoff times.
        addHnlRound(result, 1, new String[][]{
                {"2026-07-31T18:00:00Z", "Dinamo Zagreb", "Slaven Belupo", "Stadion Maksimir, Zagreb"},
                {"2026-08-01T16:30:00Z", "Istra 1961", "Lokomotiva Zagreb", "Aldo Drosina, Pula"},
                {"2026-08-01T19:00:00Z", "Gorica", "Osijek", "Gradski stadion, Velika Gorica"},
                {"2026-08-02T16:30:00Z", "Varaždin", "Hajduk Split", "Stadion Varteks, Varaždin"},
                {"2026-08-02T19:00:00Z", "Rijeka", "Rudeš", "HNK Rijeka, Rijeka"}
        });

        // 2. kolo — exact published times. Rijeka–Dinamo is officially postponed;
        // no replacement kickoff is invented.
        addHnlPostponedMatch(result, 2, "2026-08-08",
                "Rijeka", "Dinamo Zagreb", "HNK Rijeka, Rijeka");
        addHnlRound(result, 2, new String[][]{
                {"2026-08-08T16:30:00Z", "Rudeš", "Osijek", "Gradski stadion, Velika Gorica"},
                {"2026-08-08T19:00:00Z", "Lokomotiva Zagreb", "Gorica", "Stadion Maksimir, Zagreb"},
                {"2026-08-09T16:30:00Z", "Slaven Belupo", "Varaždin", "Gradski stadion Ivan Kušek Apaš, Koprivnica"},
                {"2026-08-09T19:00:00Z", "Hajduk Split", "Istra 1961", "Gradski stadion Poljud, Split"}
        });

        // 3. kolo — HNS has the verified date/pairings. Dinamo-Rudeš also
        // has a corroborated exact kickoff from current independent live-score feeds.
        addHnlExactMatch(result, 3, "2026-08-15T15:00:00Z",
                "Dinamo Zagreb", "Rudeš", "Stadion Maksimir, Zagreb");
        addHnlRound(result, 3, "2026-08-15", new String[][]{
                {"Istra 1961", "Slaven Belupo", "Aldo Drosina, Pula"},
                {"Osijek", "Lokomotiva Zagreb", "Opus Arena, Osijek"},
                {"Varaždin", "Rijeka", "Stadion Varteks, Varaždin"},
                {"Gorica", "Hajduk Split", "Gradski stadion, Velika Gorica"}
        });

        // 4. kolo — verified date/pairings only until exact kickoffs are confirmed.
        addHnlRound(result, 4, "2026-08-22", new String[][]{
                {"Rudeš", "Lokomotiva Zagreb", "Gradski stadion, Velika Gorica"},
                {"Slaven Belupo", "Gorica", "Gradski stadion Ivan Kušek Apaš, Koprivnica"},
                {"Dinamo Zagreb", "Varaždin", "Stadion Maksimir, Zagreb"},
                {"Rijeka", "Istra 1961", "HNK Rijeka, Rijeka"},
                {"Hajduk Split", "Osijek", "Gradski stadion Poljud, Split"}
        });

        // From round 5 onward HNS has published the round dates/pairings, but
        // kickoff times are still not confirmed. Keep the verified dates only.
        addHnlRound(result, 5, "2026-08-29", new String[][]{
                {"Varaždin", "Rudeš", "Stadion Varteks, Varaždin"},
                {"Istra 1961", "Dinamo Zagreb", "Aldo Drosina, Pula"},
                {"Gorica", "Rijeka", "Gradski stadion, Velika Gorica"},
                {"Osijek", "Slaven Belupo", "Opus Arena, Osijek"},
                {"Lokomotiva Zagreb", "Hajduk Split", "Gradski stadion Poljud, Split"}
        });
        addHnlRound(result, 6, "2026-09-05", new String[][]{
                {"Rudeš", "Hajduk Split", "Gradski stadion, Velika Gorica"},
                {"Slaven Belupo", "Lokomotiva Zagreb", "Gradski stadion Ivan Kušek Apaš, Koprivnica"},
                {"Rijeka", "Osijek", "HNK Rijeka, Rijeka"},
                {"Dinamo Zagreb", "Gorica", "Stadion Maksimir, Zagreb"},
                {"Varaždin", "Istra 1961", "Stadion Varteks, Varaždin"}
        });
        addHnlRound(result, 7, "2026-09-12", new String[][]{
                {"Istra 1961", "Rudeš", "Aldo Drosina, Pula"},
                {"Gorica", "Varaždin", "Gradski stadion, Velika Gorica"},
                {"Osijek", "Dinamo Zagreb", "Opus Arena, Osijek"},
                {"Lokomotiva Zagreb", "Rijeka", "Stadion Maksimir, Zagreb"},
                {"Hajduk Split", "Slaven Belupo", "Gradski stadion Poljud, Split"}
        });
        addHnlRound(result, 8, "2026-09-19", new String[][]{
                {"Rudeš", "Slaven Belupo", "Gradski stadion, Velika Gorica"},
                {"Rijeka", "Hajduk Split", "HNK Rijeka, Rijeka"},
                {"Dinamo Zagreb", "Lokomotiva Zagreb", "Stadion Maksimir, Zagreb"},
                {"Varaždin", "Osijek", "Stadion Varteks, Varaždin"},
                {"Istra 1961", "Gorica", "Aldo Drosina, Pula"}
        });
        addHnlRound(result, 9, "2026-10-10", new String[][]{
                {"Gorica", "Rudeš", "Gradski stadion, Velika Gorica"},
                {"Osijek", "Istra 1961", "Opus Arena, Osijek"},
                {"Lokomotiva Zagreb", "Varaždin", "Stadion Maksimir, Zagreb"},
                {"Hajduk Split", "Dinamo Zagreb", "Gradski stadion Poljud, Split"},
                {"Slaven Belupo", "Rijeka", "Gradski stadion Ivan Kušek Apaš, Koprivnica"}
        });

        return result;
    }


    private void addHnlExactMatch(JSONArray target, int round, String utcDate,
                                  String home, String away, String venue) {
        addHnlRound(target, round, new String[][]{{utcDate, home, away, venue}});
    }

    private void addHnlPostponedMatch(JSONArray target, int round, String date,
                                      String home, String away, String venue) {
        try {
            JSONObject match = new JSONObject();
            match.put("id", "HNL-2026-" + round + "-" + teamKey(home) + "-" + teamKey(away));
            JSONObject competition = new JSONObject();
            competition.put("code", "HNL");
            competition.put("name", "HNL");
            match.put("competition", competition);

            JSONObject homeTeam = new JSONObject();
            homeTeam.put("name", home);
            JSONObject awayTeam = new JSONObject();
            awayTeam.put("name", away);

            match.put("homeTeam", homeTeam);
            match.put("awayTeam", awayTeam);
            match.put("home", home);
            match.put("away", away);
            match.put("utcDate", date);
            match.put("date", date);
            match.put("status", "POSTPONED");
            match.put("matchday", round);
            match.put("roundNumber", round);
            match.put("roundName", "Kolo " + round);
            match.put("stage", "Kolo " + round);
            match.put("venue", venue);
            target.put(match);
        } catch (Exception ignored) {}
    }

    private void addHnlRound(JSONArray target, int round, String[][] matches) {
        for (String[] row : matches) addHnlMatch(target, round, row[0], row[1], row[2], row[3]);
    }

    private void addHnlRound(JSONArray target, int round, String date, String[][] matches) {
        for (String[] row : matches) addHnlMatch(target, round, date, row[0], row[1], row[2]);
    }

    private void addHnlMatch(JSONArray target, int round, String date, String home,
                             String away, String venue) {
        try {
            JSONObject match = new JSONObject();
            match.put("id", "HNL-2026-" + round + "-" + teamKey(home) + "-" + teamKey(away));
            JSONObject competition = new JSONObject();
            competition.put("code", "HNL");
            competition.put("name", "HNL");
            match.put("competition", competition);
            JSONObject homeTeam = new JSONObject();
            homeTeam.put("name", home);
            JSONObject awayTeam = new JSONObject();
            awayTeam.put("name", away);
            match.put("homeTeam", homeTeam);
            match.put("awayTeam", awayTeam);
            match.put("home", home);
            match.put("away", away);
            match.put("utcDate", date);
            match.put("date", date);
            match.put("status", "SCHEDULED");
            match.put("matchday", round);
            match.put("roundNumber", round);
            match.put("roundName", "Kolo " + round);
            match.put("stage", "Kolo " + round);
            match.put("venue", venue);
            target.put(match);
        } catch (Exception ignored) {}
    }

    private static final class HttpResult {
        final String body;
        final String etag;
        final boolean notModified;

        HttpResult(String body, String etag, boolean notModified) {
            this.body = body == null ? "" : body;
            this.etag = etag == null ? "" : etag;
            this.notModified = notModified;
        }
    }

    private HttpResult downloadHttp(String urlString, String previousEtag, int connectTimeoutMs, int readTimeoutMs) throws Exception {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try {
            connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setConnectTimeout(connectTimeoutMs);
            connection.setReadTimeout(readTimeoutMs);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-cache");
            connection.setRequestProperty("Pragma", "no-cache");
            connection.setRequestProperty("User-Agent", "FootballFun/Android");
            if (previousEtag != null && !previousEtag.trim().isEmpty()) {
                connection.setRequestProperty("If-None-Match", previousEtag.trim());
            }

            int responseCode = connection.getResponseCode();
            String etag = connection.getHeaderField("ETag");
            if (responseCode == HttpURLConnection.HTTP_NOT_MODIFIED) {
                return new HttpResult("", etag, true);
            }
            if (responseCode < 200 || responseCode >= 300) throw new Exception("HTTP " + responseCode);

            reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            return new HttpResult(body.toString(), etag, false);
        } finally {
            try { if (reader != null) reader.close(); } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private String downloadText(String urlString) throws Exception {
        return downloadText(urlString, SUPPLEMENT_CONNECT_TIMEOUT_MS, SUPPLEMENT_READ_TIMEOUT_MS);
    }

    private String downloadText(String urlString, int connectTimeoutMs, int readTimeoutMs) throws Exception {
        return downloadHttp(urlString, "", connectTimeoutMs, readTimeoutMs).body;
    }
}
