package com.asappfactory.footballfun.data;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Network boundary for Football Fun live data.
 * Screens never know URLs, timeouts or HTTP details.
 */
public final class LiveDataClient {
    private static final int TIMEOUT_MS = 7000;

    private static final String[] SOURCES = {
            "https://raw.githubusercontent.com/alensekula-ship-it/worldcup-live-updater/main/live-results.json",
            "https://raw.githubusercontent.com/alensekula-ship-it/worldcup-live-data/main/live-results.json",
            "https://alensekula-ship-it.github.io/worldcup-live-data/live-results.json",
            "https://raw.githubusercontent.com/alensekula-ship-it/WorldCupFan2026/main/live-results.json",
            "https://alensekula-ship-it.github.io/WorldCupFan2026/live-results.json"
    };

    public String downloadLatest() throws Exception {
        Exception lastError = null;
        for (String source : SOURCES) {
            try {
                String separator = source.contains("?") ? "&" : "?";
                String body = downloadText(source + separator + "t=" + System.currentTimeMillis());
                if (body != null && !body.trim().isEmpty()) {
                    return body;
                }
            } catch (Exception error) {
                lastError = error;
            }
        }
        if (lastError != null) {
            throw lastError;
        }
        throw new Exception("No online source");
    }

    private String downloadText(String urlString) throws Exception {
        HttpURLConnection connection = null;
        BufferedReader reader = null;
        try {
            connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setConnectTimeout(TIMEOUT_MS);
            connection.setReadTimeout(TIMEOUT_MS);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
            connection.setRequestProperty("Pragma", "no-cache");

            int responseCode = connection.getResponseCode();
            if (responseCode < 200 || responseCode >= 300) {
                throw new Exception("HTTP " + responseCode);
            }

            reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                body.append(line);
            }
            return body.toString();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (Exception ignored) {}
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
