package com.asappfactory.footballfun.data;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Dedicated disk cache for the large authoritative online JSON payload.
 *
 * Keeping multi-megabyte football data out of SharedPreferences prevents the
 * user-settings XML from becoming a startup bottleneck. Reads/writes are used
 * only from background workers in MainActivity, while lightweight metadata
 * such as ETag and timestamps remains in SharedPreferences.
 */
public final class OnlineDataCache {
    private final File cacheFile;

    public OnlineDataCache(Context context) {
        cacheFile = new File(context.getFilesDir(), "footballfun-online-cache-v1.json");
    }

    public synchronized String read() {
        if (!cacheFile.isFile() || cacheFile.length() < 2) return "";
        try (FileInputStream in = new FileInputStream(cacheFile);
             ByteArrayOutputStream out = new ByteArrayOutputStream((int)Math.min(cacheFile.length(), 4L * 1024L * 1024L))) {
            byte[] buffer = new byte[32768];
            int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return "";
        }
    }

    public synchronized boolean write(String json) {
        if (json == null || json.trim().isEmpty()) return false;
        File temp = new File(cacheFile.getParentFile(), cacheFile.getName() + ".tmp");
        try {
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(bytes);
                out.flush();
            }
            if (cacheFile.exists() && !cacheFile.delete()) throw new java.io.IOException("cache replace failed");
            if (!temp.renameTo(cacheFile)) throw new java.io.IOException("cache rename failed");
            return true;
        } catch (Exception ignored) {
            if (temp.exists()) temp.delete();
            return false;
        }
    }

    public synchronized void clear() {
        try { if (cacheFile.exists()) cacheFile.delete(); } catch (Exception ignored) {}
    }

    public synchronized long sizeBytes() {
        return cacheFile.isFile() ? cacheFile.length() : 0L;
    }
}
