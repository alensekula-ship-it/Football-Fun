package com.asappfactory.footballfun.presentation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Presentation-only match labels shared by the Match Center and match details. */
public final class MatchCenterFormatter {
    public static String stage(String group, String rawStage, String language) {
        String raw = rawStage == null ? "" : rawStage.trim();
        String key = raw.replace('-', '_').replace(' ', '_').toUpperCase(Locale.US);

        // Knockout stage metadata is more specific than a stale group inherited
        // from the original tournament schedule. This keeps Home, Competition
        // Center and Match Center on the same canonical stage.
        boolean specificStage = key.contains("THIRD_PLACE") || key.contains("3RD_PLACE") ||
                key.contains("ROUND_OF_32") || key.contains("LAST_32") || key.equals("R32") ||
                key.contains("ROUND_OF_16") || key.contains("LAST_16") || key.equals("R16") ||
                key.contains("QUARTER") || key.contains("SEMI") || key.equals("FINAL") ||
                key.endsWith("_FINAL") || key.contains("PLAYOFF");
        if (!specificStage && group != null && group.matches("[A-L]")) {
            return choose(language, "Group " + group, "Skupina " + group, "Gruppe " + group,
                    "Grupo " + group, "Groupe " + group);
        }
        if (raw.isEmpty() || "null".equalsIgnoreCase(raw) || "?".equals(raw)) return "";
        if (key.equals("GROUP") || key.equals("GROUP_STAGE"))
            return choose(language, "Group stage", "Skupina", "Gruppenphase", "Fase de grupos", "Phase de groupes");
        if (key.equals("REGULAR_SEASON") || key.equals("REGULAR") || key.equals("LEAGUE"))
            return choose(language, "Regular season", "Prvenstvo", "Reguläre Saison", "Temporada regular", "Saison régulière");
        if (key.contains("THIRD_PLACE") || key.contains("3RD_PLACE"))
            return choose(language, "Third-place match", "Utakmica za 3. mjesto", "Spiel um Platz 3", "Partido por el tercer puesto", "Match pour la 3e place");
        if (key.contains("ROUND_OF_32") || key.contains("LAST_32") || key.equals("R32"))
            return choose(language, "Round of 32", "Šesnaestina finala", "Sechzehntelfinale", "Dieciseisavos", "Seizièmes de finale");
        if (key.contains("ROUND_OF_16") || key.contains("LAST_16") || key.equals("R16"))
            return choose(language, "Round of 16", "Osmina finala", "Achtelfinale", "Octavos de final", "Huitièmes de finale");
        if (key.contains("QUARTER"))
            return choose(language, "Quarter-final", "Četvrtfinale", "Viertelfinale", "Cuartos de final", "Quart de finale");
        if (key.contains("SEMI"))
            return choose(language, "Semi-final", "Polufinale", "Halbfinale", "Semifinal", "Demi-finale");
        if (key.equals("FINAL") || key.endsWith("_FINAL"))
            return choose(language, "Final", "Finale", "Finale", "Final", "Finale");
        if (key.contains("LEAGUE_STAGE"))
            return choose(language, "League phase", "Ligaška faza", "Ligaphase", "Fase de liga", "Phase de ligue");
        if (key.contains("1._PRETKOLO") || key.contains("1_PRETKOLO") || key.contains("FIRST_QUALIFYING"))
            return appendLeg(raw, choose(language, "First qualifying round", "1. pretkolo", "1. Qualifikationsrunde", "Primera ronda previa", "1er tour de qualification"), language);
        if (key.contains("2._PRETKOLO") || key.contains("2_PRETKOLO") || key.contains("SECOND_QUALIFYING"))
            return appendLeg(raw, choose(language, "Second qualifying round", "2. pretkolo", "2. Qualifikationsrunde", "Segunda ronda previa", "2e tour de qualification"), language);
        if (key.contains("3._PRETKOLO") || key.contains("3_PRETKOLO") || key.contains("THIRD_QUALIFYING"))
            return appendLeg(raw, choose(language, "Third qualifying round", "3. pretkolo", "3. Qualifikationsrunde", "Tercera ronda previa", "3e tour de qualification"), language);
        if (key.contains("QUALIFICATION") || key.contains("QUALIFYING"))
            return choose(language, "Qualifying", "Kvalifikacije", "Qualifikation", "Clasificación", "Qualifications");
        if (key.contains("PLAYOFF") || key.contains("PLAY_OFF"))
            return choose(language, "Play-off", "Doigravanje", "Play-off", "Play-off", "Barrages");
        if (key.contains("RELEGATION"))
            return choose(language, "Relegation round", "Borba za ostanak", "Abstiegsrunde", "Ronda de descenso", "Phase de relégation");
        if (key.contains("CHAMPIONSHIP") || key.contains("CHAMPION_ROUND"))
            return choose(language, "Championship round", "Borba za naslov", "Meisterrunde", "Ronda por el título", "Phase pour le titre");
        if (key.contains("PROMOTION"))
            return choose(language, "Promotion round", "Borba za promociju", "Aufstiegsrunde", "Ronda de ascenso", "Phase de promotion");
        if (key.contains("PRELIMINARY"))
            return choose(language, "Preliminary round", "Preliminarno kolo", "Vorrunde", "Ronda preliminar", "Tour préliminaire");
        if (key.contains("QUALIFICATION") || key.contains("QUALIFYING"))
            return choose(language, "Qualifying", "Kvalifikacije", "Qualifikation", "Clasificación", "Qualifications");
        if (key.contains("ROUND_OF_64") || key.contains("LAST_64") || key.equals("R64"))
            return choose(language, "Round of 64", "Tridesetdruga finala", "Zweiunddreißigstelfinale", "Treintaidosavos", "Trente-deuxièmes de finale");
        if (key.equals("FIRST_ROUND") || key.equals("ROUND_1"))
            return choose(language, "First round", "Prvo kolo", "Erste Runde", "Primera ronda", "Premier tour");
        if (key.equals("SECOND_ROUND") || key.equals("ROUND_2"))
            return choose(language, "Second round", "Drugo kolo", "Zweite Runde", "Segunda ronda", "Deuxième tour");
        if (key.equals("THIRD_ROUND") || key.equals("ROUND_3"))
            return choose(language, "Third round", "Treće kolo", "Dritte Runde", "Tercera ronda", "Troisième tour");
        if (key.contains("CUP") && key.contains("FINAL"))
            return choose(language, "Cup final", "Finale kupa", "Pokalfinale", "Final de copa", "Finale de coupe");
        return humanize(raw);
    }

    public static String status(String rawStatus, String rawMinute, boolean live, boolean finished, String language) {
        String status = rawStatus == null ? "" : rawStatus.trim().toUpperCase(Locale.US).replace(' ', '_');
        String minute = rawMinute == null ? "" : rawMinute.trim().replace("'", "").replace("′", "");
        if (status.equals("PAUSED") || status.equals("HALF_TIME") || status.equals("HT"))
            return choose(language, "HALF-TIME", "POLUVRIJEME", "HALBZEIT", "DESCANSO", "MI-TEMPS");
        if (status.equals("EXTRA_TIME"))
            return choose(language, "EXTRA TIME", "PRODUŽECI", "VERLÄNGERUNG", "PRÓRROGA", "PROLONGATION") + minuteSuffix(minute);
        if (status.equals("PENALTY_SHOOTOUT") || status.equals("PENALTIES"))
            return choose(language, "PENALTIES", "JEDANAESTERCI", "ELFMETERSCHIESSEN", "PENALES", "TIRS AU BUT");
        if (status.contains("POSTPON"))
            return choose(language, "POSTPONED", "ODGOĐENO", "VERSCHOBEN", "APLAZADO", "REPORTÉ");
        if (status.contains("CANCEL"))
            return choose(language, "CANCELLED", "OTKAZANO", "ABGESAGT", "CANCELADO", "ANNULÉ");
        if (status.contains("SUSPEND"))
            return choose(language, "SUSPENDED", "PREKINUTO", "UNTERBROCHEN", "SUSPENDIDO", "SUSPENDU");
        if (status.equals("NO_RESULT") || status.equals("PLAYED_NO_SCORE") || status.equals("FINISHED_NO_SCORE") ||
                status.equals("RESULT_PENDING") || status.equals("UNCONFIRMED_RESULT") || status.equals("RESULT_UNCONFIRMED") ||
                status.equals("PLAYED"))
            return choose(language, "NO RESULT", "BEZ REZULTATA", "OHNE ERGEBNIS", "SIN RESULTADO", "SANS RÉSULTAT");
        if (live)
            return minute.isEmpty() ? choose(language, "LIVE", "UŽIVO", "LIVE", "EN VIVO", "DIRECT")
                    : choose(language, "LIVE ", "UŽIVO ", "LIVE ", "EN VIVO ", "DIRECT ") + minute + "′";
        if (finished)
            return choose(language, "FULL TIME", "ZAVRŠENO", "BEENDET", "FINALIZADO", "TERMINÉ");
        return "";
    }

    public static String fullDate(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        String value = new SimpleDateFormat("EEEE, d. MMMM • HH:mm", locale).format(date);
        return capitalize(value);
    }

    public static String dayHeading(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        return capitalize(new SimpleDateFormat("EEE, d. MMM", locale).format(date));
    }

    public static String dateChip(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        String day = new SimpleDateFormat("EEE", locale).format(date).toUpperCase(locale);
        String number = new SimpleDateFormat("d.M.", locale).format(date);
        return day + "\n" + number;
    }

    private static String minuteSuffix(String minute) { return minute.isEmpty() ? "" : " " + minute + "′"; }

    private static String humanize(String raw) {
        String value = raw.replace('_', ' ').replace('-', ' ').trim().toLowerCase(Locale.US);
        if (value.isEmpty()) return "";
        String[] parts = value.split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }

    private static String appendLeg(String raw, String round, String language) {
        String key = raw == null ? "" : raw.toLowerCase(Locale.US);
        String leg = "";
        if (key.contains("uzvrat") || key.contains("2nd leg") || key.contains("second leg"))
            leg = choose(language, "Second leg", "Uzvrat", "Rückspiel", "Vuelta", "Retour");
        else if (key.contains("prva utakmica") || key.contains("1st leg") || key.contains("first leg"))
            leg = choose(language, "First leg", "Prva utakmica", "Hinspiel", "Ida", "Aller");
        return leg.isEmpty() ? round : round + " • " + leg;
    }

    private static String capitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private static String choose(String language, String en, String hr, String de, String es, String fr) {
        if ("HR".equals(language)) return hr;
        if ("DE".equals(language)) return de;
        if ("ES".equals(language)) return es;
        if ("FR".equals(language)) return fr;
        return en;
    }

    private MatchCenterFormatter() {}
}
