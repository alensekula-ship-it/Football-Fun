package com.asappfactory.footballfun.presentation;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Presentation-only match labels shared by the Match Center and match details. */
public final class MatchCenterFormatter {
    public static String stage(String group, String rawStage, String language) {
        if (group != null && group.matches("[A-L]")) {
            return choose(language, "Group " + group, "Skupina " + group, "Gruppe " + group,
                    "Grupo " + group, "Groupe " + group);
        }
        String raw = rawStage == null ? "" : rawStage.trim();
        if (raw.isEmpty() || "null".equalsIgnoreCase(raw) || "?".equals(raw)) return "";
        String key = raw.replace('-', '_').replace(' ', '_').toUpperCase(Locale.US);
        if (key.equals("GROUP") || key.equals("GROUP_STAGE") || key.equals("REGULAR_SEASON")) return "";
        if (key.contains("THIRD_PLACE") || key.contains("3RD_PLACE"))
            return choose(language, "Third-place match", "Utakmica za 3. mjesto", "Spiel um Platz 3", "Partido por el tercer puesto", "Match pour la 3e place");
        if (key.contains("ROUND_OF_32") || key.contains("LAST_32") || key.equals("R32"))
            return choose(language, "Round of 32", "Šesnaestina finala", "Sechzehntelfinale", "Dieciseisavos", "Seizièmes de finale");
        if (key.contains("ROUND_OF_16") || key.contains("LAST_16") || key.equals("R16"))
            return choose(language, "Round of 16", "Osmina finala", "Achtelfinale", "Octavos de final", "Huitièmes de finale");
        if (key.contains("QUARTER"))
            return choose(language, "Quarter-final", "Četvrtfinale", "Viertelfinale", "Cuartos de final", "Quart de finale");
        if (key.contains("SEMI"))
            return choose(language, "Semi-final", "Polufinale", "Halbfinale", "Semifinal", "Demi-finale");
        if (key.equals("FINAL") || key.endsWith("_FINAL"))
            return choose(language, "Final", "Finale", "Finale", "Final", "Finale");
        if (key.contains("LEAGUE_STAGE"))
            return choose(language, "League phase", "Ligaška faza", "Ligaphase", "Fase de liga", "Phase de ligue");
        if (key.contains("QUALIFICATION") || key.contains("QUALIFYING"))
            return choose(language, "Qualifying", "Kvalifikacije", "Qualifikation", "Clasificación", "Qualifications");
        if (key.contains("PLAYOFF"))
            return choose(language, "Play-off", "Doigravanje", "Play-off", "Play-off", "Barrages");
        return humanize(raw);
    }

    public static String status(String rawStatus, String rawMinute, boolean live, boolean finished, String language) {
        String status = rawStatus == null ? "" : rawStatus.trim().toUpperCase(Locale.US).replace(' ', '_');
        String minute = rawMinute == null ? "" : rawMinute.trim().replace("'", "").replace("′", "");
        if (status.equals("PAUSED") || status.equals("HALF_TIME") || status.equals("HT"))
            return choose(language, "HALF-TIME", "POLUVRIJEME", "HALBZEIT", "DESCANSO", "MI-TEMPS");
        if (status.equals("EXTRA_TIME"))
            return choose(language, "EXTRA TIME", "PRODUŽECI", "VERLÄNGERUNG", "PRÓRROGA", "PROLONGATION") + minuteSuffix(minute);
        if (status.equals("PENALTY_SHOOTOUT") || status.equals("PENALTIES"))
            return choose(language, "PENALTIES", "JEDANAESTERCI", "ELFMETERSCHIESSEN", "PENALES", "TIRS AU BUT");
        if (status.contains("POSTPON"))
            return choose(language, "POSTPONED", "ODGOĐENO", "VERSCHOBEN", "APLAZADO", "REPORTÉ");
        if (status.contains("CANCEL"))
            return choose(language, "CANCELLED", "OTKAZANO", "ABGESAGT", "CANCELADO", "ANNULÉ");
        if (status.contains("SUSPEND"))
            return choose(language, "SUSPENDED", "PREKINUTO", "UNTERBROCHEN", "SUSPENDIDO", "SUSPENDU");
        if (live)
            return minute.isEmpty() ? choose(language, "LIVE", "UŽIVO", "LIVE", "EN VIVO", "DIRECT")
                    : choose(language, "LIVE ", "UŽIVO ", "LIVE ", "EN VIVO ", "DIRECT ") + minute + "′";
        if (finished)
            return choose(language, "FULL TIME", "ZAVRŠENO", "BEENDET", "FINALIZADO", "TERMINÉ");
        return "";
    }

    public static String fullDate(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        String value = new SimpleDateFormat("EEEE, d. MMMM • HH:mm", locale).format(date);
        return capitalize(value);
    }

    public static String dayHeading(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        return capitalize(new SimpleDateFormat("EEE, d. MMM", locale).format(date));
    }

    public static String dateChip(Date date, String language) {
        if (date == null) return "";
        Locale locale = TeamLocalizer.localeFor(language);
        String day = new SimpleDateFormat("EEE", locale).format(date).toUpperCase(locale);
        String number = new SimpleDateFormat("d.M.", locale).format(date);
        return day + "\n" + number;
    }

    private static String minuteSuffix(String minute) { return minute.isEmpty() ? "" : " " + minute + "′"; }

    private static String humanize(String raw) {
        String value = raw.replace('_', ' ').replace('-', ' ').trim().toLowerCase(Locale.US);
        if (value.isEmpty()) return "";
        String[] parts = value.split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            if (out.length() > 0) out.append(' ');
            out.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return out.toString();
    }

    private static String capitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1);
    }

    private static String choose(String language, String en, String hr, String de, String es, String fr) {
        if ("HR".equals(language)) return hr;
        if ("DE".equals(language)) return de;
        if ("ES".equals(language)) return es;
        if ("FR".equals(language)) return fr;
        return en;
    }

    private MatchCenterFormatter() {}
}
