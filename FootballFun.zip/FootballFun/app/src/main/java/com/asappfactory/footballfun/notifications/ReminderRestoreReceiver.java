package com.asappfactory.footballfun.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores locally saved alarms after restart, app update, clock or timezone changes. */
public final class ReminderRestoreReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                && !Intent.ACTION_TIME_CHANGED.equals(action)
                && !Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            return;
        }
        MatchReminderScheduler.rescheduleStored(context.getApplicationContext());
    }
}
