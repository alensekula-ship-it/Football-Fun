package com.asappfactory.footballfun.notifications;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Restores locally saved alarms after restart, app update, clock or timezone changes. */
public final class ReminderRestoreReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        MatchReminderScheduler.rescheduleStored(context.getApplicationContext());
    }
}
