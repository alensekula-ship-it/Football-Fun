package com.asappfactory.footballfun.domain;

import java.util.Locale;

/** Canonical status rules shared by lists, details, filters and refresh logic. */
public final class MatchStatus {
    public static boolean isLive(String status) {
        String value = normalize(status);
        return value.contains("live") || value.contains("in_progress") ||
                value.contains("in progress") || value.contains("in_play") ||
                value.contains("inplay") || value.contains("in play") ||
                value.equals("paused") || value.equals("half_time") ||
                value.equals("halftime") || value.equals("half time") ||
                value.equals("extra_time") || value.equals("penalty_shootout") ||
                value.equals("1h") || value.equals("2h") || value.equals("ht");
    }

    public static boolean isFinished(String status) {
        String value = normalize(status);
        if (isResultUnavailable(value)) return false;
        return value.contains("finished") || value.equals("ft") ||
                value.contains("final") || value.contains("full") || value.equals("ended") ||
                value.equals("awarded") || value.equals("after_extra_time") || value.equals("after_penalties");
    }

    /**
     * Historical/published fixture whose final score has not been verified.
     * This is deliberately neither FINISHED nor UPCOMING.
     */
    public static boolean isResultUnavailable(String status) {
        String value = normalize(status).replace('-', '_').replace(' ', '_');
        return value.equals("no_result") || value.equals("played_no_score") ||
                value.equals("finished_no_score") || value.equals("result_pending") ||
                value.equals("unconfirmed_result") || value.equals("result_unconfirmed") ||
                value.equals("played");
    }

    public static boolean isUpcoming(String status) {
        String value = normalize(status).replace('-', '_').replace(' ', '_');
        if (isResultUnavailable(value) || isLive(value) || isFinished(value) ||
                value.contains("postpon") || value.contains("cancel") || value.contains("suspend")) return false;
        return value.contains("upcoming") || value.contains("scheduled") ||
                value.contains("timed") || value.contains("not_started") ||
                value.equals("tbd") || value.equals("tba") || value.equals("ns");
    }

    public static String normalize(String status) {
        return status == null ? "" : status.trim().toLowerCase(Locale.US);
    }

    private MatchStatus() {}
}
