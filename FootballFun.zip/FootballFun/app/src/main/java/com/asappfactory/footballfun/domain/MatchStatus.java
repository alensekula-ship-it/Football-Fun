package com.asappfactory.footballfun.domain;

import java.util.Locale;

/** Canonical status rules shared by lists, details, filters and refresh logic. */
public final class MatchStatus {
    public static boolean isLive(String status) {
        String value = normalize(status);
        return value.contains("live") || value.contains("in_progress") ||
                value.contains("in progress") || value.contains("in_play") ||
                value.contains("inplay") || value.contains("in play") ||
                value.equals("paused") || value.equals("half_time") ||
                value.equals("extra_time") || value.equals("penalty_shootout") ||
                value.equals("1h") || value.equals("2h") || value.equals("ht");
    }

    public static boolean isFinished(String status) {
        String value = normalize(status);
        return value.isEmpty() || value.contains("finished") || value.equals("ft") ||
                value.contains("final") || value.contains("full") || value.equals("awarded");
    }

    public static boolean isUpcoming(String status) {
        String value = normalize(status);
        return value.contains("upcoming") || value.contains("scheduled") ||
                value.contains("timed") || value.contains("not_started") ||
                value.contains("not started");
    }

    public static String normalize(String status) {
        return status == null ? "" : status.trim().toLowerCase(Locale.US);
    }

    private MatchStatus() {}
}
