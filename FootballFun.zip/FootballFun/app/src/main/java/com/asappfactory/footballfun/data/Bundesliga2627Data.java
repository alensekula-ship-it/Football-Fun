package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Complete official Bundesliga 2026/27 fixture fallback. */
public final class Bundesliga2627Data {
    private static final String COMPETITION_NAME = "Bundesliga";
    private static final String COMPETITION_CODE = "BL1";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-28";
    private static final String LAST_DATE = "2027-05-22";

    private static final String DATA =
            "2026-08-28|1|FC Bayern München|VfB Stuttgart|Allianz Arena|TIMED\n" +
            "2026-08-30|1|Borussia Dortmund|Hamburger SV|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-08-30|1|RB Leipzig|Borussia Mönchengladbach|Red Bull Arena|SCHEDULED\n" +
            "2026-08-30|1|Sport-Club Freiburg|SV Werder Bremen|Europa-Park Stadion|SCHEDULED\n" +
            "2026-08-30|1|FC Augsburg|FC Schalke 04|WWK ARENA|SCHEDULED\n" +
            "2026-08-30|1|1. FSV Mainz 05|SC Paderborn 07|MEWA ARENA|SCHEDULED\n" +
            "2026-08-30|1|1. FC Union Berlin|Eintracht Frankfurt|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-08-30|1|1. FC Köln|TSG Hoffenheim|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-08-30|1|SV Elversberg|Bayer 04 Leverkusen|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-09-06|2|VfB Stuttgart|1. FC Köln|MHPArena|SCHEDULED\n" +
            "2026-09-06|2|TSG Hoffenheim|Borussia Dortmund|PreZero Arena|SCHEDULED\n" +
            "2026-09-06|2|Bayer 04 Leverkusen|1. FC Union Berlin|BayArena|SCHEDULED\n" +
            "2026-09-06|2|Eintracht Frankfurt|FC Augsburg|Deutsche Bank Park|SCHEDULED\n" +
            "2026-09-06|2|Borussia Mönchengladbach|SV Elversberg|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-09-06|2|Hamburger SV|1. FSV Mainz 05|Volksparkstadion|SCHEDULED\n" +
            "2026-09-06|2|SV Werder Bremen|RB Leipzig|Weserstadion|SCHEDULED\n" +
            "2026-09-06|2|FC Schalke 04|FC Bayern München|VELTINS-Arena|SCHEDULED\n" +
            "2026-09-06|2|SC Paderborn 07|Sport-Club Freiburg|Home Deluxe Arena|SCHEDULED\n" +
            "2026-09-13|3|Borussia Dortmund|SC Paderborn 07|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-09-13|3|RB Leipzig|Hamburger SV|Red Bull Arena|SCHEDULED\n" +
            "2026-09-13|3|TSG Hoffenheim|VfB Stuttgart|PreZero Arena|SCHEDULED\n" +
            "2026-09-13|3|Sport-Club Freiburg|Borussia Mönchengladbach|Europa-Park Stadion|SCHEDULED\n" +
            "2026-09-13|3|FC Augsburg|Bayer 04 Leverkusen|WWK ARENA|SCHEDULED\n" +
            "2026-09-13|3|1. FSV Mainz 05|Eintracht Frankfurt|MEWA ARENA|SCHEDULED\n" +
            "2026-09-13|3|1. FC Union Berlin|FC Schalke 04|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-09-13|3|1. FC Köln|SV Werder Bremen|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-09-13|3|SV Elversberg|FC Bayern München|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-09-20|4|FC Bayern München|1. FC Union Berlin|Allianz Arena|SCHEDULED\n" +
            "2026-09-20|4|VfB Stuttgart|Borussia Dortmund|MHPArena|SCHEDULED\n" +
            "2026-09-20|4|Bayer 04 Leverkusen|RB Leipzig|BayArena|SCHEDULED\n" +
            "2026-09-20|4|Eintracht Frankfurt|Sport-Club Freiburg|Deutsche Bank Park|SCHEDULED\n" +
            "2026-09-20|4|Borussia Mönchengladbach|1. FSV Mainz 05|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-09-20|4|Hamburger SV|1. FC Köln|Volksparkstadion|SCHEDULED\n" +
            "2026-09-20|4|SV Werder Bremen|FC Augsburg|Weserstadion|SCHEDULED\n" +
            "2026-09-20|4|FC Schalke 04|SV Elversberg|VELTINS-Arena|SCHEDULED\n" +
            "2026-09-20|4|SC Paderborn 07|TSG Hoffenheim|Home Deluxe Arena|SCHEDULED\n" +
            "2026-10-11|5|Borussia Dortmund|SV Werder Bremen|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-10-11|5|RB Leipzig|Eintracht Frankfurt|Red Bull Arena|SCHEDULED\n" +
            "2026-10-11|5|TSG Hoffenheim|Hamburger SV|PreZero Arena|SCHEDULED\n" +
            "2026-10-11|5|Sport-Club Freiburg|FC Schalke 04|Europa-Park Stadion|SCHEDULED\n" +
            "2026-10-11|5|FC Augsburg|FC Bayern München|WWK ARENA|SCHEDULED\n" +
            "2026-10-11|5|1. FSV Mainz 05|Bayer 04 Leverkusen|MEWA ARENA|SCHEDULED\n" +
            "2026-10-11|5|1. FC Union Berlin|SV Elversberg|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-10-11|5|1. FC Köln|Borussia Mönchengladbach|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-10-11|5|SC Paderborn 07|VfB Stuttgart|Home Deluxe Arena|SCHEDULED\n" +
            "2026-10-18|6|FC Bayern München|RB Leipzig|Allianz Arena|SCHEDULED\n" +
            "2026-10-18|6|Bayer 04 Leverkusen|Sport-Club Freiburg|BayArena|SCHEDULED\n" +
            "2026-10-18|6|Eintracht Frankfurt|1. FC Köln|Deutsche Bank Park|SCHEDULED\n" +
            "2026-10-18|6|1. FC Union Berlin|Borussia Dortmund|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-10-18|6|Borussia Mönchengladbach|TSG Hoffenheim|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-10-18|6|Hamburger SV|VfB Stuttgart|Volksparkstadion|SCHEDULED\n" +
            "2026-10-18|6|SV Werder Bremen|SC Paderborn 07|Weserstadion|SCHEDULED\n" +
            "2026-10-18|6|FC Schalke 04|1. FSV Mainz 05|VELTINS-Arena|SCHEDULED\n" +
            "2026-10-18|6|SV Elversberg|FC Augsburg|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-10-25|7|Borussia Dortmund|Eintracht Frankfurt|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-10-25|7|RB Leipzig|SV Elversberg|Red Bull Arena|SCHEDULED\n" +
            "2026-10-25|7|VfB Stuttgart|Borussia Mönchengladbach|MHPArena|SCHEDULED\n" +
            "2026-10-25|7|TSG Hoffenheim|Bayer 04 Leverkusen|PreZero Arena|SCHEDULED\n" +
            "2026-10-25|7|Sport-Club Freiburg|FC Bayern München|Europa-Park Stadion|SCHEDULED\n" +
            "2026-10-25|7|FC Augsburg|1. FC Union Berlin|WWK ARENA|SCHEDULED\n" +
            "2026-10-25|7|1. FSV Mainz 05|SV Werder Bremen|MEWA ARENA|SCHEDULED\n" +
            "2026-10-25|7|1. FC Köln|FC Schalke 04|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-10-25|7|SC Paderborn 07|Hamburger SV|Home Deluxe Arena|SCHEDULED\n" +
            "2026-11-01|8|FC Bayern München|Borussia Dortmund|Allianz Arena|SCHEDULED\n" +
            "2026-11-01|8|Bayer 04 Leverkusen|VfB Stuttgart|BayArena|SCHEDULED\n" +
            "2026-11-01|8|Eintracht Frankfurt|Hamburger SV|Deutsche Bank Park|SCHEDULED\n" +
            "2026-11-01|8|FC Augsburg|Sport-Club Freiburg|WWK ARENA|SCHEDULED\n" +
            "2026-11-01|8|1. FC Union Berlin|1. FC Köln|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-11-01|8|Borussia Mönchengladbach|SC Paderborn 07|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-11-01|8|SV Werder Bremen|TSG Hoffenheim|Weserstadion|SCHEDULED\n" +
            "2026-11-01|8|FC Schalke 04|RB Leipzig|VELTINS-Arena|SCHEDULED\n" +
            "2026-11-01|8|SV Elversberg|1. FSV Mainz 05|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-11-08|9|Borussia Dortmund|SV Elversberg|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-11-08|9|RB Leipzig|FC Augsburg|Red Bull Arena|SCHEDULED\n" +
            "2026-11-08|9|VfB Stuttgart|SV Werder Bremen|MHPArena|SCHEDULED\n" +
            "2026-11-08|9|TSG Hoffenheim|FC Schalke 04|PreZero Arena|SCHEDULED\n" +
            "2026-11-08|9|Sport-Club Freiburg|1. FC Union Berlin|Europa-Park Stadion|SCHEDULED\n" +
            "2026-11-08|9|1. FSV Mainz 05|FC Bayern München|MEWA ARENA|SCHEDULED\n" +
            "2026-11-08|9|Hamburger SV|Borussia Mönchengladbach|Volksparkstadion|SCHEDULED\n" +
            "2026-11-08|9|1. FC Köln|Bayer 04 Leverkusen|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-11-08|9|SC Paderborn 07|Eintracht Frankfurt|Home Deluxe Arena|SCHEDULED\n" +
            "2026-11-22|10|FC Bayern München|1. FC Köln|Allianz Arena|SCHEDULED\n" +
            "2026-11-22|10|Bayer 04 Leverkusen|SC Paderborn 07|BayArena|SCHEDULED\n" +
            "2026-11-22|10|Eintracht Frankfurt|TSG Hoffenheim|Deutsche Bank Park|SCHEDULED\n" +
            "2026-11-22|10|FC Augsburg|1. FSV Mainz 05|WWK ARENA|SCHEDULED\n" +
            "2026-11-22|10|1. FC Union Berlin|RB Leipzig|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-11-22|10|Borussia Mönchengladbach|Borussia Dortmund|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-11-22|10|SV Werder Bremen|Hamburger SV|Weserstadion|SCHEDULED\n" +
            "2026-11-22|10|FC Schalke 04|VfB Stuttgart|VELTINS-Arena|SCHEDULED\n" +
            "2026-11-22|10|SV Elversberg|Sport-Club Freiburg|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-11-29|11|Borussia Dortmund|Bayer 04 Leverkusen|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-11-29|11|VfB Stuttgart|Eintracht Frankfurt|MHPArena|SCHEDULED\n" +
            "2026-11-29|11|TSG Hoffenheim|FC Augsburg|PreZero Arena|SCHEDULED\n" +
            "2026-11-29|11|Sport-Club Freiburg|RB Leipzig|Europa-Park Stadion|SCHEDULED\n" +
            "2026-11-29|11|1. FSV Mainz 05|1. FC Union Berlin|MEWA ARENA|SCHEDULED\n" +
            "2026-11-29|11|Hamburger SV|FC Bayern München|Volksparkstadion|SCHEDULED\n" +
            "2026-11-29|11|1. FC Köln|SV Elversberg|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-11-29|11|SV Werder Bremen|Borussia Mönchengladbach|Weserstadion|SCHEDULED\n" +
            "2026-11-29|11|SC Paderborn 07|FC Schalke 04|Home Deluxe Arena|SCHEDULED\n" +
            "2026-12-06|12|FC Bayern München|SC Paderborn 07|Allianz Arena|SCHEDULED\n" +
            "2026-12-06|12|RB Leipzig|1. FSV Mainz 05|Red Bull Arena|SCHEDULED\n" +
            "2026-12-06|12|Bayer 04 Leverkusen|Borussia Mönchengladbach|BayArena|SCHEDULED\n" +
            "2026-12-06|12|Sport-Club Freiburg|TSG Hoffenheim|Europa-Park Stadion|SCHEDULED\n" +
            "2026-12-06|12|Eintracht Frankfurt|SV Werder Bremen|Deutsche Bank Park|SCHEDULED\n" +
            "2026-12-06|12|FC Augsburg|1. FC Köln|WWK ARENA|SCHEDULED\n" +
            "2026-12-06|12|1. FC Union Berlin|Hamburger SV|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-12-06|12|FC Schalke 04|Borussia Dortmund|VELTINS-Arena|SCHEDULED\n" +
            "2026-12-06|12|SV Elversberg|VfB Stuttgart|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2026-12-13|13|Borussia Dortmund|FC Augsburg|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2026-12-13|13|VfB Stuttgart|1. FC Union Berlin|MHPArena|SCHEDULED\n" +
            "2026-12-13|13|TSG Hoffenheim|FC Bayern München|PreZero Arena|SCHEDULED\n" +
            "2026-12-13|13|1. FSV Mainz 05|Sport-Club Freiburg|MEWA ARENA|SCHEDULED\n" +
            "2026-12-13|13|Borussia Mönchengladbach|Eintracht Frankfurt|BORUSSIA-PARK|SCHEDULED\n" +
            "2026-12-13|13|Hamburger SV|FC Schalke 04|Volksparkstadion|SCHEDULED\n" +
            "2026-12-13|13|1. FC Köln|RB Leipzig|RheinEnergieSTADION|SCHEDULED\n" +
            "2026-12-13|13|SV Werder Bremen|Bayer 04 Leverkusen|Weserstadion|SCHEDULED\n" +
            "2026-12-13|13|SC Paderborn 07|SV Elversberg|Home Deluxe Arena|SCHEDULED\n" +
            "2026-12-20|14|FC Bayern München|SV Werder Bremen|Allianz Arena|SCHEDULED\n" +
            "2026-12-20|14|RB Leipzig|Borussia Dortmund|Red Bull Arena|SCHEDULED\n" +
            "2026-12-20|14|Bayer 04 Leverkusen|Eintracht Frankfurt|BayArena|SCHEDULED\n" +
            "2026-12-20|14|Sport-Club Freiburg|VfB Stuttgart|Europa-Park Stadion|SCHEDULED\n" +
            "2026-12-20|14|FC Augsburg|SC Paderborn 07|WWK ARENA|SCHEDULED\n" +
            "2026-12-20|14|1. FSV Mainz 05|1. FC Köln|MEWA ARENA|SCHEDULED\n" +
            "2026-12-20|14|1. FC Union Berlin|TSG Hoffenheim|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2026-12-20|14|FC Schalke 04|Borussia Mönchengladbach|VELTINS-Arena|SCHEDULED\n" +
            "2026-12-20|14|SV Elversberg|Hamburger SV|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-01-10|15|Borussia Dortmund|1. FSV Mainz 05|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-01-10|15|VfB Stuttgart|FC Augsburg|MHPArena|SCHEDULED\n" +
            "2027-01-10|15|TSG Hoffenheim|SV Elversberg|PreZero Arena|SCHEDULED\n" +
            "2027-01-10|15|Eintracht Frankfurt|FC Schalke 04|Deutsche Bank Park|SCHEDULED\n" +
            "2027-01-10|15|Borussia Mönchengladbach|FC Bayern München|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-01-10|15|Hamburger SV|Bayer 04 Leverkusen|Volksparkstadion|SCHEDULED\n" +
            "2027-01-10|15|1. FC Köln|Sport-Club Freiburg|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-01-10|15|SV Werder Bremen|1. FC Union Berlin|Weserstadion|SCHEDULED\n" +
            "2027-01-10|15|SC Paderborn 07|RB Leipzig|Home Deluxe Arena|SCHEDULED\n" +
            "2027-01-14|16|FC Bayern München|Bayer 04 Leverkusen|Allianz Arena|SCHEDULED\n" +
            "2027-01-14|16|RB Leipzig|VfB Stuttgart|Red Bull Arena|SCHEDULED\n" +
            "2027-01-14|16|Sport-Club Freiburg|Hamburger SV|Europa-Park Stadion|SCHEDULED\n" +
            "2027-01-14|16|FC Augsburg|Borussia Mönchengladbach|WWK ARENA|SCHEDULED\n" +
            "2027-01-14|16|1. FSV Mainz 05|TSG Hoffenheim|MEWA ARENA|SCHEDULED\n" +
            "2027-01-14|16|1. FC Union Berlin|SC Paderborn 07|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-01-14|16|1. FC Köln|Borussia Dortmund|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-01-14|16|FC Schalke 04|SV Werder Bremen|VELTINS-Arena|SCHEDULED\n" +
            "2027-01-14|16|SV Elversberg|Eintracht Frankfurt|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-01-17|17|Borussia Dortmund|Sport-Club Freiburg|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-01-17|17|VfB Stuttgart|1. FSV Mainz 05|MHPArena|SCHEDULED\n" +
            "2027-01-17|17|TSG Hoffenheim|RB Leipzig|PreZero Arena|SCHEDULED\n" +
            "2027-01-17|17|Bayer 04 Leverkusen|FC Schalke 04|BayArena|SCHEDULED\n" +
            "2027-01-17|17|Eintracht Frankfurt|FC Bayern München|Deutsche Bank Park|SCHEDULED\n" +
            "2027-01-17|17|Borussia Mönchengladbach|1. FC Union Berlin|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-01-17|17|Hamburger SV|FC Augsburg|Volksparkstadion|SCHEDULED\n" +
            "2027-01-17|17|SV Werder Bremen|SV Elversberg|Weserstadion|SCHEDULED\n" +
            "2027-01-17|17|SC Paderborn 07|1. FC Köln|Home Deluxe Arena|SCHEDULED\n" +
            "2027-01-24|18|VfB Stuttgart|FC Bayern München|MHPArena|SCHEDULED\n" +
            "2027-01-24|18|TSG Hoffenheim|1. FC Köln|PreZero Arena|SCHEDULED\n" +
            "2027-01-24|18|Bayer 04 Leverkusen|SV Elversberg|BayArena|SCHEDULED\n" +
            "2027-01-24|18|Eintracht Frankfurt|1. FC Union Berlin|Deutsche Bank Park|SCHEDULED\n" +
            "2027-01-24|18|Borussia Mönchengladbach|RB Leipzig|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-01-24|18|Hamburger SV|Borussia Dortmund|Volksparkstadion|SCHEDULED\n" +
            "2027-01-24|18|SV Werder Bremen|Sport-Club Freiburg|Weserstadion|SCHEDULED\n" +
            "2027-01-24|18|FC Schalke 04|FC Augsburg|VELTINS-Arena|SCHEDULED\n" +
            "2027-01-24|18|SC Paderborn 07|1. FSV Mainz 05|Home Deluxe Arena|SCHEDULED\n" +
            "2027-01-31|19|FC Bayern München|FC Schalke 04|Allianz Arena|SCHEDULED\n" +
            "2027-01-31|19|Borussia Dortmund|TSG Hoffenheim|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-01-31|19|RB Leipzig|SV Werder Bremen|Red Bull Arena|SCHEDULED\n" +
            "2027-01-31|19|Sport-Club Freiburg|SC Paderborn 07|Europa-Park Stadion|SCHEDULED\n" +
            "2027-01-31|19|FC Augsburg|Eintracht Frankfurt|WWK ARENA|SCHEDULED\n" +
            "2027-01-31|19|1. FSV Mainz 05|Hamburger SV|MEWA ARENA|SCHEDULED\n" +
            "2027-01-31|19|1. FC Union Berlin|Bayer 04 Leverkusen|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-01-31|19|1. FC Köln|VfB Stuttgart|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-01-31|19|SV Elversberg|Borussia Mönchengladbach|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-02-07|20|FC Bayern München|SV Elversberg|Allianz Arena|SCHEDULED\n" +
            "2027-02-07|20|VfB Stuttgart|TSG Hoffenheim|MHPArena|SCHEDULED\n" +
            "2027-02-07|20|Bayer 04 Leverkusen|FC Augsburg|BayArena|SCHEDULED\n" +
            "2027-02-07|20|Eintracht Frankfurt|1. FSV Mainz 05|Deutsche Bank Park|SCHEDULED\n" +
            "2027-02-07|20|Borussia Mönchengladbach|Sport-Club Freiburg|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-02-07|20|Hamburger SV|RB Leipzig|Volksparkstadion|SCHEDULED\n" +
            "2027-02-07|20|SV Werder Bremen|1. FC Köln|Weserstadion|SCHEDULED\n" +
            "2027-02-07|20|FC Schalke 04|1. FC Union Berlin|VELTINS-Arena|SCHEDULED\n" +
            "2027-02-07|20|SC Paderborn 07|Borussia Dortmund|Home Deluxe Arena|SCHEDULED\n" +
            "2027-02-14|21|Borussia Dortmund|VfB Stuttgart|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-02-14|21|RB Leipzig|Bayer 04 Leverkusen|Red Bull Arena|SCHEDULED\n" +
            "2027-02-14|21|TSG Hoffenheim|SC Paderborn 07|PreZero Arena|SCHEDULED\n" +
            "2027-02-14|21|Sport-Club Freiburg|Eintracht Frankfurt|Europa-Park Stadion|SCHEDULED\n" +
            "2027-02-14|21|FC Augsburg|SV Werder Bremen|WWK ARENA|SCHEDULED\n" +
            "2027-02-14|21|1. FSV Mainz 05|Borussia Mönchengladbach|MEWA ARENA|SCHEDULED\n" +
            "2027-02-14|21|1. FC Union Berlin|FC Bayern München|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-02-14|21|1. FC Köln|Hamburger SV|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-02-14|21|SV Elversberg|FC Schalke 04|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-02-21|22|FC Bayern München|FC Augsburg|Allianz Arena|SCHEDULED\n" +
            "2027-02-21|22|VfB Stuttgart|SC Paderborn 07|MHPArena|SCHEDULED\n" +
            "2027-02-21|22|Bayer 04 Leverkusen|1. FSV Mainz 05|BayArena|SCHEDULED\n" +
            "2027-02-21|22|Eintracht Frankfurt|RB Leipzig|Deutsche Bank Park|SCHEDULED\n" +
            "2027-02-21|22|Borussia Mönchengladbach|1. FC Köln|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-02-21|22|Hamburger SV|TSG Hoffenheim|Volksparkstadion|SCHEDULED\n" +
            "2027-02-21|22|SV Werder Bremen|Borussia Dortmund|Weserstadion|SCHEDULED\n" +
            "2027-02-21|22|FC Schalke 04|Sport-Club Freiburg|VELTINS-Arena|SCHEDULED\n" +
            "2027-02-21|22|SV Elversberg|1. FC Union Berlin|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-02-28|23|Borussia Dortmund|1. FC Union Berlin|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-02-28|23|RB Leipzig|FC Bayern München|Red Bull Arena|SCHEDULED\n" +
            "2027-02-28|23|VfB Stuttgart|Hamburger SV|MHPArena|SCHEDULED\n" +
            "2027-02-28|23|TSG Hoffenheim|Borussia Mönchengladbach|PreZero Arena|SCHEDULED\n" +
            "2027-02-28|23|Sport-Club Freiburg|Bayer 04 Leverkusen|Europa-Park Stadion|SCHEDULED\n" +
            "2027-02-28|23|FC Augsburg|SV Elversberg|WWK ARENA|SCHEDULED\n" +
            "2027-02-28|23|1. FSV Mainz 05|FC Schalke 04|MEWA ARENA|SCHEDULED\n" +
            "2027-02-28|23|1. FC Köln|Eintracht Frankfurt|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-02-28|23|SC Paderborn 07|SV Werder Bremen|Home Deluxe Arena|SCHEDULED\n" +
            "2027-03-04|24|FC Bayern München|Sport-Club Freiburg|Allianz Arena|SCHEDULED\n" +
            "2027-03-04|24|Bayer 04 Leverkusen|TSG Hoffenheim|BayArena|SCHEDULED\n" +
            "2027-03-04|24|Eintracht Frankfurt|Borussia Dortmund|Deutsche Bank Park|SCHEDULED\n" +
            "2027-03-04|24|1. FC Union Berlin|FC Augsburg|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-03-04|24|Borussia Mönchengladbach|VfB Stuttgart|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-03-04|24|Hamburger SV|SC Paderborn 07|Volksparkstadion|SCHEDULED\n" +
            "2027-03-04|24|SV Werder Bremen|1. FSV Mainz 05|Weserstadion|SCHEDULED\n" +
            "2027-03-04|24|FC Schalke 04|1. FC Köln|VELTINS-Arena|SCHEDULED\n" +
            "2027-03-04|24|SV Elversberg|RB Leipzig|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-03-07|25|Borussia Dortmund|FC Bayern München|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-03-07|25|RB Leipzig|FC Schalke 04|Red Bull Arena|SCHEDULED\n" +
            "2027-03-07|25|VfB Stuttgart|Bayer 04 Leverkusen|MHPArena|SCHEDULED\n" +
            "2027-03-07|25|TSG Hoffenheim|SV Werder Bremen|PreZero Arena|SCHEDULED\n" +
            "2027-03-07|25|Sport-Club Freiburg|FC Augsburg|Europa-Park Stadion|SCHEDULED\n" +
            "2027-03-07|25|1. FSV Mainz 05|SV Elversberg|MEWA ARENA|SCHEDULED\n" +
            "2027-03-07|25|Hamburger SV|Eintracht Frankfurt|Volksparkstadion|SCHEDULED\n" +
            "2027-03-07|25|1. FC Köln|1. FC Union Berlin|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-03-07|25|SC Paderborn 07|Borussia Mönchengladbach|Home Deluxe Arena|SCHEDULED\n" +
            "2027-03-14|26|FC Bayern München|1. FSV Mainz 05|Allianz Arena|SCHEDULED\n" +
            "2027-03-14|26|Bayer 04 Leverkusen|1. FC Köln|BayArena|SCHEDULED\n" +
            "2027-03-14|26|Eintracht Frankfurt|SC Paderborn 07|Deutsche Bank Park|SCHEDULED\n" +
            "2027-03-14|26|FC Augsburg|RB Leipzig|WWK ARENA|SCHEDULED\n" +
            "2027-03-14|26|1. FC Union Berlin|Sport-Club Freiburg|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-03-14|26|Borussia Mönchengladbach|Hamburger SV|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-03-14|26|SV Werder Bremen|VfB Stuttgart|Weserstadion|SCHEDULED\n" +
            "2027-03-14|26|FC Schalke 04|TSG Hoffenheim|VELTINS-Arena|SCHEDULED\n" +
            "2027-03-14|26|SV Elversberg|Borussia Dortmund|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-03-21|27|Borussia Dortmund|Borussia Mönchengladbach|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-03-21|27|RB Leipzig|1. FC Union Berlin|Red Bull Arena|SCHEDULED\n" +
            "2027-03-21|27|VfB Stuttgart|FC Schalke 04|MHPArena|SCHEDULED\n" +
            "2027-03-21|27|TSG Hoffenheim|Eintracht Frankfurt|PreZero Arena|SCHEDULED\n" +
            "2027-03-21|27|Sport-Club Freiburg|SV Elversberg|Europa-Park Stadion|SCHEDULED\n" +
            "2027-03-21|27|1. FSV Mainz 05|FC Augsburg|MEWA ARENA|SCHEDULED\n" +
            "2027-03-21|27|Hamburger SV|SV Werder Bremen|Volksparkstadion|SCHEDULED\n" +
            "2027-03-21|27|1. FC Köln|FC Bayern München|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-03-21|27|SC Paderborn 07|Bayer 04 Leverkusen|Home Deluxe Arena|SCHEDULED\n" +
            "2027-04-04|28|FC Bayern München|Hamburger SV|Allianz Arena|SCHEDULED\n" +
            "2027-04-04|28|RB Leipzig|Sport-Club Freiburg|Red Bull Arena|SCHEDULED\n" +
            "2027-04-04|28|Bayer 04 Leverkusen|Borussia Dortmund|BayArena|SCHEDULED\n" +
            "2027-04-04|28|Eintracht Frankfurt|VfB Stuttgart|Deutsche Bank Park|SCHEDULED\n" +
            "2027-04-04|28|FC Augsburg|TSG Hoffenheim|WWK ARENA|SCHEDULED\n" +
            "2027-04-04|28|1. FC Union Berlin|1. FSV Mainz 05|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-04-04|28|Borussia Mönchengladbach|SV Werder Bremen|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-04-04|28|FC Schalke 04|SC Paderborn 07|VELTINS-Arena|SCHEDULED\n" +
            "2027-04-04|28|SV Elversberg|1. FC Köln|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-04-11|29|Borussia Dortmund|FC Schalke 04|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-04-11|29|VfB Stuttgart|SV Elversberg|MHPArena|SCHEDULED\n" +
            "2027-04-11|29|TSG Hoffenheim|Sport-Club Freiburg|PreZero Arena|SCHEDULED\n" +
            "2027-04-11|29|1. FSV Mainz 05|RB Leipzig|MEWA ARENA|SCHEDULED\n" +
            "2027-04-11|29|Borussia Mönchengladbach|Bayer 04 Leverkusen|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-04-11|29|Hamburger SV|1. FC Union Berlin|Volksparkstadion|SCHEDULED\n" +
            "2027-04-11|29|1. FC Köln|FC Augsburg|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-04-11|29|SV Werder Bremen|Eintracht Frankfurt|Weserstadion|SCHEDULED\n" +
            "2027-04-11|29|SC Paderborn 07|FC Bayern München|Home Deluxe Arena|SCHEDULED\n" +
            "2027-04-18|30|FC Bayern München|TSG Hoffenheim|Allianz Arena|SCHEDULED\n" +
            "2027-04-18|30|RB Leipzig|1. FC Köln|Red Bull Arena|SCHEDULED\n" +
            "2027-04-18|30|Bayer 04 Leverkusen|SV Werder Bremen|BayArena|SCHEDULED\n" +
            "2027-04-18|30|Sport-Club Freiburg|1. FSV Mainz 05|Europa-Park Stadion|SCHEDULED\n" +
            "2027-04-18|30|Eintracht Frankfurt|Borussia Mönchengladbach|Deutsche Bank Park|SCHEDULED\n" +
            "2027-04-18|30|FC Augsburg|Borussia Dortmund|WWK ARENA|SCHEDULED\n" +
            "2027-04-18|30|1. FC Union Berlin|VfB Stuttgart|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-04-18|30|FC Schalke 04|Hamburger SV|VELTINS-Arena|SCHEDULED\n" +
            "2027-04-18|30|SV Elversberg|SC Paderborn 07|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-04-25|31|Borussia Dortmund|RB Leipzig|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-04-25|31|VfB Stuttgart|Sport-Club Freiburg|MHPArena|SCHEDULED\n" +
            "2027-04-25|31|TSG Hoffenheim|1. FC Union Berlin|PreZero Arena|SCHEDULED\n" +
            "2027-04-25|31|Eintracht Frankfurt|Bayer 04 Leverkusen|Deutsche Bank Park|SCHEDULED\n" +
            "2027-04-25|31|Borussia Mönchengladbach|FC Schalke 04|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-04-25|31|Hamburger SV|SV Elversberg|Volksparkstadion|SCHEDULED\n" +
            "2027-04-25|31|1. FC Köln|1. FSV Mainz 05|RheinEnergieSTADION|SCHEDULED\n" +
            "2027-04-25|31|SV Werder Bremen|FC Bayern München|Weserstadion|SCHEDULED\n" +
            "2027-04-25|31|SC Paderborn 07|FC Augsburg|Home Deluxe Arena|SCHEDULED\n" +
            "2027-05-09|32|FC Bayern München|Borussia Mönchengladbach|Allianz Arena|SCHEDULED\n" +
            "2027-05-09|32|RB Leipzig|SC Paderborn 07|Red Bull Arena|SCHEDULED\n" +
            "2027-05-09|32|Bayer 04 Leverkusen|Hamburger SV|BayArena|SCHEDULED\n" +
            "2027-05-09|32|Sport-Club Freiburg|1. FC Köln|Europa-Park Stadion|SCHEDULED\n" +
            "2027-05-09|32|FC Augsburg|VfB Stuttgart|WWK ARENA|SCHEDULED\n" +
            "2027-05-09|32|1. FSV Mainz 05|Borussia Dortmund|MEWA ARENA|SCHEDULED\n" +
            "2027-05-09|32|1. FC Union Berlin|SV Werder Bremen|Stadion An der Alten Försterei|SCHEDULED\n" +
            "2027-05-09|32|FC Schalke 04|Eintracht Frankfurt|VELTINS-Arena|SCHEDULED\n" +
            "2027-05-09|32|SV Elversberg|TSG Hoffenheim|URSAPHARM-Arena an der Kaiserlinde|SCHEDULED\n" +
            "2027-05-16|33|Borussia Dortmund|1. FC Köln|SIGNAL IDUNA PARK|SCHEDULED\n" +
            "2027-05-16|33|VfB Stuttgart|RB Leipzig|MHPArena|SCHEDULED\n" +
            "2027-05-16|33|TSG Hoffenheim|1. FSV Mainz 05|PreZero Arena|SCHEDULED\n" +
            "2027-05-16|33|Bayer 04 Leverkusen|FC Bayern München|BayArena|SCHEDULED\n" +
            "2027-05-16|33|Eintracht Frankfurt|SV Elversberg|Deutsche Bank Park|SCHEDULED\n" +
            "2027-05-16|33|Borussia Mönchengladbach|FC Augsburg|BORUSSIA-PARK|SCHEDULED\n" +
            "2027-05-16|33|Hamburger SV|Sport-Club Freiburg|Volksparkstadion|SCHEDULED\n" +
            "2027-05-16|33|SV Werder Bremen|FC Schalke 04|Weserstadion|SCHEDULED\n" +
            "2027-05-16|33|SC Paderborn 07|1. FC Union Berlin|Home Deluxe Arena|SCHEDULED\n" +
            "2027-05-22|34|FC Bayern München|Eintracht Frankfurt|Allianz Arena|TIMED\n" +
            "2027-05-22|34|RB Leipzig|TSG Hoffenheim|Red Bull Arena|TIMED\n" +
            "2027-05-22|34|Sport-Club Freiburg|Borussia Dortmund|Europa-Park Stadion|TIMED\n" +
            "2027-05-22|34|FC Augsburg|Hamburger SV|WWK ARENA|TIMED\n" +
            "2027-05-22|34|1. FSV Mainz 05|VfB Stuttgart|MEWA ARENA|TIMED\n" +
            "2027-05-22|34|1. FC Union Berlin|Borussia Mönchengladbach|Stadion An der Alten Försterei|TIMED\n" +
            "2027-05-22|34|1. FC Köln|SC Paderborn 07|RheinEnergieSTADION|TIMED\n" +
            "2027-05-22|34|FC Schalke 04|Bayer 04 Leverkusen|VELTINS-Arena|TIMED\n" +
            "2027-05-22|34|SV Elversberg|SV Werder Bremen|URSAPHARM-Arena an der Kaiserlinde|TIMED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    private static final Map<String, String> VENUES = new LinkedHashMap<String, String>();
    private static final Map<String, Integer> FOUNDED = new LinkedHashMap<String, Integer>();
    private static final Map<String, String> WEBSITES = new LinkedHashMap<String, String>();
    private static final Map<String, String> COLORS = new LinkedHashMap<String, String>();

    static {
        TLA.put("FC Bayern München", "FCB");
        TLA.put("VfB Stuttgart", "VFB");
        TLA.put("Borussia Dortmund", "BVB");
        TLA.put("Hamburger SV", "HSV");
        TLA.put("RB Leipzig", "RBL");
        TLA.put("Borussia Mönchengladbach", "BMG");
        TLA.put("Sport-Club Freiburg", "SCF");
        TLA.put("SV Werder Bremen", "SVW");
        TLA.put("FC Augsburg", "FCA");
        TLA.put("FC Schalke 04", "S04");
        TLA.put("1. FSV Mainz 05", "M05");
        TLA.put("SC Paderborn 07", "SCP");
        TLA.put("1. FC Union Berlin", "FCU");
        TLA.put("Eintracht Frankfurt", "SGE");
        TLA.put("1. FC Köln", "KOE");
        TLA.put("TSG Hoffenheim", "TSG");
        TLA.put("SV Elversberg", "ELV");
        TLA.put("Bayer 04 Leverkusen", "B04");
        CRESTS.put("FC Bayern München", "https://crests.football-data.org/5.png");
        CRESTS.put("VfB Stuttgart", "https://crests.football-data.org/10.png");
        CRESTS.put("Borussia Dortmund", "https://crests.football-data.org/4.png");
        CRESTS.put("Hamburger SV", "https://crests.football-data.org/7.png");
        CRESTS.put("RB Leipzig", "https://crests.football-data.org/721.png");
        CRESTS.put("Borussia Mönchengladbach", "https://crests.football-data.org/18.png");
        CRESTS.put("Sport-Club Freiburg", "https://crests.football-data.org/17.png");
        CRESTS.put("SV Werder Bremen", "https://crests.football-data.org/12.png");
        CRESTS.put("FC Augsburg", "https://crests.football-data.org/16.png");
        CRESTS.put("FC Schalke 04", "https://crests.football-data.org/6.png");
        CRESTS.put("1. FSV Mainz 05", "https://crests.football-data.org/15.png");
        CRESTS.put("SC Paderborn 07", "https://crests.football-data.org/29.png");
        CRESTS.put("1. FC Union Berlin", "https://crests.football-data.org/28.png");
        CRESTS.put("Eintracht Frankfurt", "https://crests.football-data.org/19.png");
        CRESTS.put("1. FC Köln", "https://crests.football-data.org/1.png");
        CRESTS.put("TSG Hoffenheim", "https://crests.football-data.org/2.png");
        CRESTS.put("SV Elversberg", "https://crests.football-data.org/932.png");
        CRESTS.put("Bayer 04 Leverkusen", "https://crests.football-data.org/3.png");

        VENUES.put("FC Bayern München", "Allianz Arena");
        VENUES.put("VfB Stuttgart", "MHPArena");
        VENUES.put("Borussia Dortmund", "SIGNAL IDUNA PARK");
        VENUES.put("Hamburger SV", "Volksparkstadion");
        VENUES.put("RB Leipzig", "Red Bull Arena");
        VENUES.put("Borussia Mönchengladbach", "BORUSSIA-PARK");
        VENUES.put("Sport-Club Freiburg", "Europa-Park Stadion");
        VENUES.put("SV Werder Bremen", "Weserstadion");
        VENUES.put("FC Augsburg", "WWK ARENA");
        VENUES.put("FC Schalke 04", "VELTINS-Arena");
        VENUES.put("1. FSV Mainz 05", "MEWA ARENA");
        VENUES.put("SC Paderborn 07", "Home Deluxe Arena");
        VENUES.put("1. FC Union Berlin", "Stadion An der Alten Försterei");
        VENUES.put("Eintracht Frankfurt", "Deutsche Bank Park");
        VENUES.put("1. FC Köln", "RheinEnergieSTADION");
        VENUES.put("TSG Hoffenheim", "PreZero Arena");
        VENUES.put("SV Elversberg", "URSAPHARM-Arena an der Kaiserlinde");
        VENUES.put("Bayer 04 Leverkusen", "BayArena");

        FOUNDED.put("FC Bayern München", 1900); FOUNDED.put("VfB Stuttgart", 1893);
        FOUNDED.put("Borussia Dortmund", 1909); FOUNDED.put("Hamburger SV", 1887);
        FOUNDED.put("RB Leipzig", 2009); FOUNDED.put("Borussia Mönchengladbach", 1900);
        FOUNDED.put("Sport-Club Freiburg", 1904); FOUNDED.put("SV Werder Bremen", 1899);
        FOUNDED.put("FC Augsburg", 1907); FOUNDED.put("FC Schalke 04", 1904);
        FOUNDED.put("1. FSV Mainz 05", 1905); FOUNDED.put("SC Paderborn 07", 1907);
        FOUNDED.put("1. FC Union Berlin", 1966); FOUNDED.put("Eintracht Frankfurt", 1899);
        FOUNDED.put("1. FC Köln", 1948); FOUNDED.put("TSG Hoffenheim", 1899);
        FOUNDED.put("SV Elversberg", 1907); FOUNDED.put("Bayer 04 Leverkusen", 1904);

        WEBSITES.put("FC Bayern München", "https://fcbayern.com");
        WEBSITES.put("VfB Stuttgart", "https://www.vfb.de");
        WEBSITES.put("Borussia Dortmund", "https://www.bvb.de");
        WEBSITES.put("Hamburger SV", "https://www.hsv.de");
        WEBSITES.put("RB Leipzig", "https://rbleipzig.com");
        WEBSITES.put("Borussia Mönchengladbach", "https://www.borussia.de");
        WEBSITES.put("Sport-Club Freiburg", "https://www.scfreiburg.com");
        WEBSITES.put("SV Werder Bremen", "https://www.werder.de");
        WEBSITES.put("FC Augsburg", "https://www.fcaugsburg.de");
        WEBSITES.put("FC Schalke 04", "https://schalke04.de");
        WEBSITES.put("1. FSV Mainz 05", "https://www.mainz05.de");
        WEBSITES.put("SC Paderborn 07", "https://www.scp07.de");
        WEBSITES.put("1. FC Union Berlin", "https://www.fc-union-berlin.de");
        WEBSITES.put("Eintracht Frankfurt", "https://www.eintracht.de");
        WEBSITES.put("1. FC Köln", "https://fc.de");
        WEBSITES.put("TSG Hoffenheim", "https://www.tsg-hoffenheim.de");
        WEBSITES.put("SV Elversberg", "https://sv07elversberg.de");
        WEBSITES.put("Bayer 04 Leverkusen", "https://www.bayer04.de");

        COLORS.put("FC Bayern München", "Red / White"); COLORS.put("VfB Stuttgart", "White / Red");
        COLORS.put("Borussia Dortmund", "Black / Yellow"); COLORS.put("Hamburger SV", "Blue / White / Black");
        COLORS.put("RB Leipzig", "White / Red"); COLORS.put("Borussia Mönchengladbach", "Black / White / Green");
        COLORS.put("Sport-Club Freiburg", "Red / White"); COLORS.put("SV Werder Bremen", "Green / White");
        COLORS.put("FC Augsburg", "Red / Green / White"); COLORS.put("FC Schalke 04", "Blue / White");
        COLORS.put("1. FSV Mainz 05", "Red / White"); COLORS.put("SC Paderborn 07", "Blue / Black");
        COLORS.put("1. FC Union Berlin", "Red / White"); COLORS.put("Eintracht Frankfurt", "Red / Black / White");
        COLORS.put("1. FC Köln", "Red / White"); COLORS.put("TSG Hoffenheim", "Blue / White");
        COLORS.put("SV Elversberg", "Black / White"); COLORS.put("Bayer 04 Leverkusen", "Red / Black");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutBundesliga(root.optJSONArray("matches")));
            root.put("live", copyWithoutBundesliga(root.optJSONArray("live")));
            root.put("finished", copyWithoutBundesliga(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutBundesliga(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");

            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // Keep every other competition usable if this bundled fallback is
            // malformed by a future manual edit.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonBundesliga(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "BL1-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "TIMED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "DFL official Bundesliga fixture calendar");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Bundesliga source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"name", "shortName", "tla", "crest", "emblem", "logo", "area", "venue"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            String value = String.valueOf(richer.opt(key)).trim();
            if (value.length() > 0) out.put(key, richer.opt(key));
        }
        String name = out.optString("name", out.optString("shortName", ""));
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(name)) out.put("crest", CRESTS.get(name));
        return out;
    }

    private static JSONArray copyWithoutBundesliga(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isBundesliga(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonBundesliga(JSONObject row) {
        if (!isBundesliga(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isBundesliga(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        StringBuilder value = new StringBuilder();
        if (raw instanceof JSONObject) {
            JSONObject competition = (JSONObject) raw;
            value.append(competition.optString("code", "")).append(' ')
                    .append(competition.optString("name", ""));
        } else if (raw != null) value.append(String.valueOf(raw));
        value.append(' ').append(row.optString("competitionCode", ""))
                .append(' ').append(row.optString("competitionName", ""));
        String normalized = normalize(value.toString());
        return normalized.equals("bl1") || normalized.contains("bundesliga");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true);
        String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0;
        String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30;
        else if (isLive(status)) score += 25;
        else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2;
        if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") ||
                value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject();
        competition.put("code", COMPETITION_CODE);
        competition.put("name", COMPETITION_NAME);
        return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject();
        team.put("name", name);
        team.put("shortName", name);
        team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        team.put("area", "Germany");
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        if (VENUES.containsKey(name)) team.put("venue", VENUES.get(name));
        if (FOUNDED.containsKey(name)) team.put("founded", FOUNDED.get(name));
        if (WEBSITES.containsKey(name)) team.put("website", WEBSITES.get(name));
        if (COLORS.containsKey(name)) team.put("clubColors", COLORS.get(name));
        return team;
    }


    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = source == null ? new JSONArray() : new JSONArray(source.toString());
        Map<String, Integer> positions = new HashMap<String, Integer>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (name.length() > 0) positions.put(clubKey(name), i);
        }
        for (String name : TLA.keySet()) {
            JSONObject fallback = teamObject(name);
            Integer position = positions.get(clubKey(name));
            if (position == null) teams.put(fallback);
            else {
                JSONObject richer = teams.optJSONObject(position);
                teams.put(position, mergeTeam(fallback, richer == null ? new JSONObject() : richer));
            }
        }
        root.put("teams", teams);
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE);
        if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        boolean current = start.startsWith("2026") && end.startsWith("2027");
        if (!current) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources");
        if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject bundesliga = sources.optJSONObject(COMPETITION_CODE);
        if (bundesliga == null) bundesliga = new JSONObject();
        bundesliga.put("status", "connected");
        bundesliga.put("provider", "DFL official fixture calendar + connected live source");
        bundesliga.put("season", SEASON);
        bundesliga.put("matchCount", matchCount);
        bundesliga.put("teamCount", TLA.size());
        bundesliga.put("roundCount", 34);
        sources.put(COMPETITION_CODE, bundesliga);
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.equals("bayernmunich") || key.equals("fcbayernmunich") || key.equals("fcbayernmuenchen")) return "fcbayernmunchen";
        if (key.equals("borussiadortmund") || key.equals("bvb09")) return "borussiadortmund";
        if (key.equals("borussiamonchengladbach") || key.equals("borussiamoenchengladbach") || key.equals("gladbach")) return "borussiamonchengladbach";
        if (key.equals("werderbremen")) return "svwerderbremen";
        if (key.equals("freiburg") || key.equals("scfreiburg")) return "sportclubfreiburg";
        if (key.equals("hoffenheim")) return "tsghoffenheim";
        if (key.equals("unionberlin")) return "1fcunionberlin";
        if (key.equals("cologne") || key.equals("fckoln") || key.equals("1fckoeln")) return "1fckoln";
        if (key.equals("mainz05") || key.equals("fsmainz05")) return "1fsvmainz05";
        if (key.equals("schalke04") || key.equals("fcschalke")) return "fcschalke04";
        if (key.equals("paderborn") || key.equals("scpaderborn")) return "scpaderborn07";
        if (key.equals("elversberg")) return "svelversberg";
        if (key.endsWith("footballclub")) key = key.substring(0, key.length() - "footballclub".length());
        else if (key.endsWith("fc")) key = key.substring(0, key.length() - 2);
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private Bundesliga2627Data() {}
}
