package com.asappfactory.footballfun.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.asappfactory.footballfun.model.Match;
import com.asappfactory.footballfun.model.TeamRow;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class WorldCupData {
    public interface MatchRules {
        boolean isFinished(Match match);
        Match nextForTeam(String team);
    }
        public String[] groups={"A","B","C","D","E","F","G","H","I","J","K","L"};public ArrayList<String> teams=new ArrayList<>();public java.util.concurrent.CopyOnWriteArrayList<Match> matches=new java.util.concurrent.CopyOnWriteArrayList<>();private SharedPreferences sp;
        private File centralCacheFile;
        private final MatchRules rules;
        public WorldCupData(Context c, MatchRules rules){
            this.rules = rules;
            sp=c.getSharedPreferences("scores",0);
            centralCacheFile=new File(c.getFilesDir(),"footballfun-central-cache-v1.json");
            seed();
            load();
        }
        public void seed(){
            String[][] g={{"Mexico","South Africa","Korea Republic","Czechia"},{"Canada","Bosnia and Herzegovina","Qatar","Switzerland"},{"Brazil","Morocco","Haiti","Scotland"},{"USA","Paraguay","Australia","Turkey"},{"Germany","Curacao","Ivory Coast","Ecuador"},{"Netherlands","Japan","Sweden","Tunisia"},{"Belgium","Egypt","Iran","New Zealand"},{"Spain","Cape Verde","Saudi Arabia","Uruguay"},{"France","Senegal","Iraq","Norway"},{"Argentina","Algeria","Austria","Jordan"},{"Portugal","DR Congo","Uzbekistan","Colombia"},{"England","Croatia","Ghana","Panama"}};
            for(String[] row:g)for(String t:row)teams.add(t);
            // Official match schedule entered from the Google/FIFA schedule screenshots supplied by the user.
            matches.add(new Match("A","Mexico","South Africa","2026-06-11","Group stage"));
            matches.add(new Match("A","Korea Republic","Czechia","2026-06-13","Group stage"));
            matches.add(new Match("B","Canada","Bosnia and Herzegovina","2026-06-13","Group stage"));
            matches.add(new Match("D","USA","Paraguay","2026-06-14","Group stage"));
            matches.add(new Match("B","Qatar","Switzerland","2026-06-14 21:00","Group stage"));
            matches.add(new Match("C","Brazil","Morocco","2026-06-15 00:00","Group stage"));
            matches.add(new Match("C","Haiti","Scotland","2026-06-15 03:00","Group stage"));
            matches.add(new Match("D","Australia","Turkey","2026-06-15 06:00","Group stage"));
            matches.add(new Match("E","Germany","Curacao","2026-06-15 19:00","Group stage"));
            matches.add(new Match("F","Netherlands","Japan","2026-06-15 22:00","Group stage"));
            matches.add(new Match("E","Ivory Coast","Ecuador","2026-06-15 01:00","Group stage"));
            matches.add(new Match("F","Sweden","Tunisia","2026-06-15 04:00","Group stage"));
            matches.add(new Match("H","Spain","Cape Verde","2026-06-15 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Egypt","2026-06-15 21:00","Group stage"));
            matches.add(new Match("H","Saudi Arabia","Uruguay","2026-06-16 00:00","Group stage"));
            matches.add(new Match("G","Iran","New Zealand","2026-06-16 03:00","Group stage"));
            matches.add(new Match("I","France","Senegal","2026-06-16 21:00","Group stage"));
            matches.add(new Match("I","Iraq","Norway","2026-06-17 00:00","Group stage"));
            matches.add(new Match("J","Argentina","Algeria","2026-06-17 03:00","Group stage"));
            matches.add(new Match("J","Austria","Jordan","2026-06-17 06:00","Group stage"));
            matches.add(new Match("K","Portugal","DR Congo","2026-06-17 19:00","Group stage"));
            matches.add(new Match("L","England","Croatia","2026-06-17 22:00","Group stage"));
            matches.add(new Match("L","Ghana","Panama","2026-06-18 01:00","Group stage"));
            matches.add(new Match("K","Uzbekistan","Colombia","2026-06-18 04:00","Group stage"));
            matches.add(new Match("A","Czechia","South Africa","2026-06-18 18:00","Group stage"));
            matches.add(new Match("B","Switzerland","Bosnia and Herzegovina","2026-06-18 21:00","Group stage"));
            matches.add(new Match("B","Canada","Qatar","2026-06-19 00:00","Group stage"));
            matches.add(new Match("A","Mexico","Korea Republic","2026-06-19 03:00","Group stage"));
            matches.add(new Match("D","USA","Australia","2026-06-19 21:00","Group stage"));
            matches.add(new Match("C","Scotland","Morocco","2026-06-20 00:00","Group stage"));
            matches.add(new Match("C","Brazil","Haiti","2026-06-20 02:30","Group stage"));
            matches.add(new Match("D","Turkey","Paraguay","2026-06-20 05:00","Group stage"));
            matches.add(new Match("F","Netherlands","Sweden","2026-06-20 19:00","Group stage"));
            matches.add(new Match("E","Germany","Ivory Coast","2026-06-20 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Curacao","2026-06-21 02:00","Group stage"));
            matches.add(new Match("F","Tunisia","Japan","2026-06-21 06:00","Group stage"));
            matches.add(new Match("H","Spain","Saudi Arabia","2026-06-21 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Iran","2026-06-21 21:00","Group stage"));
            matches.add(new Match("H","Uruguay","Cape Verde","2026-06-22 00:00","Group stage"));
            matches.add(new Match("G","New Zealand","Egypt","2026-06-22 03:00","Group stage"));
            matches.add(new Match("J","Argentina","Austria","2026-06-22 19:00","Group stage"));
            matches.add(new Match("I","France","Iraq","2026-06-22 23:00","Group stage"));
            matches.add(new Match("I","Norway","Senegal","2026-06-23 02:00","Group stage"));
            matches.add(new Match("J","Jordan","Algeria","2026-06-23 05:00","Group stage"));
            matches.add(new Match("K","Portugal","Uzbekistan","2026-06-23 19:00","Group stage"));
            matches.add(new Match("L","England","Ghana","2026-06-23 22:00","Group stage"));
            matches.add(new Match("L","Panama","Croatia","2026-06-24 01:00","Group stage"));
            matches.add(new Match("K","Colombia","DR Congo","2026-06-24 04:00","Group stage"));
            matches.add(new Match("B","Switzerland","Canada","2026-06-24 21:00","Group stage"));
            matches.add(new Match("B","Bosnia and Herzegovina","Qatar","2026-06-24 21:00","Group stage"));
            matches.add(new Match("C","Morocco","Haiti","2026-06-25 00:00","Group stage"));
            matches.add(new Match("C","Scotland","Brazil","2026-06-25 00:00","Group stage"));
            matches.add(new Match("A","South Africa","Korea Republic","2026-06-25 03:00","Group stage"));
            matches.add(new Match("A","Czechia","Mexico","2026-06-25 03:00","Group stage"));
            matches.add(new Match("E","Curacao","Ivory Coast","2026-06-25 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Germany","2026-06-25 22:00","Group stage"));
            matches.add(new Match("F","Tunisia","Netherlands","2026-06-26 01:00","Group stage"));
            matches.add(new Match("F","Japan","Sweden","2026-06-26 01:00","Group stage"));
            matches.add(new Match("D","Turkey","USA","2026-06-26 04:00","Group stage"));
            matches.add(new Match("D","Paraguay","Australia","2026-06-26 04:00","Group stage"));
            matches.add(new Match("I","Norway","France","2026-06-26 21:00","Group stage"));
            matches.add(new Match("I","Senegal","Iraq","2026-06-26 21:00","Group stage"));
            matches.add(new Match("H","Cape Verde","Saudi Arabia","2026-06-27 02:00","Group stage"));
            matches.add(new Match("H","Uruguay","Spain","2026-06-27 02:00","Group stage"));
            matches.add(new Match("G","New Zealand","Belgium","2026-06-27 05:00","Group stage"));
            matches.add(new Match("G","Egypt","Iran","2026-06-27 05:00","Group stage"));
            matches.add(new Match("L","Panama","England","2026-06-27 23:00","Group stage"));
            matches.add(new Match("L","Croatia","Ghana","2026-06-27 23:00","Group stage"));
            matches.add(new Match("K","Colombia","Portugal","2026-06-28 01:30","Group stage"));
            matches.add(new Match("K","DR Congo","Uzbekistan","2026-06-28 01:30","Group stage"));
            matches.add(new Match("J","Algeria","Austria","2026-06-28 04:00","Group stage"));
            matches.add(new Match("J","Jordan","Argentina","2026-06-28 04:00","Group stage"));
            Collections.sort(teams);
        }

        /**
         * Returns true only when a complete persisted central model could be restored.
         * This method deliberately restores the cache as part of the check because the
         * startup fast-path in MainActivity immediately uses data.matches afterwards.
         */
        public synchronized boolean hasCentralCache(){
            if(centralCacheFile==null||!centralCacheFile.isFile()||centralCacheFile.length()<8)return false;
            try{
                byte[] raw;
                try(FileInputStream in=new FileInputStream(centralCacheFile);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                    byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);raw=out.toByteArray();
                }
                JSONObject root=new JSONObject(new String(raw,StandardCharsets.UTF_8));
                JSONArray arr=root.optJSONArray("matches");
                if(arr==null||arr.length()==0)return false;
                ArrayList<Match> restored=new ArrayList<>();
                LinkedHashSet<String> restoredTeams=new LinkedHashSet<>();
                for(int i=0;i<arr.length();i++){
                    JSONObject o=arr.optJSONObject(i);if(o==null)continue;
                    String home=o.optString("home","");String away=o.optString("away","");String date=o.optString("date","");
                    if(home.isEmpty()||away.isEmpty()||date.isEmpty())continue;
                    Match m=new Match(o.optString("group",""),home,away,date,o.optString("venue",""));
                    m.status=o.optString("status","");m.minute=o.optString("minute","");m.competition=o.optString("competition","");
                    m.actualVenue=o.optString("actualVenue","");m.eventsText=o.optString("eventsText","");m.statsText=o.optString("statsText","");
                    m.homeLineupText=o.optString("homeLineupText","");m.awayLineupText=o.optString("awayLineupText","");
                    m.homeFormation=o.optString("homeFormation","");m.awayFormation=o.optString("awayFormation","");
                    m.refereeText=o.optString("refereeText","");m.halfTimeScore=o.optString("halfTimeScore","");
                    m.extraTimeScore=o.optString("extraTimeScore","");m.penaltyScore=o.optString("penaltyScore","");m.roundName=o.optString("roundName","");
                    m.matchday=o.optInt("matchday",0);m.homeGoals=o.optInt("homeGoals",-1);m.awayGoals=o.optInt("awayGoals",-1);
                    m.apiId=o.optInt("apiId",-1);m.attendance=o.optInt("attendance",-1);m.detailsAvailable=o.optBoolean("detailsAvailable",false);
                    restored.add(m);restoredTeams.add(home);restoredTeams.add(away);
                }
                if(restored.isEmpty())return false;
                matches.clear();matches.addAll(restored);teams.clear();teams.addAll(restoredTeams);Collections.sort(teams);
                return true;
            }catch(Exception ignored){return false;}
        }

        /** Persist the already-normalized central model atomically for fast startup. */
        public synchronized void saveCentralCache(){
            if(centralCacheFile==null||matches==null||matches.isEmpty())return;
            File tmp=new File(centralCacheFile.getParentFile(),centralCacheFile.getName()+".tmp");
            try{
                JSONArray arr=new JSONArray();
                for(Match m:matches){
                    if(m==null)continue;JSONObject o=new JSONObject();
                    o.put("group",nz(m.group));o.put("home",nz(m.home));o.put("away",nz(m.away));o.put("date",nz(m.date));o.put("venue",nz(m.venue));
                    o.put("status",nz(m.status));o.put("minute",nz(m.minute));o.put("competition",nz(m.competition));o.put("actualVenue",nz(m.actualVenue));
                    o.put("eventsText",nz(m.eventsText));o.put("statsText",nz(m.statsText));o.put("homeLineupText",nz(m.homeLineupText));o.put("awayLineupText",nz(m.awayLineupText));
                    o.put("homeFormation",nz(m.homeFormation));o.put("awayFormation",nz(m.awayFormation));o.put("refereeText",nz(m.refereeText));
                    o.put("halfTimeScore",nz(m.halfTimeScore));o.put("extraTimeScore",nz(m.extraTimeScore));o.put("penaltyScore",nz(m.penaltyScore));o.put("roundName",nz(m.roundName));
                    o.put("matchday",m.matchday);o.put("homeGoals",m.homeGoals);o.put("awayGoals",m.awayGoals);o.put("apiId",m.apiId);o.put("attendance",m.attendance);o.put("detailsAvailable",m.detailsAvailable);
                    arr.put(o);
                }
                JSONObject root=new JSONObject();root.put("version",1);root.put("matches",arr);
                byte[] bytes=root.toString().getBytes(StandardCharsets.UTF_8);
                try(FileOutputStream out=new FileOutputStream(tmp)){out.write(bytes);out.flush();try{out.getFD().sync();}catch(Exception ignored){}}
                if(centralCacheFile.exists()&&!centralCacheFile.delete())throw new java.io.IOException("cache replace failed");
                if(!tmp.renameTo(centralCacheFile))throw new java.io.IOException("cache rename failed");
            }catch(Exception ignored){if(tmp.exists())tmp.delete();}
        }

        private String nz(String value){return value==null?"":value;}

        public void load(){
            for(Match match:matches){
                String key=stableScoreKey(match);
                int home=sp.getInt(key+"|h",-1);
                int away=sp.getInt(key+"|a",-1);
                if(home>=0&&away>=0){match.homeGoals=home;match.awayGoals=away;}
                else{match.homeGoals=-1;match.awayGoals=-1;}
            }
        }
        public void save(){
            SharedPreferences.Editor e=sp.edit();
            // Legacy h0/a0 index keys were unsafe once the central match list began
            // containing every competition. Never write or read them again.
            for(Match match:matches){
                String key=stableScoreKey(match);
                if(match.homeGoals>=0&&match.awayGoals>=0){
                    e.putInt(key+"|h",match.homeGoals);
                    e.putInt(key+"|a",match.awayGoals);
                }else{
                    e.remove(key+"|h");
                    e.remove(key+"|a");
                }
            }
            e.apply();
        }
        private String stableScoreKey(Match match){
            if(match==null)return "score-v2|null";
            return "score-v2|"+scorePart(match.competition)+"|"+scorePart(match.group)+"|"+
                    scorePart(match.home)+"|"+scorePart(match.away)+"|"+scorePart(match.date)+"|"+match.matchday;
        }
        private String scorePart(String raw){
            if(raw==null)return "";
            return java.text.Normalizer.normalize(raw.trim().toLowerCase(Locale.US),java.text.Normalizer.Form.NFD)
                    .replaceAll("\\p{M}+","").replaceAll("[^a-z0-9]","");
        }
        public void reset(){sp.edit().clear().apply();for(Match m:matches){m.homeGoals=-1;m.awayGoals=-1;}}
        public Map<String,List<TeamRow>> standings(){Map<String,List<TeamRow>> out=new LinkedHashMap<>();for(String gr:groups){Map<String,TeamRow> m=new LinkedHashMap<>();for(Match ma:matches)if(ma.group.equals(gr)){if(!m.containsKey(ma.home))m.put(ma.home,new TeamRow(gr,ma.home));if(!m.containsKey(ma.away))m.put(ma.away,new TeamRow(gr,ma.away));if(rules.isFinished(ma)){TeamRow h=m.get(ma.home),a=m.get(ma.away);h.p++;a.p++;h.gf+=ma.homeGoals;h.ga+=ma.awayGoals;a.gf+=ma.awayGoals;a.ga+=ma.homeGoals;if(ma.homeGoals>ma.awayGoals){h.w++;h.pts+=3;a.l++;}else if(ma.homeGoals<ma.awayGoals){a.w++;a.pts+=3;h.l++;}else{h.d++;a.d++;h.pts++;a.pts++;}}}ArrayList<TeamRow> list=new ArrayList<>(m.values());Collections.sort(list,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));out.put(gr,list);}return out;}
        public List<TeamRow> bestThirds(){ArrayList<TeamRow> third=new ArrayList<>();for(List<TeamRow> l:standings().values())if(l.size()>2)third.add(l.get(2));Collections.sort(third,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));return third;}
        public List<TeamRow> qualified(){ArrayList<TeamRow> q=new ArrayList<>();for(List<TeamRow> l:standings().values()){if(l.size()>0)q.add(l.get(0));if(l.size()>1)q.add(l.get(1));}List<TeamRow> th=bestThirds();for(int i=0;i<Math.min(8,th.size());i++)q.add(th.get(i));return q;}
        public int playedCount(){int c=0;for(Match m:matches)if(rules.isFinished(m))c++;return c;}public int totalGoals(){int g=0;for(Match m:matches)if(rules.isFinished(m))g+=m.homeGoals+m.awayGoals;return g;}public String avgGoals(){return playedCount()==0?"0.00":String.format(Locale.US,"%.2f",totalGoals()*1.0/playedCount());}public int progressPercent(){return(int)Math.round(playedCount()*100.0/matches.size());}public String bestAttack(){Map<String,Integer> gf=new HashMap<>();for(Match m:matches)if(rules.isFinished(m)){gf.put(m.home,(gf.containsKey(m.home)?gf.get(m.home):0)+m.homeGoals);gf.put(m.away,(gf.containsKey(m.away)?gf.get(m.away):0)+m.awayGoals);}String best="TBD";int max=-1;for(String t:gf.keySet())if(gf.get(t)>max){max=gf.get(t);best=t;}return best+" ("+Math.max(0,max)+")";}public String bestGroup(){Map<String,Integer> goals=new HashMap<>();for(Match m:matches)if(rules.isFinished(m))goals.put(m.group,(goals.containsKey(m.group)?goals.get(m.group):0)+m.homeGoals+m.awayGoals);String best="TBD";int max=-1;for(String g:goals.keySet())if(goals.get(g)>max){max=goals.get(g);best=g;}return best+" ("+Math.max(0,max)+" goals)";}public Match nextFor(String team){return rules.nextForTeam(team);}
    }
