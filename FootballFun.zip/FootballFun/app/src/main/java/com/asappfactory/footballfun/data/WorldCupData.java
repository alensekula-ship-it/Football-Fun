package com.asappfactory.footballfun.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.asappfactory.footballfun.model.Match;
import com.asappfactory.footballfun.model.TeamRow;

import java.util.*;

public final class WorldCupData {
    public interface MatchRules {
        boolean isFinished(Match match);
        Match nextForTeam(String team);
    }
        public String[] groups={"A","B","C","D","E","F","G","H","I","J","K","L"};public ArrayList<String> teams=new ArrayList<>();public ArrayList<Match> matches=new ArrayList<>();private SharedPreferences sp;
        private final MatchRules rules;
        public WorldCupData(Context c, MatchRules rules){
            this.rules = rules;
            sp=c.getSharedPreferences("scores",0);
            seed();
            load();
        }
        public void seed(){
            String[][] g={{"Mexico","South Africa","Korea Republic","Czechia"},{"Canada","Bosnia and Herzegovina","Qatar","Switzerland"},{"Brazil","Morocco","Haiti","Scotland"},{"USA","Paraguay","Australia","Turkey"},{"Germany","Curacao","Ivory Coast","Ecuador"},{"Netherlands","Japan","Sweden","Tunisia"},{"Belgium","Egypt","Iran","New Zealand"},{"Spain","Cape Verde","Saudi Arabia","Uruguay"},{"France","Senegal","Iraq","Norway"},{"Argentina","Algeria","Austria","Jordan"},{"Portugal","DR Congo","Uzbekistan","Colombia"},{"England","Croatia","Ghana","Panama"}};
            for(String[] row:g)for(String t:row)teams.add(t);
            // Official match schedule entered from the Google/FIFA schedule screenshots supplied by the user.
            matches.add(new Match("A","Mexico","South Africa","2026-06-11","Group stage"));
            matches.add(new Match("A","Korea Republic","Czechia","2026-06-13","Group stage"));
            matches.add(new Match("B","Canada","Bosnia and Herzegovina","2026-06-13","Group stage"));
            matches.add(new Match("D","USA","Paraguay","2026-06-14","Group stage"));
            matches.add(new Match("B","Qatar","Switzerland","2026-06-14 21:00","Group stage"));
            matches.add(new Match("C","Brazil","Morocco","2026-06-15 00:00","Group stage"));
            matches.add(new Match("C","Haiti","Scotland","2026-06-15 03:00","Group stage"));
            matches.add(new Match("D","Australia","Turkey","2026-06-15 06:00","Group stage"));
            matches.add(new Match("E","Germany","Curacao","2026-06-15 19:00","Group stage"));
            matches.add(new Match("F","Netherlands","Japan","2026-06-15 22:00","Group stage"));
            matches.add(new Match("E","Ivory Coast","Ecuador","2026-06-15 01:00","Group stage"));
            matches.add(new Match("F","Sweden","Tunisia","2026-06-15 04:00","Group stage"));
            matches.add(new Match("H","Spain","Cape Verde","2026-06-15 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Egypt","2026-06-15 21:00","Group stage"));
            matches.add(new Match("H","Saudi Arabia","Uruguay","2026-06-16 00:00","Group stage"));
            matches.add(new Match("G","Iran","New Zealand","2026-06-16 03:00","Group stage"));
            matches.add(new Match("I","France","Senegal","2026-06-16 21:00","Group stage"));
            matches.add(new Match("I","Iraq","Norway","2026-06-17 00:00","Group stage"));
            matches.add(new Match("J","Argentina","Algeria","2026-06-17 03:00","Group stage"));
            matches.add(new Match("J","Austria","Jordan","2026-06-17 06:00","Group stage"));
            matches.add(new Match("K","Portugal","DR Congo","2026-06-17 19:00","Group stage"));
            matches.add(new Match("L","England","Croatia","2026-06-17 22:00","Group stage"));
            matches.add(new Match("L","Ghana","Panama","2026-06-18 01:00","Group stage"));
            matches.add(new Match("K","Uzbekistan","Colombia","2026-06-18 04:00","Group stage"));
            matches.add(new Match("A","Czechia","South Africa","2026-06-18 18:00","Group stage"));
            matches.add(new Match("B","Switzerland","Bosnia and Herzegovina","2026-06-18 21:00","Group stage"));
            matches.add(new Match("B","Canada","Qatar","2026-06-19 00:00","Group stage"));
            matches.add(new Match("A","Mexico","Korea Republic","2026-06-19 03:00","Group stage"));
            matches.add(new Match("D","USA","Australia","2026-06-19 21:00","Group stage"));
            matches.add(new Match("C","Scotland","Morocco","2026-06-20 00:00","Group stage"));
            matches.add(new Match("C","Brazil","Haiti","2026-06-20 02:30","Group stage"));
            matches.add(new Match("D","Turkey","Paraguay","2026-06-20 05:00","Group stage"));
            matches.add(new Match("F","Netherlands","Sweden","2026-06-20 19:00","Group stage"));
            matches.add(new Match("E","Germany","Ivory Coast","2026-06-20 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Curacao","2026-06-21 02:00","Group stage"));
            matches.add(new Match("F","Tunisia","Japan","2026-06-21 06:00","Group stage"));
            matches.add(new Match("H","Spain","Saudi Arabia","2026-06-21 18:00","Group stage"));
            matches.add(new Match("G","Belgium","Iran","2026-06-21 21:00","Group stage"));
            matches.add(new Match("H","Uruguay","Cape Verde","2026-06-22 00:00","Group stage"));
            matches.add(new Match("G","New Zealand","Egypt","2026-06-22 03:00","Group stage"));
            matches.add(new Match("J","Argentina","Austria","2026-06-22 19:00","Group stage"));
            matches.add(new Match("I","France","Iraq","2026-06-22 23:00","Group stage"));
            matches.add(new Match("I","Norway","Senegal","2026-06-23 02:00","Group stage"));
            matches.add(new Match("J","Jordan","Algeria","2026-06-23 05:00","Group stage"));
            matches.add(new Match("K","Portugal","Uzbekistan","2026-06-23 19:00","Group stage"));
            matches.add(new Match("L","England","Ghana","2026-06-23 22:00","Group stage"));
            matches.add(new Match("L","Panama","Croatia","2026-06-24 01:00","Group stage"));
            matches.add(new Match("K","Colombia","DR Congo","2026-06-24 04:00","Group stage"));
            matches.add(new Match("B","Switzerland","Canada","2026-06-24 21:00","Group stage"));
            matches.add(new Match("B","Bosnia and Herzegovina","Qatar","2026-06-24 21:00","Group stage"));
            matches.add(new Match("C","Morocco","Haiti","2026-06-25 00:00","Group stage"));
            matches.add(new Match("C","Scotland","Brazil","2026-06-25 00:00","Group stage"));
            matches.add(new Match("A","South Africa","Korea Republic","2026-06-25 03:00","Group stage"));
            matches.add(new Match("A","Czechia","Mexico","2026-06-25 03:00","Group stage"));
            matches.add(new Match("E","Curacao","Ivory Coast","2026-06-25 22:00","Group stage"));
            matches.add(new Match("E","Ecuador","Germany","2026-06-25 22:00","Group stage"));
            matches.add(new Match("F","Tunisia","Netherlands","2026-06-26 01:00","Group stage"));
            matches.add(new Match("F","Japan","Sweden","2026-06-26 01:00","Group stage"));
            matches.add(new Match("D","Turkey","USA","2026-06-26 04:00","Group stage"));
            matches.add(new Match("D","Paraguay","Australia","2026-06-26 04:00","Group stage"));
            matches.add(new Match("I","Norway","France","2026-06-26 21:00","Group stage"));
            matches.add(new Match("I","Senegal","Iraq","2026-06-26 21:00","Group stage"));
            matches.add(new Match("H","Cape Verde","Saudi Arabia","2026-06-27 02:00","Group stage"));
            matches.add(new Match("H","Uruguay","Spain","2026-06-27 02:00","Group stage"));
            matches.add(new Match("G","New Zealand","Belgium","2026-06-27 05:00","Group stage"));
            matches.add(new Match("G","Egypt","Iran","2026-06-27 05:00","Group stage"));
            matches.add(new Match("L","Panama","England","2026-06-27 23:00","Group stage"));
            matches.add(new Match("L","Croatia","Ghana","2026-06-27 23:00","Group stage"));
            matches.add(new Match("K","Colombia","Portugal","2026-06-28 01:30","Group stage"));
            matches.add(new Match("K","DR Congo","Uzbekistan","2026-06-28 01:30","Group stage"));
            matches.add(new Match("J","Algeria","Austria","2026-06-28 04:00","Group stage"));
            matches.add(new Match("J","Jordan","Argentina","2026-06-28 04:00","Group stage"));
            Collections.sort(teams);
        }
        public void load(){for(int i=0;i<matches.size();i++){matches.get(i).homeGoals=sp.getInt("h"+i,-1);matches.get(i).awayGoals=sp.getInt("a"+i,-1);}}
        public void save(){SharedPreferences.Editor e=sp.edit();for(int i=0;i<matches.size();i++){e.putInt("h"+i,matches.get(i).homeGoals);e.putInt("a"+i,matches.get(i).awayGoals);}e.apply();}
        public void reset(){sp.edit().clear().apply();for(Match m:matches){m.homeGoals=-1;m.awayGoals=-1;}}
        public Map<String,List<TeamRow>> standings(){Map<String,List<TeamRow>> out=new LinkedHashMap<>();for(String gr:groups){Map<String,TeamRow> m=new LinkedHashMap<>();for(Match ma:matches)if(ma.group.equals(gr)){m.putIfAbsent(ma.home,new TeamRow(gr,ma.home));m.putIfAbsent(ma.away,new TeamRow(gr,ma.away));if(rules.isFinished(ma)){TeamRow h=m.get(ma.home),a=m.get(ma.away);h.p++;a.p++;h.gf+=ma.homeGoals;h.ga+=ma.awayGoals;a.gf+=ma.awayGoals;a.ga+=ma.homeGoals;if(ma.homeGoals>ma.awayGoals){h.w++;h.pts+=3;a.l++;}else if(ma.homeGoals<ma.awayGoals){a.w++;a.pts+=3;h.l++;}else{h.d++;a.d++;h.pts++;a.pts++;}}}ArrayList<TeamRow> list=new ArrayList<>(m.values());Collections.sort(list,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));out.put(gr,list);}return out;}
        public List<TeamRow> bestThirds(){ArrayList<TeamRow> third=new ArrayList<>();for(List<TeamRow> l:standings().values())if(l.size()>2)third.add(l.get(2));Collections.sort(third,(x,y)->y.pts!=x.pts?y.pts-x.pts:((y.gf-y.ga)!=(x.gf-x.ga)?(y.gf-y.ga)-(x.gf-x.ga):y.gf-x.gf));return third;}
        public List<TeamRow> qualified(){ArrayList<TeamRow> q=new ArrayList<>();for(List<TeamRow> l:standings().values()){if(l.size()>0)q.add(l.get(0));if(l.size()>1)q.add(l.get(1));}List<TeamRow> th=bestThirds();for(int i=0;i<Math.min(8,th.size());i++)q.add(th.get(i));return q;}
        public int playedCount(){int c=0;for(Match m:matches)if(rules.isFinished(m))c++;return c;}public int totalGoals(){int g=0;for(Match m:matches)if(rules.isFinished(m))g+=m.homeGoals+m.awayGoals;return g;}public String avgGoals(){return playedCount()==0?"0.00":String.format(Locale.US,"%.2f",totalGoals()*1.0/playedCount());}public int progressPercent(){return(int)Math.round(playedCount()*100.0/matches.size());}public String bestAttack(){Map<String,Integer> gf=new HashMap<>();for(Match m:matches)if(rules.isFinished(m)){gf.put(m.home,gf.getOrDefault(m.home,0)+m.homeGoals);gf.put(m.away,gf.getOrDefault(m.away,0)+m.awayGoals);}String best="TBD";int max=-1;for(String t:gf.keySet())if(gf.get(t)>max){max=gf.get(t);best=t;}return best+" ("+Math.max(0,max)+")";}public String bestGroup(){Map<String,Integer> goals=new HashMap<>();for(Match m:matches)if(rules.isFinished(m))goals.put(m.group,goals.getOrDefault(m.group,0)+m.homeGoals+m.awayGoals);String best="TBD";int max=-1;for(String g:goals.keySet())if(goals.get(g)>max){max=goals.get(g);best=g;}return best+" ("+Math.max(0,max)+" goals)";}public Match nextFor(String team){return rules.nextForTeam(team);}
    }
