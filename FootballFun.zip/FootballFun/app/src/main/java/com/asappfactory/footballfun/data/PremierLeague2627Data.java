package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Verified Premier League 2026/27 fixture fallback.
 *
 * The bundled fixture list guarantees a complete pre-season schedule even when
 * a connected provider has not exposed the new season yet. Any matching
 * current-season online row is merged on top, so live scores, final results,
 * venues and richer team metadata can still replace the bundled fallback.
 */
public final class PremierLeague2627Data {
    private static final String COMPETITION_NAME = "Premier League";
    private static final String COMPETITION_CODE = "PL";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-21";
    private static final String LAST_DATE = "2027-05-30";

    private static final String DATA =
            "2026-08-21T19:00:00Z|1|Arsenal|Coventry City|TIMED\n" +
            "2026-08-22T11:30:00Z|1|Hull City|Manchester United|TIMED\n" +
            "2026-08-22|1|Everton|Crystal Palace|SCHEDULED\n" +
            "2026-08-22|1|Ipswich Town|Sunderland|SCHEDULED\n" +
            "2026-08-22|1|Nottingham Forest|Leeds United|SCHEDULED\n" +
            "2026-08-22T16:30:00Z|1|Brentford|Tottenham Hotspur|TIMED\n" +
            "2026-08-23T13:00:00Z|1|Brighton & Hove Albion|Aston Villa|TIMED\n" +
            "2026-08-23T13:00:00Z|1|Manchester City|AFC Bournemouth|TIMED\n" +
            "2026-08-23T15:30:00Z|1|Newcastle United|Liverpool|TIMED\n" +
            "2026-08-24T19:00:00Z|1|Fulham|Chelsea|TIMED\n" +
            "2026-08-28T19:00:00Z|2|Crystal Palace|Manchester City|TIMED\n" +
            "2026-08-29T11:30:00Z|2|Liverpool|Nottingham Forest|TIMED\n" +
            "2026-08-29|2|AFC Bournemouth|Everton|SCHEDULED\n" +
            "2026-08-29|2|Coventry City|Hull City|SCHEDULED\n" +
            "2026-08-29T16:30:00Z|2|Tottenham Hotspur|Newcastle United|TIMED\n" +
            "2026-08-30T13:00:00Z|2|Chelsea|Brighton & Hove Albion|TIMED\n" +
            "2026-08-30T13:00:00Z|2|Leeds United|Brentford|TIMED\n" +
            "2026-08-30T13:00:00Z|2|Sunderland|Fulham|TIMED\n" +
            "2026-08-30T15:30:00Z|2|Manchester United|Ipswich Town|TIMED\n" +
            "2026-08-31T19:00:00Z|2|Aston Villa|Arsenal|TIMED\n" +
            "2026-09-04T19:00:00Z|3|Ipswich Town|Liverpool|TIMED\n" +
            "2026-09-05T11:30:00Z|3|Newcastle United|AFC Bournemouth|TIMED\n" +
            "2026-09-05|3|Brentford|Sunderland|SCHEDULED\n" +
            "2026-09-05|3|Brighton & Hove Albion|Leeds United|SCHEDULED\n" +
            "2026-09-05|3|Fulham|Crystal Palace|SCHEDULED\n" +
            "2026-09-05|3|Manchester City|Coventry City|SCHEDULED\n" +
            "2026-09-05|3|Nottingham Forest|Tottenham Hotspur|SCHEDULED\n" +
            "2026-09-05T16:30:00Z|3|Hull City|Aston Villa|TIMED\n" +
            "2026-09-06T13:00:00Z|3|Everton|Manchester United|TIMED\n" +
            "2026-09-06T15:30:00Z|3|Arsenal|Chelsea|TIMED\n" +
            "2026-09-12|4|AFC Bournemouth|Brentford|SCHEDULED\n" +
            "2026-09-12|4|Aston Villa|Nottingham Forest|SCHEDULED\n" +
            "2026-09-12|4|Chelsea|Hull City|SCHEDULED\n" +
            "2026-09-12|4|Crystal Palace|Ipswich Town|SCHEDULED\n" +
            "2026-09-12|4|Liverpool|Fulham|SCHEDULED\n" +
            "2026-09-12T16:30:00Z|4|Tottenham Hotspur|Everton|TIMED\n" +
            "2026-09-12T19:00:00Z|4|Sunderland|Arsenal|TIMED\n" +
            "2026-09-13T13:00:00Z|4|Coventry City|Brighton & Hove Albion|TIMED\n" +
            "2026-09-13T15:30:00Z|4|Manchester United|Manchester City|TIMED\n" +
            "2026-09-14T19:00:00Z|4|Leeds United|Newcastle United|TIMED\n" +
            "2026-09-18T19:00:00Z|5|Brentford|Chelsea|TIMED\n" +
            "2026-09-19T11:30:00Z|5|Tottenham Hotspur|Aston Villa|TIMED\n" +
            "2026-09-19|5|Brighton & Hove Albion|Arsenal|SCHEDULED\n" +
            "2026-09-19|5|Everton|Ipswich Town|SCHEDULED\n" +
            "2026-09-19|5|Leeds United|Crystal Palace|SCHEDULED\n" +
            "2026-09-19|5|Manchester City|Sunderland|SCHEDULED\n" +
            "2026-09-19|5|Newcastle United|Hull City|SCHEDULED\n" +
            "2026-09-19T16:30:00Z|5|Nottingham Forest|Coventry City|TIMED\n" +
            "2026-09-20T13:00:00Z|5|AFC Bournemouth|Liverpool|TIMED\n" +
            "2026-09-20T15:30:00Z|5|Fulham|Manchester United|TIMED\n" +
            "2026-10-10|6|Arsenal|Leeds United|SCHEDULED\n" +
            "2026-10-10|6|Aston Villa|Brentford|SCHEDULED\n" +
            "2026-10-10|6|Chelsea|AFC Bournemouth|SCHEDULED\n" +
            "2026-10-10|6|Coventry City|Newcastle United|SCHEDULED\n" +
            "2026-10-10|6|Crystal Palace|Nottingham Forest|SCHEDULED\n" +
            "2026-10-10|6|Hull City|Everton|SCHEDULED\n" +
            "2026-10-10|6|Ipswich Town|Fulham|SCHEDULED\n" +
            "2026-10-10|6|Liverpool|Manchester City|SCHEDULED\n" +
            "2026-10-10|6|Manchester United|Tottenham Hotspur|SCHEDULED\n" +
            "2026-10-10|6|Sunderland|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-10-17|7|AFC Bournemouth|Sunderland|SCHEDULED\n" +
            "2026-10-17|7|Brentford|Liverpool|SCHEDULED\n" +
            "2026-10-17|7|Brighton & Hove Albion|Crystal Palace|SCHEDULED\n" +
            "2026-10-17|7|Everton|Chelsea|SCHEDULED\n" +
            "2026-10-17|7|Fulham|Hull City|SCHEDULED\n" +
            "2026-10-17|7|Leeds United|Manchester United|SCHEDULED\n" +
            "2026-10-17|7|Manchester City|Ipswich Town|SCHEDULED\n" +
            "2026-10-17|7|Newcastle United|Aston Villa|SCHEDULED\n" +
            "2026-10-17|7|Nottingham Forest|Arsenal|SCHEDULED\n" +
            "2026-10-17|7|Tottenham Hotspur|Coventry City|SCHEDULED\n" +
            "2026-10-24|8|Arsenal|Everton|SCHEDULED\n" +
            "2026-10-24|8|Aston Villa|Manchester City|SCHEDULED\n" +
            "2026-10-24|8|Chelsea|Tottenham Hotspur|SCHEDULED\n" +
            "2026-10-24|8|Coventry City|Fulham|SCHEDULED\n" +
            "2026-10-24|8|Crystal Palace|Newcastle United|SCHEDULED\n" +
            "2026-10-24|8|Hull City|Brentford|SCHEDULED\n" +
            "2026-10-24|8|Ipswich Town|Nottingham Forest|SCHEDULED\n" +
            "2026-10-24|8|Liverpool|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-10-24|8|Manchester United|AFC Bournemouth|SCHEDULED\n" +
            "2026-10-24|8|Sunderland|Leeds United|SCHEDULED\n" +
            "2026-10-31|9|AFC Bournemouth|Leeds United|SCHEDULED\n" +
            "2026-10-31|9|Aston Villa|Fulham|SCHEDULED\n" +
            "2026-10-31|9|Brentford|Nottingham Forest|SCHEDULED\n" +
            "2026-10-31|9|Chelsea|Manchester United|SCHEDULED\n" +
            "2026-10-31|9|Coventry City|Sunderland|SCHEDULED\n" +
            "2026-10-31|9|Hull City|Ipswich Town|SCHEDULED\n" +
            "2026-10-31|9|Liverpool|Arsenal|SCHEDULED\n" +
            "2026-10-31|9|Manchester City|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-10-31|9|Newcastle United|Everton|SCHEDULED\n" +
            "2026-10-31|9|Tottenham Hotspur|Crystal Palace|SCHEDULED\n" +
            "2026-11-07|10|Arsenal|Hull City|SCHEDULED\n" +
            "2026-11-07|10|Brighton & Hove Albion|Brentford|SCHEDULED\n" +
            "2026-11-07|10|Crystal Palace|Liverpool|SCHEDULED\n" +
            "2026-11-07|10|Everton|Coventry City|SCHEDULED\n" +
            "2026-11-07|10|Fulham|Newcastle United|SCHEDULED\n" +
            "2026-11-07|10|Ipswich Town|AFC Bournemouth|SCHEDULED\n" +
            "2026-11-07|10|Leeds United|Tottenham Hotspur|SCHEDULED\n" +
            "2026-11-07|10|Manchester United|Aston Villa|SCHEDULED\n" +
            "2026-11-07|10|Nottingham Forest|Manchester City|SCHEDULED\n" +
            "2026-11-07|10|Sunderland|Chelsea|SCHEDULED\n" +
            "2026-11-21|11|AFC Bournemouth|Nottingham Forest|SCHEDULED\n" +
            "2026-11-21|11|Aston Villa|Sunderland|SCHEDULED\n" +
            "2026-11-21|11|Brentford|Everton|SCHEDULED\n" +
            "2026-11-21|11|Chelsea|Leeds United|SCHEDULED\n" +
            "2026-11-21|11|Coventry City|Crystal Palace|SCHEDULED\n" +
            "2026-11-21|11|Hull City|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-11-21|11|Liverpool|Manchester United|SCHEDULED\n" +
            "2026-11-21|11|Manchester City|Fulham|SCHEDULED\n" +
            "2026-11-21|11|Newcastle United|Arsenal|SCHEDULED\n" +
            "2026-11-21|11|Tottenham Hotspur|Ipswich Town|SCHEDULED\n" +
            "2026-11-28|12|Arsenal|Manchester City|SCHEDULED\n" +
            "2026-11-28|12|Brighton & Hove Albion|Newcastle United|SCHEDULED\n" +
            "2026-11-28|12|Crystal Palace|Hull City|SCHEDULED\n" +
            "2026-11-28|12|Everton|Liverpool|SCHEDULED\n" +
            "2026-11-28|12|Fulham|AFC Bournemouth|SCHEDULED\n" +
            "2026-11-28|12|Ipswich Town|Aston Villa|SCHEDULED\n" +
            "2026-11-28|12|Leeds United|Coventry City|SCHEDULED\n" +
            "2026-11-28|12|Manchester United|Brentford|SCHEDULED\n" +
            "2026-11-28|12|Nottingham Forest|Chelsea|SCHEDULED\n" +
            "2026-11-28|12|Sunderland|Tottenham Hotspur|SCHEDULED\n" +
            "2026-12-02T20:00:00Z|13|AFC Bournemouth|Brighton & Hove Albion|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Aston Villa|Everton|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Brentford|Arsenal|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Chelsea|Crystal Palace|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Coventry City|Ipswich Town|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Hull City|Nottingham Forest|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Liverpool|Sunderland|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Manchester City|Leeds United|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Newcastle United|Manchester United|TIMED\n" +
            "2026-12-02T20:00:00Z|13|Tottenham Hotspur|Fulham|TIMED\n" +
            "2026-12-05|14|AFC Bournemouth|Hull City|SCHEDULED\n" +
            "2026-12-05|14|Aston Villa|Crystal Palace|SCHEDULED\n" +
            "2026-12-05|14|Brentford|Manchester City|SCHEDULED\n" +
            "2026-12-05|14|Chelsea|Liverpool|SCHEDULED\n" +
            "2026-12-05|14|Everton|Fulham|SCHEDULED\n" +
            "2026-12-05|14|Leeds United|Ipswich Town|SCHEDULED\n" +
            "2026-12-05|14|Manchester United|Coventry City|SCHEDULED\n" +
            "2026-12-05|14|Newcastle United|Sunderland|SCHEDULED\n" +
            "2026-12-05|14|Nottingham Forest|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-12-05|14|Tottenham Hotspur|Arsenal|SCHEDULED\n" +
            "2026-12-12|15|Arsenal|AFC Bournemouth|SCHEDULED\n" +
            "2026-12-12|15|Brighton & Hove Albion|Everton|SCHEDULED\n" +
            "2026-12-12|15|Coventry City|Aston Villa|SCHEDULED\n" +
            "2026-12-12|15|Crystal Palace|Manchester United|SCHEDULED\n" +
            "2026-12-12|15|Fulham|Brentford|SCHEDULED\n" +
            "2026-12-12|15|Hull City|Tottenham Hotspur|SCHEDULED\n" +
            "2026-12-12|15|Ipswich Town|Newcastle United|SCHEDULED\n" +
            "2026-12-12|15|Liverpool|Leeds United|SCHEDULED\n" +
            "2026-12-12|15|Manchester City|Chelsea|SCHEDULED\n" +
            "2026-12-12|15|Sunderland|Nottingham Forest|SCHEDULED\n" +
            "2026-12-19|16|AFC Bournemouth|Coventry City|SCHEDULED\n" +
            "2026-12-19|16|Arsenal|Manchester United|SCHEDULED\n" +
            "2026-12-19|16|Brentford|Newcastle United|SCHEDULED\n" +
            "2026-12-19|16|Brighton & Hove Albion|Ipswich Town|SCHEDULED\n" +
            "2026-12-19|16|Chelsea|Aston Villa|SCHEDULED\n" +
            "2026-12-19|16|Leeds United|Fulham|SCHEDULED\n" +
            "2026-12-19|16|Liverpool|Tottenham Hotspur|SCHEDULED\n" +
            "2026-12-19|16|Manchester City|Hull City|SCHEDULED\n" +
            "2026-12-19|16|Nottingham Forest|Everton|SCHEDULED\n" +
            "2026-12-19|16|Sunderland|Crystal Palace|SCHEDULED\n" +
            "2026-12-26|17|Aston Villa|Leeds United|SCHEDULED\n" +
            "2026-12-26|17|Coventry City|Chelsea|SCHEDULED\n" +
            "2026-12-26|17|Crystal Palace|Arsenal|SCHEDULED\n" +
            "2026-12-26|17|Everton|Sunderland|SCHEDULED\n" +
            "2026-12-26|17|Fulham|Brighton & Hove Albion|SCHEDULED\n" +
            "2026-12-26|17|Hull City|Liverpool|SCHEDULED\n" +
            "2026-12-26|17|Ipswich Town|Brentford|SCHEDULED\n" +
            "2026-12-26|17|Manchester United|Nottingham Forest|SCHEDULED\n" +
            "2026-12-26|17|Newcastle United|Manchester City|SCHEDULED\n" +
            "2026-12-26|17|Tottenham Hotspur|AFC Bournemouth|SCHEDULED\n" +
            "2026-12-30T20:00:00Z|18|Aston Villa|Liverpool|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Coventry City|Brentford|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Crystal Palace|AFC Bournemouth|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Everton|Manchester City|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Fulham|Arsenal|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Hull City|Leeds United|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Ipswich Town|Chelsea|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Manchester United|Sunderland|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Newcastle United|Nottingham Forest|TIMED\n" +
            "2026-12-30T20:00:00Z|18|Tottenham Hotspur|Brighton & Hove Albion|TIMED\n" +
            "2027-01-02|19|AFC Bournemouth|Aston Villa|SCHEDULED\n" +
            "2027-01-02|19|Arsenal|Ipswich Town|SCHEDULED\n" +
            "2027-01-02|19|Brentford|Crystal Palace|SCHEDULED\n" +
            "2027-01-02|19|Brighton & Hove Albion|Manchester United|SCHEDULED\n" +
            "2027-01-02|19|Chelsea|Newcastle United|SCHEDULED\n" +
            "2027-01-02|19|Leeds United|Everton|SCHEDULED\n" +
            "2027-01-02|19|Liverpool|Coventry City|SCHEDULED\n" +
            "2027-01-02|19|Manchester City|Tottenham Hotspur|SCHEDULED\n" +
            "2027-01-02|19|Nottingham Forest|Fulham|SCHEDULED\n" +
            "2027-01-02|19|Sunderland|Hull City|SCHEDULED\n" +
            "2027-01-06T20:00:00Z|20|Arsenal|Brentford|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Brighton & Hove Albion|AFC Bournemouth|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Crystal Palace|Chelsea|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Everton|Aston Villa|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Fulham|Tottenham Hotspur|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Ipswich Town|Coventry City|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Leeds United|Manchester City|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Manchester United|Newcastle United|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Nottingham Forest|Hull City|TIMED\n" +
            "2027-01-06T20:00:00Z|20|Sunderland|Liverpool|TIMED\n" +
            "2027-01-16|21|AFC Bournemouth|Ipswich Town|SCHEDULED\n" +
            "2027-01-16|21|Aston Villa|Manchester United|SCHEDULED\n" +
            "2027-01-16|21|Brentford|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-01-16|21|Chelsea|Sunderland|SCHEDULED\n" +
            "2027-01-16|21|Coventry City|Everton|SCHEDULED\n" +
            "2027-01-16|21|Hull City|Arsenal|SCHEDULED\n" +
            "2027-01-16|21|Liverpool|Crystal Palace|SCHEDULED\n" +
            "2027-01-16|21|Manchester City|Nottingham Forest|SCHEDULED\n" +
            "2027-01-16|21|Newcastle United|Fulham|SCHEDULED\n" +
            "2027-01-16|21|Tottenham Hotspur|Leeds United|SCHEDULED\n" +
            "2027-01-23|22|Arsenal|Newcastle United|SCHEDULED\n" +
            "2027-01-23|22|Brighton & Hove Albion|Manchester City|SCHEDULED\n" +
            "2027-01-23|22|Crystal Palace|Tottenham Hotspur|SCHEDULED\n" +
            "2027-01-23|22|Everton|Brentford|SCHEDULED\n" +
            "2027-01-23|22|Fulham|Aston Villa|SCHEDULED\n" +
            "2027-01-23|22|Ipswich Town|Hull City|SCHEDULED\n" +
            "2027-01-23|22|Leeds United|Chelsea|SCHEDULED\n" +
            "2027-01-23|22|Manchester United|Liverpool|SCHEDULED\n" +
            "2027-01-23|22|Nottingham Forest|AFC Bournemouth|SCHEDULED\n" +
            "2027-01-23|22|Sunderland|Coventry City|SCHEDULED\n" +
            "2027-01-30|23|AFC Bournemouth|Fulham|SCHEDULED\n" +
            "2027-01-30|23|Aston Villa|Ipswich Town|SCHEDULED\n" +
            "2027-01-30|23|Brentford|Manchester United|SCHEDULED\n" +
            "2027-01-30|23|Chelsea|Nottingham Forest|SCHEDULED\n" +
            "2027-01-30|23|Coventry City|Leeds United|SCHEDULED\n" +
            "2027-01-30|23|Hull City|Crystal Palace|SCHEDULED\n" +
            "2027-01-30|23|Liverpool|Everton|SCHEDULED\n" +
            "2027-01-30|23|Manchester City|Arsenal|SCHEDULED\n" +
            "2027-01-30|23|Newcastle United|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-01-30|23|Tottenham Hotspur|Sunderland|SCHEDULED\n" +
            "2027-02-06|24|Arsenal|Liverpool|SCHEDULED\n" +
            "2027-02-06|24|Brighton & Hove Albion|Hull City|SCHEDULED\n" +
            "2027-02-06|24|Crystal Palace|Coventry City|SCHEDULED\n" +
            "2027-02-06|24|Everton|Newcastle United|SCHEDULED\n" +
            "2027-02-06|24|Fulham|Manchester City|SCHEDULED\n" +
            "2027-02-06|24|Ipswich Town|Tottenham Hotspur|SCHEDULED\n" +
            "2027-02-06|24|Leeds United|AFC Bournemouth|SCHEDULED\n" +
            "2027-02-06|24|Manchester United|Chelsea|SCHEDULED\n" +
            "2027-02-06|24|Nottingham Forest|Brentford|SCHEDULED\n" +
            "2027-02-06|24|Sunderland|Aston Villa|SCHEDULED\n" +
            "2027-02-10T20:00:00Z|25|Aston Villa|AFC Bournemouth|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Coventry City|Liverpool|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Crystal Palace|Brentford|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Everton|Leeds United|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Fulham|Nottingham Forest|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Hull City|Sunderland|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Ipswich Town|Arsenal|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Manchester United|Brighton & Hove Albion|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Newcastle United|Chelsea|TIMED\n" +
            "2027-02-10T20:00:00Z|25|Tottenham Hotspur|Manchester City|TIMED\n" +
            "2027-02-20|26|AFC Bournemouth|Crystal Palace|SCHEDULED\n" +
            "2027-02-20|26|Arsenal|Fulham|SCHEDULED\n" +
            "2027-02-20|26|Brentford|Coventry City|SCHEDULED\n" +
            "2027-02-20|26|Brighton & Hove Albion|Tottenham Hotspur|SCHEDULED\n" +
            "2027-02-20|26|Chelsea|Ipswich Town|SCHEDULED\n" +
            "2027-02-20|26|Leeds United|Aston Villa|SCHEDULED\n" +
            "2027-02-20|26|Liverpool|Hull City|SCHEDULED\n" +
            "2027-02-20|26|Manchester City|Newcastle United|SCHEDULED\n" +
            "2027-02-20|26|Nottingham Forest|Manchester United|SCHEDULED\n" +
            "2027-02-20|26|Sunderland|Everton|SCHEDULED\n" +
            "2027-02-27|27|Aston Villa|Chelsea|SCHEDULED\n" +
            "2027-02-27|27|Coventry City|AFC Bournemouth|SCHEDULED\n" +
            "2027-02-27|27|Crystal Palace|Sunderland|SCHEDULED\n" +
            "2027-02-27|27|Everton|Nottingham Forest|SCHEDULED\n" +
            "2027-02-27|27|Fulham|Leeds United|SCHEDULED\n" +
            "2027-02-27|27|Hull City|Manchester City|SCHEDULED\n" +
            "2027-02-27|27|Ipswich Town|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-02-27|27|Manchester United|Arsenal|SCHEDULED\n" +
            "2027-02-27|27|Newcastle United|Brentford|SCHEDULED\n" +
            "2027-02-27|27|Tottenham Hotspur|Liverpool|SCHEDULED\n" +
            "2027-03-03T20:00:00Z|28|AFC Bournemouth|Tottenham Hotspur|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Arsenal|Crystal Palace|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Brentford|Ipswich Town|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Brighton & Hove Albion|Fulham|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Chelsea|Coventry City|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Leeds United|Hull City|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Liverpool|Aston Villa|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Manchester City|Everton|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Nottingham Forest|Newcastle United|TIMED\n" +
            "2027-03-03T20:00:00Z|28|Sunderland|Manchester United|TIMED\n" +
            "2027-03-13|29|AFC Bournemouth|Newcastle United|SCHEDULED\n" +
            "2027-03-13|29|Aston Villa|Hull City|SCHEDULED\n" +
            "2027-03-13|29|Chelsea|Arsenal|SCHEDULED\n" +
            "2027-03-13|29|Coventry City|Manchester City|SCHEDULED\n" +
            "2027-03-13|29|Crystal Palace|Fulham|SCHEDULED\n" +
            "2027-03-13|29|Leeds United|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-03-13|29|Liverpool|Ipswich Town|SCHEDULED\n" +
            "2027-03-13|29|Manchester United|Everton|SCHEDULED\n" +
            "2027-03-13|29|Sunderland|Brentford|SCHEDULED\n" +
            "2027-03-13|29|Tottenham Hotspur|Nottingham Forest|SCHEDULED\n" +
            "2027-03-20|30|Arsenal|Sunderland|SCHEDULED\n" +
            "2027-03-20|30|Brentford|AFC Bournemouth|SCHEDULED\n" +
            "2027-03-20|30|Brighton & Hove Albion|Coventry City|SCHEDULED\n" +
            "2027-03-20|30|Everton|Tottenham Hotspur|SCHEDULED\n" +
            "2027-03-20|30|Fulham|Liverpool|SCHEDULED\n" +
            "2027-03-20|30|Hull City|Chelsea|SCHEDULED\n" +
            "2027-03-20|30|Ipswich Town|Crystal Palace|SCHEDULED\n" +
            "2027-03-20|30|Manchester City|Manchester United|SCHEDULED\n" +
            "2027-03-20|30|Newcastle United|Leeds United|SCHEDULED\n" +
            "2027-03-20|30|Nottingham Forest|Aston Villa|SCHEDULED\n" +
            "2027-04-10|31|AFC Bournemouth|Manchester City|SCHEDULED\n" +
            "2027-04-10|31|Aston Villa|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-04-10|31|Chelsea|Fulham|SCHEDULED\n" +
            "2027-04-10|31|Coventry City|Arsenal|SCHEDULED\n" +
            "2027-04-10|31|Crystal Palace|Everton|SCHEDULED\n" +
            "2027-04-10|31|Leeds United|Nottingham Forest|SCHEDULED\n" +
            "2027-04-10|31|Liverpool|Newcastle United|SCHEDULED\n" +
            "2027-04-10|31|Manchester United|Hull City|SCHEDULED\n" +
            "2027-04-10|31|Sunderland|Ipswich Town|SCHEDULED\n" +
            "2027-04-10|31|Tottenham Hotspur|Brentford|SCHEDULED\n" +
            "2027-04-17|32|Arsenal|Aston Villa|SCHEDULED\n" +
            "2027-04-17|32|Brentford|Leeds United|SCHEDULED\n" +
            "2027-04-17|32|Brighton & Hove Albion|Chelsea|SCHEDULED\n" +
            "2027-04-17|32|Everton|AFC Bournemouth|SCHEDULED\n" +
            "2027-04-17|32|Fulham|Sunderland|SCHEDULED\n" +
            "2027-04-17|32|Hull City|Coventry City|SCHEDULED\n" +
            "2027-04-17|32|Ipswich Town|Manchester United|SCHEDULED\n" +
            "2027-04-17|32|Manchester City|Crystal Palace|SCHEDULED\n" +
            "2027-04-17|32|Newcastle United|Tottenham Hotspur|SCHEDULED\n" +
            "2027-04-17|32|Nottingham Forest|Liverpool|SCHEDULED\n" +
            "2027-04-24|33|AFC Bournemouth|Arsenal|SCHEDULED\n" +
            "2027-04-24|33|Aston Villa|Coventry City|SCHEDULED\n" +
            "2027-04-24|33|Brentford|Fulham|SCHEDULED\n" +
            "2027-04-24|33|Chelsea|Manchester City|SCHEDULED\n" +
            "2027-04-24|33|Everton|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-04-24|33|Leeds United|Liverpool|SCHEDULED\n" +
            "2027-04-24|33|Manchester United|Crystal Palace|SCHEDULED\n" +
            "2027-04-24|33|Newcastle United|Ipswich Town|SCHEDULED\n" +
            "2027-04-24|33|Nottingham Forest|Sunderland|SCHEDULED\n" +
            "2027-04-24|33|Tottenham Hotspur|Hull City|SCHEDULED\n" +
            "2027-05-01|34|Arsenal|Tottenham Hotspur|SCHEDULED\n" +
            "2027-05-01|34|Brighton & Hove Albion|Nottingham Forest|SCHEDULED\n" +
            "2027-05-01|34|Coventry City|Manchester United|SCHEDULED\n" +
            "2027-05-01|34|Crystal Palace|Aston Villa|SCHEDULED\n" +
            "2027-05-01|34|Fulham|Everton|SCHEDULED\n" +
            "2027-05-01|34|Hull City|AFC Bournemouth|SCHEDULED\n" +
            "2027-05-01|34|Ipswich Town|Leeds United|SCHEDULED\n" +
            "2027-05-01|34|Liverpool|Chelsea|SCHEDULED\n" +
            "2027-05-01|34|Manchester City|Brentford|SCHEDULED\n" +
            "2027-05-01|34|Sunderland|Newcastle United|SCHEDULED\n" +
            "2027-05-08|35|AFC Bournemouth|Manchester United|SCHEDULED\n" +
            "2027-05-08|35|Brentford|Aston Villa|SCHEDULED\n" +
            "2027-05-08|35|Brighton & Hove Albion|Sunderland|SCHEDULED\n" +
            "2027-05-08|35|Everton|Hull City|SCHEDULED\n" +
            "2027-05-08|35|Fulham|Ipswich Town|SCHEDULED\n" +
            "2027-05-08|35|Leeds United|Arsenal|SCHEDULED\n" +
            "2027-05-08|35|Manchester City|Liverpool|SCHEDULED\n" +
            "2027-05-08|35|Newcastle United|Coventry City|SCHEDULED\n" +
            "2027-05-08|35|Nottingham Forest|Crystal Palace|SCHEDULED\n" +
            "2027-05-08|35|Tottenham Hotspur|Chelsea|SCHEDULED\n" +
            "2027-05-15|36|Arsenal|Nottingham Forest|SCHEDULED\n" +
            "2027-05-15|36|Aston Villa|Newcastle United|SCHEDULED\n" +
            "2027-05-15|36|Chelsea|Everton|SCHEDULED\n" +
            "2027-05-15|36|Coventry City|Tottenham Hotspur|SCHEDULED\n" +
            "2027-05-15|36|Crystal Palace|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-05-15|36|Hull City|Fulham|SCHEDULED\n" +
            "2027-05-15|36|Ipswich Town|Manchester City|SCHEDULED\n" +
            "2027-05-15|36|Liverpool|Brentford|SCHEDULED\n" +
            "2027-05-15|36|Manchester United|Leeds United|SCHEDULED\n" +
            "2027-05-15|36|Sunderland|AFC Bournemouth|SCHEDULED\n" +
            "2027-05-23|37|AFC Bournemouth|Chelsea|SCHEDULED\n" +
            "2027-05-23|37|Brentford|Hull City|SCHEDULED\n" +
            "2027-05-23|37|Brighton & Hove Albion|Liverpool|SCHEDULED\n" +
            "2027-05-23|37|Everton|Arsenal|SCHEDULED\n" +
            "2027-05-23|37|Fulham|Coventry City|SCHEDULED\n" +
            "2027-05-23|37|Leeds United|Sunderland|SCHEDULED\n" +
            "2027-05-23|37|Manchester City|Aston Villa|SCHEDULED\n" +
            "2027-05-23|37|Newcastle United|Crystal Palace|SCHEDULED\n" +
            "2027-05-23|37|Nottingham Forest|Ipswich Town|SCHEDULED\n" +
            "2027-05-23|37|Tottenham Hotspur|Manchester United|SCHEDULED\n" +
            "2027-05-30|38|Arsenal|Brighton & Hove Albion|SCHEDULED\n" +
            "2027-05-30|38|Aston Villa|Tottenham Hotspur|SCHEDULED\n" +
            "2027-05-30|38|Chelsea|Brentford|SCHEDULED\n" +
            "2027-05-30|38|Coventry City|Nottingham Forest|SCHEDULED\n" +
            "2027-05-30|38|Crystal Palace|Leeds United|SCHEDULED\n" +
            "2027-05-30|38|Hull City|Newcastle United|SCHEDULED\n" +
            "2027-05-30|38|Ipswich Town|Everton|SCHEDULED\n" +
            "2027-05-30|38|Liverpool|AFC Bournemouth|SCHEDULED\n" +
            "2027-05-30|38|Manchester United|Fulham|SCHEDULED\n" +
            "2027-05-30|38|Sunderland|Manchester City|SCHEDULED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    static {
        TLA.put("AFC Bournemouth", "BOU");
        TLA.put("Arsenal", "ARS");
        TLA.put("Aston Villa", "AVL");
        TLA.put("Brentford", "BRE");
        TLA.put("Brighton & Hove Albion", "BHA");
        TLA.put("Chelsea", "CHE");
        TLA.put("Coventry City", "COV");
        TLA.put("Crystal Palace", "CRY");
        TLA.put("Everton", "EVE");
        TLA.put("Fulham", "FUL");
        TLA.put("Hull City", "HUL");
        TLA.put("Ipswich Town", "IPS");
        TLA.put("Leeds United", "LEE");
        TLA.put("Liverpool", "LIV");
        TLA.put("Manchester City", "MCI");
        TLA.put("Manchester United", "MUN");
        TLA.put("Newcastle United", "NEW");
        TLA.put("Nottingham Forest", "NFO");
        TLA.put("Sunderland", "SUN");
        TLA.put("Tottenham Hotspur", "TOT");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutPremierLeague(root.optJSONArray("matches")));
            root.put("live", copyWithoutPremierLeague(root.optJSONArray("live")));
            root.put("finished", copyWithoutPremierLeague(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutPremierLeague(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");

            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // The rest of the connected feed must remain usable if bundled data
            // is ever malformed in a future edit.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonPremierLeague(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 5) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String status = parts[4].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "PL-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "SCHEDULED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("dataProvider", "Premier League official fixture list");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Premier League source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"name", "shortName", "tla", "crest", "emblem", "logo", "area", "venue"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) out.put(key, richer.opt(key));
        return out;
    }

    private static JSONArray copyWithoutPremierLeague(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isPremierLeague(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonPremierLeague(JSONObject row) {
        if (!isPremierLeague(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isPremierLeague(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        StringBuilder value = new StringBuilder();
        if (raw instanceof JSONObject) {
            JSONObject competition = (JSONObject) raw;
            value.append(competition.optString("code", "")).append(' ')
                    .append(competition.optString("name", ""));
        } else if (raw != null) value.append(String.valueOf(raw));
        value.append(' ').append(row.optString("competitionCode", ""))
                .append(' ').append(row.optString("competitionName", ""));
        String normalized = normalize(value.toString());
        return normalized.equals("pl") || normalized.contains("premierleague") || normalized.contains("englishpremierleague");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true);
        String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        // Directed home/away pairing is unique within one league season. Using
        // it instead of the date lets a connected source move a fixture without
        // leaving the bundled original date behind as a duplicate.
        return normalize(home) + "|" + normalize(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0;
        String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30;
        else if (isLive(status)) score += 25;
        else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2;
        if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") ||
                value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject();
        competition.put("code", COMPETITION_CODE);
        competition.put("name", COMPETITION_NAME);
        return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject();
        team.put("name", name);
        team.put("shortName", name);
        team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        team.put("area", "England");
        return team;
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = source == null ? new JSONArray() : new JSONArray(source.toString());
        Map<String, Boolean> existing = new HashMap<String, Boolean>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (name.length() > 0) existing.put(normalize(name), true);
        }
        for (String name : TLA.keySet()) {
            if (!existing.containsKey(normalize(name))) teams.put(teamObject(name));
        }
        root.put("teams", teams);
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE);
        if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        boolean current = start.startsWith("2026") && end.startsWith("2027");
        if (!current) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources");
        if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject pl = sources.optJSONObject(COMPETITION_CODE);
        if (pl == null) pl = new JSONObject();
        pl.put("status", "connected");
        pl.put("provider", "Premier League official fixture list + connected live source");
        pl.put("season", SEASON);
        pl.put("matchCount", matchCount);
        pl.put("teamCount", TLA.size());
        pl.put("roundCount", 38);
        sources.put(COMPETITION_CODE, pl);
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private PremierLeague2627Data() {}
}
