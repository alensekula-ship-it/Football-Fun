package com.asappfactory.footballfun.match;

/**
 * Vendor-neutral integration point for future verified/paid detailed match data.
 * Providers return normalized payloads. The current app may keep this unconfigured
 * until a suitable source is connected.
 */
public interface MatchDetailProvider {
    String providerId();
    boolean isConfigured();

    /** Team-level match statistics such as possession, shots and corners. */
    String fetchStatistics(String providerMatchId) throws Exception;

    /** Verified timeline events such as goals, cards, substitutions and VAR. */
    String fetchEvents(String providerMatchId) throws Exception;

    /** Verified lineups/bench payload. */
    String fetchLineups(String providerMatchId) throws Exception;
}
