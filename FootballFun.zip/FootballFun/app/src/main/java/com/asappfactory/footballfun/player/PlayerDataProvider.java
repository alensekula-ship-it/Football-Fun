package com.asappfactory.footballfun.player;

/**
 * Contract for a future paid player-data source.
 *
 * UI code must depend on this contract rather than on a vendor-specific API.
 * A provider implementation should return normalized JSON that follows
 * {@link PlayerPayloadContract}; MainActivity already understands that normalized
 * shape and can merge it into the central player index.
 */
public interface PlayerDataProvider {
    /** Stable provider identifier, e.g. "api-football" or "sportmonks". */
    String providerId();

    /** True only when credentials and the paid feature are available. */
    boolean isConfigured();

    /**
     * Fetch a complete verified squad for one canonical club.
     * Return normalized JSON or an empty string when no verified data exists.
     */
    String fetchSquad(String canonicalClubName) throws Exception;

    /**
     * Fetch one verified player profile by provider player id.
     * Return normalized JSON or an empty string when unavailable.
     */
    String fetchPlayerProfile(String providerPlayerId) throws Exception;
}
