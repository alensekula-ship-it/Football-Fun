package com.asappfactory.footballfun.data;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Small dependency-free image loader for club crests supplied by verified data.
 * Crests are cached in memory and on disk so the club directory stays fast and
 * does not download the same image every time it is opened.
 */
public final class ClubCrestCache {
    private static final int CONNECT_TIMEOUT_MS = 7000;
    private static final int READ_TIMEOUT_MS = 9000;
    private static final int MAX_DOWNLOAD_BYTES = 3 * 1024 * 1024;

    private final File diskDirectory;
    private final LruCache<String, Bitmap> memoryCache;
    private final ThreadPoolExecutor executor;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ConcurrentHashMap<String, PendingLoad> inFlight = new ConcurrentHashMap<String, PendingLoad>();
    private final AtomicInteger screenGeneration = new AtomicInteger(0);

    private static final class PendingLoad {
        final CopyOnWriteArrayList<WeakReference<ImageView>> targets = new CopyOnWriteArrayList<WeakReference<ImageView>>();
        final boolean cover;
        final int generation;
        PendingLoad(boolean cover, int generation) { this.cover = cover; this.generation = generation; }
        void add(ImageView target) { if (target != null) targets.add(new WeakReference<ImageView>(target)); }
    }

    public ClubCrestCache(Context context) {
        Context appContext = context.getApplicationContext();
        diskDirectory = new File(appContext.getCacheDir(), "club_crests");
        if (!diskDirectory.exists()) {
            //noinspection ResultOfMethodCallIgnored
            diskDirectory.mkdirs();
        }

        int maxMemoryKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheSizeKb = Math.max(2048, Math.min(8192, maxMemoryKb / 20));
        memoryCache = new LruCache<String, Bitmap>(cacheSizeKb) {
            @Override protected int sizeOf(String key, Bitmap bitmap) {
                return Math.max(1, bitmap.getByteCount() / 1024);
            }
        };

        ThreadFactory lowPriorityFactory = new ThreadFactory() {
            private int index = 0;
            @Override public synchronized Thread newThread(final Runnable runnable) {
                Thread thread = new Thread(new Runnable() {
                    @Override public void run() {
                        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); }
                        catch (Exception ignored) {}
                        runnable.run();
                    }
                }, "FootballFun-crest-" + (++index));
                thread.setDaemon(true);
                return thread;
            }
        };
        // Two low-priority workers are enough to keep scrolling responsive. A bounded
        // queue prevents rapid screen changes from accumulating hundreds of obsolete
        // bitmap downloads/decodes and triggering long GC pauses on the UI process.
        executor = new ThreadPoolExecutor(
                2, 2, 20L, TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(72),
                lowPriorityFactory,
                new ThreadPoolExecutor.AbortPolicy()
        );
        executor.allowCoreThreadTimeOut(true);
    }

    public void onScreenChanged() {
        screenGeneration.incrementAndGet();
        // Drop queued work for views that have just been detached. Running network
        // calls finish naturally, but their result is ignored by generation check.
        executor.getQueue().clear();
        inFlight.clear();
    }

    public void load(final ImageView target, final String identityKey, final String imageUrl) {
        loadInternal(target, identityKey, imageUrl, false);
    }

    /** Loads portrait-style imagery using a center-crop presentation. */
    public void loadCover(final ImageView target, final String identityKey, final String imageUrl) {
        loadInternal(target, identityKey, imageUrl, true);
    }

    private void loadInternal(final ImageView target, final String identityKey, final String imageUrl, final boolean cover) {
        if (target == null || imageUrl == null || imageUrl.trim().length() == 0) return;

        final String requestKey = identityKey + "|" + imageUrl + (cover ? "|cover" : "|inside");
        target.setTag(requestKey);

        Bitmap memory = memoryCache.get(requestKey);
        if (memory != null && !memory.isRecycled()) {
            showBitmap(target, memory, requestKey, cover);
            return;
        }

        final int requestGeneration = screenGeneration.get();
        PendingLoad created = new PendingLoad(cover, requestGeneration);
        created.add(target);
        PendingLoad existing = inFlight.putIfAbsent(requestKey, created);
        if (existing != null) {
            // One decode/download per crest, no matter how many recreated rows request it.
            existing.add(target);
            return;
        }

        try {
            executor.execute(new Runnable() {
                @Override public void run() {
                    Bitmap bitmap = null;
                    try {
                        File cachedFile = new File(diskDirectory, safeFileName(requestKey) + ".img");
                        if (cachedFile.exists() && cachedFile.length() > 0) bitmap = decodeFile(cachedFile);

                        if (bitmap == null) {
                            byte[] bytes = downloadWithCrestFallbacks(imageUrl);
                            if (bytes != null && bytes.length > 0) {
                                bitmap = decodeBytes(bytes);
                                if (bitmap != null) writeAtomically(cachedFile, bytes);
                            }
                        }

                        if (bitmap != null && !cover) bitmap = normalizeCrestBitmap(bitmap);
                        if (bitmap != null) memoryCache.put(requestKey, bitmap);
                    } finally {
                        final Bitmap ready = bitmap;
                        final PendingLoad pending = inFlight.remove(requestKey);
                        if (ready != null && pending != null && pending.generation == screenGeneration.get()) {
                            mainHandler.post(new Runnable() {
                                @Override public void run() {
                                    if (pending.generation != screenGeneration.get()) return;
                                    for (WeakReference<ImageView> reference : pending.targets) {
                                        ImageView view = reference.get();
                                        if (view != null) showBitmap(view, ready, requestKey, pending.cover);
                                    }
                                }
                            });
                        }
                    }
                }
            });
        } catch (RejectedExecutionException rejected) {
            inFlight.remove(requestKey);
        }
    }

    private void showBitmap(ImageView target, Bitmap bitmap, String requestKey, boolean cover) {
        Object current = target.getTag();
        if (current == null || !requestKey.equals(current.toString())) return;
        target.animate().cancel();
        target.setImageBitmap(bitmap);
        target.setScaleType(cover ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.CENTER_INSIDE);
        target.setAlpha(1f);
        target.setVisibility(View.VISIBLE);
        // Hide the neutral placeholder once a transparent club crest loads;
        // otherwise letters can remain visible through transparent PNG areas.
        if (target.getParent() instanceof ViewGroup) {
            ViewGroup parent = (ViewGroup) target.getParent();
            for (int i = 0; i < parent.getChildCount(); i++) {
                View sibling = parent.getChildAt(i);
                if (sibling != target) sibling.setVisibility(View.INVISIBLE);
            }
        }
    }


    /**
     * Makes transparent PNG crests optically consistent without maintaining
     * a growing list of team-specific scale multipliers.
     *
     * The visible alpha bounds are cropped, then fitted into a 256x256
     * transparent canvas with a small uniform safety margin. Aspect ratio is
     * preserved and the original bitmap is never modified.
     */
    private Bitmap normalizeCrestBitmap(Bitmap source) {
        if (source == null || source.isRecycled()) return source;

        // Never scan a multi-megapixel source. The displayed crest is at most a few
        // hundred pixels wide, so cap the working bitmap before alpha-bound analysis.
        int maxSide = Math.max(source.getWidth(), source.getHeight());
        if (maxSide > 512) {
            float ratio = 512f / maxSide;
            int scaledW = Math.max(1, Math.round(source.getWidth() * ratio));
            int scaledH = Math.max(1, Math.round(source.getHeight() * ratio));
            try { source = Bitmap.createScaledBitmap(source, scaledW, scaledH, true); }
            catch (Throwable ignored) {}
        }

        final int width = source.getWidth();
        final int height = source.getHeight();
        if (width <= 0 || height <= 0) return source;

        int left = width, top = height, right = -1, bottom = -1;
        final int alphaThreshold = 18;
        int[] row = new int[width];
        try {
            for (int y = 0; y < height; y++) {
                source.getPixels(row, 0, width, 0, y, width, 1);
                for (int x = 0; x < width; x++) {
                    int alpha = (row[x] >>> 24) & 0xff;
                    if (alpha <= alphaThreshold) continue;
                    if (x < left) left = x;
                    if (x > right) right = x;
                    if (y < top) top = y;
                    if (y > bottom) bottom = y;
                }
            }
        } catch (Throwable ignored) { return source; }

        if (right < left || bottom < top) return source;
        int visibleWidth = right - left + 1;
        int visibleHeight = bottom - top + 1;
        final int canvasSize = 256;
        final int target = 216;
        float scale = Math.min(target / (float)Math.max(1, visibleWidth), target / (float)Math.max(1, visibleHeight));
        float drawWidth = visibleWidth * scale;
        float drawHeight = visibleHeight * scale;
        float dx = (canvasSize - drawWidth) / 2f;
        float dy = (canvasSize - drawHeight) / 2f;

        try {
            Bitmap result = Bitmap.createBitmap(canvasSize, canvasSize, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(result);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
            Rect src = new Rect(left, top, right + 1, bottom + 1);
            RectF dst = new RectF(dx, dy, dx + drawWidth, dy + drawHeight);
            canvas.drawBitmap(source, src, dst, paint);
            return result;
        } catch (Throwable ignored) { return source; }
    }

    private Bitmap decodeFile(File file) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            BitmapFactory.Options options = sampledOptions(bounds.outWidth, bounds.outHeight);
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), options);
            if (bitmap == null) file.delete();
            return bitmap;
        } catch (Exception ignored) {
            file.delete();
            return null;
        }
    }

    private Bitmap decodeBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            BitmapFactory.Options options = sampledOptions(bounds.outWidth, bounds.outHeight);
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
        } catch (Throwable ignored) { return null; }
    }

    private BitmapFactory.Options sampledOptions(int width, int height) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        int largest = Math.max(width, height);
        int sample = 1;
        while (largest / sample > 512 && sample < 16) sample *= 2;
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return options;
    }


    /**
     * ESPN occasionally omits one badge size even though another raster size is
     * available. Try the supplied URL first, then the equivalent 500/100 and
     * dark variants before keeping the clean neutral fallback.
     */
    private byte[] downloadWithCrestFallbacks(String imageUrl) {
        String[] candidates = crestCandidates(imageUrl);
        for (String candidate : candidates) {
            if (candidate == null || candidate.length() == 0) continue;
            byte[] bytes = download(candidate);
            if (bytes != null && bytes.length > 0) return bytes;
        }
        return null;
    }

    private String[] crestCandidates(String imageUrl) {
        if (imageUrl == null) return new String[0];
        String clean = imageUrl.trim();
        if (!clean.contains("a.espncdn.com/i/teamlogos/soccer/")) {
            return new String[]{clean};
        }
        String size500 = clean.replace("/soccer/100/", "/soccer/500/")
                .replace("/soccer/100-dark/", "/soccer/500-dark/");
        String size100 = clean.replace("/soccer/500/", "/soccer/100/")
                .replace("/soccer/500-dark/", "/soccer/100-dark/");
        String dark500 = size500.replace("/soccer/500/", "/soccer/500-dark/");
        String dark100 = size100.replace("/soccer/100/", "/soccer/100-dark/");
        return new String[]{clean, size500, size100, dark500, dark100};
    }

    private byte[] download(String imageUrl) {
        HttpURLConnection connection = null;
        InputStream input = null;
        try {
            connection = (HttpURLConnection) new URL(imageUrl).openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Accept", "image/png,image/webp,image/jpeg,image/*;q=0.8");
            connection.setRequestProperty("User-Agent", "FootballFun/5.67.16");

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;

            String contentType = connection.getContentType();
            if (contentType != null && contentType.toLowerCase().contains("svg")) {
                // Android's BitmapFactory cannot rasterize SVG without an extra library.
                // Keep the clean neutral fallback rather than showing a broken image.
                return null;
            }

            input = connection.getInputStream();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_DOWNLOAD_BYTES) return null;
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        } catch (Exception ignored) {
            return null;
        } finally {
            try { if (input != null) input.close(); } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private void writeAtomically(File destination, byte[] bytes) {
        File temp = new File(destination.getParentFile(), destination.getName() + ".tmp");
        FileOutputStream output = null;
        try {
            output = new FileOutputStream(temp);
            output.write(bytes);
            output.flush();
            if (destination.exists()) {
                //noinspection ResultOfMethodCallIgnored
                destination.delete();
            }
            //noinspection ResultOfMethodCallIgnored
            temp.renameTo(destination);
        } catch (Exception ignored) {
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        } finally {
            try { if (output != null) output.close(); } catch (Exception ignored) {}
        }
    }

    private String safeFileName(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes("UTF-8"));
            StringBuilder result = new StringBuilder();
            for (byte item : hash) result.append(String.format("%02x", item));
            return result.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
