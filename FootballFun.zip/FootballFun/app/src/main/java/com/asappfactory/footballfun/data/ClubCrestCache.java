package com.asappfactory.footballfun.data;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.widget.ImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small dependency-free image loader for club crests supplied by verified data.
 * Crests are cached in memory and on disk so the club directory stays fast and
 * does not download the same image every time it is opened.
 */
public final class ClubCrestCache {
    private static final int CONNECT_TIMEOUT_MS = 7000;
    private static final int READ_TIMEOUT_MS = 9000;
    private static final int MAX_DOWNLOAD_BYTES = 3 * 1024 * 1024;

    private final File diskDirectory;
    private final LruCache<String, Bitmap> memoryCache;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public ClubCrestCache(Context context) {
        Context appContext = context.getApplicationContext();
        diskDirectory = new File(appContext.getCacheDir(), "club_crests");
        if (!diskDirectory.exists()) {
            //noinspection ResultOfMethodCallIgnored
            diskDirectory.mkdirs();
        }

        int maxMemoryKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        int cacheSizeKb = Math.max(2048, Math.min(12288, maxMemoryKb / 16));
        memoryCache = new LruCache<String, Bitmap>(cacheSizeKb) {
            @Override protected int sizeOf(String key, Bitmap bitmap) {
                return Math.max(1, bitmap.getByteCount() / 1024);
            }
        };
    }

    public void load(final ImageView target, final String identityKey, final String imageUrl) {
        if (target == null || imageUrl == null || imageUrl.trim().length() == 0) return;

        final String requestKey = identityKey + "|" + imageUrl;
        target.setTag(requestKey);

        Bitmap memory = memoryCache.get(requestKey);
        if (memory != null && !memory.isRecycled()) {
            showBitmap(target, memory, requestKey);
            return;
        }

        executor.execute(new Runnable() {
            @Override public void run() {
                Bitmap bitmap = null;
                File cachedFile = new File(diskDirectory, safeFileName(requestKey) + ".img");

                if (cachedFile.exists() && cachedFile.length() > 0) {
                    bitmap = decodeFile(cachedFile);
                }

                if (bitmap == null) {
                    byte[] bytes = download(imageUrl);
                    if (bytes != null && bytes.length > 0) {
                        bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                        if (bitmap != null) writeAtomically(cachedFile, bytes);
                    }
                }

                if (bitmap == null) return;
                memoryCache.put(requestKey, bitmap);
                final Bitmap ready = bitmap;
                mainHandler.post(new Runnable() {
                    @Override public void run() {
                        showBitmap(target, ready, requestKey);
                    }
                });
            }
        });
    }

    private void showBitmap(ImageView target, Bitmap bitmap, String requestKey) {
        Object current = target.getTag();
        if (current == null || !requestKey.equals(current.toString())) return;
        target.setImageBitmap(bitmap);
        target.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        target.setVisibility(View.VISIBLE);
    }

    private Bitmap decodeFile(File file) {
        FileInputStream stream = null;
        try {
            stream = new FileInputStream(file);
            return BitmapFactory.decodeStream(stream);
        } catch (Exception ignored) {
            //noinspection ResultOfMethodCallIgnored
            file.delete();
            return null;
        } finally {
            try { if (stream != null) stream.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] download(String imageUrl) {
        HttpURLConnection connection = null;
        InputStream input = null;
        try {
            connection = (HttpURLConnection) new URL(imageUrl).openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("Accept", "image/png,image/webp,image/jpeg,image/*;q=0.8");
            connection.setRequestProperty("User-Agent", "FootballFun/5.20.1");

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;

            String contentType = connection.getContentType();
            if (contentType != null && contentType.toLowerCase().contains("svg")) {
                // Android's BitmapFactory cannot rasterize SVG without an extra library.
                // Keep the clean initials fallback rather than showing a broken image.
                return null;
            }

            input = connection.getInputStream();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_DOWNLOAD_BYTES) return null;
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        } catch (Exception ignored) {
            return null;
        } finally {
            try { if (input != null) input.close(); } catch (Exception ignored) {}
            if (connection != null) connection.disconnect();
        }
    }

    private void writeAtomically(File destination, byte[] bytes) {
        File temp = new File(destination.getParentFile(), destination.getName() + ".tmp");
        FileOutputStream output = null;
        try {
            output = new FileOutputStream(temp);
            output.write(bytes);
            output.flush();
            if (destination.exists()) {
                //noinspection ResultOfMethodCallIgnored
                destination.delete();
            }
            //noinspection ResultOfMethodCallIgnored
            temp.renameTo(destination);
        } catch (Exception ignored) {
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        } finally {
            try { if (output != null) output.close(); } catch (Exception ignored) {}
        }
    }

    private String safeFileName(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(value.getBytes("UTF-8"));
            StringBuilder result = new StringBuilder();
            for (byte item : hash) result.append(String.format("%02x", item));
            return result.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode());
        }
    }
}
