package com.asappfactory.footballfun.core;

import com.asappfactory.footballfun.BuildConfig;

/** Stable application-wide configuration. Keep screen code free of infrastructure constants. */
public final class AppConfig {
    /** Internal QA switch. Public release builds never unlock Pro automatically. */
    public static final boolean QA_UNLOCK_ALL_PRO = BuildConfig.DEBUG;
    /** Debug builds use Google's demo ad units; release builds use Football Fun production units. */
    public static final boolean USE_TEST_ADS = BuildConfig.DEBUG;
    /** Point 11 Release Candidate: monetization paths are active. */
    public static final boolean MONETIZATION_RELEASE_CANDIDATE = true;
    public static final boolean ENABLE_PLAYER_DATA_MODULES = false;
    /** Future paid-source adapter switch. Keep false until credentials/provider are connected. */
    public static final String PLAYER_DATA_PROVIDER_ID = "none";
    public static final int PLAYER_DATA_SCHEMA_VERSION = 1;
    public static final boolean ENABLE_CARDS_LINEUPS_MODULES = false;
    /** Point 4 contract: detailed match data is source-driven and never fabricated. */
    public static final String MATCH_DETAIL_PROVIDER_ID = "connected-feed";
    public static final int MATCH_DETAIL_SCHEMA_VERSION = 1;
    public static final boolean ENABLE_PAID_MATCH_DISCIPLINE_MODULES = false;
    public static final int TOURNAMENT_TOTAL_MATCHES = 104;
    /** Normal background refresh when no match is live or near kickoff. */
    public static final long AUTO_REFRESH_MS = 15L * 60L * 1000L;
    /** Fast central-feed refresh while a match is live or within the kickoff window. */
    public static final long ACTIVE_FOOTBALL_REFRESH_MS = 60L * 1000L;
    /** Match-details refresh uses the same one-minute production cadence. */
    public static final long LIVE_MATCH_REFRESH_MS = 60L * 1000L;
    /** Start fast refresh two hours before a verified kickoff and retain the existing grace window. */
    public static final long ACTIVE_FOOTBALL_WINDOW_MS = 2L * 60L * 60L * 1000L;
    public static final long MATCH_START_GRACE_MS = 2L * 60L * 60L * 1000L;

    private AppConfig() {}
}
