package com.asappfactory.footballfun.core;

/** Stable application-wide configuration. Keep screen code free of infrastructure constants. */
public final class AppConfig {
    public static final boolean ENABLE_PLAYER_DATA_MODULES = false;
    public static final boolean ENABLE_CARDS_LINEUPS_MODULES = true;
    public static final int TOURNAMENT_TOTAL_MATCHES = 104;
    public static final long AUTO_REFRESH_MS = 15L * 60L * 1000L;
    public static final long LIVE_MATCH_REFRESH_MS = 60L * 1000L;
    public static final long MATCH_START_GRACE_MS = 2L * 60L * 60L * 1000L;

    private AppConfig() {}
}
