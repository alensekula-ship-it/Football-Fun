package com.asappfactory.footballfun.timeline;

public interface TimelineEnvironment {
    String text(String en, String hr, String de, String es, String fr);
    String displayTeamName(String team);
    int parseMinute(String value);
    boolean isFinished(String status);
}
