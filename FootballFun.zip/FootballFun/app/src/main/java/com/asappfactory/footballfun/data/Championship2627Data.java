package com.asappfactory.footballfun.data;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Complete verified EFL Championship 2026/27 fixture fallback.
 *
 * The bundled list keeps all 24 clubs, 46 rounds and 552 fixtures available
 * before the connected provider exposes the new season. Matching connected
 * rows are merged over the fallback so live status, scores and later fixture
 * changes still win without creating duplicates.
 */
public final class Championship2627Data {
    private static final String COMPETITION_NAME = "Championship";
    private static final String COMPETITION_CODE = "ELC";
    private static final String SEASON = "2026/27";
    private static final String FIRST_DATE = "2026-08-14";
    private static final String LAST_DATE = "2027-05-01";

    private static final String DATA =
            "2026-08-14T19:00:00Z|1|Wolverhampton Wanderers|Blackburn Rovers|Molineux Stadium|TIMED\n" +
            "2026-08-15T11:30:00Z|1|Bolton Wanderers|Preston North End|Toughsheet Community Stadium|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Bristol City|Millwall|Ashton Gate Stadium|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Charlton Athletic|Derby County|The Valley|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Middlesbrough|Lincoln City|Riverside Stadium|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Norwich City|West Bromwich Albion|Carrow Road|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Portsmouth|Queens Park Rangers|Fratton Park|TIMED\n" +
            "2026-08-15T14:00:00Z|1|Stoke City|Swansea City|bet365 Stadium|TIMED\n" +
            "2026-08-15T16:30:00Z|1|Sheffield United|Birmingham City|Bramall Lane|TIMED\n" +
            "2026-08-16T12:30:00Z|1|Watford|Southampton|Vicarage Road|TIMED\n" +
            "2026-08-16T15:00:00Z|1|Burnley|West Ham United|Turf Moor|TIMED\n" +
            "2026-08-17T19:00:00Z|1|Cardiff City|Wrexham|Cardiff City Stadium|TIMED\n" +
            "2026-08-22T11:30:00Z|2|Birmingham City|Bristol City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-08-22T11:30:00Z|2|Lincoln City|Portsmouth|LNER Stadium|TIMED\n" +
            "2026-08-22T11:30:00Z|2|Millwall|Norwich City|The Den|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Blackburn Rovers|Middlesbrough|Ewood Park|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Derby County|Cardiff City|Pride Park Stadium|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Preston North End|Wolverhampton Wanderers|Deepdale|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Queens Park Rangers|Bolton Wanderers|MATRADE Loftus Road|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Southampton|Stoke City|St. Mary's Stadium|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Swansea City|Sheffield United|Swansea.com Stadium|TIMED\n" +
            "2026-08-22T14:00:00Z|2|West Ham United|Charlton Athletic|London Stadium|TIMED\n" +
            "2026-08-22T14:00:00Z|2|Wrexham|Watford|Racecourse Ground|TIMED\n" +
            "2026-08-23T11:00:00Z|2|West Bromwich Albion|Burnley|The Hawthorns|TIMED\n" +
            "2026-08-28T19:00:00Z|3|Wrexham|Birmingham City|Racecourse Ground|TIMED\n" +
            "2026-08-29T11:30:00Z|3|Derby County|Swansea City|Pride Park Stadium|TIMED\n" +
            "2026-08-29T11:30:00Z|3|Middlesbrough|West Bromwich Albion|Riverside Stadium|TIMED\n" +
            "2026-08-29T11:30:00Z|3|Wolverhampton Wanderers|Stoke City|Molineux Stadium|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Blackburn Rovers|Queens Park Rangers|Ewood Park|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Bolton Wanderers|Lincoln City|Toughsheet Community Stadium|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Bristol City|Portsmouth|Ashton Gate Stadium|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Cardiff City|Sheffield United|Cardiff City Stadium|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Charlton Athletic|Preston North End|The Valley|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Norwich City|Burnley|Carrow Road|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Southampton|Millwall|St. Mary's Stadium|TIMED\n" +
            "2026-08-29T14:00:00Z|3|Watford|West Ham United|Vicarage Road|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Birmingham City|Southampton|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Lincoln City|Blackburn Rovers|LNER Stadium|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Portsmouth|Derby County|Fratton Park|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Preston North End|Bristol City|Deepdale|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Sheffield United|Bolton Wanderers|Bramall Lane|TIMED\n" +
            "2026-09-01T18:45:00Z|4|Swansea City|Watford|Swansea.com Stadium|TIMED\n" +
            "2026-09-01T18:45:00Z|4|West Ham United|Wolverhampton Wanderers|London Stadium|TIMED\n" +
            "2026-09-01T19:00:00Z|4|Stoke City|Norwich City|bet365 Stadium|TIMED\n" +
            "2026-09-02T18:45:00Z|4|Millwall|Wrexham|The Den|TIMED\n" +
            "2026-09-02T18:45:00Z|4|Queens Park Rangers|Cardiff City|MATRADE Loftus Road|TIMED\n" +
            "2026-09-02T18:45:00Z|4|West Bromwich Albion|Charlton Athletic|The Hawthorns|TIMED\n" +
            "2026-09-02T19:00:00Z|4|Burnley|Middlesbrough|Turf Moor|TIMED\n" +
            "2026-09-05T11:30:00Z|5|Lincoln City|Southampton|LNER Stadium|TIMED\n" +
            "2026-09-05T11:30:00Z|5|Preston North End|Blackburn Rovers|Deepdale|TIMED\n" +
            "2026-09-05T11:30:00Z|5|Stoke City|Charlton Athletic|bet365 Stadium|TIMED\n" +
            "2026-09-05T14:00:00Z|5|Burnley|Bristol City|Turf Moor|TIMED\n" +
            "2026-09-05T14:00:00Z|5|Millwall|Bolton Wanderers|The Den|TIMED\n" +
            "2026-09-05T14:00:00Z|5|Portsmouth|Cardiff City|Fratton Park|TIMED\n" +
            "2026-09-05T14:00:00Z|5|Queens Park Rangers|Middlesbrough|MATRADE Loftus Road|TIMED\n" +
            "2026-09-05T14:00:00Z|5|Sheffield United|Norwich City|Bramall Lane|TIMED\n" +
            "2026-09-05T14:00:00Z|5|West Bromwich Albion|Watford|The Hawthorns|TIMED\n" +
            "2026-09-05T14:00:00Z|5|West Ham United|Derby County|London Stadium|TIMED\n" +
            "2026-09-05T19:00:00Z|5|Swansea City|Wrexham|Swansea.com Stadium|TIMED\n" +
            "2026-09-06T11:00:00Z|5|Birmingham City|Wolverhampton Wanderers|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Blackburn Rovers|Sheffield United|Ewood Park|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Bristol City|Lincoln City|Ashton Gate Stadium|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Cardiff City|Stoke City|Cardiff City Stadium|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Middlesbrough|Millwall|Riverside Stadium|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Southampton|Swansea City|St. Mary's Stadium|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Watford|Preston North End|Vicarage Road|TIMED\n" +
            "2026-09-08T18:45:00Z|6|Wrexham|Burnley|Racecourse Ground|TIMED\n" +
            "2026-09-08T19:00:00Z|6|Bolton Wanderers|West Ham United|Toughsheet Community Stadium|TIMED\n" +
            "2026-09-09T18:45:00Z|6|Wolverhampton Wanderers|Portsmouth|Molineux Stadium|TIMED\n" +
            "2026-09-09T18:45:00Z|6|Derby County|West Bromwich Albion|Pride Park Stadium|TIMED\n" +
            "2026-09-09T18:45:00Z|6|Norwich City|Birmingham City|Carrow Road|TIMED\n" +
            "2026-09-09T19:00:00Z|6|Charlton Athletic|Queens Park Rangers|The Valley|TIMED\n" +
            "2026-09-11T19:00:00Z|7|West Ham United|Wrexham|London Stadium|TIMED\n" +
            "2026-09-12T11:30:00Z|7|Bolton Wanderers|Cardiff City|Toughsheet Community Stadium|TIMED\n" +
            "2026-09-12T11:30:00Z|7|Derby County|Birmingham City|Pride Park Stadium|TIMED\n" +
            "2026-09-12T11:30:00Z|7|West Bromwich Albion|Queens Park Rangers|The Hawthorns|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Blackburn Rovers|Millwall|Ewood Park|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Charlton Athletic|Portsmouth|The Valley|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Middlesbrough|Norwich City|Riverside Stadium|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Preston North End|Lincoln City|Deepdale|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Southampton|Bristol City|St. Mary's Stadium|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Swansea City|Burnley|Swansea.com Stadium|TIMED\n" +
            "2026-09-12T14:00:00Z|7|Watford|Stoke City|Vicarage Road|TIMED\n" +
            "2026-09-13T11:00:00Z|7|Sheffield United|Wolverhampton Wanderers|Bramall Lane|TIMED\n" +
            "2026-09-18T19:00:00Z|8|Bristol City|Watford|Ashton Gate Stadium|TIMED\n" +
            "2026-09-19T11:30:00Z|8|Cardiff City|Charlton Athletic|Cardiff City Stadium|TIMED\n" +
            "2026-09-19T11:30:00Z|8|Millwall|West Ham United|The Den|TIMED\n" +
            "2026-09-19T11:30:00Z|8|Stoke City|Sheffield United|bet365 Stadium|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Birmingham City|Middlesbrough|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Burnley|Derby County|Turf Moor|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Lincoln City|Swansea City|LNER Stadium|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Norwich City|Bolton Wanderers|Carrow Road|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Portsmouth|Blackburn Rovers|Fratton Park|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Queens Park Rangers|Preston North End|MATRADE Loftus Road|TIMED\n" +
            "2026-09-19T14:00:00Z|8|Wrexham|Southampton|Racecourse Ground|TIMED\n" +
            "2026-09-20T11:00:00Z|8|Wolverhampton Wanderers|West Bromwich Albion|Molineux Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Blackburn Rovers|Cardiff City|Ewood Park|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Bolton Wanderers|Stoke City|Toughsheet Community Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Charlton Athletic|Bristol City|The Valley|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Derby County|Wrexham|Pride Park Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Middlesbrough|Wolverhampton Wanderers|Riverside Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Preston North End|Millwall|Deepdale|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Sheffield United|Lincoln City|Bramall Lane|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Southampton|Portsmouth|St. Mary's Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Swansea City|Norwich City|Swansea.com Stadium|TIMED\n" +
            "2026-10-10T14:00:00Z|9|Watford|Burnley|Vicarage Road|TIMED\n" +
            "2026-10-10T14:00:00Z|9|West Bromwich Albion|Birmingham City|The Hawthorns|TIMED\n" +
            "2026-10-10T14:00:00Z|9|West Ham United|Queens Park Rangers|London Stadium|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Birmingham City|Preston North End|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Bristol City|Blackburn Rovers|Ashton Gate Stadium|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Burnley|Charlton Athletic|Turf Moor|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Cardiff City|Watford|Cardiff City Stadium|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Millwall|Swansea City|The Den|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Stoke City|Middlesbrough|bet365 Stadium|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Wolverhampton Wanderers|Bolton Wanderers|Molineux Stadium|TIMED\n" +
            "2026-10-13T18:45:00Z|10|Wrexham|West Bromwich Albion|Racecourse Ground|TIMED\n" +
            "2026-10-14T18:45:00Z|10|Lincoln City|West Ham United|LNER Stadium|TIMED\n" +
            "2026-10-14T18:45:00Z|10|Norwich City|Southampton|Carrow Road|TIMED\n" +
            "2026-10-14T18:45:00Z|10|Portsmouth|Sheffield United|Fratton Park|TIMED\n" +
            "2026-10-14T18:45:00Z|10|Queens Park Rangers|Derby County|MATRADE Loftus Road|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Birmingham City|Queens Park Rangers|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Bristol City|Sheffield United|Ashton Gate Stadium|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Burnley|Wolverhampton Wanderers|Turf Moor|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Derby County|Stoke City|Pride Park Stadium|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Middlesbrough|Cardiff City|Riverside Stadium|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Millwall|Lincoln City|The Den|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Norwich City|Portsmouth|Carrow Road|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Southampton|Bolton Wanderers|St. Mary's Stadium|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Swansea City|West Ham United|Swansea.com Stadium|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Watford|Charlton Athletic|Vicarage Road|TIMED\n" +
            "2026-10-17T14:00:00Z|11|West Bromwich Albion|Blackburn Rovers|The Hawthorns|TIMED\n" +
            "2026-10-17T14:00:00Z|11|Wrexham|Preston North End|Racecourse Ground|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Blackburn Rovers|Wrexham|Ewood Park|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Bolton Wanderers|Middlesbrough|Toughsheet Community Stadium|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Cardiff City|Birmingham City|Cardiff City Stadium|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Charlton Athletic|Norwich City|The Valley|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Lincoln City|Burnley|LNER Stadium|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Portsmouth|Millwall|Fratton Park|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Preston North End|West Bromwich Albion|Deepdale|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Queens Park Rangers|Swansea City|MATRADE Loftus Road|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Sheffield United|Derby County|Bramall Lane|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Stoke City|Bristol City|bet365 Stadium|TIMED\n" +
            "2026-10-24T14:00:00Z|12|West Ham United|Southampton|London Stadium|TIMED\n" +
            "2026-10-24T14:00:00Z|12|Wolverhampton Wanderers|Watford|Molineux Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Bolton Wanderers|Bristol City|Toughsheet Community Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Burnley|Portsmouth|Turf Moor|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Lincoln City|Birmingham City|LNER Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Middlesbrough|Charlton Athletic|Riverside Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Millwall|Derby County|The Den|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Norwich City|Watford|Carrow Road|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Sheffield United|Wrexham|Bramall Lane|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Southampton|Queens Park Rangers|St. Mary's Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Stoke City|Preston North End|bet365 Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Swansea City|Blackburn Rovers|Swansea.com Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|West Ham United|West Bromwich Albion|London Stadium|TIMED\n" +
            "2026-10-31T15:00:00Z|13|Wolverhampton Wanderers|Cardiff City|Molineux Stadium|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Birmingham City|Millwall|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Blackburn Rovers|Stoke City|Ewood Park|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Derby County|Norwich City|Pride Park Stadium|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Portsmouth|Swansea City|Fratton Park|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Preston North End|Sheffield United|Deepdale|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Queens Park Rangers|Burnley|MATRADE Loftus Road|TIMED\n" +
            "2026-11-03T19:45:00Z|14|Watford|Lincoln City|Vicarage Road|TIMED\n" +
            "2026-11-03T19:45:00Z|14|West Bromwich Albion|Southampton|The Hawthorns|TIMED\n" +
            "2026-11-04T19:45:00Z|14|Bristol City|Wolverhampton Wanderers|Ashton Gate Stadium|TIMED\n" +
            "2026-11-04T19:45:00Z|14|Cardiff City|West Ham United|Cardiff City Stadium|TIMED\n" +
            "2026-11-04T19:45:00Z|14|Charlton Athletic|Bolton Wanderers|The Valley|TIMED\n" +
            "2026-11-04T19:45:00Z|14|Wrexham|Middlesbrough|Racecourse Ground|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Birmingham City|Swansea City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Blackburn Rovers|West Ham United|Ewood Park|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Bristol City|Norwich City|Ashton Gate Stadium|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Cardiff City|Burnley|Cardiff City Stadium|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Charlton Athletic|Sheffield United|The Valley|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Derby County|Bolton Wanderers|Pride Park Stadium|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Portsmouth|Stoke City|Fratton Park|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Preston North End|Southampton|Deepdale|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Queens Park Rangers|Lincoln City|MATRADE Loftus Road|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Watford|Middlesbrough|Vicarage Road|TIMED\n" +
            "2026-11-07T15:00:00Z|15|West Bromwich Albion|Millwall|The Hawthorns|TIMED\n" +
            "2026-11-07T15:00:00Z|15|Wrexham|Wolverhampton Wanderers|Racecourse Ground|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Bolton Wanderers|Portsmouth|Toughsheet Community Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Burnley|Blackburn Rovers|Turf Moor|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Lincoln City|Wrexham|LNER Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Middlesbrough|Bristol City|Riverside Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Millwall|Queens Park Rangers|The Den|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Norwich City|Cardiff City|Carrow Road|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Sheffield United|Watford|Bramall Lane|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Southampton|Derby County|St. Mary's Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Stoke City|Birmingham City|bet365 Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Swansea City|West Bromwich Albion|Swansea.com Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|West Ham United|Preston North End|London Stadium|TIMED\n" +
            "2026-11-21T15:00:00Z|16|Wolverhampton Wanderers|Charlton Athletic|Molineux Stadium|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Bristol City|Wrexham|Ashton Gate Stadium|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Cardiff City|Preston North End|Cardiff City Stadium|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Charlton Athletic|Lincoln City|The Valley|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Middlesbrough|Swansea City|Riverside Stadium|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Norwich City|Queens Park Rangers|Carrow Road|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Portsmouth|West Ham United|Fratton Park|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Sheffield United|Southampton|Bramall Lane|TIMED\n" +
            "2026-11-24T19:45:00Z|17|Wolverhampton Wanderers|Derby County|Molineux Stadium|TIMED\n" +
            "2026-11-25T19:45:00Z|17|Bolton Wanderers|West Bromwich Albion|Toughsheet Community Stadium|TIMED\n" +
            "2026-11-25T19:45:00Z|17|Burnley|Birmingham City|Turf Moor|TIMED\n" +
            "2026-11-25T19:45:00Z|17|Stoke City|Millwall|bet365 Stadium|TIMED\n" +
            "2026-11-25T19:45:00Z|17|Watford|Blackburn Rovers|Vicarage Road|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Birmingham City|Bolton Wanderers|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Blackburn Rovers|Charlton Athletic|Ewood Park|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Derby County|Watford|Pride Park Stadium|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Lincoln City|Wolverhampton Wanderers|LNER Stadium|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Millwall|Burnley|The Den|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Preston North End|Norwich City|Deepdale|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Queens Park Rangers|Sheffield United|MATRADE Loftus Road|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Southampton|Middlesbrough|St. Mary's Stadium|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Swansea City|Cardiff City|Swansea.com Stadium|TIMED\n" +
            "2026-11-28T15:00:00Z|18|West Bromwich Albion|Bristol City|The Hawthorns|TIMED\n" +
            "2026-11-28T15:00:00Z|18|West Ham United|Stoke City|London Stadium|TIMED\n" +
            "2026-11-28T15:00:00Z|18|Wrexham|Portsmouth|Racecourse Ground|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Bolton Wanderers|Blackburn Rovers|Toughsheet Community Stadium|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Bristol City|Swansea City|Ashton Gate Stadium|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Burnley|Preston North End|Turf Moor|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Cardiff City|Lincoln City|Cardiff City Stadium|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Charlton Athletic|Birmingham City|The Valley|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Middlesbrough|Derby County|Riverside Stadium|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Norwich City|Wrexham|Carrow Road|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Portsmouth|West Bromwich Albion|Fratton Park|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Sheffield United|West Ham United|Bramall Lane|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Stoke City|Queens Park Rangers|bet365 Stadium|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Watford|Millwall|Vicarage Road|TIMED\n" +
            "2026-12-05T15:00:00Z|19|Wolverhampton Wanderers|Southampton|Molineux Stadium|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Birmingham City|Watford|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Blackburn Rovers|Norwich City|Ewood Park|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Millwall|Sheffield United|The Den|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Queens Park Rangers|Wolverhampton Wanderers|MATRADE Loftus Road|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Swansea City|Bolton Wanderers|Swansea.com Stadium|TIMED\n" +
            "2026-12-08T19:45:00Z|20|West Bromwich Albion|Cardiff City|The Hawthorns|TIMED\n" +
            "2026-12-08T19:45:00Z|20|West Ham United|Middlesbrough|London Stadium|TIMED\n" +
            "2026-12-08T19:45:00Z|20|Wrexham|Charlton Athletic|Racecourse Ground|TIMED\n" +
            "2026-12-09T19:45:00Z|20|Derby County|Bristol City|Pride Park Stadium|TIMED\n" +
            "2026-12-09T19:45:00Z|20|Lincoln City|Stoke City|LNER Stadium|TIMED\n" +
            "2026-12-09T19:45:00Z|20|Preston North End|Portsmouth|Deepdale|TIMED\n" +
            "2026-12-09T19:45:00Z|20|Southampton|Burnley|St. Mary's Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Blackburn Rovers|Derby County|Ewood Park|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Bolton Wanderers|Wrexham|Toughsheet Community Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Cardiff City|Southampton|Cardiff City Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Charlton Athletic|Swansea City|The Valley|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Lincoln City|Norwich City|LNER Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Portsmouth|Birmingham City|Fratton Park|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Preston North End|Middlesbrough|Deepdale|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Queens Park Rangers|Watford|MATRADE Loftus Road|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Sheffield United|Burnley|Bramall Lane|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Stoke City|West Bromwich Albion|bet365 Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|West Ham United|Bristol City|London Stadium|TIMED\n" +
            "2026-12-12T15:00:00Z|21|Wolverhampton Wanderers|Millwall|Molineux Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Birmingham City|West Ham United|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Bristol City|Cardiff City|Ashton Gate Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Burnley|Stoke City|Turf Moor|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Derby County|Lincoln City|Pride Park Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Middlesbrough|Portsmouth|Riverside Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Millwall|Charlton Athletic|The Den|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Norwich City|Wolverhampton Wanderers|Carrow Road|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Southampton|Blackburn Rovers|St. Mary's Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Swansea City|Preston North End|Swansea.com Stadium|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Watford|Bolton Wanderers|Vicarage Road|TIMED\n" +
            "2026-12-19T15:00:00Z|22|West Bromwich Albion|Sheffield United|The Hawthorns|TIMED\n" +
            "2026-12-19T15:00:00Z|22|Wrexham|Queens Park Rangers|Racecourse Ground|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Blackburn Rovers|Birmingham City|Ewood Park|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Bolton Wanderers|Burnley|Toughsheet Community Stadium|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Cardiff City|Millwall|Cardiff City Stadium|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Charlton Athletic|Southampton|The Valley|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Lincoln City|West Bromwich Albion|LNER Stadium|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Portsmouth|Watford|Fratton Park|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Preston North End|Derby County|Deepdale|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Queens Park Rangers|Bristol City|MATRADE Loftus Road|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Sheffield United|Middlesbrough|Bramall Lane|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Stoke City|Wrexham|bet365 Stadium|TIMED\n" +
            "2026-12-26T15:00:00Z|23|West Ham United|Norwich City|London Stadium|TIMED\n" +
            "2026-12-26T15:00:00Z|23|Wolverhampton Wanderers|Swansea City|Molineux Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Birmingham City|Cardiff City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Bristol City|Stoke City|Ashton Gate Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Burnley|Lincoln City|Turf Moor|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Derby County|Sheffield United|Pride Park Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Middlesbrough|Bolton Wanderers|Riverside Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Millwall|Portsmouth|The Den|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Norwich City|Charlton Athletic|Carrow Road|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Southampton|West Ham United|St. Mary's Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Swansea City|Queens Park Rangers|Swansea.com Stadium|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Watford|Wolverhampton Wanderers|Vicarage Road|TIMED\n" +
            "2026-12-29T19:45:00Z|24|West Bromwich Albion|Preston North End|The Hawthorns|TIMED\n" +
            "2026-12-29T19:45:00Z|24|Wrexham|Blackburn Rovers|Racecourse Ground|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Birmingham City|Portsmouth|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Bristol City|West Ham United|Ashton Gate Stadium|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Burnley|Sheffield United|Turf Moor|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Derby County|Blackburn Rovers|Pride Park Stadium|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Middlesbrough|Preston North End|Riverside Stadium|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Millwall|Wolverhampton Wanderers|The Den|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Norwich City|Lincoln City|Carrow Road|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Southampton|Cardiff City|St. Mary's Stadium|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Swansea City|Charlton Athletic|Swansea.com Stadium|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Watford|Queens Park Rangers|Vicarage Road|TIMED\n" +
            "2027-01-01T15:00:00Z|25|West Bromwich Albion|Stoke City|The Hawthorns|TIMED\n" +
            "2027-01-01T15:00:00Z|25|Wrexham|Bolton Wanderers|Racecourse Ground|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Blackburn Rovers|West Bromwich Albion|Ewood Park|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Bolton Wanderers|Southampton|Toughsheet Community Stadium|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Cardiff City|Middlesbrough|Cardiff City Stadium|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Charlton Athletic|Watford|The Valley|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Lincoln City|Millwall|LNER Stadium|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Portsmouth|Norwich City|Fratton Park|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Preston North End|Wrexham|Deepdale|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Queens Park Rangers|Birmingham City|MATRADE Loftus Road|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Sheffield United|Bristol City|Bramall Lane|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Stoke City|Derby County|bet365 Stadium|TIMED\n" +
            "2027-01-16T15:00:00Z|26|West Ham United|Swansea City|London Stadium|TIMED\n" +
            "2027-01-16T15:00:00Z|26|Wolverhampton Wanderers|Burnley|Molineux Stadium|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Birmingham City|Lincoln City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Blackburn Rovers|Swansea City|Ewood Park|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Bristol City|Bolton Wanderers|Ashton Gate Stadium|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Cardiff City|Wolverhampton Wanderers|Cardiff City Stadium|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Charlton Athletic|Middlesbrough|The Valley|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Derby County|Millwall|Pride Park Stadium|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Portsmouth|Burnley|Fratton Park|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Preston North End|Stoke City|Deepdale|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Queens Park Rangers|Southampton|MATRADE Loftus Road|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Watford|Norwich City|Vicarage Road|TIMED\n" +
            "2027-01-23T15:00:00Z|27|West Bromwich Albion|West Ham United|The Hawthorns|TIMED\n" +
            "2027-01-23T15:00:00Z|27|Wrexham|Sheffield United|Racecourse Ground|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Bolton Wanderers|Charlton Athletic|Toughsheet Community Stadium|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Burnley|Queens Park Rangers|Turf Moor|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Lincoln City|Watford|LNER Stadium|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Millwall|Birmingham City|The Den|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Norwich City|Derby County|Carrow Road|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Sheffield United|Preston North End|Bramall Lane|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Southampton|West Bromwich Albion|St. Mary's Stadium|TIMED\n" +
            "2027-01-26T19:45:00Z|28|Stoke City|Blackburn Rovers|bet365 Stadium|TIMED\n" +
            "2027-01-27T19:45:00Z|28|Middlesbrough|Wrexham|Riverside Stadium|TIMED\n" +
            "2027-01-27T19:45:00Z|28|Swansea City|Portsmouth|Swansea.com Stadium|TIMED\n" +
            "2027-01-27T19:45:00Z|28|West Ham United|Cardiff City|London Stadium|TIMED\n" +
            "2027-01-27T19:45:00Z|28|Wolverhampton Wanderers|Bristol City|Molineux Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Bolton Wanderers|Derby County|Toughsheet Community Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Burnley|Cardiff City|Turf Moor|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Lincoln City|Queens Park Rangers|LNER Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Middlesbrough|Watford|Riverside Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Millwall|West Bromwich Albion|The Den|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Norwich City|Bristol City|Carrow Road|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Sheffield United|Charlton Athletic|Bramall Lane|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Southampton|Preston North End|St. Mary's Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Stoke City|Portsmouth|bet365 Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Swansea City|Birmingham City|Swansea.com Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|West Ham United|Blackburn Rovers|London Stadium|TIMED\n" +
            "2027-01-30T15:00:00Z|29|Wolverhampton Wanderers|Wrexham|Molineux Stadium|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Birmingham City|Stoke City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Blackburn Rovers|Burnley|Ewood Park|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Bristol City|Middlesbrough|Ashton Gate Stadium|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Cardiff City|Norwich City|Cardiff City Stadium|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Charlton Athletic|Wolverhampton Wanderers|The Valley|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Derby County|Southampton|Pride Park Stadium|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Portsmouth|Bolton Wanderers|Fratton Park|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Preston North End|West Ham United|Deepdale|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Queens Park Rangers|Millwall|MATRADE Loftus Road|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Watford|Sheffield United|Vicarage Road|TIMED\n" +
            "2027-02-06T15:00:00Z|30|West Bromwich Albion|Swansea City|The Hawthorns|TIMED\n" +
            "2027-02-06T15:00:00Z|30|Wrexham|Lincoln City|Racecourse Ground|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Birmingham City|Derby County|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Bristol City|Southampton|Ashton Gate Stadium|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Burnley|Swansea City|Turf Moor|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Cardiff City|Bolton Wanderers|Cardiff City Stadium|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Lincoln City|Preston North End|LNER Stadium|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Millwall|Blackburn Rovers|The Den|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Norwich City|Middlesbrough|Carrow Road|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Portsmouth|Charlton Athletic|Fratton Park|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Queens Park Rangers|West Bromwich Albion|MATRADE Loftus Road|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Stoke City|Watford|bet365 Stadium|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Wolverhampton Wanderers|Sheffield United|Molineux Stadium|TIMED\n" +
            "2027-02-13T15:00:00Z|31|Wrexham|West Ham United|Racecourse Ground|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Blackburn Rovers|Bristol City|Ewood Park|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Charlton Athletic|Burnley|The Valley|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Derby County|Queens Park Rangers|Pride Park Stadium|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Preston North End|Birmingham City|Deepdale|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Sheffield United|Portsmouth|Bramall Lane|TIMED\n" +
            "2027-02-16T19:45:00Z|32|Watford|Cardiff City|Vicarage Road|TIMED\n" +
            "2027-02-16T19:45:00Z|32|West Bromwich Albion|Wrexham|The Hawthorns|TIMED\n" +
            "2027-02-16T19:45:00Z|32|West Ham United|Lincoln City|London Stadium|TIMED\n" +
            "2027-02-17T19:45:00Z|32|Bolton Wanderers|Wolverhampton Wanderers|Toughsheet Community Stadium|TIMED\n" +
            "2027-02-17T19:45:00Z|32|Middlesbrough|Stoke City|Riverside Stadium|TIMED\n" +
            "2027-02-17T19:45:00Z|32|Southampton|Norwich City|St. Mary's Stadium|TIMED\n" +
            "2027-02-17T19:45:00Z|32|Swansea City|Millwall|Swansea.com Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Blackburn Rovers|Portsmouth|Ewood Park|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Bolton Wanderers|Norwich City|Toughsheet Community Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Charlton Athletic|Cardiff City|The Valley|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Derby County|Burnley|Pride Park Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Middlesbrough|Birmingham City|Riverside Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Preston North End|Queens Park Rangers|Deepdale|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Sheffield United|Stoke City|Bramall Lane|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Southampton|Wrexham|St. Mary's Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Swansea City|Lincoln City|Swansea.com Stadium|TIMED\n" +
            "2027-02-20T15:00:00Z|33|Watford|Bristol City|Vicarage Road|TIMED\n" +
            "2027-02-20T15:00:00Z|33|West Bromwich Albion|Wolverhampton Wanderers|The Hawthorns|TIMED\n" +
            "2027-02-20T15:00:00Z|33|West Ham United|Millwall|London Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Birmingham City|West Bromwich Albion|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Bristol City|Charlton Athletic|Ashton Gate Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Burnley|Watford|Turf Moor|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Cardiff City|Blackburn Rovers|Cardiff City Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Lincoln City|Sheffield United|LNER Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Millwall|Preston North End|The Den|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Norwich City|Swansea City|Carrow Road|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Portsmouth|Southampton|Fratton Park|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Queens Park Rangers|West Ham United|MATRADE Loftus Road|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Stoke City|Bolton Wanderers|bet365 Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Wolverhampton Wanderers|Middlesbrough|Molineux Stadium|TIMED\n" +
            "2027-02-27T15:00:00Z|34|Wrexham|Derby County|Racecourse Ground|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Bolton Wanderers|Queens Park Rangers|Toughsheet Community Stadium|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Bristol City|Birmingham City|Ashton Gate Stadium|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Burnley|West Bromwich Albion|Turf Moor|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Cardiff City|Derby County|Cardiff City Stadium|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Charlton Athletic|West Ham United|The Valley|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Middlesbrough|Blackburn Rovers|Riverside Stadium|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Norwich City|Millwall|Carrow Road|TIMED\n" +
            "2027-03-02T19:45:00Z|35|Watford|Wrexham|Vicarage Road|TIMED\n" +
            "2027-03-03T19:45:00Z|35|Portsmouth|Lincoln City|Fratton Park|TIMED\n" +
            "2027-03-03T19:45:00Z|35|Sheffield United|Swansea City|Bramall Lane|TIMED\n" +
            "2027-03-03T19:45:00Z|35|Stoke City|Southampton|bet365 Stadium|TIMED\n" +
            "2027-03-03T19:45:00Z|35|Wolverhampton Wanderers|Preston North End|Molineux Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Birmingham City|Sheffield United|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Blackburn Rovers|Wolverhampton Wanderers|Ewood Park|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Derby County|Charlton Athletic|Pride Park Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Lincoln City|Middlesbrough|LNER Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Millwall|Bristol City|The Den|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Preston North End|Bolton Wanderers|Deepdale|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Queens Park Rangers|Portsmouth|MATRADE Loftus Road|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Southampton|Watford|St. Mary's Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Swansea City|Stoke City|Swansea.com Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|West Bromwich Albion|Norwich City|The Hawthorns|TIMED\n" +
            "2027-03-06T15:00:00Z|36|West Ham United|Burnley|London Stadium|TIMED\n" +
            "2027-03-06T15:00:00Z|36|Wrexham|Cardiff City|Racecourse Ground|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Bolton Wanderers|Birmingham City|Toughsheet Community Stadium|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Bristol City|West Bromwich Albion|Ashton Gate Stadium|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Burnley|Millwall|Turf Moor|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Cardiff City|Swansea City|Cardiff City Stadium|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Charlton Athletic|Blackburn Rovers|The Valley|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Middlesbrough|Southampton|Riverside Stadium|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Norwich City|Preston North End|Carrow Road|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Portsmouth|Wrexham|Fratton Park|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Sheffield United|Queens Park Rangers|Bramall Lane|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Stoke City|West Ham United|bet365 Stadium|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Watford|Derby County|Vicarage Road|TIMED\n" +
            "2027-03-13T15:00:00Z|37|Wolverhampton Wanderers|Lincoln City|Molineux Stadium|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Derby County|Middlesbrough|Pride Park Stadium|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Lincoln City|Cardiff City|LNER Stadium|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Preston North End|Burnley|Deepdale|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Queens Park Rangers|Stoke City|MATRADE Loftus Road|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Southampton|Wolverhampton Wanderers|St. Mary's Stadium|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Swansea City|Bristol City|Swansea.com Stadium|TIMED\n" +
            "2027-03-16T19:45:00Z|38|West Bromwich Albion|Portsmouth|The Hawthorns|TIMED\n" +
            "2027-03-16T19:45:00Z|38|Wrexham|Norwich City|Racecourse Ground|TIMED\n" +
            "2027-03-17T19:45:00Z|38|Birmingham City|Charlton Athletic|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-03-17T19:45:00Z|38|Blackburn Rovers|Bolton Wanderers|Ewood Park|TIMED\n" +
            "2027-03-17T19:45:00Z|38|Millwall|Watford|The Den|TIMED\n" +
            "2027-03-17T19:45:00Z|38|West Ham United|Sheffield United|London Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Birmingham City|Blackburn Rovers|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Bristol City|Queens Park Rangers|Ashton Gate Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Burnley|Bolton Wanderers|Turf Moor|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Derby County|Preston North End|Pride Park Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Middlesbrough|Sheffield United|Riverside Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Millwall|Cardiff City|The Den|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Norwich City|West Ham United|Carrow Road|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Southampton|Charlton Athletic|St. Mary's Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Swansea City|Wolverhampton Wanderers|Swansea.com Stadium|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Watford|Portsmouth|Vicarage Road|TIMED\n" +
            "2027-03-20T15:00:00Z|39|West Bromwich Albion|Lincoln City|The Hawthorns|TIMED\n" +
            "2027-03-20T15:00:00Z|39|Wrexham|Stoke City|Racecourse Ground|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Blackburn Rovers|Southampton|Ewood Park|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Bolton Wanderers|Watford|Toughsheet Community Stadium|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Cardiff City|Bristol City|Cardiff City Stadium|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Charlton Athletic|Millwall|The Valley|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Lincoln City|Derby County|LNER Stadium|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Portsmouth|Middlesbrough|Fratton Park|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Preston North End|Swansea City|Deepdale|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Queens Park Rangers|Wrexham|MATRADE Loftus Road|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Sheffield United|West Bromwich Albion|Bramall Lane|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Stoke City|Burnley|bet365 Stadium|TIMED\n" +
            "2027-04-03T14:00:00Z|40|West Ham United|Birmingham City|London Stadium|TIMED\n" +
            "2027-04-03T14:00:00Z|40|Wolverhampton Wanderers|Norwich City|Molineux Stadium|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Burnley|Wrexham|Turf Moor|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Lincoln City|Bristol City|LNER Stadium|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Millwall|Middlesbrough|The Den|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Portsmouth|Wolverhampton Wanderers|Fratton Park|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Queens Park Rangers|Charlton Athletic|MATRADE Loftus Road|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Stoke City|Cardiff City|bet365 Stadium|TIMED\n" +
            "2027-04-06T18:45:00Z|41|Swansea City|Southampton|Swansea.com Stadium|TIMED\n" +
            "2027-04-06T18:45:00Z|41|West Ham United|Bolton Wanderers|London Stadium|TIMED\n" +
            "2027-04-07T18:45:00Z|41|Birmingham City|Norwich City|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-04-07T18:45:00Z|41|Preston North End|Watford|Deepdale|TIMED\n" +
            "2027-04-07T18:45:00Z|41|Sheffield United|Blackburn Rovers|Bramall Lane|TIMED\n" +
            "2027-04-07T18:45:00Z|41|West Bromwich Albion|Derby County|The Hawthorns|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Blackburn Rovers|Preston North End|Ewood Park|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Bolton Wanderers|Millwall|Toughsheet Community Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Bristol City|Burnley|Ashton Gate Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Cardiff City|Portsmouth|Cardiff City Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Charlton Athletic|Stoke City|The Valley|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Derby County|West Ham United|Pride Park Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Middlesbrough|Queens Park Rangers|Riverside Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Norwich City|Sheffield United|Carrow Road|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Southampton|Lincoln City|St. Mary's Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Watford|West Bromwich Albion|Vicarage Road|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Wolverhampton Wanderers|Birmingham City|Molineux Stadium|TIMED\n" +
            "2027-04-10T14:00:00Z|42|Wrexham|Swansea City|Racecourse Ground|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Birmingham City|Wrexham|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Burnley|Norwich City|Turf Moor|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Lincoln City|Bolton Wanderers|LNER Stadium|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Millwall|Southampton|The Den|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Portsmouth|Bristol City|Fratton Park|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Preston North End|Charlton Athletic|Deepdale|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Queens Park Rangers|Blackburn Rovers|MATRADE Loftus Road|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Sheffield United|Cardiff City|Bramall Lane|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Stoke City|Wolverhampton Wanderers|bet365 Stadium|TIMED\n" +
            "2027-04-17T14:00:00Z|43|Swansea City|Derby County|Swansea.com Stadium|TIMED\n" +
            "2027-04-17T14:00:00Z|43|West Bromwich Albion|Middlesbrough|The Hawthorns|TIMED\n" +
            "2027-04-17T14:00:00Z|43|West Ham United|Watford|London Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Bolton Wanderers|Sheffield United|Toughsheet Community Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Charlton Athletic|West Bromwich Albion|The Valley|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Derby County|Portsmouth|Pride Park Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Middlesbrough|Burnley|Riverside Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Norwich City|Stoke City|Carrow Road|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Southampton|Birmingham City|St. Mary's Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Wolverhampton Wanderers|West Ham United|Molineux Stadium|TIMED\n" +
            "2027-04-20T18:45:00Z|44|Wrexham|Millwall|Racecourse Ground|TIMED\n" +
            "2027-04-21T18:45:00Z|44|Blackburn Rovers|Lincoln City|Ewood Park|TIMED\n" +
            "2027-04-21T18:45:00Z|44|Bristol City|Preston North End|Ashton Gate Stadium|TIMED\n" +
            "2027-04-21T18:45:00Z|44|Cardiff City|Queens Park Rangers|Cardiff City Stadium|TIMED\n" +
            "2027-04-21T18:45:00Z|44|Watford|Swansea City|Vicarage Road|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Bolton Wanderers|Swansea City|Toughsheet Community Stadium|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Bristol City|Derby County|Ashton Gate Stadium|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Burnley|Southampton|Turf Moor|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Cardiff City|West Bromwich Albion|Cardiff City Stadium|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Charlton Athletic|Wrexham|The Valley|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Middlesbrough|West Ham United|Riverside Stadium|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Norwich City|Blackburn Rovers|Carrow Road|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Portsmouth|Preston North End|Fratton Park|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Sheffield United|Millwall|Bramall Lane|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Stoke City|Lincoln City|bet365 Stadium|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Watford|Birmingham City|Vicarage Road|TIMED\n" +
            "2027-04-24T14:00:00Z|45|Wolverhampton Wanderers|Queens Park Rangers|Molineux Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Birmingham City|Burnley|St. Andrew's @ Knighthead Park|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Blackburn Rovers|Watford|Ewood Park|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Derby County|Wolverhampton Wanderers|Pride Park Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Lincoln City|Charlton Athletic|LNER Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Millwall|Stoke City|The Den|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Preston North End|Cardiff City|Deepdale|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Queens Park Rangers|Norwich City|MATRADE Loftus Road|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Southampton|Sheffield United|St. Mary's Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Swansea City|Middlesbrough|Swansea.com Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|West Bromwich Albion|Bolton Wanderers|The Hawthorns|TIMED\n" +
            "2027-05-01T11:30:00Z|46|West Ham United|Portsmouth|London Stadium|TIMED\n" +
            "2027-05-01T11:30:00Z|46|Wrexham|Bristol City|Racecourse Ground|TIMED";

    private static final Map<String, String> TLA = new LinkedHashMap<String, String>();
    private static final Map<String, String> CRESTS = new LinkedHashMap<String, String>();
    static {
        TLA.put("Birmingham City", "BIR");
        TLA.put("Blackburn Rovers", "BLA");
        TLA.put("Bolton Wanderers", "BOL");
        TLA.put("Bristol City", "BRI");
        TLA.put("Burnley", "BUR");
        TLA.put("Cardiff City", "CAR");
        TLA.put("Charlton Athletic", "CHA");
        TLA.put("Derby County", "DER");
        TLA.put("Lincoln City", "LIN");
        TLA.put("Middlesbrough", "MID");
        TLA.put("Millwall", "MIL");
        TLA.put("Norwich City", "NOR");
        TLA.put("Portsmouth", "POR");
        TLA.put("Preston North End", "PNE");
        TLA.put("Queens Park Rangers", "QPR");
        TLA.put("Sheffield United", "SHE");
        TLA.put("Southampton", "SOU");
        TLA.put("Stoke City", "STK");
        TLA.put("Swansea City", "SWA");
        TLA.put("Watford", "WAT");
        TLA.put("West Bromwich Albion", "WBA");
        TLA.put("West Ham United", "WHU");
        TLA.put("Wolverhampton Wanderers", "WOL");
        TLA.put("Wrexham", "WRE");
        CRESTS.put("Birmingham City", "https://crests.football-data.org/332.png");
        CRESTS.put("Blackburn Rovers", "https://crests.football-data.org/59.png");
        CRESTS.put("Bolton Wanderers", "https://crests.football-data.org/60.png");
        CRESTS.put("Bristol City", "https://crests.football-data.org/387.png");
        CRESTS.put("Burnley", "https://crests.football-data.org/328.png");
        CRESTS.put("Cardiff City", "https://crests.football-data.org/715.png");
        CRESTS.put("Charlton Athletic", "https://crests.football-data.org/348.png");
        CRESTS.put("Derby County", "https://crests.football-data.org/342.png");
        CRESTS.put("Lincoln City", "https://crests.football-data.org/1126.png");
        CRESTS.put("Middlesbrough", "https://crests.football-data.org/343.png");
        CRESTS.put("Millwall", "https://crests.football-data.org/384.png");
        CRESTS.put("Norwich City", "https://crests.football-data.org/68.png");
        CRESTS.put("Portsmouth", "https://crests.football-data.org/325.png");
        CRESTS.put("Preston North End", "https://crests.football-data.org/1081.png");
        CRESTS.put("Queens Park Rangers", "https://crests.football-data.org/69.png");
        CRESTS.put("Sheffield United", "https://crests.football-data.org/356.png");
        CRESTS.put("Southampton", "https://crests.football-data.org/340.png");
        CRESTS.put("Stoke City", "https://crests.football-data.org/70.png");
        CRESTS.put("Swansea City", "https://crests.football-data.org/72.png");
        CRESTS.put("Watford", "https://crests.football-data.org/346.png");
        CRESTS.put("West Bromwich Albion", "https://crests.football-data.org/74.png");
        CRESTS.put("West Ham United", "https://crests.football-data.org/563.png");
        CRESTS.put("Wolverhampton Wanderers", "https://crests.football-data.org/76.png");
        CRESTS.put("Wrexham", "https://crests.football-data.org/404.png");
    }

    public static void mergeInto(JSONObject root) {
        if (root == null) return;
        try {
            Map<String, JSONObject> online = collectCurrentSeasonRows(root);
            JSONArray fixtures = officialFixtures(online);

            root.put("matches", copyWithoutChampionship(root.optJSONArray("matches")));
            root.put("live", copyWithoutChampionship(root.optJSONArray("live")));
            root.put("finished", copyWithoutChampionship(root.optJSONArray("finished")));
            root.put("upcoming", copyWithoutChampionship(root.optJSONArray("upcoming")));

            JSONArray matches = root.optJSONArray("matches");
            JSONArray live = root.optJSONArray("live");
            JSONArray finished = root.optJSONArray("finished");
            JSONArray upcoming = root.optJSONArray("upcoming");

            for (int i = 0; i < fixtures.length(); i++) {
                JSONObject fixture = fixtures.getJSONObject(i);
                matches.put(new JSONObject(fixture.toString()));
                String status = fixture.optString("status", "SCHEDULED").toUpperCase(Locale.US);
                if (isLive(status)) live.put(new JSONObject(fixture.toString()));
                else if (isFinished(status)) finished.put(new JSONObject(fixture.toString()));
                else upcoming.put(new JSONObject(fixture.toString()));
            }

            mergeTeams(root);
            removeOutdatedStandings(root);
            addSourceMetadata(root, fixtures.length());
        } catch (Exception ignored) {
            // Keep every other competition usable if this bundled fallback is
            // malformed by a future manual edit.
        }
    }

    private static Map<String, JSONObject> collectCurrentSeasonRows(JSONObject root) {
        Map<String, JSONObject> result = new HashMap<String, JSONObject>();
        String[] feeds = {"matches", "upcoming", "live", "finished"};
        for (String feed : feeds) {
            JSONArray source = root.optJSONArray(feed);
            if (source == null) continue;
            for (int i = 0; i < source.length(); i++) {
                JSONObject row = source.optJSONObject(i);
                if (!isCurrentSeasonChampionship(row)) continue;
                String key = matchKey(row);
                if (key.length() == 0) continue;
                JSONObject existing = result.get(key);
                if (existing == null || rowRichness(row) >= rowRichness(existing)) {
                    try { result.put(key, new JSONObject(row.toString())); } catch (Exception ignored) {}
                }
            }
        }
        return result;
    }

    private static JSONArray officialFixtures(Map<String, JSONObject> online) throws Exception {
        JSONArray result = new JSONArray();
        String[] rows = DATA.split("\n");
        int index = 0;
        for (String row : rows) {
            String[] parts = row.split("\\|", -1);
            if (parts.length != 6) continue;
            String date = parts[0].trim();
            int matchday;
            try { matchday = Integer.parseInt(parts[1].trim()); } catch (Exception ignored) { continue; }
            String home = parts[2].trim();
            String away = parts[3].trim();
            String venue = parts[4].trim();
            String status = parts[5].trim();
            if (date.length() < 10 || home.length() == 0 || away.length() == 0) continue;

            JSONObject fixture = new JSONObject();
            fixture.put("id", "ELC-2026-" + matchday + "-" + (++index));
            fixture.put("competition", competitionObject());
            fixture.put("competitionName", COMPETITION_NAME);
            fixture.put("competitionCode", COMPETITION_CODE);
            fixture.put("home", home);
            fixture.put("away", away);
            fixture.put("homeTeam", teamObject(home));
            fixture.put("awayTeam", teamObject(away));
            fixture.put("utcDate", date);
            fixture.put("date", date);
            fixture.put("status", status.length() == 0 ? "TIMED" : status);
            fixture.put("matchday", matchday);
            fixture.put("roundNumber", matchday);
            fixture.put("roundName", "Kolo " + matchday);
            fixture.put("stage", "Kolo " + matchday);
            fixture.put("group", "");
            fixture.put("venue", venue);
            fixture.put("dataProvider", "EFL Championship verified fixture list");
            fixture.put("season", SEASON);

            JSONObject richer = online.get(matchKey(fixture));
            if (richer != null) mergeOnlineRow(fixture, richer);
            result.put(fixture);
        }
        return result;
    }

    private static void mergeOnlineRow(JSONObject target, JSONObject source) {
        try {
            String[] keys = {
                    "status", "minute", "matchMinute", "elapsed", "venue", "attendance",
                    "score", "scores", "result", "homeGoals", "awayGoals", "homeScore", "awayScore",
                    "events", "goals", "bookings", "substitutions", "referees"
            };
            for (String key : keys) if (source.has(key) && !source.isNull(key)) target.put(key, source.opt(key));
            JSONObject home = source.optJSONObject("homeTeam");
            JSONObject away = source.optJSONObject("awayTeam");
            if (home != null) target.put("homeTeam", mergeTeam(target.optJSONObject("homeTeam"), home));
            if (away != null) target.put("awayTeam", mergeTeam(target.optJSONObject("awayTeam"), away));
            String sourceDate = source.optString("utcDate", source.optString("date", "")).trim();
            if (sourceDate.length() >= 10) { target.put("utcDate", sourceDate); target.put("date", sourceDate); }
            target.put("dataProvider", source.optString("dataProvider", "Connected Championship source"));
        } catch (Exception ignored) {}
    }

    private static JSONObject mergeTeam(JSONObject fallback, JSONObject richer) throws Exception {
        JSONObject out = fallback == null ? new JSONObject() : new JSONObject(fallback.toString());
        String[] keys = {"name", "shortName", "tla", "crest", "emblem", "logo", "area", "venue"};
        for (String key : keys) if (richer.has(key) && !richer.isNull(key)) {
            String value = String.valueOf(richer.opt(key)).trim();
            if (value.length() > 0) out.put(key, richer.opt(key));
        }
        String name = out.optString("name", out.optString("shortName", ""));
        if (out.optString("crest", "").trim().length() == 0 && CRESTS.containsKey(name)) out.put("crest", CRESTS.get(name));
        return out;
    }

    private static JSONArray copyWithoutChampionship(JSONArray source) {
        JSONArray result = new JSONArray();
        if (source == null) return result;
        for (int i = 0; i < source.length(); i++) {
            JSONObject row = source.optJSONObject(i);
            if (row == null || isChampionship(row)) continue;
            try { result.put(new JSONObject(row.toString())); } catch (Exception ignored) {}
        }
        return result;
    }

    private static boolean isCurrentSeasonChampionship(JSONObject row) {
        if (!isChampionship(row)) return false;
        String date = row.optString("utcDate", row.optString("date", ""));
        if (date.length() < 10) return false;
        String day = date.substring(0, 10);
        return day.compareTo(FIRST_DATE) >= 0 && day.compareTo(LAST_DATE) <= 0;
    }

    private static boolean isChampionship(JSONObject row) {
        if (row == null) return false;
        Object raw = row.opt("competition");
        StringBuilder value = new StringBuilder();
        if (raw instanceof JSONObject) {
            JSONObject competition = (JSONObject) raw;
            value.append(competition.optString("code", "")).append(' ')
                    .append(competition.optString("name", ""));
        } else if (raw != null) value.append(String.valueOf(raw));
        value.append(' ').append(row.optString("competitionCode", ""))
                .append(' ').append(row.optString("competitionName", ""));
        String normalized = normalize(value.toString());
        return normalized.equals("elc") || normalized.contains("championship");
    }

    private static String matchKey(JSONObject row) {
        if (row == null) return "";
        String home = teamName(row, true);
        String away = teamName(row, false);
        if (home.length() == 0 || away.length() == 0) return "";
        return clubKey(home) + "|" + clubKey(away);
    }

    private static String teamName(JSONObject row, boolean home) {
        String value = row.optString(home ? "home" : "away", "").trim();
        if (value.length() > 0) return value;
        JSONObject team = row.optJSONObject(home ? "homeTeam" : "awayTeam");
        if (team == null) return "";
        return team.optString("name", team.optString("shortName", team.optString("tla", ""))).trim();
    }

    private static int rowRichness(JSONObject row) {
        if (row == null) return 0;
        int score = 0;
        String status = row.optString("status", "").toUpperCase(Locale.US);
        if (isFinished(status)) score += 30;
        else if (isLive(status)) score += 25;
        else if (status.contains("TIMED")) score += 8;
        if (row.has("score") || row.has("homeGoals") || row.has("homeScore")) score += 12;
        if (row.has("events") || row.has("goals")) score += 8;
        if (row.optString("venue", "").trim().length() > 0) score += 4;
        if (row.optJSONObject("homeTeam") != null) score += 2;
        if (row.optJSONObject("awayTeam") != null) score += 2;
        return score;
    }

    private static boolean isLive(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("LIVE") || value.contains("IN_PLAY") || value.contains("IN PROGRESS") ||
                value.equals("PAUSED") || value.equals("HALF_TIME") || value.equals("HT");
    }

    private static boolean isFinished(String status) {
        String value = status == null ? "" : status.toUpperCase(Locale.US);
        return value.contains("FINISHED") || value.equals("FT") || value.contains("FINAL") || value.equals("AWARDED");
    }

    private static JSONObject competitionObject() throws Exception {
        JSONObject competition = new JSONObject();
        competition.put("code", COMPETITION_CODE);
        competition.put("name", COMPETITION_NAME);
        return competition;
    }

    private static JSONObject teamObject(String name) throws Exception {
        JSONObject team = new JSONObject();
        team.put("name", name);
        team.put("shortName", name);
        team.put("tla", TLA.containsKey(name) ? TLA.get(name) : "");
        team.put("area", isWelshClub(name) ? "Wales" : "England");
        if (CRESTS.containsKey(name)) team.put("crest", CRESTS.get(name));
        return team;
    }

    private static boolean isWelshClub(String name) {
        return "Cardiff City".equals(name) || "Swansea City".equals(name) || "Wrexham".equals(name);
    }

    private static void mergeTeams(JSONObject root) throws Exception {
        JSONArray source = root.optJSONArray("teams");
        JSONArray teams = source == null ? new JSONArray() : new JSONArray(source.toString());
        Map<String, Integer> positions = new HashMap<String, Integer>();
        for (int i = 0; i < teams.length(); i++) {
            JSONObject team = teams.optJSONObject(i);
            if (team == null) continue;
            String name = team.optString("name", team.optString("shortName", team.optString("tla", "")));
            if (name.length() > 0) positions.put(clubKey(name), i);
        }
        for (String name : TLA.keySet()) {
            JSONObject fallback = teamObject(name);
            Integer position = positions.get(clubKey(name));
            if (position == null) teams.put(fallback);
            else {
                JSONObject richer = teams.optJSONObject(position);
                teams.put(position, mergeTeam(fallback, richer == null ? new JSONObject() : richer));
            }
        }
        root.put("teams", teams);
    }

    private static void removeOutdatedStandings(JSONObject root) {
        JSONObject all = root.optJSONObject("standings");
        if (all == null) return;
        JSONObject entry = all.optJSONObject(COMPETITION_CODE);
        if (entry == null) return;
        JSONObject season = entry.optJSONObject("season");
        String start = season == null ? "" : season.optString("startDate", "");
        String end = season == null ? "" : season.optString("endDate", "");
        boolean current = start.startsWith("2026") && end.startsWith("2027");
        if (!current) all.remove(COMPETITION_CODE);
    }

    private static void addSourceMetadata(JSONObject root, int matchCount) throws Exception {
        JSONObject sources = root.optJSONObject("sources");
        if (sources == null) { sources = new JSONObject(); root.put("sources", sources); }
        JSONObject championship = sources.optJSONObject(COMPETITION_CODE);
        if (championship == null) championship = new JSONObject();
        championship.put("status", "connected");
        championship.put("provider", "EFL Championship verified fixture list + connected live source");
        championship.put("season", SEASON);
        championship.put("matchCount", matchCount);
        championship.put("teamCount", TLA.size());
        championship.put("roundCount", 46);
        sources.put(COMPETITION_CODE, championship);
    }

    private static String clubKey(String value) {
        String key = normalize(value);
        if (key.endsWith("associationfootballclub")) key = key.substring(0, key.length() - "associationfootballclub".length());
        else if (key.endsWith("footballclub")) key = key.substring(0, key.length() - "footballclub".length());
        else if (key.endsWith("afc")) key = key.substring(0, key.length() - 3);
        else if (key.endsWith("fc")) key = key.substring(0, key.length() - 2);
        return key;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value.toLowerCase(Locale.US), Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^a-z0-9]+", "");
    }

    private Championship2627Data() {}
}
