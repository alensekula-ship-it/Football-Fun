# Football Fun release hardening — build 311

# Keep only Android entry-point constructors that are instantiated by the framework.
-keep class com.asappfactory.footballfun.SplashActivity { public <init>(); }
-keep class com.asappfactory.footballfun.MainActivity { public <init>(); }
-keep class com.asappfactory.footballfun.notifications.MatchReminderReceiver { public <init>(); }
-keep class com.asappfactory.footballfun.notifications.ReminderRestoreReceiver { public <init>(); }

# Required metadata for Android/Google libraries that use generic signatures/annotations.
-keepattributes Signature,*Annotation*,InnerClasses,EnclosingMethod

# Keep enum helpers if accessed reflectively.
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Do not expose original source file names in release stack traces.
-renamesourcefileattribute SourceFile
