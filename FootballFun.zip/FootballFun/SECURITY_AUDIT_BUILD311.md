# Football Fun v5.68.70 / build 311 — security audit

Baseline: confirmed stable v5.68.69 / build 310.

Fixed:
- R8 release optimization/obfuscation enabled.
- Resource shrinking enabled.
- Release explicitly non-debuggable.
- Signing passwords removed from source.
- Keystore removed from distributable source.
- Release signing moved to protected environment/CI secrets and fails closed.
- Local backup/device-transfer exclusions strengthened.
- Legacy local `proUnlocked` entitlement path removed.
- Local Billing cache cannot grant Pro after process restart.
- Release Pro access requires Google Play entitlement.
- Existing HTTPS-only manifest policy preserved.
- Existing exported-component surface preserved: launcher activity only.

Important residual limitations:
- Android bytecode can never be made impossible to reverse engineer; R8 makes it
  substantially harder but is not absolute protection.
- The current authoritative live-data endpoint is a public GitHub raw URL. It can
  be discovered from network traffic. A private authenticated backend/proxy is
  required if future paid provider data must be protected.
- Strongest subscription security requires server-side purchase-token verification
  with Google Play Developer APIs before granting Pro, plus subscription lifecycle
  handling. Client-only Billing remains patchable by a determined attacker.
- Play Integrity is strongest when its token is verified on a server.

Play Console production checklist:
- Keep Play App Signing enabled.
- Publish AAB, not an externally distributed production APK.
- Enable Protected with Play / Automatic protection / installer check.
- Enable anti-tamper/device protection if Google makes those options available.
- Never publish an unprotected production build outside Google Play.
