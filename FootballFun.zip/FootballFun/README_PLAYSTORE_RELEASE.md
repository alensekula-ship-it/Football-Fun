# Football Fun — Play Store Release Pack

Stable application base: v5.67.5.

Free access includes competition selection, fixtures/results, match details, the player directory and player profiles. Pro routes are locked behind a durable access state prepared for verified Google Play Billing. This test package does not charge users.

Before public release: connect Google Play Billing, verify purchase restoration, publish the privacy policy, complete Data safety, review rights for club badges/trademarks, build a signed AAB and complete internal/closed testing.

Required visible attribution: `Football data provided by the Football-Data.org API`.
